define(["exports"],(function(e){"use strict";function n(e,n){return null!=e?e:n}n.EMPTY_OBJECT=Object.freeze({}),e.defaultValue=n,e.defined=function(e){return null!=e}}));
