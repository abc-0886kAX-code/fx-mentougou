const __$_require_f5a5ef2e__ = "/mp4/login-video.mp4";
export {
  __$_require_f5a5ef2e__ as _
};
