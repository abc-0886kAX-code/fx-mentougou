import { v as defineComponent, j as computed, u as unref, x as onMounted, A as onBeforeUnmount, z as elementUi_common, r as ref$1 } from "./element-ui-a9609798.js";
import { t as transFormData, g as get, n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useService } from "./Application-7fa37401.js";
import { u as useWatchRevert } from "./useWatchRevert-58689033.js";
const Address = "/realData/getAddvcditem";
const Method = "POST";
const ModifyAddress = "/login";
const ModifyMethod = "POST";
const DelAddress = "/login";
const DelMethod = "POST";
const msg = "success";
const total = 2;
const code = 200;
const data = [
  {
    id: "af8a7cb0254b48c4a9acbe19486e9055",
    name: "\u5F20\u4E09",
    username: "zhangsan",
    role: "\u7CFB\u7EDF\u7BA1\u7406\u5458",
    remark: "\u5317\u4EAC\u6C34\u52A1\u5C40"
  },
  {
    id: "ac2cceb17bf3403096825c70d385d3fe",
    name: "\u674E\u56DB",
    username: "lisi",
    role: "\u666E\u901A\u7528\u6237",
    remark: "\u95E8\u5934\u6C9F\u6C34\u52A1\u5C40"
  }
];
const SystemManage = {
  msg,
  total,
  code,
  data
};
const service$1 = useService();
function transResponse$1(response) {
  const data2 = get(SystemManage, "data", []);
  return { data: data2 };
}
const SystemManage_Server = service$1.define({
  url: Address,
  method: Method
});
function SystemManage_Obtain(props) {
  SystemManage_Server.server.config.bind("data", transFormData(props));
  return SystemManage_Server.obtain({ transResponse: transResponse$1 });
}
const service = useService();
function transResponse(response) {
  const data2 = get(response, "data", {});
  return data2;
}
const Del_Server = service.define({
  url: DelAddress,
  method: DelMethod
});
function Del_Obtain(props) {
  Del_Server.server.config.bind("data", transFormData(props));
  return Del_Server.obtain({ transResponse });
}
const systemManagementDefault_vue_vue_type_style_index_0_scoped_21f108af_lang = "";
const _sfc_main$1 = {
  __name: "system-management-default",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "40%",
      height: "30vh",
      template: defineComponent(() => __vitePreload(() => import("./dialog-system-management-ef871788.js"), true ? ["assets/js/dialog-system-management-ef871788.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/useDialog-4005c8b0.js","assets/js/Application-7fa37401.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/dialog-system-management-4bd37ddb.css"] : void 0)),
      afterClose: executeQuery
    });
    const { loading } = SystemManage_Server.server;
    const tableData = computed(() => transArray(unref(SystemManage_Server.server.result.source).data, []));
    const tableColumn = [
      {
        prop: "name",
        label: "\u4EBA\u5458\u59D3\u540D",
        align: "center"
      },
      {
        prop: "username",
        label: "\u767B\u5F55\u8D26\u53F7",
        align: "center"
      },
      {
        prop: "role",
        label: "\u89D2\u8272",
        align: "center"
      },
      {
        prop: "remark",
        label: "\u5907\u6CE8",
        align: "center"
      }
    ];
    function handleAdd() {
      popupEntity.setupTitle("\u65B0\u589E");
      popupEntity.show({});
    }
    function handleEdit(rows) {
      popupEntity.setupTitle("\u4FEE\u6539");
      popupEntity.show(rows);
    }
    async function handleDel({ id }) {
      if (!id)
        return;
      const message = await elementUi_common.exports.MessageBox.confirm("\u64CD\u4F5C\u5C06\u6C38\u4E45\u5220\u9664\u8BE5\u6761\u4FE1\u606F, \u662F\u5426\u7EE7\u7EED?", "\u63D0\u793A", {
        confirmButtonText: "\u786E\u5B9A",
        cancelButtonText: "\u53D6\u6D88",
        type: "warning"
      }).catch((err) => err);
      if ("confirm" === message) {
        const data2 = await Del_Obtain({ id });
        if (data2.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u5220\u9664\u6210\u529F!"
          });
          executeQuery();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data2.msg
          });
        }
      }
    }
    async function executeQuery() {
      await SystemManage_Obtain();
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, loading, tableData, tableColumn, handleAdd, handleEdit, handleDel, executeQuery, loadStyle, transArray, Notification: elementUi_common.exports.Notification, MessageBox: elementUi_common.exports.MessageBox, usePopup, SystemManage_Obtain, SystemManage_Server, Del_Server, Del_Obtain };
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "system-management-default", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "60", "align": "center" }, scopedSlots: _vm._u([{ key: "header", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "success" }, on: { "click": _setup.handleAdd } }, [_vm._v("\u65B0\u589E")])];
  } }]) }), _c("el-table-column", { attrs: { "label": "\u64CD\u4F5C", "width": "100", "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "warning" }, on: { "click": function($event) {
      return _setup.handleEdit(scope.row);
    } } }, [_vm._v("\u4FEE\u6539")]), _c("el-divider", { attrs: { "direction": "vertical" } }), _c("el-link", { attrs: { "type": "danger" }, on: { "click": function($event) {
      return _setup.handleDel(scope.row);
    } } }, [_vm._v("\u5220\u9664")])];
  } }]) }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "21f108af",
  null,
  null
);
const SystemManagementDefault = __component__$1.exports;
const Menu = {
  defaultID: "e7c011a06efa4db7b8514198dcbafcee",
  menu: [
    {
      id: "e7c011a06efa4db7b8514198dcbafcee",
      label: "\u7CFB\u7EDF\u7BA1\u7406",
      component: SystemManagementDefault,
      render: false,
      fragment: true
    }
  ]
};
const index_vue_vue_type_style_index_0_scoped_0b255276_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const Name = "system-management-menu";
    const { menu, defaultID } = Menu;
    const active = ref$1(defaultID);
    const componentName = ref$1("");
    const setupDefaultActive = () => active.value = defaultID;
    useWatchRevert(Name, {
      setupDriver: setupDefaultActive
    });
    const handlerComponent = (cell) => {
      const { component, revert } = cell;
      componentName.value = component;
      revert && context.emit("onResolve", {
        ...cell,
        type: Name
      });
    };
    const handlerDialog = (cell) => {
    };
    return { __sfc: true, Name, menu, defaultID, active, componentName, setupDefaultActive, handlerComponent, handlerDialog, Menu, useWatchRevert };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("screen-grid-container", { scopedSlots: _vm._u([{ key: "head", fn: function() {
    return [_c("screen-grid-select", { attrs: { "icon": "el-icon-s-help", "active": _setup.active, "menu": _setup.menu, "width": 80 }, on: { "update:active": function($event) {
      _setup.active = $event;
    }, "toComponent": _setup.handlerComponent, "toDialog": _setup.handlerDialog }, scopedSlots: _vm._u([{ key: "default", fn: function(node) {
      return [_c("screen-grid-node", { attrs: { "node": node } })];
    } }]) })];
  }, proxy: true }, { key: "body", fn: function() {
    return [_c(_setup.componentName, { tag: "component" })];
  }, proxy: true }]) });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "0b255276",
  null,
  null
);
const index = __component__.exports;
const index$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index
}, Symbol.toStringTag, { value: "Module" }));
export {
  ModifyAddress as M,
  ModifyMethod as a,
  index$1 as i
};
