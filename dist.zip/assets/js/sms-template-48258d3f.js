import { t as transFormData, g as get, n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { v as defineComponent, j as computed, u as unref, x as onMounted, A as onBeforeUnmount, z as elementUi_common } from "./element-ui-a9609798.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useService } from "./Application-7fa37401.js";
const Address = "/SmsMgr/getSmsMgrList";
const Method = "POST";
const ModifyAddress = "/SmsMgr/SmsMgrSave";
const ModifyMethod = "POST";
const DelAddress = "/SmsMgr/DeleteSmsMgr";
const DelMethod = "GET";
const service$1 = useService();
function transResponse$1(response) {
  const data = get(response, "data.data", []);
  return { data };
}
const SMS_Server = service$1.define({
  url: Address,
  method: Method
});
function SMS_Obtain(props) {
  SMS_Server.server.config.bind("data", transFormData(props));
  return SMS_Server.obtain({ transResponse: transResponse$1 });
}
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Del_Server = service.define({
  url: DelAddress,
  method: DelMethod
});
function Del_Obtain(props) {
  Del_Server.server.config.bind("params", props);
  return Del_Server.obtain({ transResponse });
}
const smsTemplate_vue_vue_type_style_index_0_scoped_0efb8591_lang = "";
const _sfc_main = {
  __name: "sms-template",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "40%",
      height: "40vh",
      template: defineComponent(() => __vitePreload(() => import("./dialog-sms-template-88fd7a74.js"), true ? ["assets/js/dialog-sms-template-88fd7a74.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/Application-7fa37401.js","assets/js/usePopup-500740ad.js","assets/dialog-sms-template-bfde5729.css"] : void 0)),
      afterClose: executeQuery
    });
    const { loading } = SMS_Server.server;
    const tableData = computed(() => transArray(unref(SMS_Server.server.result.source).data, []));
    const tableColumn = [
      {
        prop: "gate",
        label: "\u95F8\u503C",
        align: "center",
        width: 60
      },
      {
        prop: "content",
        label: "\u77ED\u4FE1\u5185\u5BB9",
        align: "center"
      }
    ];
    function handleAdd() {
      popupEntity.setupTitle("\u65B0\u589E");
      popupEntity.show({});
    }
    function handleEdit(rows) {
      popupEntity.setupTitle("\u4FEE\u6539");
      popupEntity.show(rows);
    }
    async function handleDel({ tempid }) {
      if (!tempid)
        return;
      const message = await elementUi_common.exports.MessageBox.confirm("\u64CD\u4F5C\u5C06\u6C38\u4E45\u5220\u9664\u8BE5\u6761\u4FE1\u606F, \u662F\u5426\u7EE7\u7EED?", "\u63D0\u793A", {
        confirmButtonText: "\u786E\u5B9A",
        cancelButtonText: "\u53D6\u6D88",
        type: "warning"
      }).catch((err) => err);
      if ("confirm" === message) {
        const data = await Del_Obtain({ tempid });
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u5220\u9664\u6210\u529F!"
          });
          executeQuery();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      }
    }
    async function executeQuery() {
      await SMS_Obtain();
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, loading, tableData, tableColumn, handleAdd, handleEdit, handleDel, executeQuery, loadStyle, transArray, usePopup, Notification: elementUi_common.exports.Notification, MessageBox: elementUi_common.exports.MessageBox, SMS_Obtain, SMS_Server, Del_Server, Del_Obtain };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "sms-template", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "60", "align": "center" }, scopedSlots: _vm._u([{ key: "header", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "success" }, on: { "click": _setup.handleAdd } }, [_vm._v("\u65B0\u589E")])];
  } }]) }), _c("el-table-column", { attrs: { "label": "\u64CD\u4F5C", "width": "100", "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "warning" }, on: { "click": function($event) {
      return _setup.handleEdit(scope.row);
    } } }, [_vm._v("\u4FEE\u6539")]), _c("el-divider", { attrs: { "direction": "vertical" } }), _c("el-link", { attrs: { "type": "danger" }, on: { "click": function($event) {
      return _setup.handleDel(scope.row);
    } } }, [_vm._v("\u5220\u9664")])];
  } }]) }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "0efb8591",
  null,
  null
);
const smsTemplate = __component__.exports;
const smsTemplate$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: smsTemplate
}, Symbol.toStringTag, { value: "Module" }));
export {
  ModifyAddress as M,
  ModifyMethod as a,
  smsTemplate$1 as s
};
