import { v as defineComponent, j as computed, u as unref, x as onMounted, A as onBeforeUnmount, r as ref$1 } from "./element-ui-a9609798.js";
import { t as transFormData, n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { u as useService } from "./Application-7fa37401.js";
import { u as useMars3d } from "./useMars3D-c560a623.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useWatchRevert } from "./useWatchRevert-58689033.js";
const Address = "/realData/getAddvcditem";
const Method = "POST";
const service = useService();
function transResponse(response) {
  const data = [
    {
      stnm: "\u76D1\u63A7\u70B91",
      position: "\u95E8\u5934\u6C9F",
      visualangle: "\u5357\u5411\u5317",
      state: "\u5728\u7EBF",
      lttd: "32.235899",
      lgtd: "118.359936"
    },
    {
      stnm: "\u76D1\u63A7\u70B92",
      position: "\u95E8\u5934\u6C9F",
      visualangle: "\u4E1C\u5411\u897F",
      state: "\u5728\u7EBF",
      lttd: "32.24471",
      lgtd: "118.37734"
    }
  ];
  return { data };
}
const OverviewSite_Server = service.define({
  url: Address,
  method: Method
});
function OverviewSite_Obtain(props) {
  OverviewSite_Server.server.config.bind("data", transFormData(props));
  return OverviewSite_Server.obtain({ transResponse });
}
const realTimeMonitorDefault_vue_vue_type_style_index_0_scoped_9e429310_lang = "";
const _sfc_main$1 = {
  __name: "real-time-monitor-default",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "60%",
      title: "\u6570\u636E\u603B\u89C8",
      template: defineComponent(() => __vitePreload(() => import("./dialog-real-time-monitor-a50ccb93.js"), true ? ["assets/js/dialog-real-time-monitor-a50ccb93.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/login-video-69570771.js","assets/js/header-video-fd1f6550.js","assets/dialog-real-time-monitor-d752a2a8.css"] : void 0))
    });
    const tableColumn = [
      {
        prop: "stnm",
        label: "\u540D\u79F0",
        align: "center"
      },
      {
        prop: "position",
        label: "\u4F4D\u7F6E",
        align: "center"
      },
      {
        prop: "visualangle",
        label: "\u89C6\u89D2",
        align: "center"
      },
      {
        prop: "state",
        label: "\u72B6\u6001",
        align: "center"
      }
    ];
    const { mapview } = useMars3d();
    const { loading } = OverviewSite_Server.server;
    const tableData = computed(() => transArray(unref(OverviewSite_Server.server.result.source).data, []));
    function handleRow(row) {
      const { lttd, lgtd } = row;
      unref(mapview).flyToPoint(
        {
          lng: lgtd,
          lat: lttd
        },
        {
          radius: 3e3
        }
      );
    }
    function handleClick(row) {
      popupEntity.show(row);
    }
    async function executeQuery() {
      await OverviewSite_Obtain();
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, tableColumn, mapview, loading, tableData, handleRow, handleClick, executeQuery, transArray, loadStyle, OverviewSite_Obtain, OverviewSite_Server, useMars3d, usePopup };
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "real-time-monitor-default" }, [_vm._m(0), _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "real-time-monitor-default-table", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" }, on: { "row-click": _setup.handleRow } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "50", "align": "center" } }), _vm._l(_setup.tableColumn, function(item) {
    return [item.prop === "stnm" ? _c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
      return [_c("el-link", { attrs: { "type": "primary" }, on: { "click": function($event) {
        $event.stopPropagation();
        return _setup.handleClick(scope.row);
      } } }, [_vm._v(_vm._s(scope.row.stnm))])];
    } }], null, true) }) : _c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2)], 1);
};
var _sfc_staticRenderFns$1 = [function() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "real-time-monitor-default-stat" }, [_c("div", { staticClass: "real-time-monitor-default-stat-total" }, [_vm._v("\u76D1\u63A7\u603B\u6570 4")]), _c("div", { staticClass: "real-time-monitor-default-stat-state" }, [_vm._v("\u5728\u7EBF 4 - \u79BB\u7EBF 0")])]);
}];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "9e429310",
  null,
  null
);
const RealTimeMonitorDefault = __component__$1.exports;
const Menu = {
  defaultID: "e7c011a06efa4db7b8514198dcbafcee",
  menu: [
    {
      id: "e7c011a06efa4db7b8514198dcbafcee",
      label: "\u5B9E\u65F6\u76D1\u63A7",
      component: RealTimeMonitorDefault,
      render: false,
      fragment: true
    }
  ]
};
const index_vue_vue_type_style_index_0_scoped_23b80525_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const Name = "real-time-monitor-menu";
    const { menu, defaultID } = Menu;
    const active = ref$1(defaultID);
    const componentName = ref$1("");
    const setupDefaultActive = () => active.value = defaultID;
    useWatchRevert(Name, {
      setupDriver: setupDefaultActive
    });
    const handlerComponent = (cell) => {
      const { component, revert } = cell;
      componentName.value = component;
      revert && context.emit("onResolve", {
        ...cell,
        type: Name
      });
    };
    const handlerDialog = (cell) => {
    };
    return { __sfc: true, Name, menu, defaultID, active, componentName, setupDefaultActive, handlerComponent, handlerDialog, Menu, useWatchRevert };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("screen-grid-container", { scopedSlots: _vm._u([{ key: "head", fn: function() {
    return [_c("screen-grid-select", { attrs: { "icon": "el-icon-s-help", "active": _setup.active, "menu": _setup.menu, "width": 80 }, on: { "update:active": function($event) {
      _setup.active = $event;
    }, "toComponent": _setup.handlerComponent, "toDialog": _setup.handlerDialog }, scopedSlots: _vm._u([{ key: "default", fn: function(node) {
      return [_c("screen-grid-node", { attrs: { "node": node } })];
    } }]) })];
  }, proxy: true }, { key: "body", fn: function() {
    return [_c(_setup.componentName, { tag: "component" })];
  }, proxy: true }]) });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "23b80525",
  null,
  null
);
const index = __component__.exports;
export {
  index as default
};
