import { j as computed, u as unref, r as ref$1, a as reactive, x as onMounted, z as elementUi_common } from "./element-ui-a9609798.js";
import { t as transFormData, g as get, n as normalizeComponent, G as isEmptyObject } from "./index-1ea80670.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { M as ModifyAddress, a as ModifyMethod } from "./index-e5232b3d.js";
import { u as useService } from "./Application-7fa37401.js";
import "./usePopup-500740ad.js";
import "./useWatchRevert-58689033.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Modify_Server = service.define({
  url: ModifyAddress,
  method: ModifyMethod
});
function Modify_Obtain(props) {
  Modify_Server.server.config.bind("data", transFormData(props));
  return Modify_Server.obtain({ transResponse });
}
const dialogSystemManagement_vue_vue_type_style_index_0_scoped_981d0be4_lang = "";
const _sfc_main = {
  __name: "dialog-system-management",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = Modify_Server.server;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const ModifyForm = ref$1();
    const form = reactive({
      name: "",
      username: "",
      id: "",
      role: "",
      remark: ""
    });
    const rules = {
      name: [
        {
          required: true,
          message: "\u4EBA\u5458\u59D3\u540D\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      username: [
        {
          required: true,
          message: "\u767B\u5F55\u8D26\u53F7\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      role: [
        {
          required: true,
          message: "\u89D2\u8272\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function onModify() {
      unref(ModifyForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await Modify_Obtain(unref(form));
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u4FDD\u5B58\u6210\u529F!"
          });
          dialog.destroy();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    function tomapper(body) {
      form.name = get(body, "name", "");
      form.username = get(body, "username", "");
      form.id = get(body, "id", "");
      form.role = get(body, "role", "");
      form.remark = get(body, "remark", "");
    }
    onMounted(() => {
      tomapper(unref(config));
    });
    return { __sfc: true, props, loading, dialog, config, ModifyForm, form, rules, onModify, tomapper, isEmptyObject, useDialog, Modify_Server, Modify_Obtain, Notification: elementUi_common.exports.Notification };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-form", { ref: "ModifyForm", staticClass: "dialog-system-management", attrs: { "model": _setup.form, "rules": _setup.rules, "size": "mini", "label-position": "left", "label-width": "80px" } }, [_c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "name", "label": "\u4EBA\u5458\u59D3\u540D" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u4EBA\u5458\u59D3\u540D" }, model: { value: _setup.form.name, callback: function($$v) {
    _vm.$set(_setup.form, "name", $$v);
  }, expression: "form.name" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "username", "label": "\u767B\u5F55\u8D26\u53F7" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u767B\u5F55\u8D26\u53F7" }, model: { value: _setup.form.username, callback: function($$v) {
    _vm.$set(_setup.form, "username", $$v);
  }, expression: "form.username" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 24 } }, [_c("el-form-item", { attrs: { "prop": "role", "label": "\u89D2\u8272" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u89D2\u8272" }, model: { value: _setup.form.role, callback: function($$v) {
    _vm.$set(_setup.form, "role", $$v);
  }, expression: "form.role" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 24 } }, [_c("el-form-item", { attrs: { "label": "\u5907\u6CE8" } }, [_c("el-input", { attrs: { "type": "textarea", "autosize": { minRows: 2, maxRows: 4 }, "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u5907\u6CE8" }, model: { value: _setup.form.remark, callback: function($$v) {
    _vm.$set(_setup.form, "remark", $$v);
  }, expression: "form.remark" } })], 1)], 1)], 1), _c("el-form-item", { staticClass: "dialog-system-management-console" }, [_c("el-button", { staticClass: "dialog-system-management-console-button", attrs: { "type": "primary", "size": "mini", "loading": _setup.loading }, on: { "click": _setup.onModify } }, [_vm._v("\u4FDD\u5B58\u4FE1\u606F")])], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "981d0be4",
  null,
  null
);
const dialogSystemManagement = __component__.exports;
export {
  dialogSystemManagement as default
};
