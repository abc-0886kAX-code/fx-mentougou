import { j as computed, u as unref, r as ref$1, l as shallowRef, x as onMounted } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { C as ChartData_Server, a as ChartData_Obtain } from "./chart-b8a62d2a.js";
import { n as normalizeComponent, H as init, I as use, A as loadStyle, j as dayjs, i as isNil } from "./index-1ea80670.js";
import { u as useDateWater } from "./useDate-287f32d4.js";
import "./index-9706d3fe.js";
import "./useMars3D-c560a623.js";
import "./default_legend_icon-fcdb82ea.js";
import "./Application-7fa37401.js";
import "./index-4cdc94bd.js";
import "./usePopup-500740ad.js";
import "./useWatchRevert-58689033.js";
const dataChart_vue_vue_type_style_index_0_scoped_dc45f774_lang = "";
const _sfc_main = {
  __name: "data-chart",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = ChartData_Server.server;
    const source = computed(() => unref(ChartData_Server.server.result.source).data);
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const refs = ref$1(null);
    const chart = shallowRef(null);
    function releaseChart() {
      chart.value.dispose();
      chart.value = null;
      refs.value = null;
    }
    function createChart() {
      if (isNil(unref(refs)))
        return;
      if (!isNil(unref(chart)))
        return releaseChart();
      chart.value = init(unref(refs));
      return chart.value;
    }
    function setupOptions() {
      if (isNil(unref(chart)))
        createChart();
      const options = {
        color: ["#07ebfd", "#1571bf"],
        legend: {
          textStyle: {
            color: "#fff"
          },
          bottom: 12
        },
        grid: {},
        tooltip: {
          trigger: "axis",
          textStyle: {
            fontSize: 14,
            color: "#fff"
          },
          backgroundColor: "rgba(0,0,0,0.3)",
          borderColor: "#02d5f6",
          borderWidth: 1
        },
        xAxis: {
          type: "category",
          data: unref(source).map((item) => item.tm),
          axisTick: {
            alignWithLabel: true
          },
          axisLabel: {
            color: "#fff",
            formatter: (value) => {
              return isNil(value) ? "-" : dayjs(value).format("MM-DD HH:mm");
            }
          }
        },
        yAxis: [
          {
            type: "value",
            name: "\u6C34\u6DF1(cm)",
            alignTicks: true,
            min: 0,
            max: function(value) {
              return Math.ceil((value.max + 0.3) / 0.5) * 0.5;
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: "#fff"
              }
            },
            axisLabel: {
              color: "#fff"
            },
            nameTextStyle: {
              color: "#fff"
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "\u6C34\u6DF1(cm)",
            yAxisIndex: 0,
            data: unref(source).map((item) => Math.ceil(Math.random() * 10)),
            type: "line",
            z: 1
          }
        ]
      };
      chart.value.setOption(options);
    }
    const dateVal = ref$1(useDateWater());
    const params = computed(() => {
      return {
        starttime: unref(dateVal)[0],
        endtime: unref(dateVal)[1],
        stcd: unref(config).stcd
      };
    });
    async function executeQuery() {
      await ChartData_Obtain(unref(params));
      setupOptions();
    }
    async function executeReset() {
      dateVal.value = useDateWater();
      executeQuery();
    }
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, loading, source, props, dialog, config, refs, chart, releaseChart, createChart, setupOptions, dateVal, params, executeQuery, executeReset, initChart: init, useChart: use, useDialog, ChartData_Server, ChartData_Obtain, loadStyle, useDateWater, dayjs };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "data-chart" }, "div", _setup.loadStyle, false), [_c("div", { staticClass: "data-chart-form" }, [_c("el-date-picker", { attrs: { "size": "mini", "type": "datetimerange", "start-placeholder": "\u5F00\u59CB\u65E5\u671F", "end-placeholder": "\u7ED3\u675F\u65E5\u671F", "format": "yyyy-MM-dd HH:mm:ss", "value-format": "yyyy-MM-dd HH:mm:ss" }, model: { value: _setup.dateVal, callback: function($$v) {
    _setup.dateVal = $$v;
  }, expression: "dateVal" } }), _c("div", [_c("el-button", { attrs: { "size": "mini", "type": "primary" }, on: { "click": _setup.executeQuery } }, [_vm._v("\u67E5\u8BE2")]), _c("el-button", { attrs: { "size": "mini", "type": "danger" }, on: { "click": _setup.executeReset } }, [_vm._v("\u91CD\u7F6E")])], 1)], 1), _c("div", { ref: "refs", staticClass: "data-chart-body" })]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "dc45f774",
  null,
  null
);
const dataChart = __component__.exports;
export {
  dataChart as default
};
