import { v as defineComponent, j as computed, u as unref, r as ref$1, x as onMounted, A as onBeforeUnmount } from "./element-ui-a9609798.js";
import { n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { S as SelectSite_Server, a as SelectSite_Obtain } from "./index-4cdc94bd.js";
import { u as useDateWater } from "./useDate-287f32d4.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useWatchRevert } from "./useWatchRevert-58689033.js";
import "./Application-7fa37401.js";
const statisticalAnalysisDefault_vue_vue_type_style_index_0_scoped_208542ed_lang = "";
const _sfc_main$1 = {
  __name: "statistical-analysis-default",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "70%",
      template: defineComponent(() => __vitePreload(() => import("./dialog-statistical-analysis-603863e9.js"), true ? ["assets/js/dialog-statistical-analysis-603863e9.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css","assets/js/useTabs-036f428d.js","assets/js/EmptyView-301669d6.js","assets/js/usePopup-500740ad.js","assets/dialog-statistical-analysis-da6961ea.css"] : void 0)),
      title: "\u7EDF\u8BA1\u5206\u6790"
    });
    const { loading } = SelectSite_Server.server;
    const selcetOptions = computed(() => transArray(unref(SelectSite_Server.server.result.source).data, []));
    const selectValue = ref$1([]);
    const dateVal = ref$1(useDateWater());
    const params = computed(() => {
      return {
        stcd: unref(selectValue).join(","),
        starttime: unref(dateVal)[0],
        endtime: unref(dateVal)[1]
      };
    });
    async function executeQuery() {
      await SelectSite_Obtain({ sttp: "RW", usfl: "01" });
    }
    function executeReset() {
      dateVal.value = useDateWater();
      selectValue.value = [];
    }
    function openPopup() {
      popupEntity.show(unref(params));
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, loading, selcetOptions, selectValue, dateVal, params, executeQuery, executeReset, openPopup, loadStyle, transArray, SelectSite_Obtain, SelectSite_Server, useDateWater, usePopup };
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "statistical-analysis-default" }, "div", _setup.loadStyle, false), [_c("div", { staticClass: "statistical-analysis-default-form" }, [_c("div", { staticClass: "statistical-analysis-default-form-item" }, [_c("div", { staticClass: "statistical-analysis-default-form-item-label" }, [_vm._v("\u7AD9\u540D:")]), _c("div", { staticClass: "statistical-analysis-default-form-item-plugin" }, [_c("el-select", { attrs: { "size": "mini", "multiple": "", "collapse-tags": "", "placeholder": "\u8BF7\u9009\u62E9" }, model: { value: _setup.selectValue, callback: function($$v) {
    _setup.selectValue = $$v;
  }, expression: "selectValue" } }, _vm._l(_setup.selcetOptions, function(item) {
    return _c("el-option", { key: item.stcd, attrs: { "label": item.stnm, "value": item.stcd } });
  }), 1)], 1)]), _c("div", { staticClass: "statistical-analysis-default-form-item" }, [_c("div", { staticClass: "statistical-analysis-default-form-item-label" }, [_vm._v("\u65F6\u95F4:")]), _c("div", { staticClass: "statistical-analysis-default-form-item-plugin" }, [_c("el-date-picker", { attrs: { "size": "mini", "type": "datetimerange", "start-placeholder": "\u5F00\u59CB\u65E5\u671F", "end-placeholder": "\u7ED3\u675F\u65E5\u671F", "format": "yyyy-MM-dd HH:mm:ss", "value-format": "yyyy-MM-dd HH:mm:ss" }, model: { value: _setup.dateVal, callback: function($$v) {
    _setup.dateVal = $$v;
  }, expression: "dateVal" } })], 1)]), _c("div", { staticClass: "statistical-analysis-default-form-item" }, [_c("el-button", { attrs: { "size": "mini", "type": "primary" }, on: { "click": _setup.openPopup } }, [_vm._v("\u67E5\u8BE2")]), _c("el-button", { attrs: { "size": "mini", "type": "danger" }, on: { "click": _setup.executeReset } }, [_vm._v("\u91CD\u7F6E")])], 1)])]);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "208542ed",
  null,
  null
);
const StatisticalAnalysisDefault = __component__$1.exports;
const Menu = {
  defaultID: "e7c011a06efa4db7b8514198dcbafcee",
  menu: [
    {
      id: "e7c011a06efa4db7b8514198dcbafcee",
      label: "\u7EDF\u8BA1\u5206\u6790",
      component: StatisticalAnalysisDefault,
      render: false,
      fragment: true
    }
  ]
};
const index_vue_vue_type_style_index_0_scoped_f1af9087_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const Name = "statistical-analysis-menu";
    const { menu, defaultID } = Menu;
    const active = ref$1(defaultID);
    const componentName = ref$1("");
    const setupDefaultActive = () => active.value = defaultID;
    useWatchRevert(Name, {
      setupDriver: setupDefaultActive
    });
    const handlerComponent = (cell) => {
      const { component, revert } = cell;
      componentName.value = component;
      revert && context.emit("onResolve", {
        ...cell,
        type: Name
      });
    };
    const handlerDialog = (cell) => {
    };
    return { __sfc: true, Name, menu, defaultID, active, componentName, setupDefaultActive, handlerComponent, handlerDialog, Menu, useWatchRevert };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("screen-grid-container", { scopedSlots: _vm._u([{ key: "head", fn: function() {
    return [_c("screen-grid-select", { attrs: { "icon": "el-icon-s-help", "active": _setup.active, "menu": _setup.menu, "width": 80 }, on: { "update:active": function($event) {
      _setup.active = $event;
    }, "toComponent": _setup.handlerComponent, "toDialog": _setup.handlerDialog }, scopedSlots: _vm._u([{ key: "default", fn: function(node) {
      return [_c("screen-grid-node", { attrs: { "node": node } })];
    } }]) })];
  }, proxy: true }, { key: "body", fn: function() {
    return [_c(_setup.componentName, { tag: "component" })];
  }, proxy: true }]) });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "f1af9087",
  null,
  null
);
const index = __component__.exports;
export {
  index as default
};
