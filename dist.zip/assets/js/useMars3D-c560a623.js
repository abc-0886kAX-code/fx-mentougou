import { i as inject, l as shallowRef, j as computed } from "./element-ui-a9609798.js";
import { M as Mars3dSymbolName } from "./index-1ea80670.js";
function useMars3d() {
  const mapviewRef = inject(Mars3dSymbolName, shallowRef(null));
  const mapview = computed(() => {
    return mapviewRef.value.view;
  });
  return {
    mapview
  };
}
export {
  useMars3d as u
};
