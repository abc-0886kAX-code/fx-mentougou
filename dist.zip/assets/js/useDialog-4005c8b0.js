import { i as inject } from "./element-ui-a9609798.js";
import { P as POPUP_SYMBOLE } from "./index-1ea80670.js";
function useDialog(key) {
  const popup = inject(POPUP_SYMBOLE);
  return popup.cache.take(key, {
    config: {}
  });
}
export {
  useDialog as u
};
