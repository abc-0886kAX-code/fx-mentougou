import { j as computed, u as unref, r as ref$1, x as onMounted } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { D as DetailsAddress, b as DetailsMethod } from "./index-9706d3fe.js";
import { u as useService } from "./Application-7fa37401.js";
import { g as get, n as normalizeComponent, D as transObject } from "./index-1ea80670.js";
import "./useMars3D-c560a623.js";
import "./default_legend_icon-fcdb82ea.js";
import "./index-4cdc94bd.js";
import "./usePopup-500740ad.js";
import "./useWatchRevert-58689033.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data.data", {});
  return { data };
}
const Details_Server = service.define({
  url: DetailsAddress,
  method: DetailsMethod
});
function Details_Obtain(props) {
  Details_Server.server.config.bind("params", props);
  return Details_Server.obtain({ transResponse });
}
const dataInfo_vue_vue_type_style_index_0_scoped_f6fd3e01_lang = "";
const _sfc_main = {
  __name: "data-info",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const { loading } = Details_Server.server;
    const Info = computed(() => transObject(unref(Details_Server.server.result.source).data, {}));
    const caption = ref$1([
      {
        field: "stcd",
        label: "\u7F16\u7801",
        value: ""
      },
      {
        field: "stnm",
        label: "\u540D\u5B57",
        value: ""
      },
      {
        field: "lgtd",
        label: "\u7ECF\u5EA6",
        value: ""
      },
      {
        field: "lttd",
        label: "\u7EAC\u5EA6",
        value: ""
      },
      {
        field: "addvcdname",
        label: "\u884C\u653F\u533A",
        value: ""
      },
      {
        field: "sttpname",
        label: "\u7AD9\u70B9\u7C7B\u578B",
        value: ""
      }
    ]);
    async function executeQuery() {
      await Details_Obtain({ stcd: unref(config).stcd });
      caption.value.forEach((item) => {
        item.handler ? item.value = item.handler(unref(Info)[item.field]) : item.value = unref(Info)[item.field];
        return item;
      });
    }
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, props, dialog, config, loading, Info, caption, executeQuery, useDialog, Details_Server, Details_Obtain, transObject };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "data-info biz-info" }, _vm._l(_setup.caption, function(item, index) {
    return _c("div", { key: index, staticClass: "introduce-box" }, [_c("h4", [_vm._v(_vm._s(item.label))]), _c("p", [_vm._v(_vm._s(item.value))])]);
  }), 0);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "f6fd3e01",
  null,
  null
);
const dataInfo = __component__.exports;
export {
  dataInfo as default
};
