import { w as watch, u as unref } from "./element-ui-a9609798.js";
import { u as useLayerLegend, d as default_legend_icon } from "./default_legend_icon-fcdb82ea.js";
import { n as normalizeComponent, v as storeToRefs } from "./index-1ea80670.js";
const index_vue_vue_type_style_index_0_scoped_45155f42_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const legendStore = useLayerLegend();
    const { checkList, isHasLayer, group } = storeToRefs(legendStore);
    function setupIcon({ icon }) {
      return icon != null ? icon : default_legend_icon;
    }
    function handlerChange() {
      unref(group).map((item) => {
        if (unref(checkList).includes(item.keyword)) {
          item.entity.show = true;
        } else {
          item.entity.show = false;
        }
      });
    }
    watch(
      group,
      (layers) => {
        const dataset = layers.filter((layer) => layer.show).map((layer) => layer.keyword);
        checkList.value = dataset;
        handlerChange();
      },
      { immediate: true }
    );
    return { __sfc: true, legendStore, checkList, isHasLayer, group, setupIcon, handlerChange, useLayerLegend, storeToRefs, default_legend_icon };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _setup.isHasLayer ? _c("div", { staticClass: "layer-legend" }, [_vm._m(0), _c("el-checkbox-group", { staticClass: "layer-legend-body", on: { "change": _setup.handlerChange }, model: { value: _setup.checkList, callback: function($$v) {
    _setup.checkList = $$v;
  }, expression: "checkList" } }, [_vm._l(_setup.group, function(item) {
    return [_c("el-checkbox", { key: item.keyword, staticClass: "layer-legend-body-item", attrs: { "label": item.keyword } }, [_c("div", { staticClass: "layer-legend-body-item-label" }, [_c("img", { attrs: { "src": _setup.setupIcon(item), "alt": item.label } }), _c("p", [_vm._v(_vm._s(item.label))]), _c("p", { staticStyle: { "transition": "all 0.3s" } }, [_vm._v(_vm._s(item.size))])])])];
  })], 2)], 1) : _vm._e();
};
var _sfc_staticRenderFns = [function() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "layer-legend-head" }, [_c("div", { staticClass: "layer-legend-head-label" }, [_c("p", [_vm._v("\u56FE\u4F8B")]), _c("p", [_vm._v("\u63CF\u8FF0")]), _c("p", [_vm._v("\u6570\u91CF")])])]);
}];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "45155f42",
  null,
  null
);
const index = __component__.exports;
export {
  index as default
};
