import { j as computed, u as unref, r as ref$1, x as onMounted, z as elementUi_common } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { M as ModifyAddress, a as ModifyMethod } from "./director-manage-5732edd2.js";
import { u as useService } from "./Application-7fa37401.js";
import { t as transFormData, g as get, n as normalizeComponent } from "./index-1ea80670.js";
import "./usePopup-500740ad.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Modify_Server = service.define({
  url: ModifyAddress,
  method: ModifyMethod
});
function Modify_Obtain(props) {
  Modify_Server.server.config.bind("data", transFormData(props));
  return Modify_Server.obtain({ transResponse });
}
const dialogDirectorManage_vue_vue_type_style_index_0_scoped_8c31842b_lang = "";
const _sfc_main = {
  __name: "dialog-director-manage",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = Modify_Server.server;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const ModifyForm = ref$1();
    const form = ref$1({
      username: "",
      company: "",
      telephone: "",
      dutytype: "",
      id: ""
    });
    const rules = {
      username: [
        {
          required: true,
          message: "\u8D1F\u8D23\u4EBA\u59D3\u540D\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      telephone: [
        {
          required: true,
          message: "\u8D1F\u8D23\u4EBA\u624B\u673A\u53F7\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      company: [
        {
          required: true,
          message: "\u5355\u4F4D\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      dutytype: [
        {
          required: true,
          message: "\u8D1F\u8D23\u7C7B\u578B\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function onModify() {
      unref(ModifyForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await Modify_Obtain(unref(form));
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u4FEE\u6539\u6210\u529F!"
          });
          dialog.destroy();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    onMounted(() => {
      form.value = unref(config);
    });
    return { __sfc: true, props, loading, dialog, config, ModifyForm, form, rules, onModify, useDialog, Modify_Server, Modify_Obtain, Notification: elementUi_common.exports.Notification };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-form", { ref: "ModifyForm", staticClass: "dialog-director-manage", attrs: { "model": _setup.form, "rules": _setup.rules, "size": "mini", "label-position": "top" } }, [_c("el-form-item", { attrs: { "prop": "username", "label": "\u8D1F\u8D23\u4EBA\u59D3\u540D" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-remove-outline", "placeholder": "\u8BF7\u8F93\u5165\u8D1F\u8D23\u4EBA\u59D3\u540D" }, model: { value: _setup.form.username, callback: function($$v) {
    _vm.$set(_setup.form, "username", $$v);
  }, expression: "form.username" } })], 1), _c("el-form-item", { attrs: { "prop": "telephone", "label": "\u8D1F\u8D23\u4EBA\u624B\u673A\u53F7" } }, [_c("el-input", { staticClass: "numrule", attrs: { "type": "number", "prefix-icon": "el-icon-phone-outline", "placeholder": "\u8BF7\u8F93\u5165\u8D1F\u8D23\u4EBA\u624B\u673A\u53F7", "max": 11 }, model: { value: _setup.form.telephone, callback: function($$v) {
    _vm.$set(_setup.form, "telephone", _vm._n($$v));
  }, expression: "form.telephone" } })], 1), _c("el-form-item", { attrs: { "prop": "company", "label": "\u5355\u4F4D" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-office-building", "placeholder": "\u8BF7\u8F93\u5165\u5355\u4F4D" }, model: { value: _setup.form.company, callback: function($$v) {
    _vm.$set(_setup.form, "company", $$v);
  }, expression: "form.company" } })], 1), _c("el-form-item", { attrs: { "prop": "dutytype", "label": "\u8D1F\u8D23\u7C7B\u578B" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-connection", "placeholder": "\u8BF7\u8F93\u5165\u8D1F\u8D23\u7C7B\u578B" }, model: { value: _setup.form.dutytype, callback: function($$v) {
    _vm.$set(_setup.form, "dutytype", $$v);
  }, expression: "form.dutytype" } })], 1), _c("el-form-item", { staticClass: "dialog-director-manage-console" }, [_c("el-button", { staticClass: "dialog-director-manage-console-button", attrs: { "type": "primary", "size": "mini", "loading": _setup.loading }, on: { "click": _setup.onModify } }, [_vm._v("\u4FDD\u5B58 ")])], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "8c31842b",
  null,
  null
);
const dialogDirectorManage = __component__.exports;
export {
  dialogDirectorManage as default
};
