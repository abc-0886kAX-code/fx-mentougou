import { B as defineAsyncComponent, r as ref$1, j as computed, u as unref, i as inject } from "./element-ui-a9609798.js";
import { B as v4, _ as __vitePreload, i as isNil, g as get, C as transDefault, c as useBooleanState, b as useShallowObject, D as transObject, m as mergeObject, E as transFunction, P as POPUP_SYMBOLE } from "./index-1ea80670.js";
const uuid = v4;
const UNDEFINED_VIEW = defineAsyncComponent(() => __vitePreload(() => import("./EmptyView-301669d6.js"), true ? ["assets/js/EmptyView-301669d6.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css"] : void 0));
const DialogCustomClass = "furnace-dialog";
const DialogProps = {
  customClass: DialogCustomClass,
  fullscreen: false,
  modal: false,
  modalAppendToBody: true,
  appendToBody: true,
  lockScroll: true,
  closeOnClickModal: false,
  closeOnPressEscape: true,
  showClose: true,
  center: false,
  destroyOnClose: false
};
function useElementRefs() {
  const refs = ref$1(null);
  const ready = computed(() => !isNil(unref(refs)));
  return {
    refs,
    ready
  };
}
function DialogEntity(record, popup, props, keyword) {
  const template = get(props, "template", UNDEFINED_VIEW);
  const afterClose = get(props, "afterClose", () => {
  });
  const uid = transDefault(keyword, `${record}-${uuid()}`);
  const element = useElementRefs();
  const state = useBooleanState(get(props, "show", false));
  const options = useShallowObject(get(props, "options", {}));
  const visible = computed(() => unref(state.state));
  const title = ref$1(get(props, "title", "\u5F39\u6846"));
  const width = ref$1(get(props, "width", "70%"));
  const height = ref$1(get(props, "height", "60vh"));
  const top = computed(() => {
    if (!unref(element.ready))
      return "0px";
    const bodyHeight = document.body.clientHeight;
    const [container] = unref(element.refs);
    const offset = (bodyHeight - container.parentElement.parentElement.clientHeight) / 2;
    return `${offset}px`;
  });
  function setupTitle(value) {
    title.value = value;
  }
  function setupSize(size) {
    width.value = get(size, "width", unref(width));
    height.value = get(size, "height", unref(height));
  }
  function show(extend) {
    if (unref(popup.pondFind)(uid)) {
      options.clear();
      options.into(extend);
      state.toEnable();
      return this;
    } else {
      const transExtend = { options: transObject(extend) };
      const config = mergeObject(props, transExtend, { show: true });
      const entity = DialogEntity(record, popup, config, uid);
      popup.toPond(entity);
      return entity;
    }
  }
  function hide() {
    state.toDisable();
  }
  function destroy(handler) {
    const control = transFunction(handler, afterClose);
    const release = popup.pondRelease(uid);
    release(control);
  }
  return {
    template,
    constProps: DialogProps,
    config: options.source,
    refs: element.refs,
    uid,
    state,
    options,
    visible,
    title,
    width,
    height,
    top,
    setupTitle,
    setupSize,
    destroy,
    show,
    hide
  };
}
function usePopup(props) {
  const popup = inject(POPUP_SYMBOLE, {});
  const record = popup.toRecord();
  function define(extend) {
    const entity = DialogEntity(record, popup, mergeObject(props, extend));
    popup.toPond(entity);
    return entity;
  }
  function release(entity) {
    entity.destroy();
  }
  return {
    define,
    release
  };
}
export {
  uuid as a,
  usePopup as u
};
