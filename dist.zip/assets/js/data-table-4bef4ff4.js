import { j as computed, u as unref, x as onMounted } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { n as normalizeComponent, A as loadStyle } from "./index-1ea80670.js";
import { u as useDateWater } from "./useDate-287f32d4.js";
import { C as ChartData_Server, a as ChartData_Obtain } from "./chart-b8a62d2a.js";
import "./index-9706d3fe.js";
import "./useMars3D-c560a623.js";
import "./default_legend_icon-fcdb82ea.js";
import "./Application-7fa37401.js";
import "./index-4cdc94bd.js";
import "./usePopup-500740ad.js";
import "./useWatchRevert-58689033.js";
const dataTable_vue_vue_type_style_index_0_scoped_63572e62_lang = "";
const _sfc_main = {
  __name: "data-table",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const tableColumn = [
      {
        prop: "stnm",
        label: "\u540D\u79F0",
        align: "center"
      },
      {
        prop: "signname",
        label: "\u7AD9\u70B9\u7C7B\u578B",
        align: "center"
      }
    ];
    const { loading } = ChartData_Server.server;
    const source = computed(() => unref(ChartData_Server.server.result.source).data);
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const dateVal = useDateWater();
    const params = computed(() => {
      return {
        starttime: unref(dateVal)[0],
        endtime: unref(dateVal)[1],
        stcd: unref(config).stcd
      };
    });
    async function executeQuery() {
      await ChartData_Obtain(unref(params));
    }
    async function executeReset() {
      dateVal.value = useDateWater();
      executeQuery();
    }
    function executeExport() {
      console.log(unref(params));
    }
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, tableColumn, loading, source, props, dialog, config, dateVal, params, executeQuery, executeReset, executeExport, useDialog, loadStyle, useDateWater, ChartData_Server, ChartData_Obtain };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "data-table" }, "div", _setup.loadStyle, false), [_c("div", { staticClass: "data-table-form" }, [_c("el-date-picker", { attrs: { "size": "mini", "type": "datetimerange", "start-placeholder": "\u5F00\u59CB\u65E5\u671F", "end-placeholder": "\u7ED3\u675F\u65E5\u671F", "format": "yyyy-MM-dd HH:mm:ss", "value-format": "yyyy-MM-dd HH:mm:ss" }, model: { value: _setup.dateVal, callback: function($$v) {
    _setup.dateVal = $$v;
  }, expression: "dateVal" } }), _c("div", [_c("el-button", { attrs: { "size": "mini", "type": "primary" }, on: { "click": _setup.executeQuery } }, [_vm._v("\u67E5\u8BE2")]), _c("el-button", { attrs: { "size": "mini", "type": "danger" }, on: { "click": _setup.executeReset } }, [_vm._v("\u91CD\u7F6E")]), _c("el-button", { attrs: { "size": "mini", "type": "warning" }, on: { "click": _setup.executeExport } }, [_vm._v("\u5BFC\u51FA")])], 1)], 1), _c("el-table", { staticClass: "data-table-body", attrs: { "size": "mini", "data": _setup.source, "width": "100%", "height": "100%" } }, [_c("el-table-column", { attrs: { "type": "index", "width": "50", "align": "center" } }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "63572e62",
  null,
  null
);
const dataTable = __component__.exports;
export {
  dataTable as default
};
