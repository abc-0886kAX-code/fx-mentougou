import { l as shallowRef } from "./element-ui-a9609798.js";
import { j as dayjs } from "./index-1ea80670.js";
const formatDate = "YYYY-MM-DD HH:mm:ss";
function useDate(startDate, endDate) {
  const range = shallowRef([
    dayjs(startDate).format(formatDate),
    dayjs(endDate).format(formatDate)
  ]);
  return range;
}
function useDateWater() {
  const now = dayjs();
  const start = now.hour(0).minute(0).second(0);
  const end = now.hour(0).minute(0).second(0).add(1, "day");
  return useDate(start, end);
}
export {
  useDateWater as u
};
