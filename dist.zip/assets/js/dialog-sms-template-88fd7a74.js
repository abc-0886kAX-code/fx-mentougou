import { j as computed, u as unref, r as ref$1, x as onMounted, z as elementUi_common } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { M as ModifyAddress, a as ModifyMethod } from "./sms-template-48258d3f.js";
import { u as useService } from "./Application-7fa37401.js";
import { t as transFormData, g as get, n as normalizeComponent } from "./index-1ea80670.js";
import "./usePopup-500740ad.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Modify_Server = service.define({
  url: ModifyAddress,
  method: ModifyMethod
});
function Modify_Obtain(props) {
  Modify_Server.server.config.bind("data", transFormData(props));
  return Modify_Server.obtain({ transResponse });
}
const dialogSmsTemplate_vue_vue_type_style_index_0_scoped_585b3953_lang = "";
const _sfc_main = {
  __name: "dialog-sms-template",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = Modify_Server.server;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const ModifyForm = ref$1();
    const form = ref$1({
      gate: "",
      content: "",
      tempid: ""
    });
    const rules = {
      gate: [
        {
          required: true,
          message: "\u9608\u503C\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      content: [
        {
          required: true,
          message: "\u77ED\u4FE1\u5185\u5BB9\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function onModify() {
      unref(ModifyForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await Modify_Obtain(unref(form));
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u4FEE\u6539\u6210\u529F!"
          });
          dialog.destroy();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    onMounted(() => {
      form.value = unref(config);
    });
    return { __sfc: true, props, loading, dialog, config, ModifyForm, form, rules, onModify, useDialog, Modify_Server, Modify_Obtain, Notification: elementUi_common.exports.Notification };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-form", { ref: "ModifyForm", staticClass: "dialog-sms-template", attrs: { "model": _setup.form, "rules": _setup.rules, "size": "mini", "label-position": "top" } }, [_c("el-form-item", { attrs: { "prop": "gate", "label": "\u9608\u503C" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-remove-outline", "placeholder": "\u8BF7\u8F93\u5165\u9608\u503C" }, model: { value: _setup.form.gate, callback: function($$v) {
    _vm.$set(_setup.form, "gate", $$v);
  }, expression: "form.gate" } })], 1), _c("el-form-item", { attrs: { "prop": "content", "label": "\u77ED\u4FE1\u5185\u5BB9" } }, [_c("el-input", { attrs: { "type": "textarea", "autosize": { minRows: 2, maxRows: 4 }, "prefix-icon": "el-icon-reading", "placeholder": "\u8BF7\u8F93\u5165\u77ED\u4FE1\u5185\u5BB9" }, model: { value: _setup.form.content, callback: function($$v) {
    _vm.$set(_setup.form, "content", $$v);
  }, expression: "form.content" } })], 1), _c("el-form-item", { staticClass: "dialog-sms-template-console" }, [_c("el-button", { staticClass: "dialog-sms-template-console-button", attrs: { "type": "primary", "size": "mini", "loading": _setup.loading }, on: { "click": _setup.onModify } }, [_vm._v("\u4FDD\u5B58 ")])], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "585b3953",
  null,
  null
);
const dialogSmsTemplate = __component__.exports;
export {
  dialogSmsTemplate as default
};
