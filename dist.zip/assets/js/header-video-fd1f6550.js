const __$_require_0453fda3__ = "/mp4/header-video.mp4";
export {
  __$_require_0453fda3__ as _
};
