import { u as useService } from "./Application-7fa37401.js";
import { t as transFormData, g as get } from "./index-1ea80670.js";
const Address = "/SiteInfo/getSiteInfoList";
const Method = "POST";
const ChartAddress = "/RealData/RadarWater/getRadarWaterList";
const CGartMethod = "POST";
const service = useService();
function transResponse(response) {
  const data = get(response, "data.data", []);
  return { data };
}
const SelectSite_Server = service.define({
  url: Address,
  method: Method
});
function SelectSite_Obtain(props) {
  SelectSite_Server.server.config.bind("data", transFormData(props));
  return SelectSite_Server.obtain({ transResponse });
}
export {
  ChartAddress as C,
  SelectSite_Server as S,
  SelectSite_Obtain as a,
  CGartMethod as b
};
