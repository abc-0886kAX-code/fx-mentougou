import { C as ChartAddress, b as CGartMethod } from "./index-4cdc94bd.js";
import { u as useService } from "./Application-7fa37401.js";
import { t as transFormData, g as get } from "./index-1ea80670.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data.data", {});
  return { data };
}
const ChartData_Server = service.define({
  url: ChartAddress,
  method: CGartMethod
});
function ChartData_Obtain(props) {
  ChartData_Server.abort();
  ChartData_Server.server.config.bind("data", transFormData(props));
  return ChartData_Server.obtain({ transResponse });
}
export {
  ChartData_Server as C,
  ChartData_Obtain as a
};
