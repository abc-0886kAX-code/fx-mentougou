const __viteBrowserExternal = {};
export {
  __viteBrowserExternal as default
};
