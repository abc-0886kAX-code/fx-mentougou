import { j as computed, u as unref, r as ref$1, l as shallowRef, x as onMounted } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { C as ChartData_Server, a as ChartData_Obtain } from "./chart-a8297dd0.js";
import { n as normalizeComponent, D as transObject, H as init, I as use, A as loadStyle, j as dayjs, i as isNil } from "./index-1ea80670.js";
import "./index-4cdc94bd.js";
import "./Application-7fa37401.js";
const dataChart_vue_vue_type_style_index_0_scoped_f6c9859c_lang = "";
const _sfc_main = {
  __name: "data-chart",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = ChartData_Server.server;
    const source = computed(
      () => transObject(unref(ChartData_Server.server.result.source).data, {
        tableColumn: [],
        tableRows: []
      })
    );
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const refs = ref$1(null);
    const chart = shallowRef(null);
    function releaseChart() {
      chart.value.dispose();
      chart.value = null;
      refs.value = null;
    }
    function createChart() {
      if (isNil(unref(refs)))
        return;
      if (!isNil(unref(chart)))
        return releaseChart();
      chart.value = init(unref(refs));
      return chart.value;
    }
    function setupOptions() {
      if (isNil(unref(chart)))
        createChart();
      const data = unref(source).tableColumn.map((item) => {
        return {
          name: item.stnm,
          yAxisIndex: 0,
          data: unref(source).tableRows.map((cell) => cell[item.columnkey]),
          type: "line",
          z: 1
        };
      });
      const options = {
        legend: {
          textStyle: {
            color: "#fff"
          },
          bottom: 12
        },
        grid: {},
        tooltip: {
          trigger: "axis",
          textStyle: {
            fontSize: 14,
            color: "#fff"
          },
          backgroundColor: "rgba(0,0,0,0.3)",
          borderColor: "#02d5f6",
          borderWidth: 1
        },
        xAxis: {
          type: "category",
          data: unref(source).tableRows.map((item) => item.tm),
          axisTick: {
            alignWithLabel: true
          },
          axisLabel: {
            color: "#fff",
            formatter: (value) => {
              return isNil(value) ? "-" : dayjs(value).format("MM-DD HH:mm");
            }
          }
        },
        yAxis: [
          {
            type: "value",
            name: "\u6C34\u6DF1(cm)",
            alignTicks: true,
            min: 0,
            max: function(value) {
              return Math.ceil((value.max + 0.3) / 0.5) * 0.5;
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: "#fff"
              }
            },
            axisLabel: {
              color: "#fff"
            },
            nameTextStyle: {
              color: "#fff"
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: data
      };
      chart.value.setOption(options);
    }
    async function executeQuery() {
      await ChartData_Obtain(unref(config));
      setupOptions();
    }
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, loading, source, props, dialog, config, refs, chart, releaseChart, createChart, setupOptions, executeQuery, initChart: init, useChart: use, useDialog, ChartData_Server, ChartData_Obtain, loadStyle, transObject, dayjs };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], ref: "refs", staticClass: "data-chart" }, "div", _setup.loadStyle, false));
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "f6c9859c",
  null,
  null
);
const dataChart = __component__.exports;
export {
  dataChart as default
};
