import { n as normalizeComponent, _ as __vitePreload } from "./index-1ea80670.js";
import { u as useTabs } from "./useTabs-036f428d.js";
import "./element-ui-a9609798.js";
import "./EmptyView-301669d6.js";
import "./usePopup-500740ad.js";
const dialogStatisticalAnalysis_vue_vue_type_style_index_0_scoped_68139025_lang = "";
const _sfc_main = {
  __name: "dialog-statistical-analysis",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { active, component, dataset, update } = useTabs({
      data: [
        {
          keyword: "data-chart",
          label: "\u6570\u636E\u56FE\u8868",
          template: () => __vitePreload(() => import("./data-chart-f446cce9.js"), true ? ["assets/js/data-chart-f446cce9.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/chart-a8297dd0.js","assets/js/index-4cdc94bd.js","assets/js/Application-7fa37401.js","assets/data-chart-bc737e03.css"] : void 0)
        },
        {
          keyword: "data-table",
          label: "\u6570\u636E\u8868\u683C",
          template: () => __vitePreload(() => import("./data-table-ffd75750.js"), true ? ["assets/js/data-table-ffd75750.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/chart-a8297dd0.js","assets/js/index-4cdc94bd.js","assets/js/Application-7fa37401.js","assets/data-table-c100023f.css"] : void 0)
        }
      ]
    });
    function tabClick(entity) {
      update({ keyword: entity.name });
    }
    return { __sfc: true, props, active, component, dataset, update, tabClick, useTabs };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "dialog-statistical-analysis" }, [_c("div", { staticClass: "dialog-statistical-analysis-head" }, [_c("el-tabs", { attrs: { "value": _setup.active, "type": "card" }, on: { "tab-click": _setup.tabClick } }, [_vm._l(_setup.dataset, function(entity) {
    return [_c("el-tab-pane", { key: entity.keyword, attrs: { "label": entity.label, "name": entity.keyword } })];
  })], 2)], 1), _c("div", { staticClass: "dialog-statistical-analysis-body" }, [_c(_setup.component, { key: _setup.active, tag: "components", attrs: { "popupKeyword": _setup.props.popupKeyword } })], 1)]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "68139025",
  null,
  null
);
const dialogStatisticalAnalysis = __component__.exports;
export {
  dialogStatisticalAnalysis as default
};
