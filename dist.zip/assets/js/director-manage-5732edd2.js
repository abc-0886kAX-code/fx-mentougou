import { t as transFormData, g as get, n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { v as defineComponent, r as ref$1, j as computed, u as unref, x as onMounted, A as onBeforeUnmount, z as elementUi_common } from "./element-ui-a9609798.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useService } from "./Application-7fa37401.js";
const Address = "/DirectorInfo/getDirectorInfoList";
const Method = "POST";
const SelectAddress = "/DirectorInfo/DirectorInfoSave";
const SelectMethod = "POST";
const ModifyAddress = "/DirectorInfo/DirectorInfoSave";
const ModifyMethod = "POST";
const DelAddress = "/DirectorInfo/deleteDirectorInfo";
const DelMethod = "GET";
const service$2 = useService();
function transResponse$2(response) {
  const data = get(response, "data.data", []);
  return { data };
}
const DirectorManage_Server = service$2.define({
  url: Address,
  method: Method
});
function DirectorManage_Obtain(props) {
  DirectorManage_Server.server.config.bind("data", transFormData(props));
  return DirectorManage_Server.obtain({ transResponse: transResponse$2 });
}
const service$1 = useService();
function transResponse$1(response) {
  const data = get(response, "data", {});
  return data;
}
const Select_Server = service$1.define({
  url: SelectAddress,
  method: SelectMethod
});
function Select_Obtain(props) {
  Select_Server.server.config.bind("data", transFormData(props));
  return Select_Server.obtain({ transResponse: transResponse$1 });
}
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Del_Server = service.define({
  url: DelAddress,
  method: DelMethod
});
function Del_Obtain(props) {
  Del_Server.server.config.bind("params", props);
  return Del_Server.obtain({ transResponse });
}
const directorManage_vue_vue_type_style_index_0_scoped_f0f36861_lang = "";
const _sfc_main = {
  __name: "director-manage",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "40%",
      height: "50vh",
      template: defineComponent(() => __vitePreload(() => import("./dialog-director-manage-ccfd235a.js"), true ? ["assets/js/dialog-director-manage-ccfd235a.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/Application-7fa37401.js","assets/js/usePopup-500740ad.js","assets/dialog-director-manage-dc936ff1.css"] : void 0)),
      afterClose: executeQuery
    });
    const { loading } = DirectorManage_Server.server;
    const table = ref$1(null);
    const tableData = computed(() => transArray(unref(DirectorManage_Server.server.result.source).data, []));
    const tableColumn = [
      {
        prop: "username",
        label: "\u8D1F\u8D23\u4EBA\u59D3\u540D",
        align: "center"
      },
      {
        prop: "telephone",
        label: "\u8D1F\u8D23\u4EBA\u624B\u673A\u53F7",
        align: "center"
      },
      {
        prop: "company",
        label: "\u5355\u4F4D",
        align: "center"
      },
      {
        prop: "dutytype",
        label: "\u8D1F\u8D23\u7C7B\u578B",
        align: "center"
      }
    ];
    function handleAdd() {
      popupEntity.setupTitle("\u65B0\u589E");
      popupEntity.show({});
    }
    function handleEdit(rows) {
      popupEntity.setupTitle("\u4FEE\u6539");
      popupEntity.show(rows);
    }
    async function handleDel({ id }) {
      if (!id)
        return;
      const message = await elementUi_common.exports.MessageBox.confirm("\u64CD\u4F5C\u5C06\u6C38\u4E45\u5220\u9664\u8BE5\u6761\u4FE1\u606F, \u662F\u5426\u7EE7\u7EED?", "\u63D0\u793A", {
        confirmButtonText: "\u786E\u5B9A",
        cancelButtonText: "\u53D6\u6D88",
        type: "warning"
      }).catch((err) => err);
      if ("confirm" === message) {
        const data = await Del_Obtain({ id });
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u5220\u9664\u6210\u529F!"
          });
          executeQuery();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      }
    }
    async function handleSelect(selection, row) {
      const selected = selection.length && selection.indexOf(row) !== -1;
      const params = {
        id: row.id,
        ischeck: selected ? "01" : "00"
      };
      const data = await Select_Obtain(params);
      if (data.code === 200) {
        elementUi_common.exports.Notification.success({
          title: "\u6210\u529F!",
          message: "\u7ED1\u5B9A\u6210\u529F!"
        });
      } else {
        elementUi_common.exports.Notification.error({
          title: "\u9519\u8BEF!",
          message: data.msg
        });
      }
    }
    function handleSelectable(row, index) {
      return true;
    }
    async function executeQuery() {
      await DirectorManage_Obtain();
      unref(tableData).map((item) => {
        item.ischeck === "01" ? unref(table).toggleRowSelection(item, true) : unref(table).toggleRowSelection(item, false);
      });
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, loading, table, tableData, tableColumn, handleAdd, handleEdit, handleDel, handleSelect, handleSelectable, executeQuery, loadStyle, transArray, usePopup, Notification: elementUi_common.exports.Notification, MessageBox: elementUi_common.exports.MessageBox, DirectorManage_Obtain, DirectorManage_Server, Select_Obtain, Select_Server, Del_Server, Del_Obtain };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], ref: "table", staticClass: "director-manage", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" }, on: { "select": _setup.handleSelect } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "selection", "selectable": _setup.handleSelectable, "width": "55" } }), _c("el-table-column", { attrs: { "type": "index", "width": "60", "align": "center" }, scopedSlots: _vm._u([{ key: "header", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "success" }, on: { "click": _setup.handleAdd } }, [_vm._v("\u65B0\u589E")])];
  } }]) }), _c("el-table-column", { attrs: { "label": "\u64CD\u4F5C", "width": "100", "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "warning" }, on: { "click": function($event) {
      return _setup.handleEdit(scope.row);
    } } }, [_vm._v("\u4FEE\u6539")]), _c("el-divider", { attrs: { "direction": "vertical" } }), _c("el-link", { attrs: { "type": "danger" }, on: { "click": function($event) {
      return _setup.handleDel(scope.row);
    } } }, [_vm._v("\u5220\u9664")])];
  } }]) }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "f0f36861",
  null,
  null
);
const directorManage = __component__.exports;
const directorManage$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: directorManage
}, Symbol.toStringTag, { value: "Module" }));
export {
  ModifyAddress as M,
  ModifyMethod as a,
  directorManage$1 as d
};
