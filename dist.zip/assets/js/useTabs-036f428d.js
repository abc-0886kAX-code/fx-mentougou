import { r as ref$1, j as computed, u as unref, C as onBeforeMount, A as onBeforeUnmount } from "./element-ui-a9609798.js";
import EmptyView from "./EmptyView-301669d6.js";
import { g as get, m as mergeObject, F as transNumber, E as transFunction, b as useShallowObject, d as transBoolean, D as transObject, e as transArray } from "./index-1ea80670.js";
import { a as uuid } from "./usePopup-500740ad.js";
function TabsEntity(props, index) {
  const keyword = get(props, "keyword", uuid());
  const template = get(props, "template", EmptyView);
  return mergeObject(props, {
    index: transNumber(index, -1),
    keyword,
    template
  });
}
function useTabs(props = {}) {
  const trans = transFunction(props.trans);
  const { source, state, has, take, bind, clear } = useShallowObject();
  const active = ref$1(get(props, "default", uuid()));
  const component = computed(() => {
    if (!has(unref(active)))
      return EmptyView;
    return take(unref(active)).template;
  });
  const dataset = computed(() => {
    return Object.keys(unref(source)).map((keyword) => {
      return trans(take(keyword));
    });
  });
  function update(raw) {
    const entity = transObject(raw, TabsEntity());
    if (unref(state.unusable))
      return active.value = uuid();
    if (has(entity.keyword))
      return active.value = entity.keyword;
    return active.value = unref(dataset)[0].keyword;
  }
  function setup(tabsource) {
    transArray(tabsource).forEach((tab, idx) => {
      const entity = TabsEntity(tab, idx);
      bind(entity.keyword, entity);
    });
    update();
  }
  onBeforeMount(() => {
    setup(props.data);
  });
  onBeforeUnmount(() => {
    if (transBoolean(props.release, true))
      clear();
  });
  return {
    active,
    component,
    dataset,
    update,
    setup,
    clear
  };
}
export {
  useTabs as u
};
