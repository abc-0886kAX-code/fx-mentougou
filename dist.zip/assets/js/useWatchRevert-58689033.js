import { i as inject, j as computed, u as unref, w as watch } from "./element-ui-a9609798.js";
function useWatchRevert(field, options) {
  const { setupDriver } = options;
  const watchRevert = inject("revertRefs", {
    key: "",
    skip: []
  });
  const revertKey = computed(() => unref(watchRevert).key);
  const revertMap = computed(() => unref(watchRevert).skip);
  const isRevert = computed(() => !unref(revertMap).includes(field));
  watch(
    () => unref(revertKey),
    () => unref(isRevert) && setupDriver()
  );
  return {};
}
export {
  useWatchRevert as u
};
