import { j as computed, u as unref } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { _ as __$_require_f5a5ef2e__ } from "./login-video-69570771.js";
import { _ as __$_require_0453fda3__ } from "./header-video-fd1f6550.js";
import { n as normalizeComponent } from "./index-1ea80670.js";
const dataOverview_vue_vue_type_style_index_0_scoped_ad424f8a_lang = "";
const _sfc_main = {
  __name: "data-overview",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const LEDLabel = "\u524D\u65B9\u79EF\u6C34200\u7C73,\u6CE8\u610F\u5B89\u5168!";
    const LEDStyle = computed(() => {
      return {
        width: `calc(100% + ${LEDLabel.length * 41}px)`
      };
    });
    return { __sfc: true, props, dialog, config, LEDLabel, LEDStyle, useDialog };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "data-overview" }, [_c("div", { staticClass: "data-overview-info" }, [_c("el-descriptions", { staticClass: "data-overview-info-pond", attrs: { "title": "\u4FE1\u606F\u5C55\u793A", "column": 1, "border": "" } }, [_c("el-descriptions-item", { attrs: { "label": "\u5F53\u524D\u79EF\u6C34\u6C34\u4F4D", "labelStyle": { background: "#FDE2E2", color: "#000" }, "contentStyle": { "text-align": "center" } } }, [_vm._v(_vm._s(_setup.config.z) + "\u7C73")]), _c("el-descriptions-item", { attrs: { "label": "\u96E8\u91CF\u6570\u636E", "labelStyle": { background: "#FDE2E2", color: "#000" }, "contentStyle": { "text-align": "center" } } }, [_vm._v("XXX\u96E8\u91CF\u7AD9 12mm")])], 1), _c("el-card", { staticClass: "data-overview-info-led", attrs: { "body-style": { padding: "0px" }, "shadow": "always" } }, [_c("div", { staticClass: "data-overview-info-led-content" }, [_c("div", { staticClass: "data-overview-info-led-content-animation", style: _setup.LEDStyle }, [_vm._v(_vm._s(_setup.LEDLabel))])]), _c("div", { staticClass: "data-overview-info-led-text" }, [_c("span", [_vm._v(_vm._s(_setup.LEDLabel))])])])], 1), _c("div", { staticClass: "data-overview-video" }, [_c("el-card", { staticClass: "data-overview-video-item", attrs: { "body-style": { padding: "0px" }, "shadow": "always" } }, [_c("div", { staticClass: "data-overview-video-item-content" }, [_c("video", { attrs: { "src": __$_require_f5a5ef2e__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } })]), _c("div", { staticClass: "data-overview-video-item-text" }, [_c("span", [_vm._v("\u6444\u50CF\u5934\u8BF4\u660E")]), _c("div", { staticClass: "data-overview-video-item-text-details" }, [_vm._v("\u4E1C\u5411\u897F")])])]), _c("el-card", { staticClass: "data-overview-video-item", attrs: { "body-style": { padding: "0px" }, "shadow": "always" } }, [_c("div", { staticClass: "data-overview-video-item-content" }, [_c("video", { attrs: { "src": __$_require_0453fda3__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } })]), _c("div", { staticClass: "data-overview-video-item-text" }, [_c("span", [_vm._v("\u6444\u50CF\u5934\u8BF4\u660E")]), _c("div", { staticClass: "data-overview-video-item-text-details" }, [_vm._v("\u5357\u5411\u5317")])])])], 1)]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "ad424f8a",
  null,
  null
);
const dataOverview = __component__.exports;
export {
  dataOverview as default
};
