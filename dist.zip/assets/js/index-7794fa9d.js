import { r as ref$1, x as onMounted, u as unref } from "./element-ui-a9609798.js";
import { n as normalizeComponent, _ as __vitePreload } from "./index-1ea80670.js";
import { u as useWatchRevert } from "./useWatchRevert-58689033.js";
const smsManagementDefault_vue_vue_type_style_index_0_scoped_21a55dfd_lang = "";
const _sfc_main$1 = {
  __name: "sms-management-default",
  setup(__props) {
    const active = ref$1({});
    const menus = ref$1([
      {
        keyword: "sms-manage",
        label: "",
        defaultLabel: "\u77ED\u4FE1\u7BA1\u7406",
        children: [
          {
            keyword: "sms-template",
            label: "\u77ED\u4FE1\u6A21\u677F",
            component: () => __vitePreload(() => import("./sms-template-48258d3f.js").then((n) => n.s), true ? ["assets/js/sms-template-48258d3f.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css","assets/js/usePopup-500740ad.js","assets/js/Application-7fa37401.js","assets/sms-template-fffefb62.css"] : void 0),
            index: 0
          },
          {
            keyword: "director-manage",
            label: "\u8D1F\u8D23\u4EBA\u7BA1\u7406",
            component: () => __vitePreload(() => import("./director-manage-5732edd2.js").then((n) => n.d), true ? ["assets/js/director-manage-5732edd2.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css","assets/js/usePopup-500740ad.js","assets/js/Application-7fa37401.js","assets/director-manage-9583ef6e.css"] : void 0)
          }
        ]
      },
      {
        keyword: "LED-manage",
        label: "",
        defaultLabel: "LED\u7BA1\u7406",
        children: [
          {
            keyword: "current-state",
            label: "\u5F53\u524D\u72B6\u6001",
            component: () => __vitePreload(() => import("./current-state-b58419d4.js"), true ? ["assets/js/current-state-b58419d4.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/Application-7fa37401.js","assets/current-state-9ac1c0c5.css"] : void 0)
          },
          {
            keyword: "info-template",
            label: "\u4FE1\u606F\u6A21\u677F",
            component: () => __vitePreload(() => import("./info-template-3f5f845d.js").then((n) => n.i), true ? ["assets/js/info-template-3f5f845d.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css","assets/js/usePopup-500740ad.js","assets/js/Application-7fa37401.js","assets/info-template-7555a180.css"] : void 0)
          }
        ]
      }
    ]);
    function setActive(cell) {
      return cell.keyword === unref(active).keyword ? { color: "#70b5ff", background: "#ecf5ff" } : {};
    }
    function handleCommand(command) {
      if (command.keyword === unref(active).keyword)
        return;
      active.value = command;
      handleMenu();
    }
    function handleMenu() {
      menus.value = unref(menus).map((item, i) => {
        if (i === unref(active).index) {
          item.label = unref(active).label;
        } else {
          item.label = "";
        }
        return item;
      });
    }
    function setType(menu) {
      if (menu.label) {
        return "primary";
      } else {
        return "";
      }
    }
    onMounted(() => {
      handleCommand(unref(menus)[0].children[0]);
    });
    return { __sfc: true, active, menus, setActive, handleCommand, handleMenu, setType };
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "sms-management-default" }, [_c("div", { staticClass: "sms-management-default-head" }, _vm._l(_setup.menus, function(menu, index2) {
    return _c("el-dropdown", { key: menu.keyword, staticClass: "sms-management-default-head-item", attrs: { "size": "mini", "tabindex": index2 }, on: { "command": _setup.handleCommand } }, [_c("el-button", { attrs: { "size": "mini", "type": _setup.setType(menu) } }, [_vm._v(" " + _vm._s(menu.label || menu.defaultLabel)), _c("i", { staticClass: "el-icon-arrow-down el-icon--right" })]), _c("el-dropdown-menu", { attrs: { "slot": "dropdown" }, slot: "dropdown" }, [_vm._l(menu.children, function(child) {
      return [_c("el-dropdown-item", { key: child.keyword, style: _setup.setActive(child), attrs: { "command": { ...child, index: index2 } } }, [_vm._v(_vm._s(child.label))])];
    })], 2)], 1);
  }), 1), _c("div", { staticClass: "sms-management-default-body" }, [_c(_setup.active.component, { key: _setup.active.keyword, tag: "components" })], 1)]);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "21a55dfd",
  null,
  null
);
const SmsManagementDefault = __component__$1.exports;
const Menu = {
  defaultID: "e7c011a06efa4db7b8514198dcbafcee",
  menu: [
    {
      id: "e7c011a06efa4db7b8514198dcbafcee",
      label: "\u8B66\u793A\u4FE1\u606F",
      component: SmsManagementDefault,
      render: false,
      fragment: true
    }
  ]
};
const index_vue_vue_type_style_index_0_scoped_90c365bb_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const Name = "sms-management-menu";
    const { menu, defaultID } = Menu;
    const active = ref$1(defaultID);
    const componentName = ref$1("");
    const setupDefaultActive = () => active.value = defaultID;
    useWatchRevert(Name, {
      setupDriver: setupDefaultActive
    });
    const handlerComponent = (cell) => {
      const { component, revert } = cell;
      componentName.value = component;
      revert && context.emit("onResolve", {
        ...cell,
        type: Name
      });
    };
    const handlerDialog = (cell) => {
    };
    return { __sfc: true, Name, menu, defaultID, active, componentName, setupDefaultActive, handlerComponent, handlerDialog, Menu, useWatchRevert };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("screen-grid-container", { scopedSlots: _vm._u([{ key: "head", fn: function() {
    return [_c("screen-grid-select", { attrs: { "icon": "el-icon-s-help", "active": _setup.active, "menu": _setup.menu, "width": 80 }, on: { "update:active": function($event) {
      _setup.active = $event;
    }, "toComponent": _setup.handlerComponent, "toDialog": _setup.handlerDialog }, scopedSlots: _vm._u([{ key: "default", fn: function(node) {
      return [_c("screen-grid-node", { attrs: { "node": node } })];
    } }]) })];
  }, proxy: true }, { key: "body", fn: function() {
    return [_c(_setup.componentName, { tag: "component" })];
  }, proxy: true }]) });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "90c365bb",
  null,
  null
);
const index = __component__.exports;
export {
  index as default
};
