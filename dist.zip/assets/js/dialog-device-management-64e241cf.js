import { j as computed, u as unref, r as ref$1, a as reactive, x as onMounted, z as elementUi_common } from "./element-ui-a9609798.js";
import { t as transFormData, g as get, n as normalizeComponent, G as isEmptyObject } from "./index-1ea80670.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { M as ModifyAddress, a as ModifyMethod } from "./index-33096253.js";
import { u as useService } from "./Application-7fa37401.js";
import "./usePopup-500740ad.js";
import "./useWatchRevert-58689033.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Modify_Server = service.define({
  url: ModifyAddress,
  method: ModifyMethod
});
function Modify_Obtain(props) {
  Modify_Server.server.config.bind("data", transFormData(props));
  return Modify_Server.obtain({ transResponse });
}
const dialogDeviceManagement_vue_vue_type_style_index_0_scoped_dcc68450_lang = "";
const _sfc_main = {
  __name: "dialog-device-management",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = Modify_Server.server;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const ModifyForm = ref$1();
    const form = reactive({
      devicename: null,
      devicetype: null,
      id: null,
      model: null,
      specs: null,
      price: 0,
      mill: null,
      supplier: null,
      director: null,
      phone: null,
      buytime: null,
      activationtime: null,
      service: null,
      scrap: null,
      depreciation: null,
      amount: 0
    });
    const rules = {
      devicename: [
        {
          required: true,
          message: "\u8BBE\u5907\u540D\u79F0\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      devicetype: [
        {
          required: true,
          message: "\u8BBE\u5907\u7C7B\u578B\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      activationtime: [
        {
          required: true,
          message: "\u542F\u7528\u65F6\u95F4\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "change"
        }
      ],
      service: [
        {
          required: true,
          message: "\u4FDD\u517B\u5468\u671F\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      scrap: [
        {
          required: true,
          message: "\u62A5\u5E9F\u5468\u671F\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function onModify() {
      console.log(unref(form));
      unref(ModifyForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await Modify_Obtain(unref(form));
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u4FDD\u5B58\u6210\u529F!"
          });
          dialog.destroy();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    function tomapper(body) {
      form.devicename = get(body, "devicename", null);
      form.devicetype = get(body, "devicetype", null);
      form.id = get(body, "id", null);
      form.model = get(body, "model", null);
      form.specs = get(body, "specs", null);
      form.price = get(body, "price", 0);
      form.mill = get(body, "mill", null);
      form.supplier = get(body, "supplier", null);
      form.director = get(body, "director", null);
      form.phone = get(body, "phone", null);
      form.buytime = get(body, "buytime", null);
      form.activationtime = get(body, "activationtime", null);
      form.service = get(body, "service", null);
      form.scrap = get(body, "scrap", null);
      form.depreciation = get(body, "depreciation", null);
      form.amount = get(body, "amount", 0);
    }
    onMounted(() => {
      tomapper(unref(config));
    });
    return { __sfc: true, props, loading, dialog, config, ModifyForm, form, rules, onModify, tomapper, isEmptyObject, useDialog, Modify_Server, Modify_Obtain, Notification: elementUi_common.exports.Notification };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-form", { ref: "ModifyForm", staticClass: "dialog-device-management", attrs: { "model": _setup.form, "rules": _setup.rules, "size": "mini", "label-position": "left", "label-width": "115px" } }, [_c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "id", "label": "\u8BBE\u5907\u7F16\u7801" } }, [_c("el-input", { attrs: { "type": "text", "disabled": true, "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8BBE\u5907\u7F16\u7801" }, model: { value: _setup.form.id, callback: function($$v) {
    _vm.$set(_setup.form, "id", $$v);
  }, expression: "form.id" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "devicename", "label": "\u8BBE\u5907\u540D\u79F0" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8BBE\u5907\u540D\u79F0" }, model: { value: _setup.form.devicename, callback: function($$v) {
    _vm.$set(_setup.form, "devicename", $$v);
  }, expression: "form.devicename" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 24 } }, [_c("el-form-item", { attrs: { "label": "\u8BBE\u5907\u578B\u53F7" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8BBE\u5907\u578B\u53F7" }, model: { value: _setup.form.model, callback: function($$v) {
    _vm.$set(_setup.form, "model", $$v);
  }, expression: "form.model" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "devicetype", "label": "\u8BBE\u5907\u7C7B\u578B" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8BBE\u5907\u7C7B\u578B" }, model: { value: _setup.form.devicetype, callback: function($$v) {
    _vm.$set(_setup.form, "devicetype", $$v);
  }, expression: "form.devicetype" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8BBE\u5907\u89C4\u683C" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8BBE\u5907\u89C4\u683C" }, model: { value: _setup.form.specs, callback: function($$v) {
    _vm.$set(_setup.form, "specs", $$v);
  }, expression: "form.specs" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8BBE\u5907\u5355\u4EF7(\u5143)" } }, [_c("el-input-number", { attrs: { "controls-position": "right" }, model: { value: _setup.form.price, callback: function($$v) {
    _vm.$set(_setup.form, "price", _vm._n($$v));
  }, expression: "form.price" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u751F\u4EA7\u5382\u5BB6" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u751F\u4EA7\u5382\u5BB6" }, model: { value: _setup.form.mill, callback: function($$v) {
    _vm.$set(_setup.form, "mill", $$v);
  }, expression: "form.mill" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u4F9B\u5E94\u5546" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u4F9B\u5E94\u5546" }, model: { value: _setup.form.supplier, callback: function($$v) {
    _vm.$set(_setup.form, "supplier", $$v);
  }, expression: "form.supplier" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8D1F\u8D23\u4EBA" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8D1F\u8D23\u4EBA" }, model: { value: _setup.form.director, callback: function($$v) {
    _vm.$set(_setup.form, "director", $$v);
  }, expression: "form.director" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8054\u7CFB\u7535\u8BDD" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u8054\u7CFB\u7535\u8BDD" }, model: { value: _setup.form.phone, callback: function($$v) {
    _vm.$set(_setup.form, "phone", $$v);
  }, expression: "form.phone" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8D2D\u4E70\u65F6\u95F4" } }, [_c("el-date-picker", { attrs: { "type": "datetime", "placeholder": "\u8BF7\u9009\u62E9\u8D2D\u4E70\u65F6\u95F4", "format": "yyyy-MM-dd HH:mm:ss", "value-format": "yyyy-MM-dd HH:mm:ss" }, model: { value: _setup.form.buytime, callback: function($$v) {
    _vm.$set(_setup.form, "buytime", $$v);
  }, expression: "form.buytime" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "activationtime", "label": "\u542F\u7528\u65F6\u95F4" } }, [_c("el-date-picker", { attrs: { "format": "yyyy-MM-dd HH:mm:ss", "value-format": "yyyy-MM-dd HH:mm:ss", "type": "datetime", "placeholder": "\u8BF7\u9009\u62E9\u542F\u7528\u65F6\u95F4" }, model: { value: _setup.form.activationtime, callback: function($$v) {
    _vm.$set(_setup.form, "activationtime", $$v);
  }, expression: "form.activationtime" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "service", "label": "\u4FDD\u517B\u5468\u671F(\u6708\uFF09" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u4FDD\u517B\u5468\u671F" }, model: { value: _setup.form.service, callback: function($$v) {
    _vm.$set(_setup.form, "service", $$v);
  }, expression: "form.service" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "prop": "scrap", "label": "\u62A5\u5E9F\u5468\u671F(\u5E74)" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u62A5\u5E9F\u5468\u671F" }, model: { value: _setup.form.scrap, callback: function($$v) {
    _vm.$set(_setup.form, "scrap", $$v);
  }, expression: "form.scrap" } })], 1)], 1), _c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u6298\u65E7\u5E74\u9650(\u5E74)" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-edit", "placeholder": "\u8BF7\u8F93\u5165\u6298\u65E7\u5E74\u9650" }, model: { value: _setup.form.depreciation, callback: function($$v) {
    _vm.$set(_setup.form, "depreciation", $$v);
  }, expression: "form.depreciation" } })], 1)], 1)], 1), _c("el-row", { attrs: { "gutter": 20 } }, [_c("el-col", { attrs: { "span": 12 } }, [_c("el-form-item", { attrs: { "label": "\u8BBE\u5907\u6570\u91CF" } }, [_c("el-input-number", { attrs: { "controls-position": "right" }, model: { value: _setup.form.amount, callback: function($$v) {
    _vm.$set(_setup.form, "amount", _vm._n($$v));
  }, expression: "form.amount" } })], 1)], 1)], 1), _c("el-form-item", { staticClass: "dialog-device-management-console" }, [_c("el-button", { staticClass: "dialog-device-management-console-button", attrs: { "type": "primary", "size": "mini", "loading": _setup.loading }, on: { "click": _setup.onModify } }, [_vm._v("\u4FDD\u5B58\u4FE1\u606F")])], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "dcc68450",
  null,
  null
);
const dialogDeviceManagement = __component__.exports;
export {
  dialogDeviceManagement as default
};
