import { a as axios, u as useService } from "./Application-7fa37401.js";
import { n as normalizeComponent, i as isNil, t as transFormData, g as get, u as useUserStore, h as isFunction, j as dayjs } from "./index-1ea80670.js";
import { _ as __$_require_0453fda3__ } from "./header-video-fd1f6550.js";
import "./element-ui-a9609798.js";
const EXPIRE_TIME = 4 * 60 * 60 * 1e3;
const CACHE_KEY = "yiketianqi";
function sendRequest() {
  return axios.request({
    url: "https://v0.yiketianqi.com/free/day",
    method: "GET",
    params: {
      appid: "75588717",
      appsecret: "a36EhJyo",
      city: "\u95E8\u5934\u6C9F"
    }
  });
}
async function getWeather() {
  const cache = localStorage.getItem(CACHE_KEY);
  const cacheData = JSON.parse(cache);
  const now = new Date().getTime();
  if (cacheData && cacheData.time && now - cacheData.time < EXPIRE_TIME)
    return Promise.resolve(cacheData);
  const res = await sendRequest();
  const data = res.data;
  localStorage.setItem(
    CACHE_KEY,
    JSON.stringify({
      time: now,
      data
    })
  );
  return Promise.resolve({ data });
}
const EXPIRATION_TIME = 300;
const weather_vue_vue_type_style_index_0_scoped_d8584f28_lang = "";
const _sfc_main$2 = {
  name: "weather",
  data() {
    return {
      weather: null
    };
  },
  computed: {
    weatherData() {
      return this.weather;
    },
    tem() {
      let tem = "";
      if (this.weatherData) {
        tem = this.weatherData.tem ? `${this.weatherData.tem}\xB0C` : "";
      }
      return `${tem}`;
    },
    alarm() {
      if (this.weatherData.alarm) {
        return `${this.weatherData.alarm}${this.weatherData.alarm.alarm_level}\u9884\u8B66`;
      }
      return "";
    },
    newestDate() {
      if (isNil(this.weather))
        return "";
      const { date, update_time } = this.weather;
      return `${date} ${update_time}`;
    }
  },
  methods: {
    getWeatherJson() {
      getWeather().then((res) => {
        const { data, status } = res;
        this.weather = data;
        tempStorage.set("weather", data, EXPIRATION_TIME);
      }).catch((err) => {
      });
    }
  },
  mounted() {
    this.getWeatherJson();
  }
};
var _sfc_render$2 = function render() {
  var _vm = this, _c = _vm._self._c;
  return _vm.weatherData !== null ? _c("div", { staticClass: "nd-weather" }, [_c("div", { staticClass: "nd-weather__info" }, [_c("span", { staticClass: "temperature" }, [_vm._v(_vm._s(_vm.tem))]), _c("span", { staticClass: "wea" }, [_vm._v(_vm._s(_vm.weatherData.wea))]), _c("span", { staticClass: "wea_day" }, [_vm._v(_vm._s(_vm.weatherData.wea_day))]), _c("ul", { staticClass: "other" }, [_c("li", { staticClass: "other__item" }, [_vm._v(" " + _vm._s(_vm.weatherData.win)), _c("span", { staticClass: "color__y" }, [_vm._v(_vm._s(_vm.weatherData.win_speed))])]), _c("li", { staticClass: "other__item" }, [_vm._v(" \u76F8\u5BF9\u6E7F\u5EA6"), _c("span", { staticClass: "color__b" }, [_vm._v(_vm._s(_vm.weatherData.humidity))])])])]), _c("p", { staticClass: "nd-weather-time" }, [_vm._v(" \u6700\u8FD1\u5237\u65B0\u65E5\u671F\uFF1A"), _c("a", [_vm._v(_vm._s(_vm.newestDate))])]), _c("div", { staticClass: "nd-weather__warn" }, [_vm._v(" " + _vm._s(_vm.alarm) + " ")])]) : _vm._e();
};
var _sfc_staticRenderFns$2 = [];
var __component__$2 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$2,
  _sfc_render$2,
  _sfc_staticRenderFns$2,
  false,
  null,
  "d8584f28",
  null,
  null
);
const Weather = __component__$2.exports;
const DefUserIcon = "/assets/def-user-icon-0c01a218.png";
const Address = "/logout";
const Method = "POST";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const LOGOUT_Server = service.define({
  url: Address,
  method: Method
});
function LOGOUT_Obtain(props) {
  LOGOUT_Server.server.config.bind("data", transFormData(props));
  return LOGOUT_Server.obtain({ transResponse });
}
function base64ToBit$2(base64Str) {
  const base64CodeMap = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const result = [];
  for (let i = 0; i < base64Str.length; i++) {
    let n = base64CodeMap.indexOf(base64Str[i]);
    result.push(n.toString(2).padStart(6, "0"));
  }
  return result.join("");
}
function checkDate$2(year, month, date) {
  if (year < 1901 || year > 2100) {
    throw new Error("Invalid Year");
  }
  if (month < 1 || month > 12) {
    throw new Error("Invalid Month");
  }
  if (date < 1 || date > 31) {
    throw new Error("Invalid Date");
  }
  if ([4, 6, 9, 11].indexOf(month) != -1 && date > 30) {
    throw new Error("Invalid Date");
  }
  if (month == 2) {
    if (date > 29) {
      throw new Error("Invalid Date");
    } else {
      let isLeap = false;
      if (year % 400 == 0) {
        isLeap = true;
      } else if (year % 4 == 0 && year % 100 != 0) {
        isLeap = true;
      }
      if (!isLeap && date > 28) {
        throw new Error("Invalid Date");
      }
    }
  }
}
var utils = {
  base64ToBit: base64ToBit$2,
  checkDate: checkDate$2
};
const { base64ToBit: base64ToBit$1, checkDate: checkDate$1 } = utils;
const names = [
  "\u5C0F\u5BD2",
  "\u5927\u5BD2",
  "\u7ACB\u6625",
  "\u96E8\u6C34",
  "\u60CA\u86F0",
  "\u6625\u5206",
  "\u6E05\u660E",
  "\u8C37\u96E8",
  "\u7ACB\u590F",
  "\u5C0F\u6EE1",
  "\u8292\u79CD",
  "\u590F\u81F3",
  "\u5C0F\u6691",
  "\u5927\u6691",
  "\u7ACB\u79CB",
  "\u5904\u6691",
  "\u767D\u9732",
  "\u79CB\u5206",
  "\u5BD2\u9732",
  "\u971C\u964D",
  "\u7ACB\u51AC",
  "\u5C0F\u96EA",
  "\u5927\u96EA",
  "\u51AC\u81F3"
];
const baseDate = [4, 19, 3, 18, 4, 19, 4, 19, 4, 20, 4, 20, 6, 22, 6, 22, 6, 22, 7, 22, 6, 21, 6, 21];
const table$1 = [];
function decompressData$1() {
  const codeStr = "ABCDAECDAECDFGHIJKHILKMILABNOABNOAENOAENOAEPQRGSTUGSTLAVTOAWXOAWXOAYXOAYZOabcdebcQUfgThijkOilXOimXOimXOimcOnocdpqcQrsgktujkvumXvumXvumcvumcvwocxyqcz0sj10s213u243um43um53wm56wq567q589s+/0s~/3u~!3u@#3um";
  const groupsStr = "paaqmqqpqaquqqqqqvruruqq6qWaWZqlqaqqqqqqlaaqmqqppaaqqqqqqrququqqqqWaWZaVlaaampqlpaaqqqqplaWampqlqaququqqqqWZWZVVlaWaWZqlqqVZWZVVlaWaWZaVlaaqmpqpqmVZVZVVVaWaWZaVlaWampqpqlVZVZVVqVVZVVVVVaWZWZVVqVVVVVVVVaVZWZVVpaaqmpqpqVFVVVVVVaVZVZVVlaWaWZalpaaampqppVFVRVVVVWVZVZVVlaWaWpqlpVFVRVVUVVVZVVVVVaWZWZaVVFVZVVVVVFVVVVVVpVFVRUVUVFFVVVVVpVFFRUVUVFFVRVVVlVBFRUVUUFFVRVVVlVBFBEVUUFFVRVVUlVBFBEVQUFFFRUVUlVBFBEFQUFBFRUVUlVBEBEFAQFBFBEVUVVBEBEFAVVVVVVVVQFBFBEVQVVBEBEAAVVAEAEAAQFBFBEFQUFBFBUVUQFBEBEFAUFBFBEVUVQAEAAAAAFBEBEFAVQAAAAAAAFBEBEAAVAAAAAAAAFBEAEAA";
  const groups = [];
  for (let i = 0; i < groupsStr.length; i += 8) {
    const groupBitStr = base64ToBit$1(groupsStr.substr(i, 8));
    const group = [];
    for (let j = 0; j < groupBitStr.length; j += 2) {
      group.push(+`0b${groupBitStr.substr(j, 2)}`);
    }
    groups.push(group);
  }
  const codeMapStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/~!@#";
  for (let i = 0; i < codeStr.length; i++) {
    table$1.push(groups[codeMapStr.indexOf(codeStr[i])]);
  }
}
decompressData$1();
function getSolarTerm$1(year, month, date) {
  year = Math.floor(+year);
  month = Math.floor(+month);
  date = Math.floor(+date);
  checkDate$1(year, month, date);
  const index = (month - 1) * 2 + (date < 15 ? 0 : 1);
  const d = baseDate[index] + table$1[year - 1901][index];
  if (date == d) {
    return names[index];
  } else {
    return null;
  }
}
var solar_term = { getSolarTerm: getSolarTerm$1 };
const { base64ToBit, checkDate } = utils;
const { getSolarTerm } = solar_term;
const table = [];
const heavenlyStemStr = "\u7532\u4E59\u4E19\u4E01\u620A\u5DF1\u5E9A\u8F9B\u58EC\u7678";
const earthlyBranchStr = "\u5B50\u4E11\u5BC5\u536F\u8FB0\u5DF3\u5348\u672A\u7533\u9149\u620C\u4EA5";
const zodiacStr = "\u9F20\u725B\u864E\u5154\u9F99\u86C7\u9A6C\u7F8A\u7334\u9E21\u72D7\u732A";
const lunarMonthStr = "\u6B63\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D\u5341\u51AC\u814A";
const nubmerStr = "\u4E00\u4E8C\u4E09\u56DB\u4E94\u516D\u4E03\u516B\u4E5D\u5341";
function decompressData() {
  const base64Str = "hLaCVwUrqpNDSYNlUaqgrUE1pJXQSuak2FJoaSrqlC1QNailtBK26TcElwpLWyWDUoNqJW1ArYJVySXgkuzJYNSg6lVtSC1oFbHJuCS58loZKhqU20oLVQVqSq2BLoSWlkrCpV7SoNlBaqqrUE2gpbNSuClcVKg6VBqpq1QVaglslK4KVwUmPpMGyrrVQVqCW1UroJWhSamk0NJY1ShaoFtTS2glbBJtKS4Ul1ZLBqUG1GraBVsEq6pLwSXBks2pQdSw1lBawKtlk2hJcGSyalQ1KDaUlqoK1PVbAl0JLVyVhUqFpSWqgrVlVqCXQUtspXBSsKk0dKg1UFapJtQS2alcFJwaTL0mDVMFqja1BLbaV0ErQpNbSWGkoapLtUC1oFbSStgk29JcKSwqlW1KDaQVtGq2CTeEl4JLgyWzUoOpQaqSrYFVwSXHkuDJZ9SoalBtKq1UFagptRS6ClsVKwqVC0prVQVqgq0lLoKWwUrOpODSbuUwaqCtVU2oJbBSuik4NFo6TBqkG1TNagVtBK5KToUWhoqWyUNUg";
  const bitStr = base64ToBit(base64Str);
  let solarDate = { y: 1900, m: 1, d: 31, obj: new Date(1900, 0, 31, 0, 0, 0, 0) };
  let heavenlyStem = 6;
  let earthlyBranch = 0;
  for (let i = 0; i < bitStr.length; ) {
    if (i + 16 >= bitStr.length) {
      break;
    }
    const head = bitStr.substr(i, 4);
    i += 4;
    const leapMonth = +`0b${head}`;
    const monthCount = leapMonth > 0 ? 13 : 12;
    const months = bitStr.substr(i, monthCount).split("").map((o) => +o);
    i += monthCount;
    table.push({
      solarDate,
      leapMonth,
      months,
      heavenlyStem,
      earthlyBranch
    });
    const dateCount = monthCount * 29 + months.filter((o) => o == 1).length;
    const newSolarDate = new Date(solarDate.y, solarDate.m - 1, solarDate.d + dateCount, 0, 0, 0, 0);
    solarDate = {
      y: newSolarDate.getFullYear(),
      m: newSolarDate.getMonth() + 1,
      d: newSolarDate.getDate(),
      obj: newSolarDate
    };
    heavenlyStem = (heavenlyStem + 1) % 10;
    earthlyBranch = (earthlyBranch + 1) % 12;
  }
}
decompressData();
function isBefore(base, target) {
  if (base.y != target.y) {
    return base.y > target.y;
  } else if (base.m != target.m) {
    return base.m > target.m;
  } else if (base.d != target.d) {
    return base.d > target.d;
  }
  return false;
}
function getLunarStr(month, date, isLeap) {
  const monthStr = `${isLeap ? "\u95F0" : ""}${lunarMonthStr[month - 1]}\u6708`;
  if (date <= 10) {
    return `${monthStr}\u521D${nubmerStr[date - 1]}`;
  } else if (date < 20) {
    return `${monthStr}\u5341${nubmerStr[date - 11]}`;
  } else if (date == 20) {
    return `${monthStr}\u5EFF\u5341`;
  } else if (date > 20) {
    return `${monthStr}\u5EFF${nubmerStr[date - 21]}`;
  } else {
    return `${monthStr}\u4E09\u5341`;
  }
}
function getLunar(year, month, date) {
  year = Math.floor(+year);
  month = Math.floor(+month);
  date = Math.floor(+date);
  checkDate(year, month, date);
  let index = year - 1900;
  let row = table[index];
  if (isBefore(row.solarDate, { y: year, m: month, d: date })) {
    index -= 1;
    row = table[index];
  }
  if (!row) {
    throw new Error("Invalid Date");
  }
  const targetDate = new Date(year, month - 1, date, 0, 0, 0, 0);
  let delta = Math.round((targetDate.getTime() - row.solarDate.obj.getTime()) / (24 * 60 * 60 * 1e3));
  let afterLeap = false;
  for (let i = 0; i < row.months.length; i++) {
    const isLeap = row.leapMonth > 0 && i == row.leapMonth;
    if (isLeap) {
      afterLeap = true;
    }
    const days = 29 + row.months[i];
    if (delta < days) {
      let lunarMonth = afterLeap ? i : i + 1;
      return {
        lunarMonth,
        lunarDate: delta + 1,
        isLeap,
        solarTerm: getSolarTerm(year, month, date),
        lunarYear: `${heavenlyStemStr[row.heavenlyStem]}${earthlyBranchStr[row.earthlyBranch]}\u5E74`,
        zodiac: `${zodiacStr[row.earthlyBranch]}`,
        dateStr: getLunarStr(lunarMonth, delta + 1, isLeap)
      };
    } else {
      delta -= days;
    }
  }
  throw new Error(`There's something wrong!`);
}
var lunar_calendar = { getLunar };
const userController_vue_vue_type_style_index_0_scoped_df376f00_lang = "";
const _sfc_main$1 = {
  name: "ytxd-user-controller",
  mixins: [],
  components: {},
  props: {},
  data() {
    return {
      userIcon: DefUserIcon,
      userName: useUserStore().truename || "\u7BA1\u7406\u5458",
      getLunarDay: "",
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      date: new Date().getDate(),
      dateDay: null,
      dateYear: null,
      dateWeek: null,
      weekday: ["\u661F\u671F\u65E5", "\u661F\u671F\u4E00", "\u661F\u671F\u4E8C", "\u661F\u671F\u4E09", "\u661F\u671F\u56DB", "\u661F\u671F\u4E94", "\u661F\u671F\u516D"],
      timer: null
    };
  },
  computed: {},
  watch: {},
  methods: {
    handleUser() {
    },
    handleCommand(command) {
      const func = this[command];
      isFunction(func) && func();
    },
    userLogout() {
      LOGOUT_Obtain().then(this.clearCache).catch((error) => {
        console.log(error);
      });
    },
    clearCache() {
      useUserStore().emptyUserInfo();
      this.$router.push({ name: "login" });
    }
  },
  created() {
  },
  mounted() {
    this.getLunarDay = lunar_calendar.getLunar(this.year, this.month, this.date);
    this.timer = setInterval(() => {
      const date = dayjs(new Date());
      this.dateDay = date.format("HH:mm:ss");
      this.dateYear = date.format("YYYY-MM-DD");
      this.dateWeek = date.format(this.weekday[date.day()]);
    }, 1e3);
  },
  beforeCreate() {
  },
  beforeMount() {
  },
  beforeUpdate() {
  },
  updated() {
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  },
  destroyed() {
  },
  activated() {
  }
};
var _sfc_render$1 = function render2() {
  var _vm = this, _c = _vm._self._c;
  return _c("div", { staticClass: "ytxd-user-controller" }, [_c("div", { staticClass: "time-display" }, [_c("p", { staticClass: "boxDay" }, [_vm._v(_vm._s(_vm.dateDay))]), _c("div", { staticClass: "time-disply-ri" }, [_c("p", { staticClass: "boxWeek" }, [_vm._v(_vm._s(_vm.dateYear) + " " + _vm._s(_vm.dateWeek))]), _c("p", { staticClass: "boxNl" }, [_vm._v("\u519C\u5386" + _vm._s(_vm.getLunarDay.dateStr))])])]), _c("el-dropdown", { staticClass: "user-handler", attrs: { "size": "small", "split-button": "", "type": "primary" }, on: { "command": _vm.handleCommand, "click": _vm.handleUser } }, [_vm._v(" " + _vm._s(_vm.userName) + " "), _c("el-dropdown-menu", { attrs: { "slot": "dropdown" }, slot: "dropdown" }, [_c("el-dropdown-item", { attrs: { "command": "userLogout" } }, [_vm._v("\u6CE8\u9500\u767B\u5F55")]), _c("el-dropdown-item", { attrs: { "command": "clearCache", "divided": "" } }, [_vm._v("\u6E05\u7406\u7F13\u5B58")])], 1)], 1), _c("div", { staticClass: "user-icon" }, [_c("img", { attrs: { "src": _vm.userIcon } })])], 1);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "df376f00",
  null,
  null
);
const UserController = __component__$1.exports;
const Home_vue_vue_type_style_index_0_scoped_9c599c5a_lang = "";
const _sfc_main = {
  __name: "Home",
  setup(__props) {
    return { __sfc: true, Weather, UserController };
  }
};
var _sfc_render = function render3() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-container", { staticClass: "home" }, [_c("video", { attrs: { "id": "v1", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } }, [_c("source", { attrs: { "src": __$_require_0453fda3__, "type": "video/mp4" } })]), _c("el-header", { staticClass: "home-header" }, [_c("div", { staticClass: "home-header-weather" }, [_c(_setup.Weather)], 1), _c(_setup.UserController)], 1), _c("el-container", { staticClass: "home-main" }, [_c("el-main", { staticClass: "home-main-content" }, [_c("transition", { attrs: { "name": "el-fade-in-linear" } }, [_c("router-view")], 1)], 1)], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "9c599c5a",
  null,
  null
);
const Home = __component__.exports;
export {
  Home as default
};
