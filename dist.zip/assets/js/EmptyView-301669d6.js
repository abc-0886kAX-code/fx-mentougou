import { n as normalizeComponent } from "./index-1ea80670.js";
import "./element-ui-a9609798.js";
const EmptyView_vue_vue_type_style_index_0_scoped_56eb7808_lang = "";
const _sfc_main = {
  __name: "EmptyView",
  props: {
    desc: {
      type: String,
      default: "\u62B1\u6B49\uFF0C\u8BBF\u95EE\u8D44\u6E90\u4E0D\u5B58\u5728"
    }
  },
  setup(__props) {
    const props = __props;
    return { __sfc: true, props };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("el-empty", { staticClass: "furnace-empty", attrs: { "description": _vm.desc } });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "56eb7808",
  null,
  null
);
const EmptyView = __component__.exports;
export {
  EmptyView as default
};
