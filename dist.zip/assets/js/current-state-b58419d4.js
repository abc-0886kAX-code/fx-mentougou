import { j as computed, u as unref, x as onMounted } from "./element-ui-a9609798.js";
import { t as transFormData, g as get, n as normalizeComponent, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { u as useService } from "./Application-7fa37401.js";
const Address = "/realData/getAddvcditem";
const Method = "POST";
const msg = "success";
const total = 3;
const code = 200;
const data = [
  {
    id: "9c48a7426cea43fba4cef4e4356f0f7d",
    stnm: "\u76D1\u6D4B\u70B91",
    info: "\u5F53\u524D\u79EF\u6C340.01\u7C73\uFF0C\u6CE8\u610F\u5B89\u5168"
  },
  {
    id: "71ca68cc961041cba3892d1e224b48d6",
    stnm: "\u76D1\u6D4B\u70B92",
    info: "\u5F53\u524D\u79EF\u6C340.02\u7C73\uFF0C\u6CE8\u610F\u5B89\u5168"
  },
  {
    id: "04b61bf537744d8db7a48ed92395556d",
    stnm: "\u76D1\u6D4B\u70B93",
    info: "\u5F53\u524D\u79EF\u6C340.03\u7C73\uFF0C\u6CE8\u610F\u5B89\u5168"
  }
];
const CurrentState = {
  msg,
  total,
  code,
  data
};
const service = useService();
function transResponse(response) {
  const data2 = get(CurrentState, "data", []);
  return { data: data2 };
}
const CurrentState_Server = service.define({
  url: Address,
  method: Method
});
function CurrentState_Obtain(props) {
  CurrentState_Server.server.config.bind("data", transFormData(props));
  return CurrentState_Server.obtain({ transResponse });
}
const currentState_vue_vue_type_style_index_0_scoped_94e7cbe9_lang = "";
const _sfc_main = {
  __name: "current-state",
  setup(__props) {
    const { loading } = CurrentState_Server.server;
    const tableData = computed(() => transArray(unref(CurrentState_Server.server.result.source).data, []));
    const tableColumn = [
      {
        prop: "stnm",
        label: "\u7AD9\u70B9",
        align: "center"
      },
      {
        prop: "info",
        label: "LED\u5C4F\u5F53\u524D\u4FE1\u606F",
        align: "center"
      }
    ];
    async function executeQuery() {
      await CurrentState_Obtain();
    }
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, loading, tableData, tableColumn, executeQuery, transArray, loadStyle, CurrentState_Server, CurrentState_Obtain };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "current-state", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "50", "align": "center" } }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "94e7cbe9",
  null,
  null
);
const currentState = __component__.exports;
export {
  currentState as default
};
