import { k as isSymbol, l as isObject, o as isIterateeCall, p as baseSlice, n as normalizeComponent, q as mars3d, r as isNumber, m as mergeObject, u as useUserStore, s as isBoolean, _ as __vitePreload } from "./index-1ea80670.js";
import { j as computed, u as unref, q as provide, v as defineComponent } from "./element-ui-a9609798.js";
var reWhitespace = /\s/;
function trimmedEndIndex(string) {
  var index = string.length;
  while (index-- && reWhitespace.test(string.charAt(index))) {
  }
  return index;
}
var reTrimStart = /^\s+/;
function baseTrim(string) {
  return string ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, "") : string;
}
var NAN = 0 / 0;
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
var reIsBinary = /^0b[01]+$/i;
var reIsOctal = /^0o[0-7]+$/i;
var freeParseInt = parseInt;
function toNumber(value) {
  if (typeof value == "number") {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == "function" ? value.valueOf() : value;
    value = isObject(other) ? other + "" : other;
  }
  if (typeof value != "string") {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
}
var INFINITY = 1 / 0, MAX_INTEGER = 17976931348623157e292;
function toFinite(value) {
  if (!value) {
    return value === 0 ? value : 0;
  }
  value = toNumber(value);
  if (value === INFINITY || value === -INFINITY) {
    var sign = value < 0 ? -1 : 1;
    return sign * MAX_INTEGER;
  }
  return value === value ? value : 0;
}
function toInteger(value) {
  var result = toFinite(value), remainder = result % 1;
  return result === result ? remainder ? result - remainder : result : 0;
}
var nativeCeil = Math.ceil, nativeMax = Math.max;
function chunk(array, size, guard) {
  if (guard ? isIterateeCall(array, size, guard) : size === void 0) {
    size = 1;
  } else {
    size = nativeMax(toInteger(size), 0);
  }
  var length = array == null ? 0 : array.length;
  if (!length || size < 1) {
    return [];
  }
  var index = 0, resIndex = 0, result = Array(nativeCeil(length / size));
  while (index < length) {
    result[resIndex++] = baseSlice(array, index, index += size);
  }
  return result;
}
const containerLayout_vue_vue_type_style_index_0_scoped_6d8a3782_lang = "";
const _sfc_main$1 = {
  name: "container-layout",
  mixins: [],
  components: {},
  props: {
    position: {
      type: String,
      default: "right"
    },
    width: {
      type: String,
      default: "300px"
    },
    height: {
      type: String,
      default: "auto"
    }
  },
  data() {
    return {
      switch: true,
      bodyWidth: 0,
      bodyHeight: 0
    };
  },
  computed: {
    isRight() {
      return this.position === "right";
    },
    isLeft() {
      return this.position === "left";
    },
    pos() {
      if (this.isRight)
        return "right";
      if (this.isLeft)
        return "left";
      return "right";
    },
    backPos() {
      if (this.isRight)
        return "left";
      if (this.isLeft)
        return "right";
      return "right";
    },
    switchClassName() {
      let stateClassName;
      if (this.pos === "left") {
        stateClassName = this.switch ? "container-layout-switch-right container-layout-switch-open el-icon-caret-left" : "container-layout-switch-right container-layout-switch-close  el-icon-caret-right";
      } else {
        stateClassName = this.switch ? "container-layout-switch container-layout-switch-open el-icon-caret-right" : "container-layout-switch container-layout-switch-close  el-icon-caret-left";
      }
      return stateClassName;
    },
    switchStyle() {
      return {
        [this.backPos]: "-25px"
      };
    },
    layoutBodyPosition() {
      const offset = this.switch ? `10px` : `-${this.bodyWidth}px`;
      return offset;
    },
    layoutStyle() {
      return {
        width: this.width,
        height: this.height,
        [this.pos]: this.layoutBodyPosition
      };
    }
  },
  watch: {},
  methods: {
    handlerSwitch() {
      this.switch = !this.switch;
    }
  },
  created() {
  },
  mounted() {
    this.$nextTick(() => {
      const { clientWidth, clientHeight } = this.$refs.containerBody;
      this.bodyWidth = clientWidth;
      this.bodyHeight = clientHeight;
      this.$emit("bodySize", {
        width: clientWidth,
        height: clientHeight
      });
    });
  },
  beforeCreate() {
  },
  beforeMount() {
  },
  beforeUpdate() {
  },
  updated() {
  },
  beforeDestroy() {
  },
  destroyed() {
  },
  activated() {
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c;
  return _c("div", { staticClass: "container-layout", style: _vm.layoutStyle }, [_c("i", { class: _vm.switchClassName, style: _vm.switchStyle, on: { "click": _vm.handlerSwitch } }), _c("div", { ref: "containerBody", staticClass: "container-layout-body" }, [_vm._t("default", function() {
    return [_c("ytxd-empty", { attrs: { "text": "\u8FD8\u6CA1\u6709\u589E\u52A0\u5185\u5BB9", "color": "#F7EED6" } })];
  })], 2)]);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "6d8a3782",
  null,
  null
);
const ContainerLayout = __component__$1.exports;
const black_basemap = "/assets/black_basemap-ef08544a.png";
const blue_basemap = "/assets/blue_basemap-2ac6bbba.png";
const darkcolor_basemap = "/assets/darkcolor_basemap-44b0782e.png";
const electronics_basemap = "/assets/electronics_basemap-fd45fc09.png";
const image_basemap = "/assets/image_basemap-49fd07fe.png";
const solidcolor_basemap = "/assets/solidcolor_basemap-1bf31e09.png";
const { VITE_CESIUMTOKEN: VITE_CESIUMTOKEN$1, VITE_TIANMAPKEY: VITE_TIANMAPKEY$1, VITE_ROOT_LAYERID: VITE_ROOT_LAYERID$1, VITE_OFFLINEMAP_URL: VITE_OFFLINEMAP_URL$1, VITE_OFFLINEMAP_LEVEL: VITE_OFFLINEMAP_LEVEL$1 } = { "VITE_TIANMAPKEY": "ef590000990e247813bf916bdce1d941", "VITE_CESIUMTOKEN": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3YjM0MTYyYi04NTYzLTQ1NTYtODcyYi1hOTVmNTYyZjM5NTgiLCJpZCI6ODQyMzUsImlhdCI6MTY0NjE4MzcwMX0.OFhvwBV25dveooJxFo7Y5MWLmrL910eYyIjvRcblS9I", "VITE_ROOT_LAYERID": "1000", "VITE_BASE_URL": "http://127.0.0.1:7096/", "VITE_BASE_PREFIX": "/Mentougou", "VITE_ASSETS": "/", "VITE_OFFLINEMAP_URL": "/", "VITE_OFFLINEMAP_LEVEL": "14", "BASE_URL": "/", "MODE": "production", "DEV": false, "PROD": true };
const setupConfigDev = (mode = 3) => {
  const config = {
    scene: {
      globe: {
        show: true,
        baseColor: "#333333",
        depthTestAgainstTerrain: true,
        showGroundAtmosphere: true,
        enableLighting: false,
        tileCacheSize: 1024,
        terrainExaggeration: 1,
        terrainExaggerationRelativeHeight: 0
      },
      cameraController: {
        zoomFactor: 3,
        constrainedAxis: true,
        minimumZoomDistance: 1,
        maximumZoomDistance: 5e7,
        minimumCollisionTerrainHeight: 8e4,
        enableRotate: true,
        enableTranslate: true,
        enableTilt: true,
        enableZoom: true,
        enableCollisionDetection: true
      },
      removeDblClick: true,
      ionToken: VITE_CESIUMTOKEN$1,
      resolutionScale: 1,
      showSun: true,
      showMoon: true,
      showSkyBox: true,
      showSkyAtmosphere: true,
      fog: true,
      fxaa: true,
      highDynamicRange: false,
      backgroundColor: "#333333",
      sceneMode: mode,
      scene3DOnly: false,
      shouldAnimate: true,
      shadows: false,
      useDefaultRenderLoop: true,
      targetFrameRate: 60,
      useBrowserRecommendedResolution: true,
      automaticallyTrackDataSourceClocks: true,
      orderIndependentTranslucency: true,
      requestRenderMode: true
    },
    mouseOptionsmap: {
      enabledMoveTarget: true,
      moveDelay: 0
    },
    control: {
      distanceLegend: { bottom: "30px", left: "0px" },
      contextmenu: {
        hasDefault: true
      },
      mouseDownView: true,
      infoBox: false,
      selectionIndicator: false,
      animation: false,
      timeline: false,
      baseLayerPicker: false,
      fullscreenButton: false,
      vrButton: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      projectionPicker: false,
      navigationHelpButton: false,
      navigationInstructionsInitiallyVisible: false,
      showRenderLoopErrors: true
    },
    terrain: {},
    basemaps: [
      {
        type: "group",
        id: 10,
        name: "\u529F\u80FD\u56FE\u5C42"
      },
      {
        show: false,
        name: "\u79BB\u7EBF\u5730\u56FE",
        icon: image_basemap,
        type: "tms",
        url: `${VITE_OFFLINEMAP_URL$1}maps`,
        crs: mars3d.exports.CRS.EPSG3857,
        minimumLevel: 0,
        maximumLevel: VITE_OFFLINEMAP_LEVEL$1,
        fileExtension: "png",
        rectangle: {
          xmin: 117.155295610428,
          xmax: 119.225703477859,
          ymax: 33.2195341587067,
          ymin: 31.8527548939665
        }
      },
      {
        show: true,
        type: "group",
        pid: 10,
        id: 11,
        name: "\u5F71\u50CF\u5E95\u56FE",
        icon: image_basemap,
        layers: [
          {
            type: "tdt",
            pid: 11,
            id: 12,
            name: "\u5929\u5730\u56FE-\u5F71\u50CF\u56FE",
            layer: "img_d",
            key: [VITE_TIANMAPKEY$1]
          },
          {
            type: "tdt",
            pid: 11,
            id: 13,
            name: "\u5929\u5730\u56FE-\u5F71\u50CF\u56FE\u6807\u6CE8",
            layer: "img_z",
            key: [VITE_TIANMAPKEY$1]
          }
        ]
      },
      {
        type: "group",
        pid: 10,
        id: 14,
        name: "\u7535\u5B50\u5E95\u56FE",
        icon: electronics_basemap,
        layers: [
          {
            type: "tdt",
            pid: 14,
            id: 15,
            name: "\u5929\u5730\u56FE-\u7535\u5B50\u56FE",
            layer: "vec_d",
            key: [VITE_TIANMAPKEY$1]
          },
          {
            type: "tdt",
            pid: 14,
            id: 16,
            name: "\u5929\u5730\u56FE-\u7535\u5B50\u56FE\u6807\u6CE8",
            layer: "vec_z",
            key: [VITE_TIANMAPKEY$1]
          }
        ]
      },
      {
        type: "gaode",
        id: 17,
        pid: 10,
        name: "\u6697\u8272\u5E95\u56FE",
        icon: darkcolor_basemap,
        layer: "vec",
        invertColor: true,
        filterColor: "#4e70a6",
        brightness: 0.6,
        contrast: 1.8,
        gamma: 0.3,
        hue: 1,
        saturation: 0
      },
      {
        type: "xyz",
        id: 18,
        pid: 10,
        name: "\u84DD\u8272\u5E95\u56FE",
        icon: blue_basemap,
        url: "http://map.geoq.cn/arcgis/rest/services/ChinaOnlineStreetPurplishBlue/MapServer/tile/{z}/{y}/{x}",
        chinaCRS: "GCJ02",
        enablePickFeatures: false
      },
      {
        type: "tencent",
        id: 19,
        pid: 10,
        name: "\u9ED1\u8272\u5E95\u56FE",
        icon: black_basemap,
        layer: "custom",
        style: "4"
      },
      {
        name: "\u7EAF\u8272\u5E95\u56FE",
        icon: solidcolor_basemap,
        type: "gaode",
        layer: "vec",
        invertColor: true,
        filterColor: "#000000",
        brightness: 0.6,
        contrast: 1.8,
        gamma: 0.3,
        hue: 1,
        saturation: 0
      }
    ],
    layers: [
      {
        type: "group",
        id: 100,
        name: "SupportLayerGroup"
      },
      {
        type: "group",
        id: +VITE_ROOT_LAYERID$1,
        name: "BusinessLayerGroup"
      }
    ]
  };
  return config;
};
const { VITE_CESIUMTOKEN, VITE_TIANMAPKEY, VITE_ROOT_LAYERID, VITE_OFFLINEMAP_URL, VITE_OFFLINEMAP_LEVEL } = { "VITE_TIANMAPKEY": "ef590000990e247813bf916bdce1d941", "VITE_CESIUMTOKEN": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3YjM0MTYyYi04NTYzLTQ1NTYtODcyYi1hOTVmNTYyZjM5NTgiLCJpZCI6ODQyMzUsImlhdCI6MTY0NjE4MzcwMX0.OFhvwBV25dveooJxFo7Y5MWLmrL910eYyIjvRcblS9I", "VITE_ROOT_LAYERID": "1000", "VITE_BASE_URL": "http://127.0.0.1:7096/", "VITE_BASE_PREFIX": "/Mentougou", "VITE_ASSETS": "/", "VITE_OFFLINEMAP_URL": "/", "VITE_OFFLINEMAP_LEVEL": "14", "BASE_URL": "/", "MODE": "production", "DEV": false, "PROD": true };
const setupConfigPro = (mode = 3) => {
  const config = {
    scene: {
      globe: {
        show: true,
        baseColor: "#333333",
        depthTestAgainstTerrain: true,
        showGroundAtmosphere: true,
        enableLighting: false,
        tileCacheSize: 1024,
        terrainExaggeration: 1,
        terrainExaggerationRelativeHeight: 0
      },
      cameraController: {
        zoomFactor: 3,
        constrainedAxis: true,
        minimumZoomDistance: 1,
        maximumZoomDistance: 5e7,
        minimumCollisionTerrainHeight: 8e4,
        enableRotate: true,
        enableTranslate: true,
        enableTilt: true,
        enableZoom: true,
        enableCollisionDetection: true
      },
      removeDblClick: true,
      ionToken: VITE_CESIUMTOKEN,
      resolutionScale: 1,
      showSun: true,
      showMoon: true,
      showSkyBox: true,
      showSkyAtmosphere: true,
      fog: true,
      fxaa: true,
      highDynamicRange: false,
      backgroundColor: "#333333",
      sceneMode: mode,
      scene3DOnly: false,
      shouldAnimate: true,
      shadows: false,
      useDefaultRenderLoop: true,
      targetFrameRate: 60,
      useBrowserRecommendedResolution: true,
      automaticallyTrackDataSourceClocks: true,
      orderIndependentTranslucency: true,
      requestRenderMode: true
    },
    mouseOptionsmap: {
      enabledMoveTarget: true,
      moveDelay: 0
    },
    control: {
      distanceLegend: { bottom: "30px", left: "0px" },
      contextmenu: {
        hasDefault: true
      },
      mouseDownView: true,
      infoBox: false,
      selectionIndicator: false,
      animation: false,
      timeline: false,
      baseLayerPicker: false,
      fullscreenButton: false,
      vrButton: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      projectionPicker: false,
      navigationHelpButton: false,
      navigationInstructionsInitiallyVisible: false,
      showRenderLoopErrors: true
    },
    terrain: {},
    basemaps: [
      {
        type: "group",
        id: 10,
        name: "\u529F\u80FD\u56FE\u5C42"
      },
      {
        show: false,
        name: "\u79BB\u7EBF\u5730\u56FE",
        icon: image_basemap,
        type: "tms",
        url: `${VITE_OFFLINEMAP_URL}quzhoutest`,
        crs: mars3d.exports.CRS.EPSG3857,
        minimumLevel: 0,
        maximumLevel: VITE_OFFLINEMAP_LEVEL,
        fileExtension: "png",
        rectangle: { xmax: 118.386224733068, ymax: 32.2503661166022, ymin: 32.2115498736139, xmin: 118.340455518438 }
      },
      {
        show: true,
        type: "group",
        pid: 10,
        id: 11,
        name: "\u5F71\u50CF\u5E95\u56FE",
        icon: image_basemap,
        layers: [
          {
            type: "tdt",
            pid: 11,
            id: 12,
            name: "\u5929\u5730\u56FE-\u5F71\u50CF\u56FE",
            layer: "img_d",
            key: [VITE_TIANMAPKEY]
          },
          {
            type: "tdt",
            pid: 11,
            id: 13,
            name: "\u5929\u5730\u56FE-\u5F71\u50CF\u56FE\u6807\u6CE8",
            layer: "img_z",
            key: [VITE_TIANMAPKEY]
          }
        ]
      },
      {
        type: "group",
        pid: 10,
        id: 14,
        name: "\u7535\u5B50\u5E95\u56FE",
        icon: electronics_basemap,
        layers: [
          {
            type: "tdt",
            pid: 14,
            id: 15,
            name: "\u5929\u5730\u56FE-\u7535\u5B50\u56FE",
            layer: "vec_d",
            key: [VITE_TIANMAPKEY]
          },
          {
            type: "tdt",
            pid: 14,
            id: 16,
            name: "\u5929\u5730\u56FE-\u7535\u5B50\u56FE\u6807\u6CE8",
            layer: "vec_z",
            key: [VITE_TIANMAPKEY]
          }
        ]
      },
      {
        type: "gaode",
        id: 17,
        pid: 10,
        name: "\u6697\u8272\u5E95\u56FE",
        icon: darkcolor_basemap,
        layer: "vec",
        invertColor: true,
        filterColor: "#4e70a6",
        brightness: 0.6,
        contrast: 1.8,
        gamma: 0.3,
        hue: 1,
        saturation: 0
      },
      {
        type: "xyz",
        id: 18,
        pid: 10,
        name: "\u84DD\u8272\u5E95\u56FE",
        icon: blue_basemap,
        url: "http://map.geoq.cn/arcgis/rest/services/ChinaOnlineStreetPurplishBlue/MapServer/tile/{z}/{y}/{x}",
        chinaCRS: "GCJ02",
        enablePickFeatures: false
      },
      {
        type: "tencent",
        id: 19,
        pid: 10,
        name: "\u9ED1\u8272\u5E95\u56FE",
        icon: black_basemap,
        layer: "custom",
        style: "4"
      },
      {
        name: "\u7EAF\u8272\u5E95\u56FE",
        icon: solidcolor_basemap,
        type: "gaode",
        layer: "vec",
        invertColor: true,
        filterColor: "#000000",
        brightness: 0.6,
        contrast: 1.8,
        gamma: 0.3,
        hue: 1,
        saturation: 0
      }
    ],
    layers: [
      {
        type: "group",
        id: 100,
        name: "SupportLayerGroup"
      },
      {
        type: "group",
        id: +VITE_ROOT_LAYERID,
        name: "BusinessLayerGroup"
      }
    ]
  };
  return config;
};
const { MODE } = { "VITE_TIANMAPKEY": "ef590000990e247813bf916bdce1d941", "VITE_CESIUMTOKEN": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3YjM0MTYyYi04NTYzLTQ1NTYtODcyYi1hOTVmNTYyZjM5NTgiLCJpZCI6ODQyMzUsImlhdCI6MTY0NjE4MzcwMX0.OFhvwBV25dveooJxFo7Y5MWLmrL910eYyIjvRcblS9I", "VITE_ROOT_LAYERID": "1000", "VITE_BASE_URL": "http://127.0.0.1:7096/", "VITE_BASE_PREFIX": "/Mentougou", "VITE_ASSETS": "/", "VITE_OFFLINEMAP_URL": "/", "VITE_OFFLINEMAP_LEVEL": "14", "BASE_URL": "/", "MODE": "production", "DEV": false, "PROD": true };
const isDEV = MODE === "development";
const setupMars3DConfig = (mode = 3) => {
  if (isNumber(mode))
    return isDEV ? setupConfigDev(mode) : setupConfigPro(mode);
  return mergeObject(isDEV ? setupConfigDev(mode.mode) : setupConfigPro(mode.mode), mode);
};
const UserIdentityModules = "userModules";
const ADMIN = "admin";
const USER = "user";
const IdentityType = {
  [ADMIN]: "0",
  [USER]: "1"
};
const UserIdentity = {
  identity: IdentityType.admin
};
function transformCacheKeyword(value, expect) {
  if (isBoolean(value) && !value)
    return expect;
  return value;
}
function transformIdentityToNumber(value) {
  if (isNumber(+value))
    return +value;
  return 0;
}
function getUserIdentity() {
  const user = useUserStore();
  const identity = transformCacheKeyword(user.userpower, UserIdentity.identity);
  const identityToNumber = () => transformIdentityToNumber(identity);
  return {
    identity,
    identityToNumber
  };
}
const filterPowerToModule = (identity) => (item) => {
  var _a;
  const mapping = (_a = item == null ? void 0 : item.power) != null ? _a : [];
  return mapping.includes(identity);
};
const sortPowerToModule = (prev, next) => {
  var _a, _b;
  const prevValue = (_a = prev == null ? void 0 : prev.sort) != null ? _a : 0;
  const nextValue = (_b = next == null ? void 0 : next.sort) != null ? _b : 0;
  return prevValue - nextValue;
};
function setupModulesPosition(index) {
  return index % 2 <= 0 ? "right" : "left";
}
function useUserHomeModule(moduleGather) {
  const Identity = getUserIdentity();
  const { identityToNumber } = Identity;
  const modules = computed(() => {
    const data = moduleGather.filter(filterPowerToModule(identityToNumber())).sort(sortPowerToModule);
    return chunk(data, 3).reverse();
  });
  const moduleContainerNumber = computed(() => unref(modules).length);
  provide(UserIdentityModules, {
    modules,
    moduleContainerNumber
  });
  return {
    modules,
    moduleContainerNumber,
    setupModulesPosition
  };
}
const DataOverview = defineComponent(() => __vitePreload(() => import("./index-9706d3fe.js").then((n) => n.i), true ? ["assets/js/index-9706d3fe.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/useMars3D-c560a623.js","assets/js/default_legend_icon-fcdb82ea.js","assets/js/Application-7fa37401.js","assets/js/index-4cdc94bd.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-e195207d.css"] : void 0));
const DeviceManagement = defineComponent(() => __vitePreload(() => import("./index-33096253.js").then((n) => n.i), true ? ["assets/js/index-33096253.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/usePopup-500740ad.js","assets/js/Application-7fa37401.js","assets/js/useWatchRevert-58689033.js","assets/index-13380bca.css"] : void 0));
const RealTimeMonitor = defineComponent(() => __vitePreload(() => import("./index-6e1ceacf.js"), true ? ["assets/js/index-6e1ceacf.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/Application-7fa37401.js","assets/js/useMars3D-c560a623.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-7d770716.css"] : void 0));
const SmsManagement = defineComponent(() => __vitePreload(() => import("./index-7794fa9d.js"), true ? ["assets/js/index-7794fa9d.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/useWatchRevert-58689033.js","assets/index-8402bdf2.css"] : void 0));
const StatisticalAnalysis = defineComponent(() => __vitePreload(() => import("./index-6ca296ff.js"), true ? ["assets/js/index-6ca296ff.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/index-4cdc94bd.js","assets/js/Application-7fa37401.js","assets/js/useDate-287f32d4.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-9b611f5a.css"] : void 0));
const SystemManagement = defineComponent(() => __vitePreload(() => import("./index-e5232b3d.js").then((n) => n.i), true ? ["assets/js/index-e5232b3d.js","assets/js/element-ui-a9609798.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/usePopup-500740ad.js","assets/js/Application-7fa37401.js","assets/js/useWatchRevert-58689033.js","assets/index-4564cb7f.css"] : void 0));
const BusinessModules = [
  {
    name: "data-overview",
    component: DataOverview,
    className: ["data-overview"],
    power: [0, 1],
    sort: 1
  },
  {
    name: "real-time-monitor",
    component: RealTimeMonitor,
    className: ["real-time-monitor"],
    power: [0, 1],
    sort: 2
  },
  {
    name: "statistical-analysis",
    component: StatisticalAnalysis,
    className: ["statistical-analysis"],
    power: [0, 1],
    sort: 3
  },
  {
    name: "sms-management",
    component: SmsManagement,
    className: ["sms-management"],
    power: [0],
    sort: 4
  },
  {
    name: "device-management",
    component: DeviceManagement,
    className: ["device-management"],
    power: [0],
    sort: 5
  },
  {
    name: "system-management",
    component: SystemManagement,
    className: ["system-management"],
    power: [0],
    sort: 6
  }
];
const LayerLegend = defineComponent(() => __vitePreload(() => import("./index-ed616795.js"), true ? ["assets/js/index-ed616795.js","assets/js/element-ui-a9609798.js","assets/js/default_legend_icon-fcdb82ea.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/index-41d4c61b.css"] : void 0));
const home_vue_vue_type_style_index_0_scoped_2ba34987_lang = "";
const _sfc_main = {
  __name: "home",
  setup(__props) {
    const { ArcType } = mars3d.exports.Cesium;
    const layers = [
      {
        type: "geojson",
        name: "MTG_AREA_LAYER",
        show: true,
        zIndex: 101,
        url: "https://data.mars3d.cn/file/geojson/areas/110109.json",
        symbol: {
          styleOptions: {
            fill: true,
            color: "rgb(255,255,255)",
            opacity: 0,
            outline: true,
            outlineColor: "#d90000",
            outlineWidth: 2,
            outlineOpacity: 1,
            arcType: ArcType.GEODESIC,
            clampToGround: true
          }
        },
        flyTo: true
      }
    ];
    const config = setupMars3DConfig(3);
    function handlerMapReady(mapview) {
    }
    const { modules, setupModulesPosition: setupModulesPosition2 } = useUserHomeModule(BusinessModules);
    function handlerResolve(params) {
      console.log(params);
    }
    return { __sfc: true, ArcType, layers, config, handlerMapReady, modules, setupModulesPosition: setupModulesPosition2, handlerResolve, Cesium: mars3d.exports.Cesium, ContainerLayout, setupMars3DConfig, useUserHomeModule, BusinessModules, LayerLegend };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("mars3d-container", { staticClass: "home", attrs: { "config": _setup.config, "layers": _setup.layers }, on: { "onReady": _setup.handlerMapReady } }, [_c(_setup.LayerLegend, { staticClass: "layer-legend" }), _vm._l(_setup.modules, function(item, index) {
    return [item.length > 0 ? _c(_setup.ContainerLayout, { key: index, attrs: { "position": _setup.setupModulesPosition(index), "width": "380px" } }, [_vm._l(item, function(mode) {
      return [_c(mode.component, { key: mode.name, tag: "component", class: mode.className, on: { "onResolve": _setup.handlerResolve } })];
    })], 2) : _vm._e()];
  })], 2);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "2ba34987",
  null,
  null
);
const home = __component__.exports;
export {
  home as default
};
