import { j as computed, u as unref, r as ref$1, x as onMounted, z as elementUi_common } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { M as ModifyAddress, a as ModifyMethod } from "./info-template-3f5f845d.js";
import { u as useService } from "./Application-7fa37401.js";
import { t as transFormData, g as get, n as normalizeComponent } from "./index-1ea80670.js";
import "./usePopup-500740ad.js";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const Modify_Server = service.define({
  url: ModifyAddress,
  method: ModifyMethod
});
function Modify_Obtain(props) {
  Modify_Server.server.config.bind("data", transFormData(props));
  return Modify_Server.obtain({ transResponse });
}
const dialogInfoTemplate_vue_vue_type_style_index_0_scoped_312793cc_lang = "";
const _sfc_main = {
  __name: "dialog-info-template",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = Modify_Server.server;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const ModifyForm = ref$1();
    const form = ref$1({
      gate: "",
      warnInfo: "",
      color: "",
      id: ""
    });
    const rules = {
      gate: [
        {
          required: true,
          message: "\u9608\u503C\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      warnInfo: [
        {
          required: true,
          validator: checkWarnInfo,
          message: "\u8B66\u793A\u4FE1\u606F\u4E0D\u53EF\u4E3A\u7A7A\u4E14\u4E0D\u80FD\u8D85\u8FC712\u4E2A\u5168\u89D2\u5B57\u7B26",
          trigger: "change"
        }
      ],
      color: [
        {
          required: true,
          message: "\u989C\u8272\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function checkWarnInfo(rule, value, callback) {
      const reg = /[^\u4e00-\u9fa5]/g;
      if (value && value.length === value.replace(reg, "").length) {
        return callback();
      } else {
        callback(new Error("\u8B66\u793A\u4FE1\u606F\u4E0D\u53EF\u4E3A\u7A7A\u4E14\u4E0D\u80FD\u8D85\u8FC712\u4E2A\u5168\u89D2\u5B57\u7B26"));
      }
    }
    function onModify() {
      unref(ModifyForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await Modify_Obtain(unref(form));
        if (data.code === 200) {
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u4FEE\u6539\u6210\u529F!"
          });
          dialog.destroy();
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    onMounted(() => {
      form.value = unref(config);
    });
    return { __sfc: true, props, loading, dialog, config, ModifyForm, form, rules, checkWarnInfo, onModify, useDialog, Modify_Server, Modify_Obtain, Notification: elementUi_common.exports.Notification };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-form", { ref: "ModifyForm", staticClass: "dialog-info-template", attrs: { "model": _setup.form, "rules": _setup.rules, "size": "mini", "label-position": "top" } }, [_c("el-form-item", { attrs: { "prop": "gate", "label": "\u9608\u503C" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-remove-outline", "placeholder": "\u8BF7\u8F93\u5165\u9608\u503C" }, model: { value: _setup.form.gate, callback: function($$v) {
    _vm.$set(_setup.form, "gate", $$v);
  }, expression: "form.gate" } })], 1), _c("el-form-item", { attrs: { "prop": "color", "label": "\u989C\u8272" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-s-operation", "placeholder": "\u8BF7\u8F93\u5165\u989C\u8272" }, model: { value: _setup.form.color, callback: function($$v) {
    _vm.$set(_setup.form, "color", $$v);
  }, expression: "form.color" } })], 1), _c("el-form-item", { attrs: { "prop": "warnInfo", "label": "\u8B66\u793A\u4FE1\u606F" } }, [_c("el-input", { attrs: { "type": "text", "prefix-icon": "el-icon-reading", "placeholder": "\u8BF7\u8F93\u5165\u8B66\u793A\u4FE1\u606F", "maxlength": "12" }, model: { value: _setup.form.warnInfo, callback: function($$v) {
    _vm.$set(_setup.form, "warnInfo", $$v);
  }, expression: "form.warnInfo" } })], 1), _c("el-form-item", { staticClass: "dialog-info-template-console" }, [_c("el-button", { staticClass: "dialog-info-template-console-button", attrs: { "type": "primary", "size": "mini", "loading": _setup.loading }, on: { "click": _setup.onModify } }, [_vm._v("\u4FEE\u6539 ")])], 1)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "312793cc",
  null,
  null
);
const dialogInfoTemplate = __component__.exports;
export {
  dialogInfoTemplate as default
};
