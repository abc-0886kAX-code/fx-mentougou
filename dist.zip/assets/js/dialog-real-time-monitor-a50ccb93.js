import { j as computed, u as unref } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { _ as __$_require_f5a5ef2e__ } from "./login-video-69570771.js";
import { _ as __$_require_0453fda3__ } from "./header-video-fd1f6550.js";
import { n as normalizeComponent } from "./index-1ea80670.js";
const dialogRealTimeMonitor_vue_vue_type_style_index_0_scoped_41faccbb_lang = "";
const _sfc_main = {
  __name: "dialog-real-time-monitor",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    const z = 14.1;
    return { __sfc: true, props, dialog, config, z, useDialog };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "dialog-real-time-monitor" }, [_c("div", { staticClass: "dialog-real-time-monitor-info" }, [_c("div", { staticClass: "dialog-real-time-monitor-info-pond" }, [_vm._v("\u5F53\u524D\u79EF\u6C34\u6C34\u4F4D:" + _vm._s(_setup.z) + "\u7C73")]), _c("div", { staticClass: "dialog-real-time-monitor-info-led" }, [_vm._v("LED\u5C4F\u5F53\u524D\u5185\u5BB9:\u524D\u65B9\u79EF\u6C34" + _vm._s(_setup.z) + "\u7C73,\u6CE8\u610F\u5B89\u5168")])]), _c("div", { staticClass: "dialog-real-time-monitor-video" }, [_c("video", { staticClass: "dialog-real-time-monitor-video-item", attrs: { "src": __$_require_f5a5ef2e__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } }), _c("video", { staticClass: "dialog-real-time-monitor-video-item", attrs: { "src": __$_require_0453fda3__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } }), _c("video", { staticClass: "dialog-real-time-monitor-video-item", attrs: { "src": __$_require_0453fda3__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } }), _c("video", { staticClass: "dialog-real-time-monitor-video-item", attrs: { "src": __$_require_f5a5ef2e__, "type": "video/mp4", "controls": "", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } })])]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "41faccbb",
  null,
  null
);
const dialogRealTimeMonitor = __component__.exports;
export {
  dialogRealTimeMonitor as default
};
