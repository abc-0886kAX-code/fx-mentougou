import { u as unref, l as shallowRef, v as defineComponent, j as computed, i as inject, r as ref$1, x as onMounted, A as onBeforeUnmount } from "./element-ui-a9609798.js";
import { q as mars3d, a as uuid, x as handlerLayerConfig, y as addLayer, t as transFormData, g as get, n as normalizeComponent, _ as __vitePreload, e as transArray, z as mars3d$1, A as loadStyle } from "./index-1ea80670.js";
import { u as useMars3d } from "./useMars3D-c560a623.js";
import { u as useLayerLegend, d as default_legend_icon } from "./default_legend_icon-fcdb82ea.js";
import { u as useService } from "./Application-7fa37401.js";
import { S as SelectSite_Server, a as SelectSite_Obtain } from "./index-4cdc94bd.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useWatchRevert } from "./useWatchRevert-58689033.js";
/*!
 * shp涓巊eojson浜掕浆宸ュ叿绫�
 * 鐗堟湰淇℃伅锛歷1.1.0, hash鍊�: f1fedbbd6a7748f49116
 * 缂栬瘧鏃ユ湡锛�2022-11-17 21:29:55
 * 鐗堟潈鎵€鏈夛細Copyright by 鏈ㄩ仴 https://github.com/muyao1987/shp-geojson
 *
 */
!function(t, e) {
  "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define("shpUtil", [], e) : "object" == typeof exports ? exports.shpUtil = e() : t.shpUtil = e();
}(window, function() {
  return function(t) {
    var e = {};
    function i(r) {
      if (e[r])
        return e[r].exports;
      var s = e[r] = { i: r, l: false, exports: {} };
      return t[r].call(s.exports, s, s.exports, i), s.l = true, s.exports;
    }
    return i.m = t, i.c = e, i.d = function(t2, e2, r) {
      i.o(t2, e2) || Object.defineProperty(t2, e2, { enumerable: true, get: r });
    }, i.r = function(t2) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t2, "__esModule", { value: true });
    }, i.t = function(t2, e2) {
      if (1 & e2 && (t2 = i(t2)), 8 & e2)
        return t2;
      if (4 & e2 && "object" == typeof t2 && t2 && t2.__esModule)
        return t2;
      var r = /* @__PURE__ */ Object.create(null);
      if (i.r(r), Object.defineProperty(r, "default", { enumerable: true, value: t2 }), 2 & e2 && "string" != typeof t2)
        for (var s in t2)
          i.d(
            r,
            s,
            function(e3) {
              return t2[e3];
            }.bind(null, s)
          );
      return r;
    }, i.n = function(t2) {
      var e2 = t2 && t2.__esModule ? function() {
        return t2.default;
      } : function() {
        return t2;
      };
      return i.d(e2, "a", e2), e2;
    }, i.o = function(t2, e2) {
      return Object.prototype.hasOwnProperty.call(t2, e2);
    }, i.p = "", i(i.s = 6);
  }([
    function(t, e) {
      var i;
      i = function() {
        return this;
      }();
      try {
        i = i || new Function("return this")();
      } catch (t2) {
        "object" == typeof window && (i = window);
      }
      t.exports = i;
    },
    function(t, e, i) {
      (function(e2) {
        let r = i(27);
        r.default && (r = r.default);
        const s = i(7), n = i(15), a = i(18), o = i(19), h = i(4), u = i(26), l = i(2).Buffer, c = e2.URL, f = new u({ max: 20 });
        function d(t2) {
          if (!t2)
            throw new Error("forgot to pass buffer");
          return l.isBuffer(t2) ? t2 : p(t2) ? l.from(t2) : p(t2.buffer) ? 1 === t2.BYTES_PER_ELEMENT ? l.from(t2) : l.from(t2.buffer) : void 0;
        }
        function p(t2) {
          return t2 instanceof e2.ArrayBuffer || "[object ArrayBuffer]" === Object.prototype.toString.call(t2);
        }
        function m(t2, e3, i2) {
          return "string" == typeof t2 && f.has(t2) ? h.resolve(f.get(t2)) : m.getShapefile(t2, e3, i2).then(function(e4) {
            return "string" == typeof t2 && f.set(t2, e4), e4;
          });
        }
        m.combine = function([t2, e3]) {
          const i2 = { type: "FeatureCollection", features: [] };
          let r2 = 0;
          const s2 = t2.length;
          for (e3 || (e3 = []); r2 < s2; )
            i2.features.push({ type: "Feature", geometry: t2[r2], properties: e3[r2] || {} }), r2++;
          return i2;
        }, m.parseZip = async function(t2, e3, i2) {
          let n2;
          t2 = d(t2);
          const h2 = await s(t2), u2 = [];
          for (n2 in e3 = e3 || [], h2)
            -1 === n2.indexOf("__MACOSX") && ("shp" === n2.slice(-3).toLowerCase() ? (u2.push(n2.slice(0, -4)), h2[n2.slice(0, -3) + n2.slice(-3).toLowerCase()] = h2[n2]) : "prj" === n2.slice(-3).toLowerCase() ? h2[n2.slice(0, -3) + n2.slice(-3).toLowerCase()] = r(h2[n2]) : "json" === n2.slice(-4).toLowerCase() || e3.indexOf(n2.split(".").pop()) > -1 ? u2.push(n2.slice(0, -3) + n2.slice(-3).toLowerCase()) : "dbf" !== n2.slice(-3).toLowerCase() && "cpg" !== n2.slice(-3).toLowerCase() || (h2[n2.slice(0, -3) + n2.slice(-3).toLowerCase()] = h2[n2]));
          if (!u2.length)
            throw new Error("no layers founds");
          const l2 = u2.map(function(t3) {
            let r2, s2;
            const n3 = t3.lastIndexOf(".");
            return n3 > -1 && t3.slice(n3).indexOf("json") > -1 ? (r2 = JSON.parse(h2[t3]), r2.fileName = t3.slice(0, n3)) : e3.indexOf(t3.slice(n3 + 1)) > -1 ? (r2 = h2[t3], r2.fileName = t3) : (h2[t3 + ".dbf"] && (s2 = o(h2[t3 + ".dbf"], i2 || h2[t3 + ".cpg"])), r2 = m.combine([a(h2[t3 + ".shp"], h2[t3 + ".prj"]), s2]), r2.fileName = t3), r2;
          });
          return 1 === l2.length ? l2[0] : l2;
        };
        const g = async (t2) => {
          const e3 = await h.all([n(t2, "shp"), n(t2, "prj")]);
          let i2 = false;
          try {
            e3[1] && (i2 = r(e3[1]));
          } catch (t3) {
            i2 = false;
          }
          return a(e3[0], i2);
        }, _ = async (t2) => {
          const [e3, i2] = await h.all([n(t2, "dbf"), n(t2, "cpg")]);
          if (e3)
            return o(e3, i2);
        };
        m.getShapefile = async function(t2, e3, i2) {
          if ("string" != typeof t2)
            return m.parseZip(t2, e3, i2);
          if (((t3, e4) => new c(t3).pathname.slice(-4).toLowerCase() === e4)(t2, ".zip"))
            return async function(t3, e4, i3) {
              const r3 = await n(t3);
              return m.parseZip(r3, e4, i3);
            }(t2, e3, i2);
          const r2 = await h.all([g(t2), _(t2)]);
          return m.combine(r2);
        }, m.parseShp = function(t2, e3) {
          if (t2 = d(t2), l.isBuffer(e3) && (e3 = e3.toString()), "string" == typeof e3)
            try {
              e3 = r(e3);
            } catch (t3) {
              e3 = false;
            }
          return a(t2, e3);
        }, m.parseDbf = function(t2, e3) {
          return t2 = d(t2), o(t2, e3);
        }, t.exports = m;
      }).call(this, i(0));
    },
    function(t, e, i) {
      (function(t2) {
        /*!
         * The buffer module from node.js, for the browser.
         *
         * @author   Feross Aboukhadijeh <http://feross.org>
         * @license  MIT
         */
        var r = i(9), s = i(10), n = i(11);
        function a() {
          return h.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
        }
        function o(t3, e2) {
          if (a() < e2)
            throw new RangeError("Invalid typed array length");
          return h.TYPED_ARRAY_SUPPORT ? (t3 = new Uint8Array(e2)).__proto__ = h.prototype : (null === t3 && (t3 = new h(e2)), t3.length = e2), t3;
        }
        function h(t3, e2, i2) {
          if (!(h.TYPED_ARRAY_SUPPORT || this instanceof h))
            return new h(t3, e2, i2);
          if ("number" == typeof t3) {
            if ("string" == typeof e2)
              throw new Error("If encoding is specified then the first argument must be a string");
            return c(this, t3);
          }
          return u(this, t3, e2, i2);
        }
        function u(t3, e2, i2, r2) {
          if ("number" == typeof e2)
            throw new TypeError('"value" argument must not be a number');
          return "undefined" != typeof ArrayBuffer && e2 instanceof ArrayBuffer ? function(t4, e3, i3, r3) {
            if (e3.byteLength, i3 < 0 || e3.byteLength < i3)
              throw new RangeError("'offset' is out of bounds");
            if (e3.byteLength < i3 + (r3 || 0))
              throw new RangeError("'length' is out of bounds");
            e3 = void 0 === i3 && void 0 === r3 ? new Uint8Array(e3) : void 0 === r3 ? new Uint8Array(e3, i3) : new Uint8Array(e3, i3, r3);
            h.TYPED_ARRAY_SUPPORT ? (t4 = e3).__proto__ = h.prototype : t4 = f(t4, e3);
            return t4;
          }(t3, e2, i2, r2) : "string" == typeof e2 ? function(t4, e3, i3) {
            "string" == typeof i3 && "" !== i3 || (i3 = "utf8");
            if (!h.isEncoding(i3))
              throw new TypeError('"encoding" must be a valid string encoding');
            var r3 = 0 | p(e3, i3), s2 = (t4 = o(t4, r3)).write(e3, i3);
            s2 !== r3 && (t4 = t4.slice(0, s2));
            return t4;
          }(t3, e2, i2) : function(t4, e3) {
            if (h.isBuffer(e3)) {
              var i3 = 0 | d(e3.length);
              return 0 === (t4 = o(t4, i3)).length || e3.copy(t4, 0, 0, i3), t4;
            }
            if (e3) {
              if ("undefined" != typeof ArrayBuffer && e3.buffer instanceof ArrayBuffer || "length" in e3)
                return "number" != typeof e3.length || (r3 = e3.length) != r3 ? o(t4, 0) : f(t4, e3);
              if ("Buffer" === e3.type && n(e3.data))
                return f(t4, e3.data);
            }
            var r3;
            throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
          }(t3, e2);
        }
        function l(t3) {
          if ("number" != typeof t3)
            throw new TypeError('"size" argument must be a number');
          if (t3 < 0)
            throw new RangeError('"size" argument must not be negative');
        }
        function c(t3, e2) {
          if (l(e2), t3 = o(t3, e2 < 0 ? 0 : 0 | d(e2)), !h.TYPED_ARRAY_SUPPORT)
            for (var i2 = 0; i2 < e2; ++i2)
              t3[i2] = 0;
          return t3;
        }
        function f(t3, e2) {
          var i2 = e2.length < 0 ? 0 : 0 | d(e2.length);
          t3 = o(t3, i2);
          for (var r2 = 0; r2 < i2; r2 += 1)
            t3[r2] = 255 & e2[r2];
          return t3;
        }
        function d(t3) {
          if (t3 >= a())
            throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + a().toString(16) + " bytes");
          return 0 | t3;
        }
        function p(t3, e2) {
          if (h.isBuffer(t3))
            return t3.length;
          if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(t3) || t3 instanceof ArrayBuffer))
            return t3.byteLength;
          "string" != typeof t3 && (t3 = "" + t3);
          var i2 = t3.length;
          if (0 === i2)
            return 0;
          for (var r2 = false; ; )
            switch (e2) {
              case "ascii":
              case "latin1":
              case "binary":
                return i2;
              case "utf8":
              case "utf-8":
              case void 0:
                return U(t3).length;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return 2 * i2;
              case "hex":
                return i2 >>> 1;
              case "base64":
                return F(t3).length;
              default:
                if (r2)
                  return U(t3).length;
                e2 = ("" + e2).toLowerCase(), r2 = true;
            }
        }
        function m(t3, e2, i2) {
          var r2 = false;
          if ((void 0 === e2 || e2 < 0) && (e2 = 0), e2 > this.length)
            return "";
          if ((void 0 === i2 || i2 > this.length) && (i2 = this.length), i2 <= 0)
            return "";
          if ((i2 >>>= 0) <= (e2 >>>= 0))
            return "";
          for (t3 || (t3 = "utf8"); ; )
            switch (t3) {
              case "hex":
                return I(this, e2, i2);
              case "utf8":
              case "utf-8":
                return E(this, e2, i2);
              case "ascii":
                return C(this, e2, i2);
              case "latin1":
              case "binary":
                return A(this, e2, i2);
              case "base64":
                return S(this, e2, i2);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return O(this, e2, i2);
              default:
                if (r2)
                  throw new TypeError("Unknown encoding: " + t3);
                t3 = (t3 + "").toLowerCase(), r2 = true;
            }
        }
        function g(t3, e2, i2) {
          var r2 = t3[e2];
          t3[e2] = t3[i2], t3[i2] = r2;
        }
        function _(t3, e2, i2, r2, s2) {
          if (0 === t3.length)
            return -1;
          if ("string" == typeof i2 ? (r2 = i2, i2 = 0) : i2 > 2147483647 ? i2 = 2147483647 : i2 < -2147483648 && (i2 = -2147483648), i2 = +i2, isNaN(i2) && (i2 = s2 ? 0 : t3.length - 1), i2 < 0 && (i2 = t3.length + i2), i2 >= t3.length) {
            if (s2)
              return -1;
            i2 = t3.length - 1;
          } else if (i2 < 0) {
            if (!s2)
              return -1;
            i2 = 0;
          }
          if ("string" == typeof e2 && (e2 = h.from(e2, r2)), h.isBuffer(e2))
            return 0 === e2.length ? -1 : y(t3, e2, i2, r2, s2);
          if ("number" == typeof e2)
            return e2 &= 255, h.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf ? s2 ? Uint8Array.prototype.indexOf.call(t3, e2, i2) : Uint8Array.prototype.lastIndexOf.call(t3, e2, i2) : y(t3, [e2], i2, r2, s2);
          throw new TypeError("val must be string, number or Buffer");
        }
        function y(t3, e2, i2, r2, s2) {
          var n2, a2 = 1, o2 = t3.length, h2 = e2.length;
          if (void 0 !== r2 && ("ucs2" === (r2 = String(r2).toLowerCase()) || "ucs-2" === r2 || "utf16le" === r2 || "utf-16le" === r2)) {
            if (t3.length < 2 || e2.length < 2)
              return -1;
            a2 = 2, o2 /= 2, h2 /= 2, i2 /= 2;
          }
          function u2(t4, e3) {
            return 1 === a2 ? t4[e3] : t4.readUInt16BE(e3 * a2);
          }
          if (s2) {
            var l2 = -1;
            for (n2 = i2; n2 < o2; n2++)
              if (u2(t3, n2) === u2(e2, -1 === l2 ? 0 : n2 - l2)) {
                if (-1 === l2 && (l2 = n2), n2 - l2 + 1 === h2)
                  return l2 * a2;
              } else
                -1 !== l2 && (n2 -= n2 - l2), l2 = -1;
          } else
            for (i2 + h2 > o2 && (i2 = o2 - h2), n2 = i2; n2 >= 0; n2--) {
              for (var c2 = true, f2 = 0; f2 < h2; f2++)
                if (u2(t3, n2 + f2) !== u2(e2, f2)) {
                  c2 = false;
                  break;
                }
              if (c2)
                return n2;
            }
          return -1;
        }
        function v(t3, e2, i2, r2) {
          i2 = Number(i2) || 0;
          var s2 = t3.length - i2;
          r2 ? (r2 = Number(r2)) > s2 && (r2 = s2) : r2 = s2;
          var n2 = e2.length;
          if (n2 % 2 != 0)
            throw new TypeError("Invalid hex string");
          r2 > n2 / 2 && (r2 = n2 / 2);
          for (var a2 = 0; a2 < r2; ++a2) {
            var o2 = parseInt(e2.substr(2 * a2, 2), 16);
            if (isNaN(o2))
              return a2;
            t3[i2 + a2] = o2;
          }
          return a2;
        }
        function b(t3, e2, i2, r2) {
          return q(U(e2, t3.length - i2), t3, i2, r2);
        }
        function w(t3, e2, i2, r2) {
          return q(
            function(t4) {
              for (var e3 = [], i3 = 0; i3 < t4.length; ++i3)
                e3.push(255 & t4.charCodeAt(i3));
              return e3;
            }(e2),
            t3,
            i2,
            r2
          );
        }
        function M(t3, e2, i2, r2) {
          return w(t3, e2, i2, r2);
        }
        function x(t3, e2, i2, r2) {
          return q(F(e2), t3, i2, r2);
        }
        function k(t3, e2, i2, r2) {
          return q(
            function(t4, e3) {
              for (var i3, r3, s2, n2 = [], a2 = 0; a2 < t4.length && !((e3 -= 2) < 0); ++a2)
                i3 = t4.charCodeAt(a2), r3 = i3 >> 8, s2 = i3 % 256, n2.push(s2), n2.push(r3);
              return n2;
            }(e2, t3.length - i2),
            t3,
            i2,
            r2
          );
        }
        function S(t3, e2, i2) {
          return 0 === e2 && i2 === t3.length ? r.fromByteArray(t3) : r.fromByteArray(t3.slice(e2, i2));
        }
        function E(t3, e2, i2) {
          i2 = Math.min(t3.length, i2);
          for (var r2 = [], s2 = e2; s2 < i2; ) {
            var n2, a2, o2, h2, u2 = t3[s2], l2 = null, c2 = u2 > 239 ? 4 : u2 > 223 ? 3 : u2 > 191 ? 2 : 1;
            if (s2 + c2 <= i2)
              switch (c2) {
                case 1:
                  u2 < 128 && (l2 = u2);
                  break;
                case 2:
                  128 == (192 & (n2 = t3[s2 + 1])) && (h2 = (31 & u2) << 6 | 63 & n2) > 127 && (l2 = h2);
                  break;
                case 3:
                  n2 = t3[s2 + 1], a2 = t3[s2 + 2], 128 == (192 & n2) && 128 == (192 & a2) && (h2 = (15 & u2) << 12 | (63 & n2) << 6 | 63 & a2) > 2047 && (h2 < 55296 || h2 > 57343) && (l2 = h2);
                  break;
                case 4:
                  n2 = t3[s2 + 1], a2 = t3[s2 + 2], o2 = t3[s2 + 3], 128 == (192 & n2) && 128 == (192 & a2) && 128 == (192 & o2) && (h2 = (15 & u2) << 18 | (63 & n2) << 12 | (63 & a2) << 6 | 63 & o2) > 65535 && h2 < 1114112 && (l2 = h2);
              }
            null === l2 ? (l2 = 65533, c2 = 1) : l2 > 65535 && (l2 -= 65536, r2.push(l2 >>> 10 & 1023 | 55296), l2 = 56320 | 1023 & l2), r2.push(l2), s2 += c2;
          }
          return function(t4) {
            var e3 = t4.length;
            if (e3 <= 4096)
              return String.fromCharCode.apply(String, t4);
            var i3 = "", r3 = 0;
            for (; r3 < e3; )
              i3 += String.fromCharCode.apply(String, t4.slice(r3, r3 += 4096));
            return i3;
          }(r2);
        }
        e.Buffer = h, e.SlowBuffer = function(t3) {
          +t3 != t3 && (t3 = 0);
          return h.alloc(+t3);
        }, e.INSPECT_MAX_BYTES = 50, h.TYPED_ARRAY_SUPPORT = void 0 !== t2.TYPED_ARRAY_SUPPORT ? t2.TYPED_ARRAY_SUPPORT : function() {
          try {
            var t3 = new Uint8Array(1);
            return t3.__proto__ = {
              __proto__: Uint8Array.prototype,
              foo: function() {
                return 42;
              }
            }, 42 === t3.foo() && "function" == typeof t3.subarray && 0 === t3.subarray(1, 1).byteLength;
          } catch (t4) {
            return false;
          }
        }(), e.kMaxLength = a(), h.poolSize = 8192, h._augment = function(t3) {
          return t3.__proto__ = h.prototype, t3;
        }, h.from = function(t3, e2, i2) {
          return u(null, t3, e2, i2);
        }, h.TYPED_ARRAY_SUPPORT && (h.prototype.__proto__ = Uint8Array.prototype, h.__proto__ = Uint8Array, "undefined" != typeof Symbol && Symbol.species && h[Symbol.species] === h && Object.defineProperty(h, Symbol.species, { value: null, configurable: true })), h.alloc = function(t3, e2, i2) {
          return function(t4, e3, i3, r2) {
            return l(e3), e3 <= 0 ? o(t4, e3) : void 0 !== i3 ? "string" == typeof r2 ? o(t4, e3).fill(i3, r2) : o(t4, e3).fill(i3) : o(t4, e3);
          }(null, t3, e2, i2);
        }, h.allocUnsafe = function(t3) {
          return c(null, t3);
        }, h.allocUnsafeSlow = function(t3) {
          return c(null, t3);
        }, h.isBuffer = function(t3) {
          return !(null == t3 || !t3._isBuffer);
        }, h.compare = function(t3, e2) {
          if (!h.isBuffer(t3) || !h.isBuffer(e2))
            throw new TypeError("Arguments must be Buffers");
          if (t3 === e2)
            return 0;
          for (var i2 = t3.length, r2 = e2.length, s2 = 0, n2 = Math.min(i2, r2); s2 < n2; ++s2)
            if (t3[s2] !== e2[s2]) {
              i2 = t3[s2], r2 = e2[s2];
              break;
            }
          return i2 < r2 ? -1 : r2 < i2 ? 1 : 0;
        }, h.isEncoding = function(t3) {
          switch (String(t3).toLowerCase()) {
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "latin1":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return true;
            default:
              return false;
          }
        }, h.concat = function(t3, e2) {
          if (!n(t3))
            throw new TypeError('"list" argument must be an Array of Buffers');
          if (0 === t3.length)
            return h.alloc(0);
          var i2;
          if (void 0 === e2)
            for (e2 = 0, i2 = 0; i2 < t3.length; ++i2)
              e2 += t3[i2].length;
          var r2 = h.allocUnsafe(e2), s2 = 0;
          for (i2 = 0; i2 < t3.length; ++i2) {
            var a2 = t3[i2];
            if (!h.isBuffer(a2))
              throw new TypeError('"list" argument must be an Array of Buffers');
            a2.copy(r2, s2), s2 += a2.length;
          }
          return r2;
        }, h.byteLength = p, h.prototype._isBuffer = true, h.prototype.swap16 = function() {
          var t3 = this.length;
          if (t3 % 2 != 0)
            throw new RangeError("Buffer size must be a multiple of 16-bits");
          for (var e2 = 0; e2 < t3; e2 += 2)
            g(this, e2, e2 + 1);
          return this;
        }, h.prototype.swap32 = function() {
          var t3 = this.length;
          if (t3 % 4 != 0)
            throw new RangeError("Buffer size must be a multiple of 32-bits");
          for (var e2 = 0; e2 < t3; e2 += 4)
            g(this, e2, e2 + 3), g(this, e2 + 1, e2 + 2);
          return this;
        }, h.prototype.swap64 = function() {
          var t3 = this.length;
          if (t3 % 8 != 0)
            throw new RangeError("Buffer size must be a multiple of 64-bits");
          for (var e2 = 0; e2 < t3; e2 += 8)
            g(this, e2, e2 + 7), g(this, e2 + 1, e2 + 6), g(this, e2 + 2, e2 + 5), g(this, e2 + 3, e2 + 4);
          return this;
        }, h.prototype.toString = function() {
          var t3 = 0 | this.length;
          return 0 === t3 ? "" : 0 === arguments.length ? E(this, 0, t3) : m.apply(this, arguments);
        }, h.prototype.equals = function(t3) {
          if (!h.isBuffer(t3))
            throw new TypeError("Argument must be a Buffer");
          return this === t3 || 0 === h.compare(this, t3);
        }, h.prototype.inspect = function() {
          var t3 = "", i2 = e.INSPECT_MAX_BYTES;
          return this.length > 0 && (t3 = this.toString("hex", 0, i2).match(/.{2}/g).join(" "), this.length > i2 && (t3 += " ... ")), "<Buffer " + t3 + ">";
        }, h.prototype.compare = function(t3, e2, i2, r2, s2) {
          if (!h.isBuffer(t3))
            throw new TypeError("Argument must be a Buffer");
          if (void 0 === e2 && (e2 = 0), void 0 === i2 && (i2 = t3 ? t3.length : 0), void 0 === r2 && (r2 = 0), void 0 === s2 && (s2 = this.length), e2 < 0 || i2 > t3.length || r2 < 0 || s2 > this.length)
            throw new RangeError("out of range index");
          if (r2 >= s2 && e2 >= i2)
            return 0;
          if (r2 >= s2)
            return -1;
          if (e2 >= i2)
            return 1;
          if (this === t3)
            return 0;
          for (var n2 = (s2 >>>= 0) - (r2 >>>= 0), a2 = (i2 >>>= 0) - (e2 >>>= 0), o2 = Math.min(n2, a2), u2 = this.slice(r2, s2), l2 = t3.slice(e2, i2), c2 = 0; c2 < o2; ++c2)
            if (u2[c2] !== l2[c2]) {
              n2 = u2[c2], a2 = l2[c2];
              break;
            }
          return n2 < a2 ? -1 : a2 < n2 ? 1 : 0;
        }, h.prototype.includes = function(t3, e2, i2) {
          return -1 !== this.indexOf(t3, e2, i2);
        }, h.prototype.indexOf = function(t3, e2, i2) {
          return _(this, t3, e2, i2, true);
        }, h.prototype.lastIndexOf = function(t3, e2, i2) {
          return _(this, t3, e2, i2, false);
        }, h.prototype.write = function(t3, e2, i2, r2) {
          if (void 0 === e2)
            r2 = "utf8", i2 = this.length, e2 = 0;
          else if (void 0 === i2 && "string" == typeof e2)
            r2 = e2, i2 = this.length, e2 = 0;
          else {
            if (!isFinite(e2))
              throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
            e2 |= 0, isFinite(i2) ? (i2 |= 0, void 0 === r2 && (r2 = "utf8")) : (r2 = i2, i2 = void 0);
          }
          var s2 = this.length - e2;
          if ((void 0 === i2 || i2 > s2) && (i2 = s2), t3.length > 0 && (i2 < 0 || e2 < 0) || e2 > this.length)
            throw new RangeError("Attempt to write outside buffer bounds");
          r2 || (r2 = "utf8");
          for (var n2 = false; ; )
            switch (r2) {
              case "hex":
                return v(this, t3, e2, i2);
              case "utf8":
              case "utf-8":
                return b(this, t3, e2, i2);
              case "ascii":
                return w(this, t3, e2, i2);
              case "latin1":
              case "binary":
                return M(this, t3, e2, i2);
              case "base64":
                return x(this, t3, e2, i2);
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return k(this, t3, e2, i2);
              default:
                if (n2)
                  throw new TypeError("Unknown encoding: " + r2);
                r2 = ("" + r2).toLowerCase(), n2 = true;
            }
        }, h.prototype.toJSON = function() {
          return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
        };
        function C(t3, e2, i2) {
          var r2 = "";
          i2 = Math.min(t3.length, i2);
          for (var s2 = e2; s2 < i2; ++s2)
            r2 += String.fromCharCode(127 & t3[s2]);
          return r2;
        }
        function A(t3, e2, i2) {
          var r2 = "";
          i2 = Math.min(t3.length, i2);
          for (var s2 = e2; s2 < i2; ++s2)
            r2 += String.fromCharCode(t3[s2]);
          return r2;
        }
        function I(t3, e2, i2) {
          var r2 = t3.length;
          (!e2 || e2 < 0) && (e2 = 0), (!i2 || i2 < 0 || i2 > r2) && (i2 = r2);
          for (var s2 = "", n2 = e2; n2 < i2; ++n2)
            s2 += j(t3[n2]);
          return s2;
        }
        function O(t3, e2, i2) {
          for (var r2 = t3.slice(e2, i2), s2 = "", n2 = 0; n2 < r2.length; n2 += 2)
            s2 += String.fromCharCode(r2[n2] + 256 * r2[n2 + 1]);
          return s2;
        }
        function T(t3, e2, i2) {
          if (t3 % 1 != 0 || t3 < 0)
            throw new RangeError("offset is not uint");
          if (t3 + e2 > i2)
            throw new RangeError("Trying to access beyond buffer length");
        }
        function z(t3, e2, i2, r2, s2, n2) {
          if (!h.isBuffer(t3))
            throw new TypeError('"buffer" argument must be a Buffer instance');
          if (e2 > s2 || e2 < n2)
            throw new RangeError('"value" argument is out of bounds');
          if (i2 + r2 > t3.length)
            throw new RangeError("Index out of range");
        }
        function P(t3, e2, i2, r2) {
          e2 < 0 && (e2 = 65535 + e2 + 1);
          for (var s2 = 0, n2 = Math.min(t3.length - i2, 2); s2 < n2; ++s2)
            t3[i2 + s2] = (e2 & 255 << 8 * (r2 ? s2 : 1 - s2)) >>> 8 * (r2 ? s2 : 1 - s2);
        }
        function N(t3, e2, i2, r2) {
          e2 < 0 && (e2 = 4294967295 + e2 + 1);
          for (var s2 = 0, n2 = Math.min(t3.length - i2, 4); s2 < n2; ++s2)
            t3[i2 + s2] = e2 >>> 8 * (r2 ? s2 : 3 - s2) & 255;
        }
        function L(t3, e2, i2, r2, s2, n2) {
          if (i2 + r2 > t3.length)
            throw new RangeError("Index out of range");
          if (i2 < 0)
            throw new RangeError("Index out of range");
        }
        function R(t3, e2, i2, r2, n2) {
          return n2 || L(t3, 0, i2, 4), s.write(t3, e2, i2, r2, 23, 4), i2 + 4;
        }
        function B(t3, e2, i2, r2, n2) {
          return n2 || L(t3, 0, i2, 8), s.write(t3, e2, i2, r2, 52, 8), i2 + 8;
        }
        h.prototype.slice = function(t3, e2) {
          var i2, r2 = this.length;
          if ((t3 = ~~t3) < 0 ? (t3 += r2) < 0 && (t3 = 0) : t3 > r2 && (t3 = r2), (e2 = void 0 === e2 ? r2 : ~~e2) < 0 ? (e2 += r2) < 0 && (e2 = 0) : e2 > r2 && (e2 = r2), e2 < t3 && (e2 = t3), h.TYPED_ARRAY_SUPPORT)
            (i2 = this.subarray(t3, e2)).__proto__ = h.prototype;
          else {
            var s2 = e2 - t3;
            i2 = new h(s2, void 0);
            for (var n2 = 0; n2 < s2; ++n2)
              i2[n2] = this[n2 + t3];
          }
          return i2;
        }, h.prototype.readUIntLE = function(t3, e2, i2) {
          t3 |= 0, e2 |= 0, i2 || T(t3, e2, this.length);
          for (var r2 = this[t3], s2 = 1, n2 = 0; ++n2 < e2 && (s2 *= 256); )
            r2 += this[t3 + n2] * s2;
          return r2;
        }, h.prototype.readUIntBE = function(t3, e2, i2) {
          t3 |= 0, e2 |= 0, i2 || T(t3, e2, this.length);
          for (var r2 = this[t3 + --e2], s2 = 1; e2 > 0 && (s2 *= 256); )
            r2 += this[t3 + --e2] * s2;
          return r2;
        }, h.prototype.readUInt8 = function(t3, e2) {
          return e2 || T(t3, 1, this.length), this[t3];
        }, h.prototype.readUInt16LE = function(t3, e2) {
          return e2 || T(t3, 2, this.length), this[t3] | this[t3 + 1] << 8;
        }, h.prototype.readUInt16BE = function(t3, e2) {
          return e2 || T(t3, 2, this.length), this[t3] << 8 | this[t3 + 1];
        }, h.prototype.readUInt32LE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), (this[t3] | this[t3 + 1] << 8 | this[t3 + 2] << 16) + 16777216 * this[t3 + 3];
        }, h.prototype.readUInt32BE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), 16777216 * this[t3] + (this[t3 + 1] << 16 | this[t3 + 2] << 8 | this[t3 + 3]);
        }, h.prototype.readIntLE = function(t3, e2, i2) {
          t3 |= 0, e2 |= 0, i2 || T(t3, e2, this.length);
          for (var r2 = this[t3], s2 = 1, n2 = 0; ++n2 < e2 && (s2 *= 256); )
            r2 += this[t3 + n2] * s2;
          return r2 >= (s2 *= 128) && (r2 -= Math.pow(2, 8 * e2)), r2;
        }, h.prototype.readIntBE = function(t3, e2, i2) {
          t3 |= 0, e2 |= 0, i2 || T(t3, e2, this.length);
          for (var r2 = e2, s2 = 1, n2 = this[t3 + --r2]; r2 > 0 && (s2 *= 256); )
            n2 += this[t3 + --r2] * s2;
          return n2 >= (s2 *= 128) && (n2 -= Math.pow(2, 8 * e2)), n2;
        }, h.prototype.readInt8 = function(t3, e2) {
          return e2 || T(t3, 1, this.length), 128 & this[t3] ? -1 * (255 - this[t3] + 1) : this[t3];
        }, h.prototype.readInt16LE = function(t3, e2) {
          e2 || T(t3, 2, this.length);
          var i2 = this[t3] | this[t3 + 1] << 8;
          return 32768 & i2 ? 4294901760 | i2 : i2;
        }, h.prototype.readInt16BE = function(t3, e2) {
          e2 || T(t3, 2, this.length);
          var i2 = this[t3 + 1] | this[t3] << 8;
          return 32768 & i2 ? 4294901760 | i2 : i2;
        }, h.prototype.readInt32LE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), this[t3] | this[t3 + 1] << 8 | this[t3 + 2] << 16 | this[t3 + 3] << 24;
        }, h.prototype.readInt32BE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), this[t3] << 24 | this[t3 + 1] << 16 | this[t3 + 2] << 8 | this[t3 + 3];
        }, h.prototype.readFloatLE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), s.read(this, t3, true, 23, 4);
        }, h.prototype.readFloatBE = function(t3, e2) {
          return e2 || T(t3, 4, this.length), s.read(this, t3, false, 23, 4);
        }, h.prototype.readDoubleLE = function(t3, e2) {
          return e2 || T(t3, 8, this.length), s.read(this, t3, true, 52, 8);
        }, h.prototype.readDoubleBE = function(t3, e2) {
          return e2 || T(t3, 8, this.length), s.read(this, t3, false, 52, 8);
        }, h.prototype.writeUIntLE = function(t3, e2, i2, r2) {
          (t3 = +t3, e2 |= 0, i2 |= 0, r2) || z(this, t3, e2, i2, Math.pow(2, 8 * i2) - 1, 0);
          var s2 = 1, n2 = 0;
          for (this[e2] = 255 & t3; ++n2 < i2 && (s2 *= 256); )
            this[e2 + n2] = t3 / s2 & 255;
          return e2 + i2;
        }, h.prototype.writeUIntBE = function(t3, e2, i2, r2) {
          (t3 = +t3, e2 |= 0, i2 |= 0, r2) || z(this, t3, e2, i2, Math.pow(2, 8 * i2) - 1, 0);
          var s2 = i2 - 1, n2 = 1;
          for (this[e2 + s2] = 255 & t3; --s2 >= 0 && (n2 *= 256); )
            this[e2 + s2] = t3 / n2 & 255;
          return e2 + i2;
        }, h.prototype.writeUInt8 = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 1, 255, 0), h.TYPED_ARRAY_SUPPORT || (t3 = Math.floor(t3)), this[e2] = 255 & t3, e2 + 1;
        }, h.prototype.writeUInt16LE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 2, 65535, 0), h.TYPED_ARRAY_SUPPORT ? (this[e2] = 255 & t3, this[e2 + 1] = t3 >>> 8) : P(this, t3, e2, true), e2 + 2;
        }, h.prototype.writeUInt16BE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 2, 65535, 0), h.TYPED_ARRAY_SUPPORT ? (this[e2] = t3 >>> 8, this[e2 + 1] = 255 & t3) : P(this, t3, e2, false), e2 + 2;
        }, h.prototype.writeUInt32LE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 4, 4294967295, 0), h.TYPED_ARRAY_SUPPORT ? (this[e2 + 3] = t3 >>> 24, this[e2 + 2] = t3 >>> 16, this[e2 + 1] = t3 >>> 8, this[e2] = 255 & t3) : N(this, t3, e2, true), e2 + 4;
        }, h.prototype.writeUInt32BE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 4, 4294967295, 0), h.TYPED_ARRAY_SUPPORT ? (this[e2] = t3 >>> 24, this[e2 + 1] = t3 >>> 16, this[e2 + 2] = t3 >>> 8, this[e2 + 3] = 255 & t3) : N(this, t3, e2, false), e2 + 4;
        }, h.prototype.writeIntLE = function(t3, e2, i2, r2) {
          if (t3 = +t3, e2 |= 0, !r2) {
            var s2 = Math.pow(2, 8 * i2 - 1);
            z(this, t3, e2, i2, s2 - 1, -s2);
          }
          var n2 = 0, a2 = 1, o2 = 0;
          for (this[e2] = 255 & t3; ++n2 < i2 && (a2 *= 256); )
            t3 < 0 && 0 === o2 && 0 !== this[e2 + n2 - 1] && (o2 = 1), this[e2 + n2] = (t3 / a2 >> 0) - o2 & 255;
          return e2 + i2;
        }, h.prototype.writeIntBE = function(t3, e2, i2, r2) {
          if (t3 = +t3, e2 |= 0, !r2) {
            var s2 = Math.pow(2, 8 * i2 - 1);
            z(this, t3, e2, i2, s2 - 1, -s2);
          }
          var n2 = i2 - 1, a2 = 1, o2 = 0;
          for (this[e2 + n2] = 255 & t3; --n2 >= 0 && (a2 *= 256); )
            t3 < 0 && 0 === o2 && 0 !== this[e2 + n2 + 1] && (o2 = 1), this[e2 + n2] = (t3 / a2 >> 0) - o2 & 255;
          return e2 + i2;
        }, h.prototype.writeInt8 = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 1, 127, -128), h.TYPED_ARRAY_SUPPORT || (t3 = Math.floor(t3)), t3 < 0 && (t3 = 255 + t3 + 1), this[e2] = 255 & t3, e2 + 1;
        }, h.prototype.writeInt16LE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 2, 32767, -32768), h.TYPED_ARRAY_SUPPORT ? (this[e2] = 255 & t3, this[e2 + 1] = t3 >>> 8) : P(this, t3, e2, true), e2 + 2;
        }, h.prototype.writeInt16BE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 2, 32767, -32768), h.TYPED_ARRAY_SUPPORT ? (this[e2] = t3 >>> 8, this[e2 + 1] = 255 & t3) : P(this, t3, e2, false), e2 + 2;
        }, h.prototype.writeInt32LE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 4, 2147483647, -2147483648), h.TYPED_ARRAY_SUPPORT ? (this[e2] = 255 & t3, this[e2 + 1] = t3 >>> 8, this[e2 + 2] = t3 >>> 16, this[e2 + 3] = t3 >>> 24) : N(this, t3, e2, true), e2 + 4;
        }, h.prototype.writeInt32BE = function(t3, e2, i2) {
          return t3 = +t3, e2 |= 0, i2 || z(this, t3, e2, 4, 2147483647, -2147483648), t3 < 0 && (t3 = 4294967295 + t3 + 1), h.TYPED_ARRAY_SUPPORT ? (this[e2] = t3 >>> 24, this[e2 + 1] = t3 >>> 16, this[e2 + 2] = t3 >>> 8, this[e2 + 3] = 255 & t3) : N(this, t3, e2, false), e2 + 4;
        }, h.prototype.writeFloatLE = function(t3, e2, i2) {
          return R(this, t3, e2, true, i2);
        }, h.prototype.writeFloatBE = function(t3, e2, i2) {
          return R(this, t3, e2, false, i2);
        }, h.prototype.writeDoubleLE = function(t3, e2, i2) {
          return B(this, t3, e2, true, i2);
        }, h.prototype.writeDoubleBE = function(t3, e2, i2) {
          return B(this, t3, e2, false, i2);
        }, h.prototype.copy = function(t3, e2, i2, r2) {
          if (i2 || (i2 = 0), r2 || 0 === r2 || (r2 = this.length), e2 >= t3.length && (e2 = t3.length), e2 || (e2 = 0), r2 > 0 && r2 < i2 && (r2 = i2), r2 === i2)
            return 0;
          if (0 === t3.length || 0 === this.length)
            return 0;
          if (e2 < 0)
            throw new RangeError("targetStart out of bounds");
          if (i2 < 0 || i2 >= this.length)
            throw new RangeError("sourceStart out of bounds");
          if (r2 < 0)
            throw new RangeError("sourceEnd out of bounds");
          r2 > this.length && (r2 = this.length), t3.length - e2 < r2 - i2 && (r2 = t3.length - e2 + i2);
          var s2, n2 = r2 - i2;
          if (this === t3 && i2 < e2 && e2 < r2)
            for (s2 = n2 - 1; s2 >= 0; --s2)
              t3[s2 + e2] = this[s2 + i2];
          else if (n2 < 1e3 || !h.TYPED_ARRAY_SUPPORT)
            for (s2 = 0; s2 < n2; ++s2)
              t3[s2 + e2] = this[s2 + i2];
          else
            Uint8Array.prototype.set.call(t3, this.subarray(i2, i2 + n2), e2);
          return n2;
        }, h.prototype.fill = function(t3, e2, i2, r2) {
          if ("string" == typeof t3) {
            if ("string" == typeof e2 ? (r2 = e2, e2 = 0, i2 = this.length) : "string" == typeof i2 && (r2 = i2, i2 = this.length), 1 === t3.length) {
              var s2 = t3.charCodeAt(0);
              s2 < 256 && (t3 = s2);
            }
            if (void 0 !== r2 && "string" != typeof r2)
              throw new TypeError("encoding must be a string");
            if ("string" == typeof r2 && !h.isEncoding(r2))
              throw new TypeError("Unknown encoding: " + r2);
          } else
            "number" == typeof t3 && (t3 &= 255);
          if (e2 < 0 || this.length < e2 || this.length < i2)
            throw new RangeError("Out of range index");
          if (i2 <= e2)
            return this;
          var n2;
          if (e2 >>>= 0, i2 = void 0 === i2 ? this.length : i2 >>> 0, t3 || (t3 = 0), "number" == typeof t3)
            for (n2 = e2; n2 < i2; ++n2)
              this[n2] = t3;
          else {
            var a2 = h.isBuffer(t3) ? t3 : U(new h(t3, r2).toString()), o2 = a2.length;
            for (n2 = 0; n2 < i2 - e2; ++n2)
              this[n2 + e2] = a2[n2 % o2];
          }
          return this;
        };
        var D = /[^+\/0-9A-Za-z-_]/g;
        function j(t3) {
          return t3 < 16 ? "0" + t3.toString(16) : t3.toString(16);
        }
        function U(t3, e2) {
          var i2;
          e2 = e2 || 1 / 0;
          for (var r2 = t3.length, s2 = null, n2 = [], a2 = 0; a2 < r2; ++a2) {
            if ((i2 = t3.charCodeAt(a2)) > 55295 && i2 < 57344) {
              if (!s2) {
                if (i2 > 56319) {
                  (e2 -= 3) > -1 && n2.push(239, 191, 189);
                  continue;
                }
                if (a2 + 1 === r2) {
                  (e2 -= 3) > -1 && n2.push(239, 191, 189);
                  continue;
                }
                s2 = i2;
                continue;
              }
              if (i2 < 56320) {
                (e2 -= 3) > -1 && n2.push(239, 191, 189), s2 = i2;
                continue;
              }
              i2 = 65536 + (s2 - 55296 << 10 | i2 - 56320);
            } else
              s2 && (e2 -= 3) > -1 && n2.push(239, 191, 189);
            if (s2 = null, i2 < 128) {
              if ((e2 -= 1) < 0)
                break;
              n2.push(i2);
            } else if (i2 < 2048) {
              if ((e2 -= 2) < 0)
                break;
              n2.push(i2 >> 6 | 192, 63 & i2 | 128);
            } else if (i2 < 65536) {
              if ((e2 -= 3) < 0)
                break;
              n2.push(i2 >> 12 | 224, i2 >> 6 & 63 | 128, 63 & i2 | 128);
            } else {
              if (!(i2 < 1114112))
                throw new Error("Invalid code point");
              if ((e2 -= 4) < 0)
                break;
              n2.push(i2 >> 18 | 240, i2 >> 12 & 63 | 128, i2 >> 6 & 63 | 128, 63 & i2 | 128);
            }
          }
          return n2;
        }
        function F(t3) {
          return r.toByteArray(
            function(t4) {
              if ((t4 = function(t5) {
                return t5.trim ? t5.trim() : t5.replace(/^\s+|\s+$/g, "");
              }(t4).replace(D, "")).length < 2)
                return "";
              for (; t4.length % 4 != 0; )
                t4 += "=";
              return t4;
            }(t3)
          );
        }
        function q(t3, e2, i2, r2) {
          for (var s2 = 0; s2 < r2 && !(s2 + i2 >= e2.length || s2 >= t3.length); ++s2)
            e2[s2 + i2] = t3[s2];
          return s2;
        }
      }).call(this, i(0));
    },
    function(t, e) {
      var i, r, s = t.exports = {};
      function n() {
        throw new Error("setTimeout has not been defined");
      }
      function a() {
        throw new Error("clearTimeout has not been defined");
      }
      function o(t2) {
        if (i === setTimeout)
          return setTimeout(t2, 0);
        if ((i === n || !i) && setTimeout)
          return i = setTimeout, setTimeout(t2, 0);
        try {
          return i(t2, 0);
        } catch (e2) {
          try {
            return i.call(null, t2, 0);
          } catch (e3) {
            return i.call(this, t2, 0);
          }
        }
      }
      !function() {
        try {
          i = "function" == typeof setTimeout ? setTimeout : n;
        } catch (t2) {
          i = n;
        }
        try {
          r = "function" == typeof clearTimeout ? clearTimeout : a;
        } catch (t2) {
          r = a;
        }
      }();
      var h, u = [], l = false, c = -1;
      function f() {
        l && h && (l = false, h.length ? u = h.concat(u) : c = -1, u.length && d());
      }
      function d() {
        if (!l) {
          var t2 = o(f);
          l = true;
          for (var e2 = u.length; e2; ) {
            for (h = u, u = []; ++c < e2; )
              h && h[c].run();
            c = -1, e2 = u.length;
          }
          h = null, l = false, function(t3) {
            if (r === clearTimeout)
              return clearTimeout(t3);
            if ((r === a || !r) && clearTimeout)
              return r = clearTimeout, clearTimeout(t3);
            try {
              r(t3);
            } catch (e3) {
              try {
                return r.call(null, t3);
              } catch (e4) {
                return r.call(this, t3);
              }
            }
          }(t2);
        }
      }
      function p(t2, e2) {
        this.fun = t2, this.array = e2;
      }
      function m() {
      }
      s.nextTick = function(t2) {
        var e2 = new Array(arguments.length - 1);
        if (arguments.length > 1)
          for (var i2 = 1; i2 < arguments.length; i2++)
            e2[i2 - 1] = arguments[i2];
        u.push(new p(t2, e2)), 1 !== u.length || l || o(d);
      }, p.prototype.run = function() {
        this.fun.apply(null, this.array);
      }, s.title = "browser", s.browser = true, s.env = {}, s.argv = [], s.version = "", s.versions = {}, s.on = m, s.addListener = m, s.once = m, s.off = m, s.removeListener = m, s.removeAllListeners = m, s.emit = m, s.prependListener = m, s.prependOnceListener = m, s.listeners = function(t2) {
        return [];
      }, s.binding = function(t2) {
        throw new Error("process.binding is not supported");
      }, s.cwd = function() {
        return "/";
      }, s.chdir = function(t2) {
        throw new Error("process.chdir is not supported");
      }, s.umask = function() {
        return 0;
      };
    },
    function(t, e, i) {
      var r = i(17);
      function s() {
      }
      var n = {}, a = ["REJECTED"], o = ["FULFILLED"], h = ["PENDING"];
      function u(t2) {
        if ("function" != typeof t2)
          throw new TypeError("resolver must be a function");
        this.state = h, this.queue = [], this.outcome = void 0, t2 !== s && d(this, t2);
      }
      function l(t2, e2, i2) {
        this.promise = t2, "function" == typeof e2 && (this.onFulfilled = e2, this.callFulfilled = this.otherCallFulfilled), "function" == typeof i2 && (this.onRejected = i2, this.callRejected = this.otherCallRejected);
      }
      function c(t2, e2, i2) {
        r(function() {
          var r2;
          try {
            r2 = e2(i2);
          } catch (e3) {
            return n.reject(t2, e3);
          }
          r2 === t2 ? n.reject(t2, new TypeError("Cannot resolve promise with itself")) : n.resolve(t2, r2);
        });
      }
      function f(t2) {
        var e2 = t2 && t2.then;
        if (t2 && ("object" == typeof t2 || "function" == typeof t2) && "function" == typeof e2)
          return function() {
            e2.apply(t2, arguments);
          };
      }
      function d(t2, e2) {
        var i2 = false;
        function r2(e3) {
          i2 || (i2 = true, n.reject(t2, e3));
        }
        function s2(e3) {
          i2 || (i2 = true, n.resolve(t2, e3));
        }
        var a2 = p(function() {
          e2(s2, r2);
        });
        "error" === a2.status && r2(a2.value);
      }
      function p(t2, e2) {
        var i2 = {};
        try {
          i2.value = t2(e2), i2.status = "success";
        } catch (t3) {
          i2.status = "error", i2.value = t3;
        }
        return i2;
      }
      t.exports = u, u.prototype.finally = function(t2) {
        if ("function" != typeof t2)
          return this;
        var e2 = this.constructor;
        return this.then(
          function(i2) {
            return e2.resolve(t2()).then(function() {
              return i2;
            });
          },
          function(i2) {
            return e2.resolve(t2()).then(function() {
              throw i2;
            });
          }
        );
      }, u.prototype.catch = function(t2) {
        return this.then(null, t2);
      }, u.prototype.then = function(t2, e2) {
        if ("function" != typeof t2 && this.state === o || "function" != typeof e2 && this.state === a)
          return this;
        var i2 = new this.constructor(s);
        this.state !== h ? c(i2, this.state === o ? t2 : e2, this.outcome) : this.queue.push(new l(i2, t2, e2));
        return i2;
      }, l.prototype.callFulfilled = function(t2) {
        n.resolve(this.promise, t2);
      }, l.prototype.otherCallFulfilled = function(t2) {
        c(this.promise, this.onFulfilled, t2);
      }, l.prototype.callRejected = function(t2) {
        n.reject(this.promise, t2);
      }, l.prototype.otherCallRejected = function(t2) {
        c(this.promise, this.onRejected, t2);
      }, n.resolve = function(t2, e2) {
        var i2 = p(f, e2);
        if ("error" === i2.status)
          return n.reject(t2, i2.value);
        var r2 = i2.value;
        if (r2)
          d(t2, r2);
        else {
          t2.state = o, t2.outcome = e2;
          for (var s2 = -1, a2 = t2.queue.length; ++s2 < a2; )
            t2.queue[s2].callFulfilled(e2);
        }
        return t2;
      }, n.reject = function(t2, e2) {
        t2.state = a, t2.outcome = e2;
        for (var i2 = -1, r2 = t2.queue.length; ++i2 < r2; )
          t2.queue[i2].callRejected(e2);
        return t2;
      }, u.resolve = function(t2) {
        if (t2 instanceof this)
          return t2;
        return n.resolve(new this(s), t2);
      }, u.reject = function(t2) {
        var e2 = new this(s);
        return n.reject(e2, t2);
      }, u.all = function(t2) {
        var e2 = this;
        if ("[object Array]" !== Object.prototype.toString.call(t2))
          return this.reject(new TypeError("must be an array"));
        var i2 = t2.length, r2 = false;
        if (!i2)
          return this.resolve([]);
        var a2 = new Array(i2), o2 = 0, h2 = -1, u2 = new this(s);
        for (; ++h2 < i2; )
          l2(t2[h2], h2);
        return u2;
        function l2(t3, s2) {
          e2.resolve(t3).then(
            function(t4) {
              a2[s2] = t4, ++o2 !== i2 || r2 || (r2 = true, n.resolve(u2, a2));
            },
            function(t4) {
              r2 || (r2 = true, n.reject(u2, t4));
            }
          );
        }
      }, u.race = function(t2) {
        var e2 = this;
        if ("[object Array]" !== Object.prototype.toString.call(t2))
          return this.reject(new TypeError("must be an array"));
        var i2 = t2.length, r2 = false;
        if (!i2)
          return this.resolve([]);
        var a2 = -1, o2 = new this(s);
        for (; ++a2 < i2; )
          h2 = t2[a2], e2.resolve(h2).then(
            function(t3) {
              r2 || (r2 = true, n.resolve(o2, t3));
            },
            function(t3) {
              r2 || (r2 = true, n.reject(o2, t3));
            }
          );
        var h2;
        return o2;
      };
    },
    function(t, e, i) {
      (function(e2) {
        const i2 = e2.URL;
        t.exports = (t2, e3) => {
          if (!e3)
            return t2;
          const r = new i2(t2);
          return r.pathname = `${r.pathname}.${e3}`, r.href;
        };
      }).call(this, i(0));
    },
    function(t, e, i) {
      i.r(e), i.d(e, "toGeoJSON", function() {
        return n;
      }), i.d(e, "parseShp", function() {
        return a;
      }), i.d(e, "parseDbf", function() {
        return o;
      }), i.d(e, "parseZip", function() {
        return h;
      }), i.d(e, "getShapefile", function() {
        return u;
      }), i.d(e, "combine", function() {
        return l;
      });
      var r = i(1), s = i.n(r);
      function n(t2, e2, i2) {
        return s()(t2, e2, i2);
      }
      function a(t2, e2) {
        return t2.parseShp(t2, e2);
      }
      function o(t2, e2) {
        return s.a.parseDbf(t2, e2);
      }
      function h(t2, e2, i2) {
        return s.a.parseZip(t2, e2, i2);
      }
      function u(t2, e2, i2) {
        return s.a.getShapefile(t2, e2, i2);
      }
      function l(t2) {
        return s.a.combine(t2);
      }
    },
    function(t, e, i) {
      const r = i(8);
      t.exports = async (t2) => {
        const e2 = new r();
        await e2.loadAsync(t2);
        const i2 = e2.file(/.+/), s = {};
        return await Promise.all(
          i2.map(async (t3) => {
            let e3;
            e3 = "shp" === t3.name.slice(-3).toLowerCase() || "dbf" === t3.name.slice(-3).toLowerCase() ? await t3.async("nodebuffer") : await t3.async("text"), s[t3.name] = e3;
          })
        ), s;
      };
    },
    function(t, e, i) {
      (function(e2, r, s, n) {
        t.exports = function t2(e3, r2, s2) {
          function n2(o2, h) {
            if (!r2[o2]) {
              if (!e3[o2]) {
                if (!h && i(14))
                  return (void 0)(o2, true);
                if (a)
                  return a(o2, true);
                var u = new Error("Cannot find module '" + o2 + "'");
                throw u.code = "MODULE_NOT_FOUND", u;
              }
              var l = r2[o2] = { exports: {} };
              e3[o2][0].call(
                l.exports,
                function(t3) {
                  return n2(e3[o2][1][t3] || t3);
                },
                l,
                l.exports,
                t2,
                e3,
                r2,
                s2
              );
            }
            return r2[o2].exports;
          }
          for (var a = false, o = 0; o < s2.length; o++)
            n2(s2[o]);
          return n2;
        }(
          {
            1: [
              function(t2, e3, i2) {
                var r2 = t2("./utils"), s2 = t2("./support"), n2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
                i2.encode = function(t3) {
                  for (var e4, i3, s3, a, o, h, u, l = [], c = 0, f = t3.length, d = f, p = "string" !== r2.getTypeOf(t3); c < t3.length; )
                    d = f - c, s3 = p ? (e4 = t3[c++], i3 = c < f ? t3[c++] : 0, c < f ? t3[c++] : 0) : (e4 = t3.charCodeAt(c++), i3 = c < f ? t3.charCodeAt(c++) : 0, c < f ? t3.charCodeAt(c++) : 0), a = e4 >> 2, o = (3 & e4) << 4 | i3 >> 4, h = 1 < d ? (15 & i3) << 2 | s3 >> 6 : 64, u = 2 < d ? 63 & s3 : 64, l.push(n2.charAt(a) + n2.charAt(o) + n2.charAt(h) + n2.charAt(u));
                  return l.join("");
                }, i2.decode = function(t3) {
                  var e4, i3, r3, a, o, h, u = 0, l = 0, c = "data:";
                  if (t3.substr(0, c.length) === c)
                    throw new Error("Invalid base64 input, it looks like a data url.");
                  var f, d = 3 * (t3 = t3.replace(/[^A-Za-z0-9+/=]/g, "")).length / 4;
                  if (t3.charAt(t3.length - 1) === n2.charAt(64) && d--, t3.charAt(t3.length - 2) === n2.charAt(64) && d--, d % 1 != 0)
                    throw new Error("Invalid base64 input, bad content length.");
                  for (f = s2.uint8array ? new Uint8Array(0 | d) : new Array(0 | d); u < t3.length; )
                    e4 = n2.indexOf(t3.charAt(u++)) << 2 | (a = n2.indexOf(t3.charAt(u++))) >> 4, i3 = (15 & a) << 4 | (o = n2.indexOf(t3.charAt(u++))) >> 2, r3 = (3 & o) << 6 | (h = n2.indexOf(t3.charAt(u++))), f[l++] = e4, 64 !== o && (f[l++] = i3), 64 !== h && (f[l++] = r3);
                  return f;
                };
              },
              { "./support": 30, "./utils": 32 }
            ],
            2: [
              function(t2, e3, i2) {
                var r2 = t2("./external"), s2 = t2("./stream/DataWorker"), n2 = t2("./stream/Crc32Probe"), a = t2("./stream/DataLengthProbe");
                function o(t3, e4, i3, r3, s3) {
                  this.compressedSize = t3, this.uncompressedSize = e4, this.crc32 = i3, this.compression = r3, this.compressedContent = s3;
                }
                o.prototype = {
                  getContentWorker: function() {
                    var t3 = new s2(r2.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")), e4 = this;
                    return t3.on("end", function() {
                      if (this.streamInfo.data_length !== e4.uncompressedSize)
                        throw new Error("Bug : uncompressed data size mismatch");
                    }), t3;
                  },
                  getCompressedWorker: function() {
                    return new s2(r2.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
                  }
                }, o.createWorkerFrom = function(t3, e4, i3) {
                  return t3.pipe(new n2()).pipe(new a("uncompressedSize")).pipe(e4.compressWorker(i3)).pipe(new a("compressedSize")).withStreamInfo("compression", e4);
                }, e3.exports = o;
              },
              { "./external": 6, "./stream/Crc32Probe": 25, "./stream/DataLengthProbe": 26, "./stream/DataWorker": 27 }
            ],
            3: [
              function(t2, e3, i2) {
                var r2 = t2("./stream/GenericWorker");
                i2.STORE = {
                  magic: "\0\0",
                  compressWorker: function() {
                    return new r2("STORE compression");
                  },
                  uncompressWorker: function() {
                    return new r2("STORE decompression");
                  }
                }, i2.DEFLATE = t2("./flate");
              },
              { "./flate": 7, "./stream/GenericWorker": 28 }
            ],
            4: [
              function(t2, e3, i2) {
                var r2 = t2("./utils"), s2 = function() {
                  for (var t3, e4 = [], i3 = 0; i3 < 256; i3++) {
                    t3 = i3;
                    for (var r3 = 0; r3 < 8; r3++)
                      t3 = 1 & t3 ? 3988292384 ^ t3 >>> 1 : t3 >>> 1;
                    e4[i3] = t3;
                  }
                  return e4;
                }();
                e3.exports = function(t3, e4) {
                  return void 0 !== t3 && t3.length ? "string" !== r2.getTypeOf(t3) ? function(t4, e5, i3, r3) {
                    var n2 = s2, a = 0 + i3;
                    t4 ^= -1;
                    for (var o = 0; o < a; o++)
                      t4 = t4 >>> 8 ^ n2[255 & (t4 ^ e5[o])];
                    return -1 ^ t4;
                  }(0 | e4, t3, t3.length) : function(t4, e5, i3, r3) {
                    var n2 = s2, a = 0 + i3;
                    t4 ^= -1;
                    for (var o = 0; o < a; o++)
                      t4 = t4 >>> 8 ^ n2[255 & (t4 ^ e5.charCodeAt(o))];
                    return -1 ^ t4;
                  }(0 | e4, t3, t3.length) : 0;
                };
              },
              { "./utils": 32 }
            ],
            5: [
              function(t2, e3, i2) {
                i2.base64 = false, i2.binary = false, i2.dir = false, i2.createFolders = true, i2.date = null, i2.compression = null, i2.compressionOptions = null, i2.comment = null, i2.unixPermissions = null, i2.dosPermissions = null;
              },
              {}
            ],
            6: [
              function(t2, e3, i2) {
                var r2;
                r2 = "undefined" != typeof Promise ? Promise : t2("lie"), e3.exports = { Promise: r2 };
              },
              { lie: 37 }
            ],
            7: [
              function(t2, e3, i2) {
                var r2 = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Uint32Array, s2 = t2("pako"), n2 = t2("./utils"), a = t2("./stream/GenericWorker"), o = r2 ? "uint8array" : "array";
                function h(t3, e4) {
                  a.call(this, "FlateWorker/" + t3), this._pako = null, this._pakoAction = t3, this._pakoOptions = e4, this.meta = {};
                }
                i2.magic = "\b\0", n2.inherits(h, a), h.prototype.processChunk = function(t3) {
                  this.meta = t3.meta, null === this._pako && this._createPako(), this._pako.push(n2.transformTo(o, t3.data), false);
                }, h.prototype.flush = function() {
                  a.prototype.flush.call(this), null === this._pako && this._createPako(), this._pako.push([], true);
                }, h.prototype.cleanUp = function() {
                  a.prototype.cleanUp.call(this), this._pako = null;
                }, h.prototype._createPako = function() {
                  this._pako = new s2[this._pakoAction]({ raw: true, level: this._pakoOptions.level || -1 });
                  var t3 = this;
                  this._pako.onData = function(e4) {
                    t3.push({ data: e4, meta: t3.meta });
                  };
                }, i2.compressWorker = function(t3) {
                  return new h("Deflate", t3);
                }, i2.uncompressWorker = function() {
                  return new h("Inflate", {});
                };
              },
              { "./stream/GenericWorker": 28, "./utils": 32, pako: 38 }
            ],
            8: [
              function(t2, e3, i2) {
                function r2(t3, e4) {
                  var i3, r3 = "";
                  for (i3 = 0; i3 < e4; i3++)
                    r3 += String.fromCharCode(255 & t3), t3 >>>= 8;
                  return r3;
                }
                function s2(t3, e4, i3, s3, a2, l2) {
                  var c, f, d = t3.file, p = t3.compression, m = l2 !== o.utf8encode, g = n2.transformTo("string", l2(d.name)), _ = n2.transformTo("string", o.utf8encode(d.name)), y = d.comment, v = n2.transformTo("string", l2(y)), b = n2.transformTo("string", o.utf8encode(y)), w = _.length !== d.name.length, M = b.length !== y.length, x = "", k = "", S = "", E = d.dir, C = d.date, A = { crc32: 0, compressedSize: 0, uncompressedSize: 0 };
                  e4 && !i3 || (A.crc32 = t3.crc32, A.compressedSize = t3.compressedSize, A.uncompressedSize = t3.uncompressedSize);
                  var I = 0;
                  e4 && (I |= 8), m || !w && !M || (I |= 2048);
                  var O = 0, T = 0;
                  E && (O |= 16), "UNIX" === a2 ? (T = 798, O |= function(t4, e5) {
                    var i4 = t4;
                    return t4 || (i4 = e5 ? 16893 : 33204), (65535 & i4) << 16;
                  }(d.unixPermissions, E)) : (T = 20, O |= function(t4) {
                    return 63 & (t4 || 0);
                  }(d.dosPermissions)), c = C.getUTCHours(), c <<= 6, c |= C.getUTCMinutes(), c <<= 5, c |= C.getUTCSeconds() / 2, f = C.getUTCFullYear() - 1980, f <<= 4, f |= C.getUTCMonth() + 1, f <<= 5, f |= C.getUTCDate(), w && (k = r2(1, 1) + r2(h(g), 4) + _, x += "up" + r2(k.length, 2) + k), M && (S = r2(1, 1) + r2(h(v), 4) + b, x += "uc" + r2(S.length, 2) + S);
                  var z = "";
                  return z += "\n\0", z += r2(I, 2), z += p.magic, z += r2(c, 2), z += r2(f, 2), z += r2(A.crc32, 4), z += r2(A.compressedSize, 4), z += r2(A.uncompressedSize, 4), z += r2(g.length, 2), z += r2(x.length, 2), { fileRecord: u.LOCAL_FILE_HEADER + z + g + x, dirRecord: u.CENTRAL_FILE_HEADER + r2(T, 2) + z + r2(v.length, 2) + "\0\0\0\0" + r2(O, 4) + r2(s3, 4) + g + x + v };
                }
                var n2 = t2("../utils"), a = t2("../stream/GenericWorker"), o = t2("../utf8"), h = t2("../crc32"), u = t2("../signature");
                function l(t3, e4, i3, r3) {
                  a.call(this, "ZipFileWorker"), this.bytesWritten = 0, this.zipComment = e4, this.zipPlatform = i3, this.encodeFileName = r3, this.streamFiles = t3, this.accumulate = false, this.contentBuffer = [], this.dirRecords = [], this.currentSourceOffset = 0, this.entriesCount = 0, this.currentFile = null, this._sources = [];
                }
                n2.inherits(l, a), l.prototype.push = function(t3) {
                  var e4 = t3.meta.percent || 0, i3 = this.entriesCount, r3 = this._sources.length;
                  this.accumulate ? this.contentBuffer.push(t3) : (this.bytesWritten += t3.data.length, a.prototype.push.call(this, { data: t3.data, meta: { currentFile: this.currentFile, percent: i3 ? (e4 + 100 * (i3 - r3 - 1)) / i3 : 100 } }));
                }, l.prototype.openedSource = function(t3) {
                  this.currentSourceOffset = this.bytesWritten, this.currentFile = t3.file.name;
                  var e4 = this.streamFiles && !t3.file.dir;
                  if (e4) {
                    var i3 = s2(t3, e4, false, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
                    this.push({ data: i3.fileRecord, meta: { percent: 0 } });
                  } else
                    this.accumulate = true;
                }, l.prototype.closedSource = function(t3) {
                  this.accumulate = false;
                  var e4 = this.streamFiles && !t3.file.dir, i3 = s2(t3, e4, true, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
                  if (this.dirRecords.push(i3.dirRecord), e4)
                    this.push({
                      data: function(t4) {
                        return u.DATA_DESCRIPTOR + r2(t4.crc32, 4) + r2(t4.compressedSize, 4) + r2(t4.uncompressedSize, 4);
                      }(t3),
                      meta: { percent: 100 }
                    });
                  else
                    for (this.push({ data: i3.fileRecord, meta: { percent: 0 } }); this.contentBuffer.length; )
                      this.push(this.contentBuffer.shift());
                  this.currentFile = null;
                }, l.prototype.flush = function() {
                  for (var t3 = this.bytesWritten, e4 = 0; e4 < this.dirRecords.length; e4++)
                    this.push({ data: this.dirRecords[e4], meta: { percent: 100 } });
                  var i3 = this.bytesWritten - t3, s3 = function(t4, e5, i4, s4, a2) {
                    var o2 = n2.transformTo("string", a2(s4));
                    return u.CENTRAL_DIRECTORY_END + "\0\0\0\0" + r2(t4, 2) + r2(t4, 2) + r2(e5, 4) + r2(i4, 4) + r2(o2.length, 2) + o2;
                  }(this.dirRecords.length, i3, t3, this.zipComment, this.encodeFileName);
                  this.push({ data: s3, meta: { percent: 100 } });
                }, l.prototype.prepareNextSource = function() {
                  this.previous = this._sources.shift(), this.openedSource(this.previous.streamInfo), this.isPaused ? this.previous.pause() : this.previous.resume();
                }, l.prototype.registerPrevious = function(t3) {
                  this._sources.push(t3);
                  var e4 = this;
                  return t3.on("data", function(t4) {
                    e4.processChunk(t4);
                  }), t3.on("end", function() {
                    e4.closedSource(e4.previous.streamInfo), e4._sources.length ? e4.prepareNextSource() : e4.end();
                  }), t3.on("error", function(t4) {
                    e4.error(t4);
                  }), this;
                }, l.prototype.resume = function() {
                  return !!a.prototype.resume.call(this) && (!this.previous && this._sources.length ? (this.prepareNextSource(), true) : this.previous || this._sources.length || this.generatedError ? void 0 : (this.end(), true));
                }, l.prototype.error = function(t3) {
                  var e4 = this._sources;
                  if (!a.prototype.error.call(this, t3))
                    return false;
                  for (var i3 = 0; i3 < e4.length; i3++)
                    try {
                      e4[i3].error(t3);
                    } catch (t4) {
                    }
                  return true;
                }, l.prototype.lock = function() {
                  a.prototype.lock.call(this);
                  for (var t3 = this._sources, e4 = 0; e4 < t3.length; e4++)
                    t3[e4].lock();
                }, e3.exports = l;
              },
              { "../crc32": 4, "../signature": 23, "../stream/GenericWorker": 28, "../utf8": 31, "../utils": 32 }
            ],
            9: [
              function(t2, e3, i2) {
                var r2 = t2("../compressions"), s2 = t2("./ZipFileWorker");
                i2.generateWorker = function(t3, e4, i3) {
                  var n2 = new s2(e4.streamFiles, i3, e4.platform, e4.encodeFileName), a = 0;
                  try {
                    t3.forEach(function(t4, i4) {
                      a++;
                      var s3 = function(t5, e5) {
                        var i5 = t5 || e5, s4 = r2[i5];
                        if (!s4)
                          throw new Error(i5 + " is not a valid compression method !");
                        return s4;
                      }(i4.options.compression, e4.compression), o = i4.options.compressionOptions || e4.compressionOptions || {}, h = i4.dir, u = i4.date;
                      i4._compressWorker(s3, o).withStreamInfo("file", { name: t4, dir: h, date: u, comment: i4.comment || "", unixPermissions: i4.unixPermissions, dosPermissions: i4.dosPermissions }).pipe(n2);
                    }), n2.entriesCount = a;
                  } catch (t4) {
                    n2.error(t4);
                  }
                  return n2;
                };
              },
              { "../compressions": 3, "./ZipFileWorker": 8 }
            ],
            10: [
              function(t2, e3, i2) {
                function r2() {
                  if (!(this instanceof r2))
                    return new r2();
                  if (arguments.length)
                    throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
                  this.files = /* @__PURE__ */ Object.create(null), this.comment = null, this.root = "", this.clone = function() {
                    var t3 = new r2();
                    for (var e4 in this)
                      "function" != typeof this[e4] && (t3[e4] = this[e4]);
                    return t3;
                  };
                }
                (r2.prototype = t2("./object")).loadAsync = t2("./load"), r2.support = t2("./support"), r2.defaults = t2("./defaults"), r2.version = "3.10.1", r2.loadAsync = function(t3, e4) {
                  return new r2().loadAsync(t3, e4);
                }, r2.external = t2("./external"), e3.exports = r2;
              },
              { "./defaults": 5, "./external": 6, "./load": 11, "./object": 15, "./support": 30 }
            ],
            11: [
              function(t2, e3, i2) {
                var r2 = t2("./utils"), s2 = t2("./external"), n2 = t2("./utf8"), a = t2("./zipEntries"), o = t2("./stream/Crc32Probe"), h = t2("./nodejsUtils");
                function u(t3) {
                  return new s2.Promise(function(e4, i3) {
                    var r3 = t3.decompressed.getContentWorker().pipe(new o());
                    r3.on("error", function(t4) {
                      i3(t4);
                    }).on("end", function() {
                      r3.streamInfo.crc32 !== t3.decompressed.crc32 ? i3(new Error("Corrupted zip : CRC32 mismatch")) : e4();
                    }).resume();
                  });
                }
                e3.exports = function(t3, e4) {
                  var i3 = this;
                  return e4 = r2.extend(e4 || {}, { base64: false, checkCRC32: false, optimizedBinaryString: false, createFolders: false, decodeFileName: n2.utf8decode }), h.isNode && h.isStream(t3) ? s2.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")) : r2.prepareContent("the loaded zip file", t3, true, e4.optimizedBinaryString, e4.base64).then(function(t4) {
                    var i4 = new a(e4);
                    return i4.load(t4), i4;
                  }).then(function(t4) {
                    var i4 = [s2.Promise.resolve(t4)], r3 = t4.files;
                    if (e4.checkCRC32)
                      for (var n3 = 0; n3 < r3.length; n3++)
                        i4.push(u(r3[n3]));
                    return s2.Promise.all(i4);
                  }).then(function(t4) {
                    for (var s3 = t4.shift(), n3 = s3.files, a2 = 0; a2 < n3.length; a2++) {
                      var o2 = n3[a2], h2 = o2.fileNameStr, u2 = r2.resolve(o2.fileNameStr);
                      i3.file(u2, o2.decompressed, {
                        binary: true,
                        optimizedBinaryString: true,
                        date: o2.date,
                        dir: o2.dir,
                        comment: o2.fileCommentStr.length ? o2.fileCommentStr : null,
                        unixPermissions: o2.unixPermissions,
                        dosPermissions: o2.dosPermissions,
                        createFolders: e4.createFolders
                      }), o2.dir || (i3.file(u2).unsafeOriginalName = h2);
                    }
                    return s3.zipComment.length && (i3.comment = s3.zipComment), i3;
                  });
                };
              },
              { "./external": 6, "./nodejsUtils": 14, "./stream/Crc32Probe": 25, "./utf8": 31, "./utils": 32, "./zipEntries": 33 }
            ],
            12: [
              function(t2, e3, i2) {
                var r2 = t2("../utils"), s2 = t2("../stream/GenericWorker");
                function n2(t3, e4) {
                  s2.call(this, "Nodejs stream input adapter for " + t3), this._upstreamEnded = false, this._bindStream(e4);
                }
                r2.inherits(n2, s2), n2.prototype._bindStream = function(t3) {
                  var e4 = this;
                  (this._stream = t3).pause(), t3.on("data", function(t4) {
                    e4.push({ data: t4, meta: { percent: 0 } });
                  }).on("error", function(t4) {
                    e4.isPaused ? this.generatedError = t4 : e4.error(t4);
                  }).on("end", function() {
                    e4.isPaused ? e4._upstreamEnded = true : e4.end();
                  });
                }, n2.prototype.pause = function() {
                  return !!s2.prototype.pause.call(this) && (this._stream.pause(), true);
                }, n2.prototype.resume = function() {
                  return !!s2.prototype.resume.call(this) && (this._upstreamEnded ? this.end() : this._stream.resume(), true);
                }, e3.exports = n2;
              },
              { "../stream/GenericWorker": 28, "../utils": 32 }
            ],
            13: [
              function(t2, e3, i2) {
                var r2 = t2("readable-stream").Readable;
                function s2(t3, e4, i3) {
                  r2.call(this, e4), this._helper = t3;
                  var s3 = this;
                  t3.on("data", function(t4, e5) {
                    s3.push(t4) || s3._helper.pause(), i3 && i3(e5);
                  }).on("error", function(t4) {
                    s3.emit("error", t4);
                  }).on("end", function() {
                    s3.push(null);
                  });
                }
                t2("../utils").inherits(s2, r2), s2.prototype._read = function() {
                  this._helper.resume();
                }, e3.exports = s2;
              },
              { "../utils": 32, "readable-stream": 16 }
            ],
            14: [
              function(t2, i2, r2) {
                i2.exports = {
                  isNode: void 0 !== e2,
                  newBufferFrom: function(t3, i3) {
                    if (e2.from && e2.from !== Uint8Array.from)
                      return e2.from(t3, i3);
                    if ("number" == typeof t3)
                      throw new Error('The "data" argument must not be a number');
                    return new e2(t3, i3);
                  },
                  allocBuffer: function(t3) {
                    if (e2.alloc)
                      return e2.alloc(t3);
                    var i3 = new e2(t3);
                    return i3.fill(0), i3;
                  },
                  isBuffer: function(t3) {
                    return e2.isBuffer(t3);
                  },
                  isStream: function(t3) {
                    return t3 && "function" == typeof t3.on && "function" == typeof t3.pause && "function" == typeof t3.resume;
                  }
                };
              },
              {}
            ],
            15: [
              function(t2, e3, i2) {
                function r2(t3, e4, i3) {
                  var r3, s3 = n2.getTypeOf(e4), o2 = n2.extend(i3 || {}, h);
                  o2.date = o2.date || new Date(), null !== o2.compression && (o2.compression = o2.compression.toUpperCase()), "string" == typeof o2.unixPermissions && (o2.unixPermissions = parseInt(o2.unixPermissions, 8)), o2.unixPermissions && 16384 & o2.unixPermissions && (o2.dir = true), o2.dosPermissions && 16 & o2.dosPermissions && (o2.dir = true), o2.dir && (t3 = m(t3)), o2.createFolders && (r3 = p(t3)) && g.call(this, r3, true);
                  var c2, _2 = "string" === s3 && false === o2.binary && false === o2.base64;
                  i3 && void 0 !== i3.binary || (o2.binary = !_2), (e4 instanceof u && 0 === e4.uncompressedSize || o2.dir || !e4 || 0 === e4.length) && (o2.base64 = false, o2.binary = true, e4 = "", o2.compression = "STORE", s3 = "string"), c2 = e4 instanceof u || e4 instanceof a ? e4 : f.isNode && f.isStream(e4) ? new d(t3, e4) : n2.prepareContent(t3, e4, o2.binary, o2.optimizedBinaryString, o2.base64);
                  var y2 = new l(t3, c2, o2);
                  this.files[t3] = y2;
                }
                var s2 = t2("./utf8"), n2 = t2("./utils"), a = t2("./stream/GenericWorker"), o = t2("./stream/StreamHelper"), h = t2("./defaults"), u = t2("./compressedObject"), l = t2("./zipObject"), c = t2("./generate"), f = t2("./nodejsUtils"), d = t2("./nodejs/NodejsStreamInputAdapter"), p = function(t3) {
                  "/" === t3.slice(-1) && (t3 = t3.substring(0, t3.length - 1));
                  var e4 = t3.lastIndexOf("/");
                  return 0 < e4 ? t3.substring(0, e4) : "";
                }, m = function(t3) {
                  return "/" !== t3.slice(-1) && (t3 += "/"), t3;
                }, g = function(t3, e4) {
                  return e4 = void 0 !== e4 ? e4 : h.createFolders, t3 = m(t3), this.files[t3] || r2.call(this, t3, null, { dir: true, createFolders: e4 }), this.files[t3];
                };
                function _(t3) {
                  return "[object RegExp]" === Object.prototype.toString.call(t3);
                }
                var y = {
                  load: function() {
                    throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
                  },
                  forEach: function(t3) {
                    var e4, i3, r3;
                    for (e4 in this.files)
                      r3 = this.files[e4], (i3 = e4.slice(this.root.length, e4.length)) && e4.slice(0, this.root.length) === this.root && t3(i3, r3);
                  },
                  filter: function(t3) {
                    var e4 = [];
                    return this.forEach(function(i3, r3) {
                      t3(i3, r3) && e4.push(r3);
                    }), e4;
                  },
                  file: function(t3, e4, i3) {
                    if (1 !== arguments.length)
                      return t3 = this.root + t3, r2.call(this, t3, e4, i3), this;
                    if (_(t3)) {
                      var s3 = t3;
                      return this.filter(function(t4, e5) {
                        return !e5.dir && s3.test(t4);
                      });
                    }
                    var n3 = this.files[this.root + t3];
                    return n3 && !n3.dir ? n3 : null;
                  },
                  folder: function(t3) {
                    if (!t3)
                      return this;
                    if (_(t3))
                      return this.filter(function(e5, i4) {
                        return i4.dir && t3.test(e5);
                      });
                    var e4 = this.root + t3, i3 = g.call(this, e4), r3 = this.clone();
                    return r3.root = i3.name, r3;
                  },
                  remove: function(t3) {
                    t3 = this.root + t3;
                    var e4 = this.files[t3];
                    if (e4 || ("/" !== t3.slice(-1) && (t3 += "/"), e4 = this.files[t3]), e4 && !e4.dir)
                      delete this.files[t3];
                    else
                      for (var i3 = this.filter(function(e5, i4) {
                        return i4.name.slice(0, t3.length) === t3;
                      }), r3 = 0; r3 < i3.length; r3++)
                        delete this.files[i3[r3].name];
                    return this;
                  },
                  generate: function() {
                    throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
                  },
                  generateInternalStream: function(t3) {
                    var e4, i3 = {};
                    try {
                      if ((i3 = n2.extend(t3 || {}, { streamFiles: false, compression: "STORE", compressionOptions: null, type: "", platform: "DOS", comment: null, mimeType: "application/zip", encodeFileName: s2.utf8encode })).type = i3.type.toLowerCase(), i3.compression = i3.compression.toUpperCase(), "binarystring" === i3.type && (i3.type = "string"), !i3.type)
                        throw new Error("No output type specified.");
                      n2.checkSupport(i3.type), "darwin" !== i3.platform && "freebsd" !== i3.platform && "linux" !== i3.platform && "sunos" !== i3.platform || (i3.platform = "UNIX"), "win32" === i3.platform && (i3.platform = "DOS");
                      var r3 = i3.comment || this.comment || "";
                      e4 = c.generateWorker(this, i3, r3);
                    } catch (t4) {
                      (e4 = new a("error")).error(t4);
                    }
                    return new o(e4, i3.type || "string", i3.mimeType);
                  },
                  generateAsync: function(t3, e4) {
                    return this.generateInternalStream(t3).accumulate(e4);
                  },
                  generateNodeStream: function(t3, e4) {
                    return (t3 = t3 || {}).type || (t3.type = "nodebuffer"), this.generateInternalStream(t3).toNodejsStream(e4);
                  }
                };
                e3.exports = y;
              },
              { "./compressedObject": 2, "./defaults": 5, "./generate": 9, "./nodejs/NodejsStreamInputAdapter": 12, "./nodejsUtils": 14, "./stream/GenericWorker": 28, "./stream/StreamHelper": 29, "./utf8": 31, "./utils": 32, "./zipObject": 35 }
            ],
            16: [
              function(t2, e3, i2) {
                e3.exports = t2("stream");
              },
              { stream: void 0 }
            ],
            17: [
              function(t2, e3, i2) {
                var r2 = t2("./DataReader");
                function s2(t3) {
                  r2.call(this, t3);
                  for (var e4 = 0; e4 < this.data.length; e4++)
                    t3[e4] = 255 & t3[e4];
                }
                t2("../utils").inherits(s2, r2), s2.prototype.byteAt = function(t3) {
                  return this.data[this.zero + t3];
                }, s2.prototype.lastIndexOfSignature = function(t3) {
                  for (var e4 = t3.charCodeAt(0), i3 = t3.charCodeAt(1), r3 = t3.charCodeAt(2), s3 = t3.charCodeAt(3), n2 = this.length - 4; 0 <= n2; --n2)
                    if (this.data[n2] === e4 && this.data[n2 + 1] === i3 && this.data[n2 + 2] === r3 && this.data[n2 + 3] === s3)
                      return n2 - this.zero;
                  return -1;
                }, s2.prototype.readAndCheckSignature = function(t3) {
                  var e4 = t3.charCodeAt(0), i3 = t3.charCodeAt(1), r3 = t3.charCodeAt(2), s3 = t3.charCodeAt(3), n2 = this.readData(4);
                  return e4 === n2[0] && i3 === n2[1] && r3 === n2[2] && s3 === n2[3];
                }, s2.prototype.readData = function(t3) {
                  if (this.checkOffset(t3), 0 === t3)
                    return [];
                  var e4 = this.data.slice(this.zero + this.index, this.zero + this.index + t3);
                  return this.index += t3, e4;
                }, e3.exports = s2;
              },
              { "../utils": 32, "./DataReader": 18 }
            ],
            18: [
              function(t2, e3, i2) {
                var r2 = t2("../utils");
                function s2(t3) {
                  this.data = t3, this.length = t3.length, this.index = 0, this.zero = 0;
                }
                s2.prototype = {
                  checkOffset: function(t3) {
                    this.checkIndex(this.index + t3);
                  },
                  checkIndex: function(t3) {
                    if (this.length < this.zero + t3 || t3 < 0)
                      throw new Error("End of data reached (data length = " + this.length + ", asked index = " + t3 + "). Corrupted zip ?");
                  },
                  setIndex: function(t3) {
                    this.checkIndex(t3), this.index = t3;
                  },
                  skip: function(t3) {
                    this.setIndex(this.index + t3);
                  },
                  byteAt: function() {
                  },
                  readInt: function(t3) {
                    var e4, i3 = 0;
                    for (this.checkOffset(t3), e4 = this.index + t3 - 1; e4 >= this.index; e4--)
                      i3 = (i3 << 8) + this.byteAt(e4);
                    return this.index += t3, i3;
                  },
                  readString: function(t3) {
                    return r2.transformTo("string", this.readData(t3));
                  },
                  readData: function() {
                  },
                  lastIndexOfSignature: function() {
                  },
                  readAndCheckSignature: function() {
                  },
                  readDate: function() {
                    var t3 = this.readInt(4);
                    return new Date(Date.UTC(1980 + (t3 >> 25 & 127), (t3 >> 21 & 15) - 1, t3 >> 16 & 31, t3 >> 11 & 31, t3 >> 5 & 63, (31 & t3) << 1));
                  }
                }, e3.exports = s2;
              },
              { "../utils": 32 }
            ],
            19: [
              function(t2, e3, i2) {
                var r2 = t2("./Uint8ArrayReader");
                function s2(t3) {
                  r2.call(this, t3);
                }
                t2("../utils").inherits(s2, r2), s2.prototype.readData = function(t3) {
                  this.checkOffset(t3);
                  var e4 = this.data.slice(this.zero + this.index, this.zero + this.index + t3);
                  return this.index += t3, e4;
                }, e3.exports = s2;
              },
              { "../utils": 32, "./Uint8ArrayReader": 21 }
            ],
            20: [
              function(t2, e3, i2) {
                var r2 = t2("./DataReader");
                function s2(t3) {
                  r2.call(this, t3);
                }
                t2("../utils").inherits(s2, r2), s2.prototype.byteAt = function(t3) {
                  return this.data.charCodeAt(this.zero + t3);
                }, s2.prototype.lastIndexOfSignature = function(t3) {
                  return this.data.lastIndexOf(t3) - this.zero;
                }, s2.prototype.readAndCheckSignature = function(t3) {
                  return t3 === this.readData(4);
                }, s2.prototype.readData = function(t3) {
                  this.checkOffset(t3);
                  var e4 = this.data.slice(this.zero + this.index, this.zero + this.index + t3);
                  return this.index += t3, e4;
                }, e3.exports = s2;
              },
              { "../utils": 32, "./DataReader": 18 }
            ],
            21: [
              function(t2, e3, i2) {
                var r2 = t2("./ArrayReader");
                function s2(t3) {
                  r2.call(this, t3);
                }
                t2("../utils").inherits(s2, r2), s2.prototype.readData = function(t3) {
                  if (this.checkOffset(t3), 0 === t3)
                    return new Uint8Array(0);
                  var e4 = this.data.subarray(this.zero + this.index, this.zero + this.index + t3);
                  return this.index += t3, e4;
                }, e3.exports = s2;
              },
              { "../utils": 32, "./ArrayReader": 17 }
            ],
            22: [
              function(t2, e3, i2) {
                var r2 = t2("../utils"), s2 = t2("../support"), n2 = t2("./ArrayReader"), a = t2("./StringReader"), o = t2("./NodeBufferReader"), h = t2("./Uint8ArrayReader");
                e3.exports = function(t3) {
                  var e4 = r2.getTypeOf(t3);
                  return r2.checkSupport(e4), "string" !== e4 || s2.uint8array ? "nodebuffer" === e4 ? new o(t3) : s2.uint8array ? new h(r2.transformTo("uint8array", t3)) : new n2(r2.transformTo("array", t3)) : new a(t3);
                };
              },
              { "../support": 30, "../utils": 32, "./ArrayReader": 17, "./NodeBufferReader": 19, "./StringReader": 20, "./Uint8ArrayReader": 21 }
            ],
            23: [
              function(t2, e3, i2) {
                i2.LOCAL_FILE_HEADER = "PK", i2.CENTRAL_FILE_HEADER = "PK", i2.CENTRAL_DIRECTORY_END = "PK", i2.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07", i2.ZIP64_CENTRAL_DIRECTORY_END = "PK", i2.DATA_DESCRIPTOR = "PK\x07\b";
              },
              {}
            ],
            24: [
              function(t2, e3, i2) {
                var r2 = t2("./GenericWorker"), s2 = t2("../utils");
                function n2(t3) {
                  r2.call(this, "ConvertWorker to " + t3), this.destType = t3;
                }
                s2.inherits(n2, r2), n2.prototype.processChunk = function(t3) {
                  this.push({ data: s2.transformTo(this.destType, t3.data), meta: t3.meta });
                }, e3.exports = n2;
              },
              { "../utils": 32, "./GenericWorker": 28 }
            ],
            25: [
              function(t2, e3, i2) {
                var r2 = t2("./GenericWorker"), s2 = t2("../crc32");
                function n2() {
                  r2.call(this, "Crc32Probe"), this.withStreamInfo("crc32", 0);
                }
                t2("../utils").inherits(n2, r2), n2.prototype.processChunk = function(t3) {
                  this.streamInfo.crc32 = s2(t3.data, this.streamInfo.crc32 || 0), this.push(t3);
                }, e3.exports = n2;
              },
              { "../crc32": 4, "../utils": 32, "./GenericWorker": 28 }
            ],
            26: [
              function(t2, e3, i2) {
                var r2 = t2("../utils"), s2 = t2("./GenericWorker");
                function n2(t3) {
                  s2.call(this, "DataLengthProbe for " + t3), this.propName = t3, this.withStreamInfo(t3, 0);
                }
                r2.inherits(n2, s2), n2.prototype.processChunk = function(t3) {
                  if (t3) {
                    var e4 = this.streamInfo[this.propName] || 0;
                    this.streamInfo[this.propName] = e4 + t3.data.length;
                  }
                  s2.prototype.processChunk.call(this, t3);
                }, e3.exports = n2;
              },
              { "../utils": 32, "./GenericWorker": 28 }
            ],
            27: [
              function(t2, e3, i2) {
                var r2 = t2("../utils"), s2 = t2("./GenericWorker");
                function n2(t3) {
                  s2.call(this, "DataWorker");
                  var e4 = this;
                  this.dataIsReady = false, this.index = 0, this.max = 0, this.data = null, this.type = "", this._tickScheduled = false, t3.then(
                    function(t4) {
                      e4.dataIsReady = true, e4.data = t4, e4.max = t4 && t4.length || 0, e4.type = r2.getTypeOf(t4), e4.isPaused || e4._tickAndRepeat();
                    },
                    function(t4) {
                      e4.error(t4);
                    }
                  );
                }
                r2.inherits(n2, s2), n2.prototype.cleanUp = function() {
                  s2.prototype.cleanUp.call(this), this.data = null;
                }, n2.prototype.resume = function() {
                  return !!s2.prototype.resume.call(this) && (!this._tickScheduled && this.dataIsReady && (this._tickScheduled = true, r2.delay(this._tickAndRepeat, [], this)), true);
                }, n2.prototype._tickAndRepeat = function() {
                  this._tickScheduled = false, this.isPaused || this.isFinished || (this._tick(), this.isFinished || (r2.delay(this._tickAndRepeat, [], this), this._tickScheduled = true));
                }, n2.prototype._tick = function() {
                  if (this.isPaused || this.isFinished)
                    return false;
                  var t3 = null, e4 = Math.min(this.max, this.index + 16384);
                  if (this.index >= this.max)
                    return this.end();
                  switch (this.type) {
                    case "string":
                      t3 = this.data.substring(this.index, e4);
                      break;
                    case "uint8array":
                      t3 = this.data.subarray(this.index, e4);
                      break;
                    case "array":
                    case "nodebuffer":
                      t3 = this.data.slice(this.index, e4);
                  }
                  return this.index = e4, this.push({ data: t3, meta: { percent: this.max ? this.index / this.max * 100 : 0 } });
                }, e3.exports = n2;
              },
              { "../utils": 32, "./GenericWorker": 28 }
            ],
            28: [
              function(t2, e3, i2) {
                function r2(t3) {
                  this.name = t3 || "default", this.streamInfo = {}, this.generatedError = null, this.extraStreamInfo = {}, this.isPaused = true, this.isFinished = false, this.isLocked = false, this._listeners = { data: [], end: [], error: [] }, this.previous = null;
                }
                r2.prototype = {
                  push: function(t3) {
                    this.emit("data", t3);
                  },
                  end: function() {
                    if (this.isFinished)
                      return false;
                    this.flush();
                    try {
                      this.emit("end"), this.cleanUp(), this.isFinished = true;
                    } catch (t3) {
                      this.emit("error", t3);
                    }
                    return true;
                  },
                  error: function(t3) {
                    return !this.isFinished && (this.isPaused ? this.generatedError = t3 : (this.isFinished = true, this.emit("error", t3), this.previous && this.previous.error(t3), this.cleanUp()), true);
                  },
                  on: function(t3, e4) {
                    return this._listeners[t3].push(e4), this;
                  },
                  cleanUp: function() {
                    this.streamInfo = this.generatedError = this.extraStreamInfo = null, this._listeners = [];
                  },
                  emit: function(t3, e4) {
                    if (this._listeners[t3])
                      for (var i3 = 0; i3 < this._listeners[t3].length; i3++)
                        this._listeners[t3][i3].call(this, e4);
                  },
                  pipe: function(t3) {
                    return t3.registerPrevious(this);
                  },
                  registerPrevious: function(t3) {
                    if (this.isLocked)
                      throw new Error("The stream '" + this + "' has already been used.");
                    this.streamInfo = t3.streamInfo, this.mergeStreamInfo(), this.previous = t3;
                    var e4 = this;
                    return t3.on("data", function(t4) {
                      e4.processChunk(t4);
                    }), t3.on("end", function() {
                      e4.end();
                    }), t3.on("error", function(t4) {
                      e4.error(t4);
                    }), this;
                  },
                  pause: function() {
                    return !this.isPaused && !this.isFinished && (this.isPaused = true, this.previous && this.previous.pause(), true);
                  },
                  resume: function() {
                    if (!this.isPaused || this.isFinished)
                      return false;
                    var t3 = this.isPaused = false;
                    return this.generatedError && (this.error(this.generatedError), t3 = true), this.previous && this.previous.resume(), !t3;
                  },
                  flush: function() {
                  },
                  processChunk: function(t3) {
                    this.push(t3);
                  },
                  withStreamInfo: function(t3, e4) {
                    return this.extraStreamInfo[t3] = e4, this.mergeStreamInfo(), this;
                  },
                  mergeStreamInfo: function() {
                    for (var t3 in this.extraStreamInfo)
                      Object.prototype.hasOwnProperty.call(this.extraStreamInfo, t3) && (this.streamInfo[t3] = this.extraStreamInfo[t3]);
                  },
                  lock: function() {
                    if (this.isLocked)
                      throw new Error("The stream '" + this + "' has already been used.");
                    this.isLocked = true, this.previous && this.previous.lock();
                  },
                  toString: function() {
                    var t3 = "Worker " + this.name;
                    return this.previous ? this.previous + " -> " + t3 : t3;
                  }
                }, e3.exports = r2;
              },
              {}
            ],
            29: [
              function(t2, i2, r2) {
                var s2 = t2("../utils"), n2 = t2("./ConvertWorker"), a = t2("./GenericWorker"), o = t2("../base64"), h = t2("../support"), u = t2("../external"), l = null;
                if (h.nodestream)
                  try {
                    l = t2("../nodejs/NodejsStreamOutputAdapter");
                  } catch (t3) {
                  }
                function c(t3, e3, i3) {
                  var r3 = e3;
                  switch (e3) {
                    case "blob":
                    case "arraybuffer":
                      r3 = "uint8array";
                      break;
                    case "base64":
                      r3 = "string";
                  }
                  try {
                    this._internalType = r3, this._outputType = e3, this._mimeType = i3, s2.checkSupport(r3), this._worker = t3.pipe(new n2(r3)), t3.lock();
                  } catch (t4) {
                    this._worker = new a("error"), this._worker.error(t4);
                  }
                }
                c.prototype = {
                  accumulate: function(t3) {
                    return function(t4, i3) {
                      return new u.Promise(function(r3, n3) {
                        var a2 = [], h2 = t4._internalType, u2 = t4._outputType, l2 = t4._mimeType;
                        t4.on("data", function(t5, e3) {
                          a2.push(t5), i3 && i3(e3);
                        }).on("error", function(t5) {
                          a2 = [], n3(t5);
                        }).on("end", function() {
                          try {
                            var t5 = function(t6, e3, i4) {
                              switch (t6) {
                                case "blob":
                                  return s2.newBlob(s2.transformTo("arraybuffer", e3), i4);
                                case "base64":
                                  return o.encode(e3);
                                default:
                                  return s2.transformTo(t6, e3);
                              }
                            }(
                              u2,
                              function(t6, i4) {
                                var r4, s3 = 0, n4 = null, a3 = 0;
                                for (r4 = 0; r4 < i4.length; r4++)
                                  a3 += i4[r4].length;
                                switch (t6) {
                                  case "string":
                                    return i4.join("");
                                  case "array":
                                    return Array.prototype.concat.apply([], i4);
                                  case "uint8array":
                                    for (n4 = new Uint8Array(a3), r4 = 0; r4 < i4.length; r4++)
                                      n4.set(i4[r4], s3), s3 += i4[r4].length;
                                    return n4;
                                  case "nodebuffer":
                                    return e2.concat(i4);
                                  default:
                                    throw new Error("concat : unsupported type '" + t6 + "'");
                                }
                              }(h2, a2),
                              l2
                            );
                            r3(t5);
                          } catch (t6) {
                            n3(t6);
                          }
                          a2 = [];
                        }).resume();
                      });
                    }(this, t3);
                  },
                  on: function(t3, e3) {
                    var i3 = this;
                    return "data" === t3 ? this._worker.on(t3, function(t4) {
                      e3.call(i3, t4.data, t4.meta);
                    }) : this._worker.on(t3, function() {
                      s2.delay(e3, arguments, i3);
                    }), this;
                  },
                  resume: function() {
                    return s2.delay(this._worker.resume, [], this._worker), this;
                  },
                  pause: function() {
                    return this._worker.pause(), this;
                  },
                  toNodejsStream: function(t3) {
                    if (s2.checkSupport("nodestream"), "nodebuffer" !== this._outputType)
                      throw new Error(this._outputType + " is not supported by this method");
                    return new l(this, { objectMode: "nodebuffer" !== this._outputType }, t3);
                  }
                }, i2.exports = c;
              },
              { "../base64": 1, "../external": 6, "../nodejs/NodejsStreamOutputAdapter": 13, "../support": 30, "../utils": 32, "./ConvertWorker": 24, "./GenericWorker": 28 }
            ],
            30: [
              function(t2, i2, r2) {
                if (r2.base64 = true, r2.array = true, r2.string = true, r2.arraybuffer = "undefined" != typeof ArrayBuffer && "undefined" != typeof Uint8Array, r2.nodebuffer = void 0 !== e2, r2.uint8array = "undefined" != typeof Uint8Array, "undefined" == typeof ArrayBuffer)
                  r2.blob = false;
                else {
                  var s2 = new ArrayBuffer(0);
                  try {
                    r2.blob = 0 === new Blob([s2], { type: "application/zip" }).size;
                  } catch (t3) {
                    try {
                      var n2 = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
                      n2.append(s2), r2.blob = 0 === n2.getBlob("application/zip").size;
                    } catch (t4) {
                      r2.blob = false;
                    }
                  }
                }
                try {
                  r2.nodestream = !!t2("readable-stream").Readable;
                } catch (t3) {
                  r2.nodestream = false;
                }
              },
              { "readable-stream": 16 }
            ],
            31: [
              function(t2, e3, i2) {
                for (var r2 = t2("./utils"), s2 = t2("./support"), n2 = t2("./nodejsUtils"), a = t2("./stream/GenericWorker"), o = new Array(256), h = 0; h < 256; h++)
                  o[h] = 252 <= h ? 6 : 248 <= h ? 5 : 240 <= h ? 4 : 224 <= h ? 3 : 192 <= h ? 2 : 1;
                function u() {
                  a.call(this, "utf-8 decode"), this.leftOver = null;
                }
                function l() {
                  a.call(this, "utf-8 encode");
                }
                o[254] = o[254] = 1, i2.utf8encode = function(t3) {
                  return s2.nodebuffer ? n2.newBufferFrom(t3, "utf-8") : function(t4) {
                    var e4, i3, r3, n3, a2, o2 = t4.length, h2 = 0;
                    for (n3 = 0; n3 < o2; n3++)
                      55296 == (64512 & (i3 = t4.charCodeAt(n3))) && n3 + 1 < o2 && 56320 == (64512 & (r3 = t4.charCodeAt(n3 + 1))) && (i3 = 65536 + (i3 - 55296 << 10) + (r3 - 56320), n3++), h2 += i3 < 128 ? 1 : i3 < 2048 ? 2 : i3 < 65536 ? 3 : 4;
                    for (e4 = s2.uint8array ? new Uint8Array(h2) : new Array(h2), n3 = a2 = 0; a2 < h2; n3++)
                      55296 == (64512 & (i3 = t4.charCodeAt(n3))) && n3 + 1 < o2 && 56320 == (64512 & (r3 = t4.charCodeAt(n3 + 1))) && (i3 = 65536 + (i3 - 55296 << 10) + (r3 - 56320), n3++), i3 < 128 ? e4[a2++] = i3 : (i3 < 2048 ? e4[a2++] = 192 | i3 >>> 6 : (i3 < 65536 ? e4[a2++] = 224 | i3 >>> 12 : (e4[a2++] = 240 | i3 >>> 18, e4[a2++] = 128 | i3 >>> 12 & 63), e4[a2++] = 128 | i3 >>> 6 & 63), e4[a2++] = 128 | 63 & i3);
                    return e4;
                  }(t3);
                }, i2.utf8decode = function(t3) {
                  return s2.nodebuffer ? r2.transformTo("nodebuffer", t3).toString("utf-8") : function(t4) {
                    var e4, i3, s3, n3, a2 = t4.length, h2 = new Array(2 * a2);
                    for (e4 = i3 = 0; e4 < a2; )
                      if ((s3 = t4[e4++]) < 128)
                        h2[i3++] = s3;
                      else if (4 < (n3 = o[s3]))
                        h2[i3++] = 65533, e4 += n3 - 1;
                      else {
                        for (s3 &= 2 === n3 ? 31 : 3 === n3 ? 15 : 7; 1 < n3 && e4 < a2; )
                          s3 = s3 << 6 | 63 & t4[e4++], n3--;
                        1 < n3 ? h2[i3++] = 65533 : s3 < 65536 ? h2[i3++] = s3 : (s3 -= 65536, h2[i3++] = 55296 | s3 >> 10 & 1023, h2[i3++] = 56320 | 1023 & s3);
                      }
                    return h2.length !== i3 && (h2.subarray ? h2 = h2.subarray(0, i3) : h2.length = i3), r2.applyFromCharCode(h2);
                  }(t3 = r2.transformTo(s2.uint8array ? "uint8array" : "array", t3));
                }, r2.inherits(u, a), u.prototype.processChunk = function(t3) {
                  var e4 = r2.transformTo(s2.uint8array ? "uint8array" : "array", t3.data);
                  if (this.leftOver && this.leftOver.length) {
                    if (s2.uint8array) {
                      var n3 = e4;
                      (e4 = new Uint8Array(n3.length + this.leftOver.length)).set(this.leftOver, 0), e4.set(n3, this.leftOver.length);
                    } else
                      e4 = this.leftOver.concat(e4);
                    this.leftOver = null;
                  }
                  var a2 = function(t4, e5) {
                    var i3;
                    for ((e5 = e5 || t4.length) > t4.length && (e5 = t4.length), i3 = e5 - 1; 0 <= i3 && 128 == (192 & t4[i3]); )
                      i3--;
                    return i3 < 0 || 0 === i3 ? e5 : i3 + o[t4[i3]] > e5 ? i3 : e5;
                  }(e4), h2 = e4;
                  a2 !== e4.length && (s2.uint8array ? (h2 = e4.subarray(0, a2), this.leftOver = e4.subarray(a2, e4.length)) : (h2 = e4.slice(0, a2), this.leftOver = e4.slice(a2, e4.length))), this.push({ data: i2.utf8decode(h2), meta: t3.meta });
                }, u.prototype.flush = function() {
                  this.leftOver && this.leftOver.length && (this.push({ data: i2.utf8decode(this.leftOver), meta: {} }), this.leftOver = null);
                }, i2.Utf8DecodeWorker = u, r2.inherits(l, a), l.prototype.processChunk = function(t3) {
                  this.push({ data: i2.utf8encode(t3.data), meta: t3.meta });
                }, i2.Utf8EncodeWorker = l;
              },
              { "./nodejsUtils": 14, "./stream/GenericWorker": 28, "./support": 30, "./utils": 32 }
            ],
            32: [
              function(t2, e3, i2) {
                var s2 = t2("./support"), n2 = t2("./base64"), a = t2("./nodejsUtils"), o = t2("./external");
                function h(t3) {
                  return t3;
                }
                function u(t3, e4) {
                  for (var i3 = 0; i3 < t3.length; ++i3)
                    e4[i3] = 255 & t3.charCodeAt(i3);
                  return e4;
                }
                t2("setimmediate"), i2.newBlob = function(t3, e4) {
                  i2.checkSupport("blob");
                  try {
                    return new Blob([t3], { type: e4 });
                  } catch (i3) {
                    try {
                      var r2 = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
                      return r2.append(t3), r2.getBlob(e4);
                    } catch (t4) {
                      throw new Error("Bug : can't construct the Blob.");
                    }
                  }
                };
                var l = {
                  stringifyByChunk: function(t3, e4, i3) {
                    var r2 = [], s3 = 0, n3 = t3.length;
                    if (n3 <= i3)
                      return String.fromCharCode.apply(null, t3);
                    for (; s3 < n3; )
                      "array" === e4 || "nodebuffer" === e4 ? r2.push(String.fromCharCode.apply(null, t3.slice(s3, Math.min(s3 + i3, n3)))) : r2.push(String.fromCharCode.apply(null, t3.subarray(s3, Math.min(s3 + i3, n3)))), s3 += i3;
                    return r2.join("");
                  },
                  stringifyByChar: function(t3) {
                    for (var e4 = "", i3 = 0; i3 < t3.length; i3++)
                      e4 += String.fromCharCode(t3[i3]);
                    return e4;
                  },
                  applyCanBeUsed: {
                    uint8array: function() {
                      try {
                        return s2.uint8array && 1 === String.fromCharCode.apply(null, new Uint8Array(1)).length;
                      } catch (t3) {
                        return false;
                      }
                    }(),
                    nodebuffer: function() {
                      try {
                        return s2.nodebuffer && 1 === String.fromCharCode.apply(null, a.allocBuffer(1)).length;
                      } catch (t3) {
                        return false;
                      }
                    }()
                  }
                };
                function c(t3) {
                  var e4 = 65536, r2 = i2.getTypeOf(t3), s3 = true;
                  if ("uint8array" === r2 ? s3 = l.applyCanBeUsed.uint8array : "nodebuffer" === r2 && (s3 = l.applyCanBeUsed.nodebuffer), s3)
                    for (; 1 < e4; )
                      try {
                        return l.stringifyByChunk(t3, r2, e4);
                      } catch (t4) {
                        e4 = Math.floor(e4 / 2);
                      }
                  return l.stringifyByChar(t3);
                }
                function f(t3, e4) {
                  for (var i3 = 0; i3 < t3.length; i3++)
                    e4[i3] = t3[i3];
                  return e4;
                }
                i2.applyFromCharCode = c;
                var d = {};
                d.string = {
                  string: h,
                  array: function(t3) {
                    return u(t3, new Array(t3.length));
                  },
                  arraybuffer: function(t3) {
                    return d.string.uint8array(t3).buffer;
                  },
                  uint8array: function(t3) {
                    return u(t3, new Uint8Array(t3.length));
                  },
                  nodebuffer: function(t3) {
                    return u(t3, a.allocBuffer(t3.length));
                  }
                }, d.array = {
                  string: c,
                  array: h,
                  arraybuffer: function(t3) {
                    return new Uint8Array(t3).buffer;
                  },
                  uint8array: function(t3) {
                    return new Uint8Array(t3);
                  },
                  nodebuffer: function(t3) {
                    return a.newBufferFrom(t3);
                  }
                }, d.arraybuffer = {
                  string: function(t3) {
                    return c(new Uint8Array(t3));
                  },
                  array: function(t3) {
                    return f(new Uint8Array(t3), new Array(t3.byteLength));
                  },
                  arraybuffer: h,
                  uint8array: function(t3) {
                    return new Uint8Array(t3);
                  },
                  nodebuffer: function(t3) {
                    return a.newBufferFrom(new Uint8Array(t3));
                  }
                }, d.uint8array = {
                  string: c,
                  array: function(t3) {
                    return f(t3, new Array(t3.length));
                  },
                  arraybuffer: function(t3) {
                    return t3.buffer;
                  },
                  uint8array: h,
                  nodebuffer: function(t3) {
                    return a.newBufferFrom(t3);
                  }
                }, d.nodebuffer = {
                  string: c,
                  array: function(t3) {
                    return f(t3, new Array(t3.length));
                  },
                  arraybuffer: function(t3) {
                    return d.nodebuffer.uint8array(t3).buffer;
                  },
                  uint8array: function(t3) {
                    return f(t3, new Uint8Array(t3.length));
                  },
                  nodebuffer: h
                }, i2.transformTo = function(t3, e4) {
                  if (e4 = e4 || "", !t3)
                    return e4;
                  i2.checkSupport(t3);
                  var r2 = i2.getTypeOf(e4);
                  return d[r2][t3](e4);
                }, i2.resolve = function(t3) {
                  for (var e4 = t3.split("/"), i3 = [], r2 = 0; r2 < e4.length; r2++) {
                    var s3 = e4[r2];
                    "." === s3 || "" === s3 && 0 !== r2 && r2 !== e4.length - 1 || (".." === s3 ? i3.pop() : i3.push(s3));
                  }
                  return i3.join("/");
                }, i2.getTypeOf = function(t3) {
                  return "string" == typeof t3 ? "string" : "[object Array]" === Object.prototype.toString.call(t3) ? "array" : s2.nodebuffer && a.isBuffer(t3) ? "nodebuffer" : s2.uint8array && t3 instanceof Uint8Array ? "uint8array" : s2.arraybuffer && t3 instanceof ArrayBuffer ? "arraybuffer" : void 0;
                }, i2.checkSupport = function(t3) {
                  if (!s2[t3.toLowerCase()])
                    throw new Error(t3 + " is not supported by this platform");
                }, i2.MAX_VALUE_16BITS = 65535, i2.MAX_VALUE_32BITS = -1, i2.pretty = function(t3) {
                  var e4, i3, r2 = "";
                  for (i3 = 0; i3 < (t3 || "").length; i3++)
                    r2 += "\\x" + ((e4 = t3.charCodeAt(i3)) < 16 ? "0" : "") + e4.toString(16).toUpperCase();
                  return r2;
                }, i2.delay = function(t3, e4, i3) {
                  r(function() {
                    t3.apply(i3 || null, e4 || []);
                  });
                }, i2.inherits = function(t3, e4) {
                  function i3() {
                  }
                  i3.prototype = e4.prototype, t3.prototype = new i3();
                }, i2.extend = function() {
                  var t3, e4, i3 = {};
                  for (t3 = 0; t3 < arguments.length; t3++)
                    for (e4 in arguments[t3])
                      Object.prototype.hasOwnProperty.call(arguments[t3], e4) && void 0 === i3[e4] && (i3[e4] = arguments[t3][e4]);
                  return i3;
                }, i2.prepareContent = function(t3, e4, r2, a2, h2) {
                  return o.Promise.resolve(e4).then(function(t4) {
                    return s2.blob && (t4 instanceof Blob || -1 !== ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(t4))) && "undefined" != typeof FileReader ? new o.Promise(function(e5, i3) {
                      var r3 = new FileReader();
                      r3.onload = function(t5) {
                        e5(t5.target.result);
                      }, r3.onerror = function(t5) {
                        i3(t5.target.error);
                      }, r3.readAsArrayBuffer(t4);
                    }) : t4;
                  }).then(function(e5) {
                    var l2 = i2.getTypeOf(e5);
                    return l2 ? ("arraybuffer" === l2 ? e5 = i2.transformTo("uint8array", e5) : "string" === l2 && (h2 ? e5 = n2.decode(e5) : r2 && true !== a2 && (e5 = function(t4) {
                      return u(t4, s2.uint8array ? new Uint8Array(t4.length) : new Array(t4.length));
                    }(e5))), e5) : o.Promise.reject(new Error("Can't read the data of '" + t3 + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"));
                  });
                };
              },
              { "./base64": 1, "./external": 6, "./nodejsUtils": 14, "./support": 30, setimmediate: 54 }
            ],
            33: [
              function(t2, e3, i2) {
                var r2 = t2("./reader/readerFor"), s2 = t2("./utils"), n2 = t2("./signature"), a = t2("./zipEntry"), o = t2("./support");
                function h(t3) {
                  this.files = [], this.loadOptions = t3;
                }
                h.prototype = {
                  checkSignature: function(t3) {
                    if (!this.reader.readAndCheckSignature(t3)) {
                      this.reader.index -= 4;
                      var e4 = this.reader.readString(4);
                      throw new Error("Corrupted zip or bug: unexpected signature (" + s2.pretty(e4) + ", expected " + s2.pretty(t3) + ")");
                    }
                  },
                  isSignature: function(t3, e4) {
                    var i3 = this.reader.index;
                    this.reader.setIndex(t3);
                    var r3 = this.reader.readString(4) === e4;
                    return this.reader.setIndex(i3), r3;
                  },
                  readBlockEndOfCentral: function() {
                    this.diskNumber = this.reader.readInt(2), this.diskWithCentralDirStart = this.reader.readInt(2), this.centralDirRecordsOnThisDisk = this.reader.readInt(2), this.centralDirRecords = this.reader.readInt(2), this.centralDirSize = this.reader.readInt(4), this.centralDirOffset = this.reader.readInt(4), this.zipCommentLength = this.reader.readInt(2);
                    var t3 = this.reader.readData(this.zipCommentLength), e4 = o.uint8array ? "uint8array" : "array", i3 = s2.transformTo(e4, t3);
                    this.zipComment = this.loadOptions.decodeFileName(i3);
                  },
                  readBlockZip64EndOfCentral: function() {
                    this.zip64EndOfCentralSize = this.reader.readInt(8), this.reader.skip(4), this.diskNumber = this.reader.readInt(4), this.diskWithCentralDirStart = this.reader.readInt(4), this.centralDirRecordsOnThisDisk = this.reader.readInt(8), this.centralDirRecords = this.reader.readInt(8), this.centralDirSize = this.reader.readInt(8), this.centralDirOffset = this.reader.readInt(8), this.zip64ExtensibleData = {};
                    for (var t3, e4, i3, r3 = this.zip64EndOfCentralSize - 44; 0 < r3; )
                      t3 = this.reader.readInt(2), e4 = this.reader.readInt(4), i3 = this.reader.readData(e4), this.zip64ExtensibleData[t3] = { id: t3, length: e4, value: i3 };
                  },
                  readBlockZip64EndOfCentralLocator: function() {
                    if (this.diskWithZip64CentralDirStart = this.reader.readInt(4), this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8), this.disksCount = this.reader.readInt(4), 1 < this.disksCount)
                      throw new Error("Multi-volumes zip are not supported");
                  },
                  readLocalFiles: function() {
                    var t3, e4;
                    for (t3 = 0; t3 < this.files.length; t3++)
                      e4 = this.files[t3], this.reader.setIndex(e4.localHeaderOffset), this.checkSignature(n2.LOCAL_FILE_HEADER), e4.readLocalPart(this.reader), e4.handleUTF8(), e4.processAttributes();
                  },
                  readCentralDir: function() {
                    var t3;
                    for (this.reader.setIndex(this.centralDirOffset); this.reader.readAndCheckSignature(n2.CENTRAL_FILE_HEADER); )
                      (t3 = new a({ zip64: this.zip64 }, this.loadOptions)).readCentralPart(this.reader), this.files.push(t3);
                    if (this.centralDirRecords !== this.files.length && 0 !== this.centralDirRecords && 0 === this.files.length)
                      throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
                  },
                  readEndOfCentral: function() {
                    var t3 = this.reader.lastIndexOfSignature(n2.CENTRAL_DIRECTORY_END);
                    if (t3 < 0)
                      throw this.isSignature(0, n2.LOCAL_FILE_HEADER) ? new Error("Corrupted zip: can't find end of central directory") : new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");
                    this.reader.setIndex(t3);
                    var e4 = t3;
                    if (this.checkSignature(n2.CENTRAL_DIRECTORY_END), this.readBlockEndOfCentral(), this.diskNumber === s2.MAX_VALUE_16BITS || this.diskWithCentralDirStart === s2.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === s2.MAX_VALUE_16BITS || this.centralDirRecords === s2.MAX_VALUE_16BITS || this.centralDirSize === s2.MAX_VALUE_32BITS || this.centralDirOffset === s2.MAX_VALUE_32BITS) {
                      if (this.zip64 = true, (t3 = this.reader.lastIndexOfSignature(n2.ZIP64_CENTRAL_DIRECTORY_LOCATOR)) < 0)
                        throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
                      if (this.reader.setIndex(t3), this.checkSignature(n2.ZIP64_CENTRAL_DIRECTORY_LOCATOR), this.readBlockZip64EndOfCentralLocator(), !this.isSignature(this.relativeOffsetEndOfZip64CentralDir, n2.ZIP64_CENTRAL_DIRECTORY_END) && (this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(n2.ZIP64_CENTRAL_DIRECTORY_END), this.relativeOffsetEndOfZip64CentralDir < 0))
                        throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
                      this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir), this.checkSignature(n2.ZIP64_CENTRAL_DIRECTORY_END), this.readBlockZip64EndOfCentral();
                    }
                    var i3 = this.centralDirOffset + this.centralDirSize;
                    this.zip64 && (i3 += 20, i3 += 12 + this.zip64EndOfCentralSize);
                    var r3 = e4 - i3;
                    if (0 < r3)
                      this.isSignature(e4, n2.CENTRAL_FILE_HEADER) || (this.reader.zero = r3);
                    else if (r3 < 0)
                      throw new Error("Corrupted zip: missing " + Math.abs(r3) + " bytes.");
                  },
                  prepareReader: function(t3) {
                    this.reader = r2(t3);
                  },
                  load: function(t3) {
                    this.prepareReader(t3), this.readEndOfCentral(), this.readCentralDir(), this.readLocalFiles();
                  }
                }, e3.exports = h;
              },
              { "./reader/readerFor": 22, "./signature": 23, "./support": 30, "./utils": 32, "./zipEntry": 34 }
            ],
            34: [
              function(t2, e3, i2) {
                var r2 = t2("./reader/readerFor"), s2 = t2("./utils"), n2 = t2("./compressedObject"), a = t2("./crc32"), o = t2("./utf8"), h = t2("./compressions"), u = t2("./support");
                function l(t3, e4) {
                  this.options = t3, this.loadOptions = e4;
                }
                l.prototype = {
                  isEncrypted: function() {
                    return 1 == (1 & this.bitFlag);
                  },
                  useUTF8: function() {
                    return 2048 == (2048 & this.bitFlag);
                  },
                  readLocalPart: function(t3) {
                    var e4, i3;
                    if (t3.skip(22), this.fileNameLength = t3.readInt(2), i3 = t3.readInt(2), this.fileName = t3.readData(this.fileNameLength), t3.skip(i3), -1 === this.compressedSize || -1 === this.uncompressedSize)
                      throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
                    if (null === (e4 = function(t4) {
                      for (var e5 in h)
                        if (Object.prototype.hasOwnProperty.call(h, e5) && h[e5].magic === t4)
                          return h[e5];
                      return null;
                    }(this.compressionMethod)))
                      throw new Error("Corrupted zip : compression " + s2.pretty(this.compressionMethod) + " unknown (inner file : " + s2.transformTo("string", this.fileName) + ")");
                    this.decompressed = new n2(this.compressedSize, this.uncompressedSize, this.crc32, e4, t3.readData(this.compressedSize));
                  },
                  readCentralPart: function(t3) {
                    this.versionMadeBy = t3.readInt(2), t3.skip(2), this.bitFlag = t3.readInt(2), this.compressionMethod = t3.readString(2), this.date = t3.readDate(), this.crc32 = t3.readInt(4), this.compressedSize = t3.readInt(4), this.uncompressedSize = t3.readInt(4);
                    var e4 = t3.readInt(2);
                    if (this.extraFieldsLength = t3.readInt(2), this.fileCommentLength = t3.readInt(2), this.diskNumberStart = t3.readInt(2), this.internalFileAttributes = t3.readInt(2), this.externalFileAttributes = t3.readInt(4), this.localHeaderOffset = t3.readInt(4), this.isEncrypted())
                      throw new Error("Encrypted zip are not supported");
                    t3.skip(e4), this.readExtraFields(t3), this.parseZIP64ExtraField(t3), this.fileComment = t3.readData(this.fileCommentLength);
                  },
                  processAttributes: function() {
                    this.unixPermissions = null, this.dosPermissions = null;
                    var t3 = this.versionMadeBy >> 8;
                    this.dir = !!(16 & this.externalFileAttributes), 0 == t3 && (this.dosPermissions = 63 & this.externalFileAttributes), 3 == t3 && (this.unixPermissions = this.externalFileAttributes >> 16 & 65535), this.dir || "/" !== this.fileNameStr.slice(-1) || (this.dir = true);
                  },
                  parseZIP64ExtraField: function() {
                    if (this.extraFields[1]) {
                      var t3 = r2(this.extraFields[1].value);
                      this.uncompressedSize === s2.MAX_VALUE_32BITS && (this.uncompressedSize = t3.readInt(8)), this.compressedSize === s2.MAX_VALUE_32BITS && (this.compressedSize = t3.readInt(8)), this.localHeaderOffset === s2.MAX_VALUE_32BITS && (this.localHeaderOffset = t3.readInt(8)), this.diskNumberStart === s2.MAX_VALUE_32BITS && (this.diskNumberStart = t3.readInt(4));
                    }
                  },
                  readExtraFields: function(t3) {
                    var e4, i3, r3, s3 = t3.index + this.extraFieldsLength;
                    for (this.extraFields || (this.extraFields = {}); t3.index + 4 < s3; )
                      e4 = t3.readInt(2), i3 = t3.readInt(2), r3 = t3.readData(i3), this.extraFields[e4] = { id: e4, length: i3, value: r3 };
                    t3.setIndex(s3);
                  },
                  handleUTF8: function() {
                    var t3 = u.uint8array ? "uint8array" : "array";
                    if (this.useUTF8())
                      this.fileNameStr = o.utf8decode(this.fileName), this.fileCommentStr = o.utf8decode(this.fileComment);
                    else {
                      var e4 = this.findExtraFieldUnicodePath();
                      if (null !== e4)
                        this.fileNameStr = e4;
                      else {
                        var i3 = s2.transformTo(t3, this.fileName);
                        this.fileNameStr = this.loadOptions.decodeFileName(i3);
                      }
                      var r3 = this.findExtraFieldUnicodeComment();
                      if (null !== r3)
                        this.fileCommentStr = r3;
                      else {
                        var n3 = s2.transformTo(t3, this.fileComment);
                        this.fileCommentStr = this.loadOptions.decodeFileName(n3);
                      }
                    }
                  },
                  findExtraFieldUnicodePath: function() {
                    var t3 = this.extraFields[28789];
                    if (t3) {
                      var e4 = r2(t3.value);
                      return 1 !== e4.readInt(1) || a(this.fileName) !== e4.readInt(4) ? null : o.utf8decode(e4.readData(t3.length - 5));
                    }
                    return null;
                  },
                  findExtraFieldUnicodeComment: function() {
                    var t3 = this.extraFields[25461];
                    if (t3) {
                      var e4 = r2(t3.value);
                      return 1 !== e4.readInt(1) || a(this.fileComment) !== e4.readInt(4) ? null : o.utf8decode(e4.readData(t3.length - 5));
                    }
                    return null;
                  }
                }, e3.exports = l;
              },
              { "./compressedObject": 2, "./compressions": 3, "./crc32": 4, "./reader/readerFor": 22, "./support": 30, "./utf8": 31, "./utils": 32 }
            ],
            35: [
              function(t2, e3, i2) {
                function r2(t3, e4, i3) {
                  this.name = t3, this.dir = i3.dir, this.date = i3.date, this.comment = i3.comment, this.unixPermissions = i3.unixPermissions, this.dosPermissions = i3.dosPermissions, this._data = e4, this._dataBinary = i3.binary, this.options = { compression: i3.compression, compressionOptions: i3.compressionOptions };
                }
                var s2 = t2("./stream/StreamHelper"), n2 = t2("./stream/DataWorker"), a = t2("./utf8"), o = t2("./compressedObject"), h = t2("./stream/GenericWorker");
                r2.prototype = {
                  internalStream: function(t3) {
                    var e4 = null, i3 = "string";
                    try {
                      if (!t3)
                        throw new Error("No output type specified.");
                      var r3 = "string" === (i3 = t3.toLowerCase()) || "text" === i3;
                      "binarystring" !== i3 && "text" !== i3 || (i3 = "string"), e4 = this._decompressWorker();
                      var n3 = !this._dataBinary;
                      n3 && !r3 && (e4 = e4.pipe(new a.Utf8EncodeWorker())), !n3 && r3 && (e4 = e4.pipe(new a.Utf8DecodeWorker()));
                    } catch (t4) {
                      (e4 = new h("error")).error(t4);
                    }
                    return new s2(e4, i3, "");
                  },
                  async: function(t3, e4) {
                    return this.internalStream(t3).accumulate(e4);
                  },
                  nodeStream: function(t3, e4) {
                    return this.internalStream(t3 || "nodebuffer").toNodejsStream(e4);
                  },
                  _compressWorker: function(t3, e4) {
                    if (this._data instanceof o && this._data.compression.magic === t3.magic)
                      return this._data.getCompressedWorker();
                    var i3 = this._decompressWorker();
                    return this._dataBinary || (i3 = i3.pipe(new a.Utf8EncodeWorker())), o.createWorkerFrom(i3, t3, e4);
                  },
                  _decompressWorker: function() {
                    return this._data instanceof o ? this._data.getContentWorker() : this._data instanceof h ? this._data : new n2(this._data);
                  }
                };
                for (var u = ["asText", "asBinary", "asNodeBuffer", "asUint8Array", "asArrayBuffer"], l = function() {
                  throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
                }, c = 0; c < u.length; c++)
                  r2.prototype[u[c]] = l;
                e3.exports = r2;
              },
              { "./compressedObject": 2, "./stream/DataWorker": 27, "./stream/GenericWorker": 28, "./stream/StreamHelper": 29, "./utf8": 31 }
            ],
            36: [
              function(t2, e3, i2) {
                (function(t3) {
                  var i3, r2, s2 = t3.MutationObserver || t3.WebKitMutationObserver;
                  if (s2) {
                    var n2 = 0, a = new s2(l), o = t3.document.createTextNode("");
                    a.observe(o, { characterData: true }), i3 = function() {
                      o.data = n2 = ++n2 % 2;
                    };
                  } else if (t3.setImmediate || void 0 === t3.MessageChannel)
                    i3 = "document" in t3 && "onreadystatechange" in t3.document.createElement("script") ? function() {
                      var e4 = t3.document.createElement("script");
                      e4.onreadystatechange = function() {
                        l(), e4.onreadystatechange = null, e4.parentNode.removeChild(e4), e4 = null;
                      }, t3.document.documentElement.appendChild(e4);
                    } : function() {
                      setTimeout(l, 0);
                    };
                  else {
                    var h = new t3.MessageChannel();
                    h.port1.onmessage = l, i3 = function() {
                      h.port2.postMessage(0);
                    };
                  }
                  var u = [];
                  function l() {
                    var t4, e4;
                    r2 = true;
                    for (var i4 = u.length; i4; ) {
                      for (e4 = u, u = [], t4 = -1; ++t4 < i4; )
                        e4[t4]();
                      i4 = u.length;
                    }
                    r2 = false;
                  }
                  e3.exports = function(t4) {
                    1 !== u.push(t4) || r2 || i3();
                  };
                }).call(this, void 0 !== s ? s : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
              },
              {}
            ],
            37: [
              function(t2, e3, i2) {
                var r2 = t2("immediate");
                function s2() {
                }
                var n2 = {}, a = ["REJECTED"], o = ["FULFILLED"], h = ["PENDING"];
                function u(t3) {
                  if ("function" != typeof t3)
                    throw new TypeError("resolver must be a function");
                  this.state = h, this.queue = [], this.outcome = void 0, t3 !== s2 && d(this, t3);
                }
                function l(t3, e4, i3) {
                  this.promise = t3, "function" == typeof e4 && (this.onFulfilled = e4, this.callFulfilled = this.otherCallFulfilled), "function" == typeof i3 && (this.onRejected = i3, this.callRejected = this.otherCallRejected);
                }
                function c(t3, e4, i3) {
                  r2(function() {
                    var r3;
                    try {
                      r3 = e4(i3);
                    } catch (r4) {
                      return n2.reject(t3, r4);
                    }
                    r3 === t3 ? n2.reject(t3, new TypeError("Cannot resolve promise with itself")) : n2.resolve(t3, r3);
                  });
                }
                function f(t3) {
                  var e4 = t3 && t3.then;
                  if (t3 && ("object" == typeof t3 || "function" == typeof t3) && "function" == typeof e4)
                    return function() {
                      e4.apply(t3, arguments);
                    };
                }
                function d(t3, e4) {
                  var i3 = false;
                  function r3(e5) {
                    i3 || (i3 = true, n2.reject(t3, e5));
                  }
                  function s3(e5) {
                    i3 || (i3 = true, n2.resolve(t3, e5));
                  }
                  var a2 = p(function() {
                    e4(s3, r3);
                  });
                  "error" === a2.status && r3(a2.value);
                }
                function p(t3, e4) {
                  var i3 = {};
                  try {
                    i3.value = t3(e4), i3.status = "success";
                  } catch (t4) {
                    i3.status = "error", i3.value = t4;
                  }
                  return i3;
                }
                (e3.exports = u).prototype.finally = function(t3) {
                  if ("function" != typeof t3)
                    return this;
                  var e4 = this.constructor;
                  return this.then(
                    function(i3) {
                      return e4.resolve(t3()).then(function() {
                        return i3;
                      });
                    },
                    function(i3) {
                      return e4.resolve(t3()).then(function() {
                        throw i3;
                      });
                    }
                  );
                }, u.prototype.catch = function(t3) {
                  return this.then(null, t3);
                }, u.prototype.then = function(t3, e4) {
                  if ("function" != typeof t3 && this.state === o || "function" != typeof e4 && this.state === a)
                    return this;
                  var i3 = new this.constructor(s2);
                  return this.state !== h ? c(i3, this.state === o ? t3 : e4, this.outcome) : this.queue.push(new l(i3, t3, e4)), i3;
                }, l.prototype.callFulfilled = function(t3) {
                  n2.resolve(this.promise, t3);
                }, l.prototype.otherCallFulfilled = function(t3) {
                  c(this.promise, this.onFulfilled, t3);
                }, l.prototype.callRejected = function(t3) {
                  n2.reject(this.promise, t3);
                }, l.prototype.otherCallRejected = function(t3) {
                  c(this.promise, this.onRejected, t3);
                }, n2.resolve = function(t3, e4) {
                  var i3 = p(f, e4);
                  if ("error" === i3.status)
                    return n2.reject(t3, i3.value);
                  var r3 = i3.value;
                  if (r3)
                    d(t3, r3);
                  else {
                    t3.state = o, t3.outcome = e4;
                    for (var s3 = -1, a2 = t3.queue.length; ++s3 < a2; )
                      t3.queue[s3].callFulfilled(e4);
                  }
                  return t3;
                }, n2.reject = function(t3, e4) {
                  t3.state = a, t3.outcome = e4;
                  for (var i3 = -1, r3 = t3.queue.length; ++i3 < r3; )
                    t3.queue[i3].callRejected(e4);
                  return t3;
                }, u.resolve = function(t3) {
                  return t3 instanceof this ? t3 : n2.resolve(new this(s2), t3);
                }, u.reject = function(t3) {
                  var e4 = new this(s2);
                  return n2.reject(e4, t3);
                }, u.all = function(t3) {
                  var e4 = this;
                  if ("[object Array]" !== Object.prototype.toString.call(t3))
                    return this.reject(new TypeError("must be an array"));
                  var i3 = t3.length, r3 = false;
                  if (!i3)
                    return this.resolve([]);
                  for (var a2 = new Array(i3), o2 = 0, h2 = -1, u2 = new this(s2); ++h2 < i3; )
                    l2(t3[h2], h2);
                  return u2;
                  function l2(t4, s3) {
                    e4.resolve(t4).then(
                      function(t5) {
                        a2[s3] = t5, ++o2 !== i3 || r3 || (r3 = true, n2.resolve(u2, a2));
                      },
                      function(t5) {
                        r3 || (r3 = true, n2.reject(u2, t5));
                      }
                    );
                  }
                }, u.race = function(t3) {
                  if ("[object Array]" !== Object.prototype.toString.call(t3))
                    return this.reject(new TypeError("must be an array"));
                  var e4 = t3.length, i3 = false;
                  if (!e4)
                    return this.resolve([]);
                  for (var r3, a2 = -1, o2 = new this(s2); ++a2 < e4; )
                    r3 = t3[a2], this.resolve(r3).then(
                      function(t4) {
                        i3 || (i3 = true, n2.resolve(o2, t4));
                      },
                      function(t4) {
                        i3 || (i3 = true, n2.reject(o2, t4));
                      }
                    );
                  return o2;
                };
              },
              { immediate: 36 }
            ],
            38: [
              function(t2, e3, i2) {
                var r2 = {};
                (0, t2("./lib/utils/common").assign)(r2, t2("./lib/deflate"), t2("./lib/inflate"), t2("./lib/zlib/constants")), e3.exports = r2;
              },
              { "./lib/deflate": 39, "./lib/inflate": 40, "./lib/utils/common": 41, "./lib/zlib/constants": 44 }
            ],
            39: [
              function(t2, e3, i2) {
                var r2 = t2("./zlib/deflate"), s2 = t2("./utils/common"), n2 = t2("./utils/strings"), a = t2("./zlib/messages"), o = t2("./zlib/zstream"), h = Object.prototype.toString;
                function u(t3) {
                  if (!(this instanceof u))
                    return new u(t3);
                  this.options = s2.assign({ level: -1, method: 8, chunkSize: 16384, windowBits: 15, memLevel: 8, strategy: 0, to: "" }, t3 || {});
                  var e4 = this.options;
                  e4.raw && 0 < e4.windowBits ? e4.windowBits = -e4.windowBits : e4.gzip && 0 < e4.windowBits && e4.windowBits < 16 && (e4.windowBits += 16), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new o(), this.strm.avail_out = 0;
                  var i3 = r2.deflateInit2(this.strm, e4.level, e4.method, e4.windowBits, e4.memLevel, e4.strategy);
                  if (0 !== i3)
                    throw new Error(a[i3]);
                  if (e4.header && r2.deflateSetHeader(this.strm, e4.header), e4.dictionary) {
                    var l2;
                    if (l2 = "string" == typeof e4.dictionary ? n2.string2buf(e4.dictionary) : "[object ArrayBuffer]" === h.call(e4.dictionary) ? new Uint8Array(e4.dictionary) : e4.dictionary, 0 !== (i3 = r2.deflateSetDictionary(this.strm, l2)))
                      throw new Error(a[i3]);
                    this._dict_set = true;
                  }
                }
                function l(t3, e4) {
                  var i3 = new u(e4);
                  if (i3.push(t3, true), i3.err)
                    throw i3.msg || a[i3.err];
                  return i3.result;
                }
                u.prototype.push = function(t3, e4) {
                  var i3, a2, o2 = this.strm, u2 = this.options.chunkSize;
                  if (this.ended)
                    return false;
                  a2 = e4 === ~~e4 ? e4 : true === e4 ? 4 : 0, "string" == typeof t3 ? o2.input = n2.string2buf(t3) : "[object ArrayBuffer]" === h.call(t3) ? o2.input = new Uint8Array(t3) : o2.input = t3, o2.next_in = 0, o2.avail_in = o2.input.length;
                  do {
                    if (0 === o2.avail_out && (o2.output = new s2.Buf8(u2), o2.next_out = 0, o2.avail_out = u2), 1 !== (i3 = r2.deflate(o2, a2)) && 0 !== i3)
                      return this.onEnd(i3), !(this.ended = true);
                    0 !== o2.avail_out && (0 !== o2.avail_in || 4 !== a2 && 2 !== a2) || ("string" === this.options.to ? this.onData(n2.buf2binstring(s2.shrinkBuf(o2.output, o2.next_out))) : this.onData(s2.shrinkBuf(o2.output, o2.next_out)));
                  } while ((0 < o2.avail_in || 0 === o2.avail_out) && 1 !== i3);
                  return 4 === a2 ? (i3 = r2.deflateEnd(this.strm), this.onEnd(i3), this.ended = true, 0 === i3) : 2 !== a2 || (this.onEnd(0), !(o2.avail_out = 0));
                }, u.prototype.onData = function(t3) {
                  this.chunks.push(t3);
                }, u.prototype.onEnd = function(t3) {
                  0 === t3 && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = s2.flattenChunks(this.chunks)), this.chunks = [], this.err = t3, this.msg = this.strm.msg;
                }, i2.Deflate = u, i2.deflate = l, i2.deflateRaw = function(t3, e4) {
                  return (e4 = e4 || {}).raw = true, l(t3, e4);
                }, i2.gzip = function(t3, e4) {
                  return (e4 = e4 || {}).gzip = true, l(t3, e4);
                };
              },
              { "./utils/common": 41, "./utils/strings": 42, "./zlib/deflate": 46, "./zlib/messages": 51, "./zlib/zstream": 53 }
            ],
            40: [
              function(t2, e3, i2) {
                var r2 = t2("./zlib/inflate"), s2 = t2("./utils/common"), n2 = t2("./utils/strings"), a = t2("./zlib/constants"), o = t2("./zlib/messages"), h = t2("./zlib/zstream"), u = t2("./zlib/gzheader"), l = Object.prototype.toString;
                function c(t3) {
                  if (!(this instanceof c))
                    return new c(t3);
                  this.options = s2.assign({ chunkSize: 16384, windowBits: 0, to: "" }, t3 || {});
                  var e4 = this.options;
                  e4.raw && 0 <= e4.windowBits && e4.windowBits < 16 && (e4.windowBits = -e4.windowBits, 0 === e4.windowBits && (e4.windowBits = -15)), !(0 <= e4.windowBits && e4.windowBits < 16) || t3 && t3.windowBits || (e4.windowBits += 32), 15 < e4.windowBits && e4.windowBits < 48 && 0 == (15 & e4.windowBits) && (e4.windowBits |= 15), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new h(), this.strm.avail_out = 0;
                  var i3 = r2.inflateInit2(this.strm, e4.windowBits);
                  if (i3 !== a.Z_OK)
                    throw new Error(o[i3]);
                  this.header = new u(), r2.inflateGetHeader(this.strm, this.header);
                }
                function f(t3, e4) {
                  var i3 = new c(e4);
                  if (i3.push(t3, true), i3.err)
                    throw i3.msg || o[i3.err];
                  return i3.result;
                }
                c.prototype.push = function(t3, e4) {
                  var i3, o2, h2, u2, c2, f2, d = this.strm, p = this.options.chunkSize, m = this.options.dictionary, g = false;
                  if (this.ended)
                    return false;
                  o2 = e4 === ~~e4 ? e4 : true === e4 ? a.Z_FINISH : a.Z_NO_FLUSH, "string" == typeof t3 ? d.input = n2.binstring2buf(t3) : "[object ArrayBuffer]" === l.call(t3) ? d.input = new Uint8Array(t3) : d.input = t3, d.next_in = 0, d.avail_in = d.input.length;
                  do {
                    if (0 === d.avail_out && (d.output = new s2.Buf8(p), d.next_out = 0, d.avail_out = p), (i3 = r2.inflate(d, a.Z_NO_FLUSH)) === a.Z_NEED_DICT && m && (f2 = "string" == typeof m ? n2.string2buf(m) : "[object ArrayBuffer]" === l.call(m) ? new Uint8Array(m) : m, i3 = r2.inflateSetDictionary(this.strm, f2)), i3 === a.Z_BUF_ERROR && true === g && (i3 = a.Z_OK, g = false), i3 !== a.Z_STREAM_END && i3 !== a.Z_OK)
                      return this.onEnd(i3), !(this.ended = true);
                    d.next_out && (0 !== d.avail_out && i3 !== a.Z_STREAM_END && (0 !== d.avail_in || o2 !== a.Z_FINISH && o2 !== a.Z_SYNC_FLUSH) || ("string" === this.options.to ? (h2 = n2.utf8border(d.output, d.next_out), u2 = d.next_out - h2, c2 = n2.buf2string(d.output, h2), d.next_out = u2, d.avail_out = p - u2, u2 && s2.arraySet(d.output, d.output, h2, u2, 0), this.onData(c2)) : this.onData(s2.shrinkBuf(d.output, d.next_out)))), 0 === d.avail_in && 0 === d.avail_out && (g = true);
                  } while ((0 < d.avail_in || 0 === d.avail_out) && i3 !== a.Z_STREAM_END);
                  return i3 === a.Z_STREAM_END && (o2 = a.Z_FINISH), o2 === a.Z_FINISH ? (i3 = r2.inflateEnd(this.strm), this.onEnd(i3), this.ended = true, i3 === a.Z_OK) : o2 !== a.Z_SYNC_FLUSH || (this.onEnd(a.Z_OK), !(d.avail_out = 0));
                }, c.prototype.onData = function(t3) {
                  this.chunks.push(t3);
                }, c.prototype.onEnd = function(t3) {
                  t3 === a.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = s2.flattenChunks(this.chunks)), this.chunks = [], this.err = t3, this.msg = this.strm.msg;
                }, i2.Inflate = c, i2.inflate = f, i2.inflateRaw = function(t3, e4) {
                  return (e4 = e4 || {}).raw = true, f(t3, e4);
                }, i2.ungzip = f;
              },
              { "./utils/common": 41, "./utils/strings": 42, "./zlib/constants": 44, "./zlib/gzheader": 47, "./zlib/inflate": 49, "./zlib/messages": 51, "./zlib/zstream": 53 }
            ],
            41: [
              function(t2, e3, i2) {
                var r2 = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
                i2.assign = function(t3) {
                  for (var e4 = Array.prototype.slice.call(arguments, 1); e4.length; ) {
                    var i3 = e4.shift();
                    if (i3) {
                      if ("object" != typeof i3)
                        throw new TypeError(i3 + "must be non-object");
                      for (var r3 in i3)
                        i3.hasOwnProperty(r3) && (t3[r3] = i3[r3]);
                    }
                  }
                  return t3;
                }, i2.shrinkBuf = function(t3, e4) {
                  return t3.length === e4 ? t3 : t3.subarray ? t3.subarray(0, e4) : (t3.length = e4, t3);
                };
                var s2 = {
                  arraySet: function(t3, e4, i3, r3, s3) {
                    if (e4.subarray && t3.subarray)
                      t3.set(e4.subarray(i3, i3 + r3), s3);
                    else
                      for (var n3 = 0; n3 < r3; n3++)
                        t3[s3 + n3] = e4[i3 + n3];
                  },
                  flattenChunks: function(t3) {
                    var e4, i3, r3, s3, n3, a;
                    for (e4 = r3 = 0, i3 = t3.length; e4 < i3; e4++)
                      r3 += t3[e4].length;
                    for (a = new Uint8Array(r3), e4 = s3 = 0, i3 = t3.length; e4 < i3; e4++)
                      n3 = t3[e4], a.set(n3, s3), s3 += n3.length;
                    return a;
                  }
                }, n2 = {
                  arraySet: function(t3, e4, i3, r3, s3) {
                    for (var n3 = 0; n3 < r3; n3++)
                      t3[s3 + n3] = e4[i3 + n3];
                  },
                  flattenChunks: function(t3) {
                    return [].concat.apply([], t3);
                  }
                };
                i2.setTyped = function(t3) {
                  t3 ? (i2.Buf8 = Uint8Array, i2.Buf16 = Uint16Array, i2.Buf32 = Int32Array, i2.assign(i2, s2)) : (i2.Buf8 = Array, i2.Buf16 = Array, i2.Buf32 = Array, i2.assign(i2, n2));
                }, i2.setTyped(r2);
              },
              {}
            ],
            42: [
              function(t2, e3, i2) {
                var r2 = t2("./common"), s2 = true, n2 = true;
                try {
                  String.fromCharCode.apply(null, [0]);
                } catch (t3) {
                  s2 = false;
                }
                try {
                  String.fromCharCode.apply(null, new Uint8Array(1));
                } catch (t3) {
                  n2 = false;
                }
                for (var a = new r2.Buf8(256), o = 0; o < 256; o++)
                  a[o] = 252 <= o ? 6 : 248 <= o ? 5 : 240 <= o ? 4 : 224 <= o ? 3 : 192 <= o ? 2 : 1;
                function h(t3, e4) {
                  if (e4 < 65537 && (t3.subarray && n2 || !t3.subarray && s2))
                    return String.fromCharCode.apply(null, r2.shrinkBuf(t3, e4));
                  for (var i3 = "", a2 = 0; a2 < e4; a2++)
                    i3 += String.fromCharCode(t3[a2]);
                  return i3;
                }
                a[254] = a[254] = 1, i2.string2buf = function(t3) {
                  var e4, i3, s3, n3, a2, o2 = t3.length, h2 = 0;
                  for (n3 = 0; n3 < o2; n3++)
                    55296 == (64512 & (i3 = t3.charCodeAt(n3))) && n3 + 1 < o2 && 56320 == (64512 & (s3 = t3.charCodeAt(n3 + 1))) && (i3 = 65536 + (i3 - 55296 << 10) + (s3 - 56320), n3++), h2 += i3 < 128 ? 1 : i3 < 2048 ? 2 : i3 < 65536 ? 3 : 4;
                  for (e4 = new r2.Buf8(h2), n3 = a2 = 0; a2 < h2; n3++)
                    55296 == (64512 & (i3 = t3.charCodeAt(n3))) && n3 + 1 < o2 && 56320 == (64512 & (s3 = t3.charCodeAt(n3 + 1))) && (i3 = 65536 + (i3 - 55296 << 10) + (s3 - 56320), n3++), i3 < 128 ? e4[a2++] = i3 : (i3 < 2048 ? e4[a2++] = 192 | i3 >>> 6 : (i3 < 65536 ? e4[a2++] = 224 | i3 >>> 12 : (e4[a2++] = 240 | i3 >>> 18, e4[a2++] = 128 | i3 >>> 12 & 63), e4[a2++] = 128 | i3 >>> 6 & 63), e4[a2++] = 128 | 63 & i3);
                  return e4;
                }, i2.buf2binstring = function(t3) {
                  return h(t3, t3.length);
                }, i2.binstring2buf = function(t3) {
                  for (var e4 = new r2.Buf8(t3.length), i3 = 0, s3 = e4.length; i3 < s3; i3++)
                    e4[i3] = t3.charCodeAt(i3);
                  return e4;
                }, i2.buf2string = function(t3, e4) {
                  var i3, r3, s3, n3, o2 = e4 || t3.length, u = new Array(2 * o2);
                  for (i3 = r3 = 0; i3 < o2; )
                    if ((s3 = t3[i3++]) < 128)
                      u[r3++] = s3;
                    else if (4 < (n3 = a[s3]))
                      u[r3++] = 65533, i3 += n3 - 1;
                    else {
                      for (s3 &= 2 === n3 ? 31 : 3 === n3 ? 15 : 7; 1 < n3 && i3 < o2; )
                        s3 = s3 << 6 | 63 & t3[i3++], n3--;
                      1 < n3 ? u[r3++] = 65533 : s3 < 65536 ? u[r3++] = s3 : (s3 -= 65536, u[r3++] = 55296 | s3 >> 10 & 1023, u[r3++] = 56320 | 1023 & s3);
                    }
                  return h(u, r3);
                }, i2.utf8border = function(t3, e4) {
                  var i3;
                  for ((e4 = e4 || t3.length) > t3.length && (e4 = t3.length), i3 = e4 - 1; 0 <= i3 && 128 == (192 & t3[i3]); )
                    i3--;
                  return i3 < 0 || 0 === i3 ? e4 : i3 + a[t3[i3]] > e4 ? i3 : e4;
                };
              },
              { "./common": 41 }
            ],
            43: [
              function(t2, e3, i2) {
                e3.exports = function(t3, e4, i3, r2) {
                  for (var s2 = 65535 & t3 | 0, n2 = t3 >>> 16 & 65535 | 0, a = 0; 0 !== i3; ) {
                    for (i3 -= a = 2e3 < i3 ? 2e3 : i3; n2 = n2 + (s2 = s2 + e4[r2++] | 0) | 0, --a; )
                      ;
                    s2 %= 65521, n2 %= 65521;
                  }
                  return s2 | n2 << 16 | 0;
                };
              },
              {}
            ],
            44: [
              function(t2, e3, i2) {
                e3.exports = {
                  Z_NO_FLUSH: 0,
                  Z_PARTIAL_FLUSH: 1,
                  Z_SYNC_FLUSH: 2,
                  Z_FULL_FLUSH: 3,
                  Z_FINISH: 4,
                  Z_BLOCK: 5,
                  Z_TREES: 6,
                  Z_OK: 0,
                  Z_STREAM_END: 1,
                  Z_NEED_DICT: 2,
                  Z_ERRNO: -1,
                  Z_STREAM_ERROR: -2,
                  Z_DATA_ERROR: -3,
                  Z_BUF_ERROR: -5,
                  Z_NO_COMPRESSION: 0,
                  Z_BEST_SPEED: 1,
                  Z_BEST_COMPRESSION: 9,
                  Z_DEFAULT_COMPRESSION: -1,
                  Z_FILTERED: 1,
                  Z_HUFFMAN_ONLY: 2,
                  Z_RLE: 3,
                  Z_FIXED: 4,
                  Z_DEFAULT_STRATEGY: 0,
                  Z_BINARY: 0,
                  Z_TEXT: 1,
                  Z_UNKNOWN: 2,
                  Z_DEFLATED: 8
                };
              },
              {}
            ],
            45: [
              function(t2, e3, i2) {
                var r2 = function() {
                  for (var t3, e4 = [], i3 = 0; i3 < 256; i3++) {
                    t3 = i3;
                    for (var r3 = 0; r3 < 8; r3++)
                      t3 = 1 & t3 ? 3988292384 ^ t3 >>> 1 : t3 >>> 1;
                    e4[i3] = t3;
                  }
                  return e4;
                }();
                e3.exports = function(t3, e4, i3, s2) {
                  var n2 = r2, a = s2 + i3;
                  t3 ^= -1;
                  for (var o = s2; o < a; o++)
                    t3 = t3 >>> 8 ^ n2[255 & (t3 ^ e4[o])];
                  return -1 ^ t3;
                };
              },
              {}
            ],
            46: [
              function(t2, e3, i2) {
                var r2, s2 = t2("../utils/common"), n2 = t2("./trees"), a = t2("./adler32"), o = t2("./crc32"), h = t2("./messages"), u = -2, l = 258, c = 262, f = 113;
                function d(t3, e4) {
                  return t3.msg = h[e4], e4;
                }
                function p(t3) {
                  return (t3 << 1) - (4 < t3 ? 9 : 0);
                }
                function m(t3) {
                  for (var e4 = t3.length; 0 <= --e4; )
                    t3[e4] = 0;
                }
                function g(t3) {
                  var e4 = t3.state, i3 = e4.pending;
                  i3 > t3.avail_out && (i3 = t3.avail_out), 0 !== i3 && (s2.arraySet(t3.output, e4.pending_buf, e4.pending_out, i3, t3.next_out), t3.next_out += i3, e4.pending_out += i3, t3.total_out += i3, t3.avail_out -= i3, e4.pending -= i3, 0 === e4.pending && (e4.pending_out = 0));
                }
                function _(t3, e4) {
                  n2._tr_flush_block(t3, 0 <= t3.block_start ? t3.block_start : -1, t3.strstart - t3.block_start, e4), t3.block_start = t3.strstart, g(t3.strm);
                }
                function y(t3, e4) {
                  t3.pending_buf[t3.pending++] = e4;
                }
                function v(t3, e4) {
                  t3.pending_buf[t3.pending++] = e4 >>> 8 & 255, t3.pending_buf[t3.pending++] = 255 & e4;
                }
                function b(t3, e4) {
                  var i3, r3, s3 = t3.max_chain_length, n3 = t3.strstart, a2 = t3.prev_length, o2 = t3.nice_match, h2 = t3.strstart > t3.w_size - c ? t3.strstart - (t3.w_size - c) : 0, u2 = t3.window, f2 = t3.w_mask, d2 = t3.prev, p2 = t3.strstart + l, m2 = u2[n3 + a2 - 1], g2 = u2[n3 + a2];
                  t3.prev_length >= t3.good_match && (s3 >>= 2), o2 > t3.lookahead && (o2 = t3.lookahead);
                  do {
                    if (u2[(i3 = e4) + a2] === g2 && u2[i3 + a2 - 1] === m2 && u2[i3] === u2[n3] && u2[++i3] === u2[n3 + 1]) {
                      n3 += 2, i3++;
                      do {
                      } while (u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && u2[++n3] === u2[++i3] && n3 < p2);
                      if (r3 = l - (p2 - n3), n3 = p2 - l, a2 < r3) {
                        if (t3.match_start = e4, o2 <= (a2 = r3))
                          break;
                        m2 = u2[n3 + a2 - 1], g2 = u2[n3 + a2];
                      }
                    }
                  } while ((e4 = d2[e4 & f2]) > h2 && 0 != --s3);
                  return a2 <= t3.lookahead ? a2 : t3.lookahead;
                }
                function w(t3) {
                  var e4, i3, r3, n3, h2, u2, l2, f2, d2, p2, m2 = t3.w_size;
                  do {
                    if (n3 = t3.window_size - t3.lookahead - t3.strstart, t3.strstart >= m2 + (m2 - c)) {
                      for (s2.arraySet(t3.window, t3.window, m2, m2, 0), t3.match_start -= m2, t3.strstart -= m2, t3.block_start -= m2, e4 = i3 = t3.hash_size; r3 = t3.head[--e4], t3.head[e4] = m2 <= r3 ? r3 - m2 : 0, --i3; )
                        ;
                      for (e4 = i3 = m2; r3 = t3.prev[--e4], t3.prev[e4] = m2 <= r3 ? r3 - m2 : 0, --i3; )
                        ;
                      n3 += m2;
                    }
                    if (0 === t3.strm.avail_in)
                      break;
                    if (u2 = t3.strm, l2 = t3.window, f2 = t3.strstart + t3.lookahead, p2 = void 0, (d2 = n3) < (p2 = u2.avail_in) && (p2 = d2), i3 = 0 === p2 ? 0 : (u2.avail_in -= p2, s2.arraySet(l2, u2.input, u2.next_in, p2, f2), 1 === u2.state.wrap ? u2.adler = a(u2.adler, l2, p2, f2) : 2 === u2.state.wrap && (u2.adler = o(u2.adler, l2, p2, f2)), u2.next_in += p2, u2.total_in += p2, p2), t3.lookahead += i3, t3.lookahead + t3.insert >= 3)
                      for (h2 = t3.strstart - t3.insert, t3.ins_h = t3.window[h2], t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[h2 + 1]) & t3.hash_mask; t3.insert && (t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[h2 + 3 - 1]) & t3.hash_mask, t3.prev[h2 & t3.w_mask] = t3.head[t3.ins_h], t3.head[t3.ins_h] = h2, h2++, t3.insert--, !(t3.lookahead + t3.insert < 3)); )
                        ;
                  } while (t3.lookahead < c && 0 !== t3.strm.avail_in);
                }
                function M(t3, e4) {
                  for (var i3, r3; ; ) {
                    if (t3.lookahead < c) {
                      if (w(t3), t3.lookahead < c && 0 === e4)
                        return 1;
                      if (0 === t3.lookahead)
                        break;
                    }
                    if (i3 = 0, t3.lookahead >= 3 && (t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[t3.strstart + 3 - 1]) & t3.hash_mask, i3 = t3.prev[t3.strstart & t3.w_mask] = t3.head[t3.ins_h], t3.head[t3.ins_h] = t3.strstart), 0 !== i3 && t3.strstart - i3 <= t3.w_size - c && (t3.match_length = b(t3, i3)), t3.match_length >= 3)
                      if (r3 = n2._tr_tally(t3, t3.strstart - t3.match_start, t3.match_length - 3), t3.lookahead -= t3.match_length, t3.match_length <= t3.max_lazy_match && t3.lookahead >= 3) {
                        for (t3.match_length--; t3.strstart++, t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[t3.strstart + 3 - 1]) & t3.hash_mask, i3 = t3.prev[t3.strstart & t3.w_mask] = t3.head[t3.ins_h], t3.head[t3.ins_h] = t3.strstart, 0 != --t3.match_length; )
                          ;
                        t3.strstart++;
                      } else
                        t3.strstart += t3.match_length, t3.match_length = 0, t3.ins_h = t3.window[t3.strstart], t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[t3.strstart + 1]) & t3.hash_mask;
                    else
                      r3 = n2._tr_tally(t3, 0, t3.window[t3.strstart]), t3.lookahead--, t3.strstart++;
                    if (r3 && (_(t3, false), 0 === t3.strm.avail_out))
                      return 1;
                  }
                  return t3.insert = t3.strstart < 2 ? t3.strstart : 2, 4 === e4 ? (_(t3, true), 0 === t3.strm.avail_out ? 3 : 4) : t3.last_lit && (_(t3, false), 0 === t3.strm.avail_out) ? 1 : 2;
                }
                function x(t3, e4) {
                  for (var i3, r3, s3; ; ) {
                    if (t3.lookahead < c) {
                      if (w(t3), t3.lookahead < c && 0 === e4)
                        return 1;
                      if (0 === t3.lookahead)
                        break;
                    }
                    if (i3 = 0, t3.lookahead >= 3 && (t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[t3.strstart + 3 - 1]) & t3.hash_mask, i3 = t3.prev[t3.strstart & t3.w_mask] = t3.head[t3.ins_h], t3.head[t3.ins_h] = t3.strstart), t3.prev_length = t3.match_length, t3.prev_match = t3.match_start, t3.match_length = 2, 0 !== i3 && t3.prev_length < t3.max_lazy_match && t3.strstart - i3 <= t3.w_size - c && (t3.match_length = b(t3, i3), t3.match_length <= 5 && (1 === t3.strategy || 3 === t3.match_length && 4096 < t3.strstart - t3.match_start) && (t3.match_length = 2)), t3.prev_length >= 3 && t3.match_length <= t3.prev_length) {
                      for (s3 = t3.strstart + t3.lookahead - 3, r3 = n2._tr_tally(t3, t3.strstart - 1 - t3.prev_match, t3.prev_length - 3), t3.lookahead -= t3.prev_length - 1, t3.prev_length -= 2; ++t3.strstart <= s3 && (t3.ins_h = (t3.ins_h << t3.hash_shift ^ t3.window[t3.strstart + 3 - 1]) & t3.hash_mask, i3 = t3.prev[t3.strstart & t3.w_mask] = t3.head[t3.ins_h], t3.head[t3.ins_h] = t3.strstart), 0 != --t3.prev_length; )
                        ;
                      if (t3.match_available = 0, t3.match_length = 2, t3.strstart++, r3 && (_(t3, false), 0 === t3.strm.avail_out))
                        return 1;
                    } else if (t3.match_available) {
                      if ((r3 = n2._tr_tally(t3, 0, t3.window[t3.strstart - 1])) && _(t3, false), t3.strstart++, t3.lookahead--, 0 === t3.strm.avail_out)
                        return 1;
                    } else
                      t3.match_available = 1, t3.strstart++, t3.lookahead--;
                  }
                  return t3.match_available && (r3 = n2._tr_tally(t3, 0, t3.window[t3.strstart - 1]), t3.match_available = 0), t3.insert = t3.strstart < 2 ? t3.strstart : 2, 4 === e4 ? (_(t3, true), 0 === t3.strm.avail_out ? 3 : 4) : t3.last_lit && (_(t3, false), 0 === t3.strm.avail_out) ? 1 : 2;
                }
                function k(t3, e4, i3, r3, s3) {
                  this.good_length = t3, this.max_lazy = e4, this.nice_length = i3, this.max_chain = r3, this.func = s3;
                }
                function S() {
                  this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = 8, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new s2.Buf16(1146), this.dyn_dtree = new s2.Buf16(122), this.bl_tree = new s2.Buf16(78), m(this.dyn_ltree), m(this.dyn_dtree), m(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new s2.Buf16(16), this.heap = new s2.Buf16(573), m(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new s2.Buf16(573), m(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
                }
                function E(t3) {
                  var e4;
                  return t3 && t3.state ? (t3.total_in = t3.total_out = 0, t3.data_type = 2, (e4 = t3.state).pending = 0, e4.pending_out = 0, e4.wrap < 0 && (e4.wrap = -e4.wrap), e4.status = e4.wrap ? 42 : f, t3.adler = 2 === e4.wrap ? 0 : 1, e4.last_flush = 0, n2._tr_init(e4), 0) : d(t3, u);
                }
                function C(t3) {
                  var e4 = E(t3);
                  return 0 === e4 && function(t4) {
                    t4.window_size = 2 * t4.w_size, m(t4.head), t4.max_lazy_match = r2[t4.level].max_lazy, t4.good_match = r2[t4.level].good_length, t4.nice_match = r2[t4.level].nice_length, t4.max_chain_length = r2[t4.level].max_chain, t4.strstart = 0, t4.block_start = 0, t4.lookahead = 0, t4.insert = 0, t4.match_length = t4.prev_length = 2, t4.match_available = 0, t4.ins_h = 0;
                  }(t3.state), e4;
                }
                function A(t3, e4, i3, r3, n3, a2) {
                  if (!t3)
                    return u;
                  var o2 = 1;
                  if (-1 === e4 && (e4 = 6), r3 < 0 ? (o2 = 0, r3 = -r3) : 15 < r3 && (o2 = 2, r3 -= 16), n3 < 1 || 9 < n3 || 8 !== i3 || r3 < 8 || 15 < r3 || e4 < 0 || 9 < e4 || a2 < 0 || 4 < a2)
                    return d(t3, u);
                  8 === r3 && (r3 = 9);
                  var h2 = new S();
                  return (t3.state = h2).strm = t3, h2.wrap = o2, h2.gzhead = null, h2.w_bits = r3, h2.w_size = 1 << h2.w_bits, h2.w_mask = h2.w_size - 1, h2.hash_bits = n3 + 7, h2.hash_size = 1 << h2.hash_bits, h2.hash_mask = h2.hash_size - 1, h2.hash_shift = ~~((h2.hash_bits + 3 - 1) / 3), h2.window = new s2.Buf8(2 * h2.w_size), h2.head = new s2.Buf16(h2.hash_size), h2.prev = new s2.Buf16(h2.w_size), h2.lit_bufsize = 1 << n3 + 6, h2.pending_buf_size = 4 * h2.lit_bufsize, h2.pending_buf = new s2.Buf8(h2.pending_buf_size), h2.d_buf = 1 * h2.lit_bufsize, h2.l_buf = 3 * h2.lit_bufsize, h2.level = e4, h2.strategy = a2, h2.method = i3, C(t3);
                }
                r2 = [
                  new k(0, 0, 0, 0, function(t3, e4) {
                    var i3 = 65535;
                    for (i3 > t3.pending_buf_size - 5 && (i3 = t3.pending_buf_size - 5); ; ) {
                      if (t3.lookahead <= 1) {
                        if (w(t3), 0 === t3.lookahead && 0 === e4)
                          return 1;
                        if (0 === t3.lookahead)
                          break;
                      }
                      t3.strstart += t3.lookahead, t3.lookahead = 0;
                      var r3 = t3.block_start + i3;
                      if ((0 === t3.strstart || t3.strstart >= r3) && (t3.lookahead = t3.strstart - r3, t3.strstart = r3, _(t3, false), 0 === t3.strm.avail_out))
                        return 1;
                      if (t3.strstart - t3.block_start >= t3.w_size - c && (_(t3, false), 0 === t3.strm.avail_out))
                        return 1;
                    }
                    return t3.insert = 0, 4 === e4 ? (_(t3, true), 0 === t3.strm.avail_out ? 3 : 4) : (t3.strstart > t3.block_start && (_(t3, false), t3.strm.avail_out), 1);
                  }),
                  new k(4, 4, 8, 4, M),
                  new k(4, 5, 16, 8, M),
                  new k(4, 6, 32, 32, M),
                  new k(4, 4, 16, 16, x),
                  new k(8, 16, 32, 32, x),
                  new k(8, 16, 128, 128, x),
                  new k(8, 32, 128, 256, x),
                  new k(32, 128, 258, 1024, x),
                  new k(32, 258, 258, 4096, x)
                ], i2.deflateInit = function(t3, e4) {
                  return A(t3, e4, 8, 15, 8, 0);
                }, i2.deflateInit2 = A, i2.deflateReset = C, i2.deflateResetKeep = E, i2.deflateSetHeader = function(t3, e4) {
                  return t3 && t3.state ? 2 !== t3.state.wrap ? u : (t3.state.gzhead = e4, 0) : u;
                }, i2.deflate = function(t3, e4) {
                  var i3, s3, a2, h2;
                  if (!t3 || !t3.state || 5 < e4 || e4 < 0)
                    return t3 ? d(t3, u) : u;
                  if (s3 = t3.state, !t3.output || !t3.input && 0 !== t3.avail_in || 666 === s3.status && 4 !== e4)
                    return d(t3, 0 === t3.avail_out ? -5 : u);
                  if (s3.strm = t3, i3 = s3.last_flush, s3.last_flush = e4, 42 === s3.status)
                    if (2 === s3.wrap)
                      t3.adler = 0, y(s3, 31), y(s3, 139), y(s3, 8), s3.gzhead ? (y(s3, (s3.gzhead.text ? 1 : 0) + (s3.gzhead.hcrc ? 2 : 0) + (s3.gzhead.extra ? 4 : 0) + (s3.gzhead.name ? 8 : 0) + (s3.gzhead.comment ? 16 : 0)), y(s3, 255 & s3.gzhead.time), y(s3, s3.gzhead.time >> 8 & 255), y(s3, s3.gzhead.time >> 16 & 255), y(s3, s3.gzhead.time >> 24 & 255), y(s3, 9 === s3.level ? 2 : 2 <= s3.strategy || s3.level < 2 ? 4 : 0), y(s3, 255 & s3.gzhead.os), s3.gzhead.extra && s3.gzhead.extra.length && (y(s3, 255 & s3.gzhead.extra.length), y(s3, s3.gzhead.extra.length >> 8 & 255)), s3.gzhead.hcrc && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending, 0)), s3.gzindex = 0, s3.status = 69) : (y(s3, 0), y(s3, 0), y(s3, 0), y(s3, 0), y(s3, 0), y(s3, 9 === s3.level ? 2 : 2 <= s3.strategy || s3.level < 2 ? 4 : 0), y(s3, 3), s3.status = f);
                    else {
                      var c2 = 8 + (s3.w_bits - 8 << 4) << 8;
                      c2 |= (2 <= s3.strategy || s3.level < 2 ? 0 : s3.level < 6 ? 1 : 6 === s3.level ? 2 : 3) << 6, 0 !== s3.strstart && (c2 |= 32), c2 += 31 - c2 % 31, s3.status = f, v(s3, c2), 0 !== s3.strstart && (v(s3, t3.adler >>> 16), v(s3, 65535 & t3.adler)), t3.adler = 1;
                    }
                  if (69 === s3.status)
                    if (s3.gzhead.extra) {
                      for (a2 = s3.pending; s3.gzindex < (65535 & s3.gzhead.extra.length) && (s3.pending !== s3.pending_buf_size || (s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), g(t3), a2 = s3.pending, s3.pending !== s3.pending_buf_size)); )
                        y(s3, 255 & s3.gzhead.extra[s3.gzindex]), s3.gzindex++;
                      s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), s3.gzindex === s3.gzhead.extra.length && (s3.gzindex = 0, s3.status = 73);
                    } else
                      s3.status = 73;
                  if (73 === s3.status)
                    if (s3.gzhead.name) {
                      a2 = s3.pending;
                      do {
                        if (s3.pending === s3.pending_buf_size && (s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), g(t3), a2 = s3.pending, s3.pending === s3.pending_buf_size)) {
                          h2 = 1;
                          break;
                        }
                        h2 = s3.gzindex < s3.gzhead.name.length ? 255 & s3.gzhead.name.charCodeAt(s3.gzindex++) : 0, y(s3, h2);
                      } while (0 !== h2);
                      s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), 0 === h2 && (s3.gzindex = 0, s3.status = 91);
                    } else
                      s3.status = 91;
                  if (91 === s3.status)
                    if (s3.gzhead.comment) {
                      a2 = s3.pending;
                      do {
                        if (s3.pending === s3.pending_buf_size && (s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), g(t3), a2 = s3.pending, s3.pending === s3.pending_buf_size)) {
                          h2 = 1;
                          break;
                        }
                        h2 = s3.gzindex < s3.gzhead.comment.length ? 255 & s3.gzhead.comment.charCodeAt(s3.gzindex++) : 0, y(s3, h2);
                      } while (0 !== h2);
                      s3.gzhead.hcrc && s3.pending > a2 && (t3.adler = o(t3.adler, s3.pending_buf, s3.pending - a2, a2)), 0 === h2 && (s3.status = 103);
                    } else
                      s3.status = 103;
                  if (103 === s3.status && (s3.gzhead.hcrc ? (s3.pending + 2 > s3.pending_buf_size && g(t3), s3.pending + 2 <= s3.pending_buf_size && (y(s3, 255 & t3.adler), y(s3, t3.adler >> 8 & 255), t3.adler = 0, s3.status = f)) : s3.status = f), 0 !== s3.pending) {
                    if (g(t3), 0 === t3.avail_out)
                      return s3.last_flush = -1, 0;
                  } else if (0 === t3.avail_in && p(e4) <= p(i3) && 4 !== e4)
                    return d(t3, -5);
                  if (666 === s3.status && 0 !== t3.avail_in)
                    return d(t3, -5);
                  if (0 !== t3.avail_in || 0 !== s3.lookahead || 0 !== e4 && 666 !== s3.status) {
                    var b2 = 2 === s3.strategy ? function(t4, e5) {
                      for (var i4; ; ) {
                        if (0 === t4.lookahead && (w(t4), 0 === t4.lookahead)) {
                          if (0 === e5)
                            return 1;
                          break;
                        }
                        if (t4.match_length = 0, i4 = n2._tr_tally(t4, 0, t4.window[t4.strstart]), t4.lookahead--, t4.strstart++, i4 && (_(t4, false), 0 === t4.strm.avail_out))
                          return 1;
                      }
                      return t4.insert = 0, 4 === e5 ? (_(t4, true), 0 === t4.strm.avail_out ? 3 : 4) : t4.last_lit && (_(t4, false), 0 === t4.strm.avail_out) ? 1 : 2;
                    }(s3, e4) : 3 === s3.strategy ? function(t4, e5) {
                      for (var i4, r3, s4, a3, o2 = t4.window; ; ) {
                        if (t4.lookahead <= l) {
                          if (w(t4), t4.lookahead <= l && 0 === e5)
                            return 1;
                          if (0 === t4.lookahead)
                            break;
                        }
                        if (t4.match_length = 0, t4.lookahead >= 3 && 0 < t4.strstart && (r3 = o2[s4 = t4.strstart - 1]) === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4]) {
                          a3 = t4.strstart + l;
                          do {
                          } while (r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && r3 === o2[++s4] && s4 < a3);
                          t4.match_length = l - (a3 - s4), t4.match_length > t4.lookahead && (t4.match_length = t4.lookahead);
                        }
                        if (t4.match_length >= 3 ? (i4 = n2._tr_tally(t4, 1, t4.match_length - 3), t4.lookahead -= t4.match_length, t4.strstart += t4.match_length, t4.match_length = 0) : (i4 = n2._tr_tally(t4, 0, t4.window[t4.strstart]), t4.lookahead--, t4.strstart++), i4 && (_(t4, false), 0 === t4.strm.avail_out))
                          return 1;
                      }
                      return t4.insert = 0, 4 === e5 ? (_(t4, true), 0 === t4.strm.avail_out ? 3 : 4) : t4.last_lit && (_(t4, false), 0 === t4.strm.avail_out) ? 1 : 2;
                    }(s3, e4) : r2[s3.level].func(s3, e4);
                    if (3 !== b2 && 4 !== b2 || (s3.status = 666), 1 === b2 || 3 === b2)
                      return 0 === t3.avail_out && (s3.last_flush = -1), 0;
                    if (2 === b2 && (1 === e4 ? n2._tr_align(s3) : 5 !== e4 && (n2._tr_stored_block(s3, 0, 0, false), 3 === e4 && (m(s3.head), 0 === s3.lookahead && (s3.strstart = 0, s3.block_start = 0, s3.insert = 0))), g(t3), 0 === t3.avail_out))
                      return s3.last_flush = -1, 0;
                  }
                  return 4 !== e4 ? 0 : s3.wrap <= 0 ? 1 : (2 === s3.wrap ? (y(s3, 255 & t3.adler), y(s3, t3.adler >> 8 & 255), y(s3, t3.adler >> 16 & 255), y(s3, t3.adler >> 24 & 255), y(s3, 255 & t3.total_in), y(s3, t3.total_in >> 8 & 255), y(s3, t3.total_in >> 16 & 255), y(s3, t3.total_in >> 24 & 255)) : (v(s3, t3.adler >>> 16), v(s3, 65535 & t3.adler)), g(t3), 0 < s3.wrap && (s3.wrap = -s3.wrap), 0 !== s3.pending ? 0 : 1);
                }, i2.deflateEnd = function(t3) {
                  var e4;
                  return t3 && t3.state ? 42 !== (e4 = t3.state.status) && 69 !== e4 && 73 !== e4 && 91 !== e4 && 103 !== e4 && e4 !== f && 666 !== e4 ? d(t3, u) : (t3.state = null, e4 === f ? d(t3, -3) : 0) : u;
                }, i2.deflateSetDictionary = function(t3, e4) {
                  var i3, r3, n3, o2, h2, l2, c2, f2, d2 = e4.length;
                  if (!t3 || !t3.state)
                    return u;
                  if (2 === (o2 = (i3 = t3.state).wrap) || 1 === o2 && 42 !== i3.status || i3.lookahead)
                    return u;
                  for (1 === o2 && (t3.adler = a(t3.adler, e4, d2, 0)), i3.wrap = 0, d2 >= i3.w_size && (0 === o2 && (m(i3.head), i3.strstart = 0, i3.block_start = 0, i3.insert = 0), f2 = new s2.Buf8(i3.w_size), s2.arraySet(f2, e4, d2 - i3.w_size, i3.w_size, 0), e4 = f2, d2 = i3.w_size), h2 = t3.avail_in, l2 = t3.next_in, c2 = t3.input, t3.avail_in = d2, t3.next_in = 0, t3.input = e4, w(i3); i3.lookahead >= 3; ) {
                    for (r3 = i3.strstart, n3 = i3.lookahead - 2; i3.ins_h = (i3.ins_h << i3.hash_shift ^ i3.window[r3 + 3 - 1]) & i3.hash_mask, i3.prev[r3 & i3.w_mask] = i3.head[i3.ins_h], i3.head[i3.ins_h] = r3, r3++, --n3; )
                      ;
                    i3.strstart = r3, i3.lookahead = 2, w(i3);
                  }
                  return i3.strstart += i3.lookahead, i3.block_start = i3.strstart, i3.insert = i3.lookahead, i3.lookahead = 0, i3.match_length = i3.prev_length = 2, i3.match_available = 0, t3.next_in = l2, t3.input = c2, t3.avail_in = h2, i3.wrap = o2, 0;
                }, i2.deflateInfo = "pako deflate (from Nodeca project)";
              },
              { "../utils/common": 41, "./adler32": 43, "./crc32": 45, "./messages": 51, "./trees": 52 }
            ],
            47: [
              function(t2, e3, i2) {
                e3.exports = function() {
                  this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = false;
                };
              },
              {}
            ],
            48: [
              function(t2, e3, i2) {
                e3.exports = function(t3, e4) {
                  var i3, r2, s2, n2, a, o, h, u, l, c, f, d, p, m, g, _, y, v, b, w, M, x, k, S, E;
                  i3 = t3.state, r2 = t3.next_in, S = t3.input, s2 = r2 + (t3.avail_in - 5), n2 = t3.next_out, E = t3.output, a = n2 - (e4 - t3.avail_out), o = n2 + (t3.avail_out - 257), h = i3.dmax, u = i3.wsize, l = i3.whave, c = i3.wnext, f = i3.window, d = i3.hold, p = i3.bits, m = i3.lencode, g = i3.distcode, _ = (1 << i3.lenbits) - 1, y = (1 << i3.distbits) - 1;
                  t:
                    do {
                      p < 15 && (d += S[r2++] << p, p += 8, d += S[r2++] << p, p += 8), v = m[d & _];
                      e:
                        for (; ; ) {
                          if (d >>>= b = v >>> 24, p -= b, 0 == (b = v >>> 16 & 255))
                            E[n2++] = 65535 & v;
                          else {
                            if (!(16 & b)) {
                              if (0 == (64 & b)) {
                                v = m[(65535 & v) + (d & (1 << b) - 1)];
                                continue e;
                              }
                              if (32 & b) {
                                i3.mode = 12;
                                break t;
                              }
                              t3.msg = "invalid literal/length code", i3.mode = 30;
                              break t;
                            }
                            w = 65535 & v, (b &= 15) && (p < b && (d += S[r2++] << p, p += 8), w += d & (1 << b) - 1, d >>>= b, p -= b), p < 15 && (d += S[r2++] << p, p += 8, d += S[r2++] << p, p += 8), v = g[d & y];
                            i:
                              for (; ; ) {
                                if (d >>>= b = v >>> 24, p -= b, !(16 & (b = v >>> 16 & 255))) {
                                  if (0 == (64 & b)) {
                                    v = g[(65535 & v) + (d & (1 << b) - 1)];
                                    continue i;
                                  }
                                  t3.msg = "invalid distance code", i3.mode = 30;
                                  break t;
                                }
                                if (M = 65535 & v, p < (b &= 15) && (d += S[r2++] << p, (p += 8) < b && (d += S[r2++] << p, p += 8)), h < (M += d & (1 << b) - 1)) {
                                  t3.msg = "invalid distance too far back", i3.mode = 30;
                                  break t;
                                }
                                if (d >>>= b, p -= b, (b = n2 - a) < M) {
                                  if (l < (b = M - b) && i3.sane) {
                                    t3.msg = "invalid distance too far back", i3.mode = 30;
                                    break t;
                                  }
                                  if (k = f, (x = 0) === c) {
                                    if (x += u - b, b < w) {
                                      for (w -= b; E[n2++] = f[x++], --b; )
                                        ;
                                      x = n2 - M, k = E;
                                    }
                                  } else if (c < b) {
                                    if (x += u + c - b, (b -= c) < w) {
                                      for (w -= b; E[n2++] = f[x++], --b; )
                                        ;
                                      if (x = 0, c < w) {
                                        for (w -= b = c; E[n2++] = f[x++], --b; )
                                          ;
                                        x = n2 - M, k = E;
                                      }
                                    }
                                  } else if (x += c - b, b < w) {
                                    for (w -= b; E[n2++] = f[x++], --b; )
                                      ;
                                    x = n2 - M, k = E;
                                  }
                                  for (; 2 < w; )
                                    E[n2++] = k[x++], E[n2++] = k[x++], E[n2++] = k[x++], w -= 3;
                                  w && (E[n2++] = k[x++], 1 < w && (E[n2++] = k[x++]));
                                } else {
                                  for (x = n2 - M; E[n2++] = E[x++], E[n2++] = E[x++], E[n2++] = E[x++], 2 < (w -= 3); )
                                    ;
                                  w && (E[n2++] = E[x++], 1 < w && (E[n2++] = E[x++]));
                                }
                                break;
                              }
                          }
                          break;
                        }
                    } while (r2 < s2 && n2 < o);
                  r2 -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, t3.next_in = r2, t3.next_out = n2, t3.avail_in = r2 < s2 ? s2 - r2 + 5 : 5 - (r2 - s2), t3.avail_out = n2 < o ? o - n2 + 257 : 257 - (n2 - o), i3.hold = d, i3.bits = p;
                };
              },
              {}
            ],
            49: [
              function(t2, e3, i2) {
                var r2 = t2("../utils/common"), s2 = t2("./adler32"), n2 = t2("./crc32"), a = t2("./inffast"), o = t2("./inftrees"), h = -2;
                function u(t3) {
                  return (t3 >>> 24 & 255) + (t3 >>> 8 & 65280) + ((65280 & t3) << 8) + ((255 & t3) << 24);
                }
                function l() {
                  this.mode = 0, this.last = false, this.wrap = 0, this.havedict = false, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new r2.Buf16(320), this.work = new r2.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
                }
                function c(t3) {
                  var e4;
                  return t3 && t3.state ? (e4 = t3.state, t3.total_in = t3.total_out = e4.total = 0, t3.msg = "", e4.wrap && (t3.adler = 1 & e4.wrap), e4.mode = 1, e4.last = 0, e4.havedict = 0, e4.dmax = 32768, e4.head = null, e4.hold = 0, e4.bits = 0, e4.lencode = e4.lendyn = new r2.Buf32(852), e4.distcode = e4.distdyn = new r2.Buf32(592), e4.sane = 1, e4.back = -1, 0) : h;
                }
                function f(t3) {
                  var e4;
                  return t3 && t3.state ? ((e4 = t3.state).wsize = 0, e4.whave = 0, e4.wnext = 0, c(t3)) : h;
                }
                function d(t3, e4) {
                  var i3, r3;
                  return t3 && t3.state ? (r3 = t3.state, e4 < 0 ? (i3 = 0, e4 = -e4) : (i3 = 1 + (e4 >> 4), e4 < 48 && (e4 &= 15)), e4 && (e4 < 8 || 15 < e4) ? h : (null !== r3.window && r3.wbits !== e4 && (r3.window = null), r3.wrap = i3, r3.wbits = e4, f(t3))) : h;
                }
                function p(t3, e4) {
                  var i3, r3;
                  return t3 ? (r3 = new l(), (t3.state = r3).window = null, 0 !== (i3 = d(t3, e4)) && (t3.state = null), i3) : h;
                }
                var m, g, _ = true;
                function y(t3) {
                  if (_) {
                    var e4;
                    for (m = new r2.Buf32(512), g = new r2.Buf32(32), e4 = 0; e4 < 144; )
                      t3.lens[e4++] = 8;
                    for (; e4 < 256; )
                      t3.lens[e4++] = 9;
                    for (; e4 < 280; )
                      t3.lens[e4++] = 7;
                    for (; e4 < 288; )
                      t3.lens[e4++] = 8;
                    for (o(1, t3.lens, 0, 288, m, 0, t3.work, { bits: 9 }), e4 = 0; e4 < 32; )
                      t3.lens[e4++] = 5;
                    o(2, t3.lens, 0, 32, g, 0, t3.work, { bits: 5 }), _ = false;
                  }
                  t3.lencode = m, t3.lenbits = 9, t3.distcode = g, t3.distbits = 5;
                }
                function v(t3, e4, i3, s3) {
                  var n3, a2 = t3.state;
                  return null === a2.window && (a2.wsize = 1 << a2.wbits, a2.wnext = 0, a2.whave = 0, a2.window = new r2.Buf8(a2.wsize)), s3 >= a2.wsize ? (r2.arraySet(a2.window, e4, i3 - a2.wsize, a2.wsize, 0), a2.wnext = 0, a2.whave = a2.wsize) : (s3 < (n3 = a2.wsize - a2.wnext) && (n3 = s3), r2.arraySet(a2.window, e4, i3 - s3, n3, a2.wnext), (s3 -= n3) ? (r2.arraySet(a2.window, e4, i3 - s3, s3, 0), a2.wnext = s3, a2.whave = a2.wsize) : (a2.wnext += n3, a2.wnext === a2.wsize && (a2.wnext = 0), a2.whave < a2.wsize && (a2.whave += n3))), 0;
                }
                i2.inflateReset = f, i2.inflateReset2 = d, i2.inflateResetKeep = c, i2.inflateInit = function(t3) {
                  return p(t3, 15);
                }, i2.inflateInit2 = p, i2.inflate = function(t3, e4) {
                  var i3, l2, c2, f2, d2, p2, m2, g2, _2, b, w, M, x, k, S, E, C, A, I, O, T, z, P, N, L = 0, R = new r2.Buf8(4), B = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
                  if (!t3 || !t3.state || !t3.output || !t3.input && 0 !== t3.avail_in)
                    return h;
                  12 === (i3 = t3.state).mode && (i3.mode = 13), d2 = t3.next_out, c2 = t3.output, m2 = t3.avail_out, f2 = t3.next_in, l2 = t3.input, p2 = t3.avail_in, g2 = i3.hold, _2 = i3.bits, b = p2, w = m2, z = 0;
                  t:
                    for (; ; )
                      switch (i3.mode) {
                        case 1:
                          if (0 === i3.wrap) {
                            i3.mode = 13;
                            break;
                          }
                          for (; _2 < 16; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if (2 & i3.wrap && 35615 === g2) {
                            R[i3.check = 0] = 255 & g2, R[1] = g2 >>> 8 & 255, i3.check = n2(i3.check, R, 2, 0), _2 = g2 = 0, i3.mode = 2;
                            break;
                          }
                          if (i3.flags = 0, i3.head && (i3.head.done = false), !(1 & i3.wrap) || (((255 & g2) << 8) + (g2 >> 8)) % 31) {
                            t3.msg = "incorrect header check", i3.mode = 30;
                            break;
                          }
                          if (8 != (15 & g2)) {
                            t3.msg = "unknown compression method", i3.mode = 30;
                            break;
                          }
                          if (_2 -= 4, T = 8 + (15 & (g2 >>>= 4)), 0 === i3.wbits)
                            i3.wbits = T;
                          else if (T > i3.wbits) {
                            t3.msg = "invalid window size", i3.mode = 30;
                            break;
                          }
                          i3.dmax = 1 << T, t3.adler = i3.check = 1, i3.mode = 512 & g2 ? 10 : 12, _2 = g2 = 0;
                          break;
                        case 2:
                          for (; _2 < 16; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if (i3.flags = g2, 8 != (255 & i3.flags)) {
                            t3.msg = "unknown compression method", i3.mode = 30;
                            break;
                          }
                          if (57344 & i3.flags) {
                            t3.msg = "unknown header flags set", i3.mode = 30;
                            break;
                          }
                          i3.head && (i3.head.text = g2 >> 8 & 1), 512 & i3.flags && (R[0] = 255 & g2, R[1] = g2 >>> 8 & 255, i3.check = n2(i3.check, R, 2, 0)), _2 = g2 = 0, i3.mode = 3;
                        case 3:
                          for (; _2 < 32; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          i3.head && (i3.head.time = g2), 512 & i3.flags && (R[0] = 255 & g2, R[1] = g2 >>> 8 & 255, R[2] = g2 >>> 16 & 255, R[3] = g2 >>> 24 & 255, i3.check = n2(i3.check, R, 4, 0)), _2 = g2 = 0, i3.mode = 4;
                        case 4:
                          for (; _2 < 16; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          i3.head && (i3.head.xflags = 255 & g2, i3.head.os = g2 >> 8), 512 & i3.flags && (R[0] = 255 & g2, R[1] = g2 >>> 8 & 255, i3.check = n2(i3.check, R, 2, 0)), _2 = g2 = 0, i3.mode = 5;
                        case 5:
                          if (1024 & i3.flags) {
                            for (; _2 < 16; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            i3.length = g2, i3.head && (i3.head.extra_len = g2), 512 & i3.flags && (R[0] = 255 & g2, R[1] = g2 >>> 8 & 255, i3.check = n2(i3.check, R, 2, 0)), _2 = g2 = 0;
                          } else
                            i3.head && (i3.head.extra = null);
                          i3.mode = 6;
                        case 6:
                          if (1024 & i3.flags && (p2 < (M = i3.length) && (M = p2), M && (i3.head && (T = i3.head.extra_len - i3.length, i3.head.extra || (i3.head.extra = new Array(i3.head.extra_len)), r2.arraySet(i3.head.extra, l2, f2, M, T)), 512 & i3.flags && (i3.check = n2(i3.check, l2, M, f2)), p2 -= M, f2 += M, i3.length -= M), i3.length))
                            break t;
                          i3.length = 0, i3.mode = 7;
                        case 7:
                          if (2048 & i3.flags) {
                            if (0 === p2)
                              break t;
                            for (M = 0; T = l2[f2 + M++], i3.head && T && i3.length < 65536 && (i3.head.name += String.fromCharCode(T)), T && M < p2; )
                              ;
                            if (512 & i3.flags && (i3.check = n2(i3.check, l2, M, f2)), p2 -= M, f2 += M, T)
                              break t;
                          } else
                            i3.head && (i3.head.name = null);
                          i3.length = 0, i3.mode = 8;
                        case 8:
                          if (4096 & i3.flags) {
                            if (0 === p2)
                              break t;
                            for (M = 0; T = l2[f2 + M++], i3.head && T && i3.length < 65536 && (i3.head.comment += String.fromCharCode(T)), T && M < p2; )
                              ;
                            if (512 & i3.flags && (i3.check = n2(i3.check, l2, M, f2)), p2 -= M, f2 += M, T)
                              break t;
                          } else
                            i3.head && (i3.head.comment = null);
                          i3.mode = 9;
                        case 9:
                          if (512 & i3.flags) {
                            for (; _2 < 16; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            if (g2 !== (65535 & i3.check)) {
                              t3.msg = "header crc mismatch", i3.mode = 30;
                              break;
                            }
                            _2 = g2 = 0;
                          }
                          i3.head && (i3.head.hcrc = i3.flags >> 9 & 1, i3.head.done = true), t3.adler = i3.check = 0, i3.mode = 12;
                          break;
                        case 10:
                          for (; _2 < 32; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          t3.adler = i3.check = u(g2), _2 = g2 = 0, i3.mode = 11;
                        case 11:
                          if (0 === i3.havedict)
                            return t3.next_out = d2, t3.avail_out = m2, t3.next_in = f2, t3.avail_in = p2, i3.hold = g2, i3.bits = _2, 2;
                          t3.adler = i3.check = 1, i3.mode = 12;
                        case 12:
                          if (5 === e4 || 6 === e4)
                            break t;
                        case 13:
                          if (i3.last) {
                            g2 >>>= 7 & _2, _2 -= 7 & _2, i3.mode = 27;
                            break;
                          }
                          for (; _2 < 3; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          switch (i3.last = 1 & g2, _2 -= 1, 3 & (g2 >>>= 1)) {
                            case 0:
                              i3.mode = 14;
                              break;
                            case 1:
                              if (y(i3), i3.mode = 20, 6 !== e4)
                                break;
                              g2 >>>= 2, _2 -= 2;
                              break t;
                            case 2:
                              i3.mode = 17;
                              break;
                            case 3:
                              t3.msg = "invalid block type", i3.mode = 30;
                          }
                          g2 >>>= 2, _2 -= 2;
                          break;
                        case 14:
                          for (g2 >>>= 7 & _2, _2 -= 7 & _2; _2 < 32; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if ((65535 & g2) != (g2 >>> 16 ^ 65535)) {
                            t3.msg = "invalid stored block lengths", i3.mode = 30;
                            break;
                          }
                          if (i3.length = 65535 & g2, _2 = g2 = 0, i3.mode = 15, 6 === e4)
                            break t;
                        case 15:
                          i3.mode = 16;
                        case 16:
                          if (M = i3.length) {
                            if (p2 < M && (M = p2), m2 < M && (M = m2), 0 === M)
                              break t;
                            r2.arraySet(c2, l2, f2, M, d2), p2 -= M, f2 += M, m2 -= M, d2 += M, i3.length -= M;
                            break;
                          }
                          i3.mode = 12;
                          break;
                        case 17:
                          for (; _2 < 14; ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if (i3.nlen = 257 + (31 & g2), g2 >>>= 5, _2 -= 5, i3.ndist = 1 + (31 & g2), g2 >>>= 5, _2 -= 5, i3.ncode = 4 + (15 & g2), g2 >>>= 4, _2 -= 4, 286 < i3.nlen || 30 < i3.ndist) {
                            t3.msg = "too many length or distance symbols", i3.mode = 30;
                            break;
                          }
                          i3.have = 0, i3.mode = 18;
                        case 18:
                          for (; i3.have < i3.ncode; ) {
                            for (; _2 < 3; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            i3.lens[B[i3.have++]] = 7 & g2, g2 >>>= 3, _2 -= 3;
                          }
                          for (; i3.have < 19; )
                            i3.lens[B[i3.have++]] = 0;
                          if (i3.lencode = i3.lendyn, i3.lenbits = 7, P = { bits: i3.lenbits }, z = o(0, i3.lens, 0, 19, i3.lencode, 0, i3.work, P), i3.lenbits = P.bits, z) {
                            t3.msg = "invalid code lengths set", i3.mode = 30;
                            break;
                          }
                          i3.have = 0, i3.mode = 19;
                        case 19:
                          for (; i3.have < i3.nlen + i3.ndist; ) {
                            for (; E = (L = i3.lencode[g2 & (1 << i3.lenbits) - 1]) >>> 16 & 255, C = 65535 & L, !((S = L >>> 24) <= _2); ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            if (C < 16)
                              g2 >>>= S, _2 -= S, i3.lens[i3.have++] = C;
                            else {
                              if (16 === C) {
                                for (N = S + 2; _2 < N; ) {
                                  if (0 === p2)
                                    break t;
                                  p2--, g2 += l2[f2++] << _2, _2 += 8;
                                }
                                if (g2 >>>= S, _2 -= S, 0 === i3.have) {
                                  t3.msg = "invalid bit length repeat", i3.mode = 30;
                                  break;
                                }
                                T = i3.lens[i3.have - 1], M = 3 + (3 & g2), g2 >>>= 2, _2 -= 2;
                              } else if (17 === C) {
                                for (N = S + 3; _2 < N; ) {
                                  if (0 === p2)
                                    break t;
                                  p2--, g2 += l2[f2++] << _2, _2 += 8;
                                }
                                _2 -= S, T = 0, M = 3 + (7 & (g2 >>>= S)), g2 >>>= 3, _2 -= 3;
                              } else {
                                for (N = S + 7; _2 < N; ) {
                                  if (0 === p2)
                                    break t;
                                  p2--, g2 += l2[f2++] << _2, _2 += 8;
                                }
                                _2 -= S, T = 0, M = 11 + (127 & (g2 >>>= S)), g2 >>>= 7, _2 -= 7;
                              }
                              if (i3.have + M > i3.nlen + i3.ndist) {
                                t3.msg = "invalid bit length repeat", i3.mode = 30;
                                break;
                              }
                              for (; M--; )
                                i3.lens[i3.have++] = T;
                            }
                          }
                          if (30 === i3.mode)
                            break;
                          if (0 === i3.lens[256]) {
                            t3.msg = "invalid code -- missing end-of-block", i3.mode = 30;
                            break;
                          }
                          if (i3.lenbits = 9, P = { bits: i3.lenbits }, z = o(1, i3.lens, 0, i3.nlen, i3.lencode, 0, i3.work, P), i3.lenbits = P.bits, z) {
                            t3.msg = "invalid literal/lengths set", i3.mode = 30;
                            break;
                          }
                          if (i3.distbits = 6, i3.distcode = i3.distdyn, P = { bits: i3.distbits }, z = o(2, i3.lens, i3.nlen, i3.ndist, i3.distcode, 0, i3.work, P), i3.distbits = P.bits, z) {
                            t3.msg = "invalid distances set", i3.mode = 30;
                            break;
                          }
                          if (i3.mode = 20, 6 === e4)
                            break t;
                        case 20:
                          i3.mode = 21;
                        case 21:
                          if (6 <= p2 && 258 <= m2) {
                            t3.next_out = d2, t3.avail_out = m2, t3.next_in = f2, t3.avail_in = p2, i3.hold = g2, i3.bits = _2, a(t3, w), d2 = t3.next_out, c2 = t3.output, m2 = t3.avail_out, f2 = t3.next_in, l2 = t3.input, p2 = t3.avail_in, g2 = i3.hold, _2 = i3.bits, 12 === i3.mode && (i3.back = -1);
                            break;
                          }
                          for (i3.back = 0; E = (L = i3.lencode[g2 & (1 << i3.lenbits) - 1]) >>> 16 & 255, C = 65535 & L, !((S = L >>> 24) <= _2); ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if (E && 0 == (240 & E)) {
                            for (A = S, I = E, O = C; E = (L = i3.lencode[O + ((g2 & (1 << A + I) - 1) >> A)]) >>> 16 & 255, C = 65535 & L, !(A + (S = L >>> 24) <= _2); ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            g2 >>>= A, _2 -= A, i3.back += A;
                          }
                          if (g2 >>>= S, _2 -= S, i3.back += S, i3.length = C, 0 === E) {
                            i3.mode = 26;
                            break;
                          }
                          if (32 & E) {
                            i3.back = -1, i3.mode = 12;
                            break;
                          }
                          if (64 & E) {
                            t3.msg = "invalid literal/length code", i3.mode = 30;
                            break;
                          }
                          i3.extra = 15 & E, i3.mode = 22;
                        case 22:
                          if (i3.extra) {
                            for (N = i3.extra; _2 < N; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            i3.length += g2 & (1 << i3.extra) - 1, g2 >>>= i3.extra, _2 -= i3.extra, i3.back += i3.extra;
                          }
                          i3.was = i3.length, i3.mode = 23;
                        case 23:
                          for (; E = (L = i3.distcode[g2 & (1 << i3.distbits) - 1]) >>> 16 & 255, C = 65535 & L, !((S = L >>> 24) <= _2); ) {
                            if (0 === p2)
                              break t;
                            p2--, g2 += l2[f2++] << _2, _2 += 8;
                          }
                          if (0 == (240 & E)) {
                            for (A = S, I = E, O = C; E = (L = i3.distcode[O + ((g2 & (1 << A + I) - 1) >> A)]) >>> 16 & 255, C = 65535 & L, !(A + (S = L >>> 24) <= _2); ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            g2 >>>= A, _2 -= A, i3.back += A;
                          }
                          if (g2 >>>= S, _2 -= S, i3.back += S, 64 & E) {
                            t3.msg = "invalid distance code", i3.mode = 30;
                            break;
                          }
                          i3.offset = C, i3.extra = 15 & E, i3.mode = 24;
                        case 24:
                          if (i3.extra) {
                            for (N = i3.extra; _2 < N; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            i3.offset += g2 & (1 << i3.extra) - 1, g2 >>>= i3.extra, _2 -= i3.extra, i3.back += i3.extra;
                          }
                          if (i3.offset > i3.dmax) {
                            t3.msg = "invalid distance too far back", i3.mode = 30;
                            break;
                          }
                          i3.mode = 25;
                        case 25:
                          if (0 === m2)
                            break t;
                          if (M = w - m2, i3.offset > M) {
                            if ((M = i3.offset - M) > i3.whave && i3.sane) {
                              t3.msg = "invalid distance too far back", i3.mode = 30;
                              break;
                            }
                            x = M > i3.wnext ? (M -= i3.wnext, i3.wsize - M) : i3.wnext - M, M > i3.length && (M = i3.length), k = i3.window;
                          } else
                            k = c2, x = d2 - i3.offset, M = i3.length;
                          for (m2 < M && (M = m2), m2 -= M, i3.length -= M; c2[d2++] = k[x++], --M; )
                            ;
                          0 === i3.length && (i3.mode = 21);
                          break;
                        case 26:
                          if (0 === m2)
                            break t;
                          c2[d2++] = i3.length, m2--, i3.mode = 21;
                          break;
                        case 27:
                          if (i3.wrap) {
                            for (; _2 < 32; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 |= l2[f2++] << _2, _2 += 8;
                            }
                            if (w -= m2, t3.total_out += w, i3.total += w, w && (t3.adler = i3.check = i3.flags ? n2(i3.check, c2, w, d2 - w) : s2(i3.check, c2, w, d2 - w)), w = m2, (i3.flags ? g2 : u(g2)) !== i3.check) {
                              t3.msg = "incorrect data check", i3.mode = 30;
                              break;
                            }
                            _2 = g2 = 0;
                          }
                          i3.mode = 28;
                        case 28:
                          if (i3.wrap && i3.flags) {
                            for (; _2 < 32; ) {
                              if (0 === p2)
                                break t;
                              p2--, g2 += l2[f2++] << _2, _2 += 8;
                            }
                            if (g2 !== (4294967295 & i3.total)) {
                              t3.msg = "incorrect length check", i3.mode = 30;
                              break;
                            }
                            _2 = g2 = 0;
                          }
                          i3.mode = 29;
                        case 29:
                          z = 1;
                          break t;
                        case 30:
                          z = -3;
                          break t;
                        case 31:
                          return -4;
                        case 32:
                        default:
                          return h;
                      }
                  return t3.next_out = d2, t3.avail_out = m2, t3.next_in = f2, t3.avail_in = p2, i3.hold = g2, i3.bits = _2, (i3.wsize || w !== t3.avail_out && i3.mode < 30 && (i3.mode < 27 || 4 !== e4)) && v(t3, t3.output, t3.next_out, w - t3.avail_out) ? (i3.mode = 31, -4) : (b -= t3.avail_in, w -= t3.avail_out, t3.total_in += b, t3.total_out += w, i3.total += w, i3.wrap && w && (t3.adler = i3.check = i3.flags ? n2(i3.check, c2, w, t3.next_out - w) : s2(i3.check, c2, w, t3.next_out - w)), t3.data_type = i3.bits + (i3.last ? 64 : 0) + (12 === i3.mode ? 128 : 0) + (20 === i3.mode || 15 === i3.mode ? 256 : 0), (0 == b && 0 === w || 4 === e4) && 0 === z && (z = -5), z);
                }, i2.inflateEnd = function(t3) {
                  if (!t3 || !t3.state)
                    return h;
                  var e4 = t3.state;
                  return e4.window && (e4.window = null), t3.state = null, 0;
                }, i2.inflateGetHeader = function(t3, e4) {
                  var i3;
                  return t3 && t3.state ? 0 == (2 & (i3 = t3.state).wrap) ? h : ((i3.head = e4).done = false, 0) : h;
                }, i2.inflateSetDictionary = function(t3, e4) {
                  var i3, r3 = e4.length;
                  return t3 && t3.state ? 0 !== (i3 = t3.state).wrap && 11 !== i3.mode ? h : 11 === i3.mode && s2(1, e4, r3, 0) !== i3.check ? -3 : v(t3, e4, r3, r3) ? (i3.mode = 31, -4) : (i3.havedict = 1, 0) : h;
                }, i2.inflateInfo = "pako inflate (from Nodeca project)";
              },
              { "../utils/common": 41, "./adler32": 43, "./crc32": 45, "./inffast": 48, "./inftrees": 50 }
            ],
            50: [
              function(t2, e3, i2) {
                var r2 = t2("../utils/common"), s2 = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0], n2 = [16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78], a = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0], o = [16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64];
                e3.exports = function(t3, e4, i3, h, u, l, c, f) {
                  var d, p, m, g, _, y, v, b, w, M = f.bits, x = 0, k = 0, S = 0, E = 0, C = 0, A = 0, I = 0, O = 0, T = 0, z = 0, P = null, N = 0, L = new r2.Buf16(16), R = new r2.Buf16(16), B = null, D = 0;
                  for (x = 0; x <= 15; x++)
                    L[x] = 0;
                  for (k = 0; k < h; k++)
                    L[e4[i3 + k]]++;
                  for (C = M, E = 15; 1 <= E && 0 === L[E]; E--)
                    ;
                  if (E < C && (C = E), 0 === E)
                    return u[l++] = 20971520, u[l++] = 20971520, f.bits = 1, 0;
                  for (S = 1; S < E && 0 === L[S]; S++)
                    ;
                  for (C < S && (C = S), x = O = 1; x <= 15; x++)
                    if (O <<= 1, (O -= L[x]) < 0)
                      return -1;
                  if (0 < O && (0 === t3 || 1 !== E))
                    return -1;
                  for (R[1] = 0, x = 1; x < 15; x++)
                    R[x + 1] = R[x] + L[x];
                  for (k = 0; k < h; k++)
                    0 !== e4[i3 + k] && (c[R[e4[i3 + k]]++] = k);
                  if (y = 0 === t3 ? (P = B = c, 19) : 1 === t3 ? (P = s2, N -= 257, B = n2, D -= 257, 256) : (P = a, B = o, -1), x = S, _ = l, I = k = z = 0, m = -1, g = (T = 1 << (A = C)) - 1, 1 === t3 && 852 < T || 2 === t3 && 592 < T)
                    return 1;
                  for (; ; ) {
                    for (v = x - I, w = c[k] < y ? (b = 0, c[k]) : c[k] > y ? (b = B[D + c[k]], P[N + c[k]]) : (b = 96, 0), d = 1 << x - I, S = p = 1 << A; u[_ + (z >> I) + (p -= d)] = v << 24 | b << 16 | w | 0, 0 !== p; )
                      ;
                    for (d = 1 << x - 1; z & d; )
                      d >>= 1;
                    if (0 !== d ? (z &= d - 1, z += d) : z = 0, k++, 0 == --L[x]) {
                      if (x === E)
                        break;
                      x = e4[i3 + c[k]];
                    }
                    if (C < x && (z & g) !== m) {
                      for (0 === I && (I = C), _ += S, O = 1 << (A = x - I); A + I < E && !((O -= L[A + I]) <= 0); )
                        A++, O <<= 1;
                      if (T += 1 << A, 1 === t3 && 852 < T || 2 === t3 && 592 < T)
                        return 1;
                      u[m = z & g] = C << 24 | A << 16 | _ - l | 0;
                    }
                  }
                  return 0 !== z && (u[_ + z] = x - I << 24 | 64 << 16 | 0), f.bits = C, 0;
                };
              },
              { "../utils/common": 41 }
            ],
            51: [
              function(t2, e3, i2) {
                e3.exports = { 2: "need dictionary", 1: "stream end", 0: "", "-1": "file error", "-2": "stream error", "-3": "data error", "-4": "insufficient memory", "-5": "buffer error", "-6": "incompatible version" };
              },
              {}
            ],
            52: [
              function(t2, e3, i2) {
                var r2 = t2("../utils/common");
                function s2(t3) {
                  for (var e4 = t3.length; 0 <= --e4; )
                    t3[e4] = 0;
                }
                var n2 = 256, a = 286, o = 30, h = 15, u = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], l = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], c = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7], f = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], d = new Array(576);
                s2(d);
                var p = new Array(60);
                s2(p);
                var m = new Array(512);
                s2(m);
                var g = new Array(256);
                s2(g);
                var _ = new Array(29);
                s2(_);
                var y, v, b, w = new Array(o);
                function M(t3, e4, i3, r3, s3) {
                  this.static_tree = t3, this.extra_bits = e4, this.extra_base = i3, this.elems = r3, this.max_length = s3, this.has_stree = t3 && t3.length;
                }
                function x(t3, e4) {
                  this.dyn_tree = t3, this.max_code = 0, this.stat_desc = e4;
                }
                function k(t3) {
                  return t3 < 256 ? m[t3] : m[256 + (t3 >>> 7)];
                }
                function S(t3, e4) {
                  t3.pending_buf[t3.pending++] = 255 & e4, t3.pending_buf[t3.pending++] = e4 >>> 8 & 255;
                }
                function E(t3, e4, i3) {
                  t3.bi_valid > 16 - i3 ? (t3.bi_buf |= e4 << t3.bi_valid & 65535, S(t3, t3.bi_buf), t3.bi_buf = e4 >> 16 - t3.bi_valid, t3.bi_valid += i3 - 16) : (t3.bi_buf |= e4 << t3.bi_valid & 65535, t3.bi_valid += i3);
                }
                function C(t3, e4, i3) {
                  E(t3, i3[2 * e4], i3[2 * e4 + 1]);
                }
                function A(t3, e4) {
                  for (var i3 = 0; i3 |= 1 & t3, t3 >>>= 1, i3 <<= 1, 0 < --e4; )
                    ;
                  return i3 >>> 1;
                }
                function I(t3, e4, i3) {
                  var r3, s3, n3 = new Array(16), a2 = 0;
                  for (r3 = 1; r3 <= h; r3++)
                    n3[r3] = a2 = a2 + i3[r3 - 1] << 1;
                  for (s3 = 0; s3 <= e4; s3++) {
                    var o2 = t3[2 * s3 + 1];
                    0 !== o2 && (t3[2 * s3] = A(n3[o2]++, o2));
                  }
                }
                function O(t3) {
                  var e4;
                  for (e4 = 0; e4 < a; e4++)
                    t3.dyn_ltree[2 * e4] = 0;
                  for (e4 = 0; e4 < o; e4++)
                    t3.dyn_dtree[2 * e4] = 0;
                  for (e4 = 0; e4 < 19; e4++)
                    t3.bl_tree[2 * e4] = 0;
                  t3.dyn_ltree[512] = 1, t3.opt_len = t3.static_len = 0, t3.last_lit = t3.matches = 0;
                }
                function T(t3) {
                  8 < t3.bi_valid ? S(t3, t3.bi_buf) : 0 < t3.bi_valid && (t3.pending_buf[t3.pending++] = t3.bi_buf), t3.bi_buf = 0, t3.bi_valid = 0;
                }
                function z(t3, e4, i3, r3) {
                  var s3 = 2 * e4, n3 = 2 * i3;
                  return t3[s3] < t3[n3] || t3[s3] === t3[n3] && r3[e4] <= r3[i3];
                }
                function P(t3, e4, i3) {
                  for (var r3 = t3.heap[i3], s3 = i3 << 1; s3 <= t3.heap_len && (s3 < t3.heap_len && z(e4, t3.heap[s3 + 1], t3.heap[s3], t3.depth) && s3++, !z(e4, r3, t3.heap[s3], t3.depth)); )
                    t3.heap[i3] = t3.heap[s3], i3 = s3, s3 <<= 1;
                  t3.heap[i3] = r3;
                }
                function N(t3, e4, i3) {
                  var r3, s3, a2, o2, h2 = 0;
                  if (0 !== t3.last_lit)
                    for (; r3 = t3.pending_buf[t3.d_buf + 2 * h2] << 8 | t3.pending_buf[t3.d_buf + 2 * h2 + 1], s3 = t3.pending_buf[t3.l_buf + h2], h2++, 0 === r3 ? C(t3, s3, e4) : (C(t3, (a2 = g[s3]) + n2 + 1, e4), 0 !== (o2 = u[a2]) && E(t3, s3 -= _[a2], o2), C(t3, a2 = k(--r3), i3), 0 !== (o2 = l[a2]) && E(t3, r3 -= w[a2], o2)), h2 < t3.last_lit; )
                      ;
                  C(t3, 256, e4);
                }
                function L(t3, e4) {
                  var i3, r3, s3, n3 = e4.dyn_tree, a2 = e4.stat_desc.static_tree, o2 = e4.stat_desc.has_stree, u2 = e4.stat_desc.elems, l2 = -1;
                  for (t3.heap_len = 0, t3.heap_max = 573, i3 = 0; i3 < u2; i3++)
                    0 !== n3[2 * i3] ? (t3.heap[++t3.heap_len] = l2 = i3, t3.depth[i3] = 0) : n3[2 * i3 + 1] = 0;
                  for (; t3.heap_len < 2; )
                    n3[2 * (s3 = t3.heap[++t3.heap_len] = l2 < 2 ? ++l2 : 0)] = 1, t3.depth[s3] = 0, t3.opt_len--, o2 && (t3.static_len -= a2[2 * s3 + 1]);
                  for (e4.max_code = l2, i3 = t3.heap_len >> 1; 1 <= i3; i3--)
                    P(t3, n3, i3);
                  for (s3 = u2; i3 = t3.heap[1], t3.heap[1] = t3.heap[t3.heap_len--], P(t3, n3, 1), r3 = t3.heap[1], t3.heap[--t3.heap_max] = i3, t3.heap[--t3.heap_max] = r3, n3[2 * s3] = n3[2 * i3] + n3[2 * r3], t3.depth[s3] = (t3.depth[i3] >= t3.depth[r3] ? t3.depth[i3] : t3.depth[r3]) + 1, n3[2 * i3 + 1] = n3[2 * r3 + 1] = s3, t3.heap[1] = s3++, P(t3, n3, 1), 2 <= t3.heap_len; )
                    ;
                  t3.heap[--t3.heap_max] = t3.heap[1], function(t4, e5) {
                    var i4, r4, s4, n4, a3, o3, u3 = e5.dyn_tree, l3 = e5.max_code, c2 = e5.stat_desc.static_tree, f2 = e5.stat_desc.has_stree, d2 = e5.stat_desc.extra_bits, p2 = e5.stat_desc.extra_base, m2 = e5.stat_desc.max_length, g2 = 0;
                    for (n4 = 0; n4 <= h; n4++)
                      t4.bl_count[n4] = 0;
                    for (u3[2 * t4.heap[t4.heap_max] + 1] = 0, i4 = t4.heap_max + 1; i4 < 573; i4++)
                      m2 < (n4 = u3[2 * u3[2 * (r4 = t4.heap[i4]) + 1] + 1] + 1) && (n4 = m2, g2++), u3[2 * r4 + 1] = n4, l3 < r4 || (t4.bl_count[n4]++, a3 = 0, p2 <= r4 && (a3 = d2[r4 - p2]), o3 = u3[2 * r4], t4.opt_len += o3 * (n4 + a3), f2 && (t4.static_len += o3 * (c2[2 * r4 + 1] + a3)));
                    if (0 !== g2) {
                      do {
                        for (n4 = m2 - 1; 0 === t4.bl_count[n4]; )
                          n4--;
                        t4.bl_count[n4]--, t4.bl_count[n4 + 1] += 2, t4.bl_count[m2]--, g2 -= 2;
                      } while (0 < g2);
                      for (n4 = m2; 0 !== n4; n4--)
                        for (r4 = t4.bl_count[n4]; 0 !== r4; )
                          l3 < (s4 = t4.heap[--i4]) || (u3[2 * s4 + 1] !== n4 && (t4.opt_len += (n4 - u3[2 * s4 + 1]) * u3[2 * s4], u3[2 * s4 + 1] = n4), r4--);
                    }
                  }(t3, e4), I(n3, l2, t3.bl_count);
                }
                function R(t3, e4, i3) {
                  var r3, s3, n3 = -1, a2 = e4[1], o2 = 0, h2 = 7, u2 = 4;
                  for (0 === a2 && (h2 = 138, u2 = 3), e4[2 * (i3 + 1) + 1] = 65535, r3 = 0; r3 <= i3; r3++)
                    s3 = a2, a2 = e4[2 * (r3 + 1) + 1], ++o2 < h2 && s3 === a2 || (o2 < u2 ? t3.bl_tree[2 * s3] += o2 : 0 !== s3 ? (s3 !== n3 && t3.bl_tree[2 * s3]++, t3.bl_tree[32]++) : o2 <= 10 ? t3.bl_tree[34]++ : t3.bl_tree[36]++, n3 = s3, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : s3 === a2 ? (h2 = 6, 3) : (h2 = 7, 4));
                }
                function B(t3, e4, i3) {
                  var r3, s3, n3 = -1, a2 = e4[1], o2 = 0, h2 = 7, u2 = 4;
                  for (0 === a2 && (h2 = 138, u2 = 3), r3 = 0; r3 <= i3; r3++)
                    if (s3 = a2, a2 = e4[2 * (r3 + 1) + 1], !(++o2 < h2 && s3 === a2)) {
                      if (o2 < u2)
                        for (; C(t3, s3, t3.bl_tree), 0 != --o2; )
                          ;
                      else
                        0 !== s3 ? (s3 !== n3 && (C(t3, s3, t3.bl_tree), o2--), C(t3, 16, t3.bl_tree), E(t3, o2 - 3, 2)) : o2 <= 10 ? (C(t3, 17, t3.bl_tree), E(t3, o2 - 3, 3)) : (C(t3, 18, t3.bl_tree), E(t3, o2 - 11, 7));
                      n3 = s3, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : s3 === a2 ? (h2 = 6, 3) : (h2 = 7, 4);
                    }
                }
                s2(w);
                var D = false;
                function j(t3, e4, i3, s3) {
                  E(t3, 0 + (s3 ? 1 : 0), 3), function(t4, e5, i4, s4) {
                    T(t4), S(t4, i4), S(t4, ~i4), r2.arraySet(t4.pending_buf, t4.window, e5, i4, t4.pending), t4.pending += i4;
                  }(t3, e4, i3);
                }
                i2._tr_init = function(t3) {
                  D || (function() {
                    var t4, e4, i3, r3, s3, n3 = new Array(16);
                    for (r3 = i3 = 0; r3 < 28; r3++)
                      for (_[r3] = i3, t4 = 0; t4 < 1 << u[r3]; t4++)
                        g[i3++] = r3;
                    for (g[i3 - 1] = r3, r3 = s3 = 0; r3 < 16; r3++)
                      for (w[r3] = s3, t4 = 0; t4 < 1 << l[r3]; t4++)
                        m[s3++] = r3;
                    for (s3 >>= 7; r3 < o; r3++)
                      for (w[r3] = s3 << 7, t4 = 0; t4 < 1 << l[r3] - 7; t4++)
                        m[256 + s3++] = r3;
                    for (e4 = 0; e4 <= h; e4++)
                      n3[e4] = 0;
                    for (t4 = 0; t4 <= 143; )
                      d[2 * t4 + 1] = 8, t4++, n3[8]++;
                    for (; t4 <= 255; )
                      d[2 * t4 + 1] = 9, t4++, n3[9]++;
                    for (; t4 <= 279; )
                      d[2 * t4 + 1] = 7, t4++, n3[7]++;
                    for (; t4 <= 287; )
                      d[2 * t4 + 1] = 8, t4++, n3[8]++;
                    for (I(d, 287, n3), t4 = 0; t4 < o; t4++)
                      p[2 * t4 + 1] = 5, p[2 * t4] = A(t4, 5);
                    y = new M(d, u, 257, a, h), v = new M(p, l, 0, o, h), b = new M(new Array(0), c, 0, 19, 7);
                  }(), D = true), t3.l_desc = new x(t3.dyn_ltree, y), t3.d_desc = new x(t3.dyn_dtree, v), t3.bl_desc = new x(t3.bl_tree, b), t3.bi_buf = 0, t3.bi_valid = 0, O(t3);
                }, i2._tr_stored_block = j, i2._tr_flush_block = function(t3, e4, i3, r3) {
                  var s3, a2, o2 = 0;
                  0 < t3.level ? (2 === t3.strm.data_type && (t3.strm.data_type = function(t4) {
                    var e5, i4 = 4093624447;
                    for (e5 = 0; e5 <= 31; e5++, i4 >>>= 1)
                      if (1 & i4 && 0 !== t4.dyn_ltree[2 * e5])
                        return 0;
                    if (0 !== t4.dyn_ltree[18] || 0 !== t4.dyn_ltree[20] || 0 !== t4.dyn_ltree[26])
                      return 1;
                    for (e5 = 32; e5 < n2; e5++)
                      if (0 !== t4.dyn_ltree[2 * e5])
                        return 1;
                    return 0;
                  }(t3)), L(t3, t3.l_desc), L(t3, t3.d_desc), o2 = function(t4) {
                    var e5;
                    for (R(t4, t4.dyn_ltree, t4.l_desc.max_code), R(t4, t4.dyn_dtree, t4.d_desc.max_code), L(t4, t4.bl_desc), e5 = 18; 3 <= e5 && 0 === t4.bl_tree[2 * f[e5] + 1]; e5--)
                      ;
                    return t4.opt_len += 3 * (e5 + 1) + 5 + 5 + 4, e5;
                  }(t3), s3 = t3.opt_len + 3 + 7 >>> 3, (a2 = t3.static_len + 3 + 7 >>> 3) <= s3 && (s3 = a2)) : s3 = a2 = i3 + 5, i3 + 4 <= s3 && -1 !== e4 ? j(t3, e4, i3, r3) : 4 === t3.strategy || a2 === s3 ? (E(t3, 2 + (r3 ? 1 : 0), 3), N(t3, d, p)) : (E(t3, 4 + (r3 ? 1 : 0), 3), function(t4, e5, i4, r4) {
                    var s4;
                    for (E(t4, e5 - 257, 5), E(t4, i4 - 1, 5), E(t4, r4 - 4, 4), s4 = 0; s4 < r4; s4++)
                      E(t4, t4.bl_tree[2 * f[s4] + 1], 3);
                    B(t4, t4.dyn_ltree, e5 - 1), B(t4, t4.dyn_dtree, i4 - 1);
                  }(t3, t3.l_desc.max_code + 1, t3.d_desc.max_code + 1, o2 + 1), N(t3, t3.dyn_ltree, t3.dyn_dtree)), O(t3), r3 && T(t3);
                }, i2._tr_tally = function(t3, e4, i3) {
                  return t3.pending_buf[t3.d_buf + 2 * t3.last_lit] = e4 >>> 8 & 255, t3.pending_buf[t3.d_buf + 2 * t3.last_lit + 1] = 255 & e4, t3.pending_buf[t3.l_buf + t3.last_lit] = 255 & i3, t3.last_lit++, 0 === e4 ? t3.dyn_ltree[2 * i3]++ : (t3.matches++, e4--, t3.dyn_ltree[2 * (g[i3] + n2 + 1)]++, t3.dyn_dtree[2 * k(e4)]++), t3.last_lit === t3.lit_bufsize - 1;
                }, i2._tr_align = function(t3) {
                  E(t3, 2, 3), C(t3, 256, d), function(t4) {
                    16 === t4.bi_valid ? (S(t4, t4.bi_buf), t4.bi_buf = 0, t4.bi_valid = 0) : 8 <= t4.bi_valid && (t4.pending_buf[t4.pending++] = 255 & t4.bi_buf, t4.bi_buf >>= 8, t4.bi_valid -= 8);
                  }(t3);
                };
              },
              { "../utils/common": 41 }
            ],
            53: [
              function(t2, e3, i2) {
                e3.exports = function() {
                  this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
                };
              },
              {}
            ],
            54: [
              function(t2, e3, i2) {
                (function(t3) {
                  !function(t4, e4) {
                    if (!t4.setImmediate) {
                      var i3, r2, s2, a, o = 1, h = {}, u = false, l = t4.document, c = Object.getPrototypeOf && Object.getPrototypeOf(t4);
                      c = c && c.setTimeout ? c : t4, i3 = "[object process]" === {}.toString.call(t4.process) ? function(t5) {
                        n.nextTick(function() {
                          d(t5);
                        });
                      } : function() {
                        if (t4.postMessage && !t4.importScripts) {
                          var e5 = true, i4 = t4.onmessage;
                          return t4.onmessage = function() {
                            e5 = false;
                          }, t4.postMessage("", "*"), t4.onmessage = i4, e5;
                        }
                      }() ? (a = "setImmediate$" + Math.random() + "$", t4.addEventListener ? t4.addEventListener("message", p, false) : t4.attachEvent("onmessage", p), function(e5) {
                        t4.postMessage(a + e5, "*");
                      }) : t4.MessageChannel ? ((s2 = new MessageChannel()).port1.onmessage = function(t5) {
                        d(t5.data);
                      }, function(t5) {
                        s2.port2.postMessage(t5);
                      }) : l && "onreadystatechange" in l.createElement("script") ? (r2 = l.documentElement, function(t5) {
                        var e5 = l.createElement("script");
                        e5.onreadystatechange = function() {
                          d(t5), e5.onreadystatechange = null, r2.removeChild(e5), e5 = null;
                        }, r2.appendChild(e5);
                      }) : function(t5) {
                        setTimeout(d, 0, t5);
                      }, c.setImmediate = function(t5) {
                        "function" != typeof t5 && (t5 = new Function("" + t5));
                        for (var e5 = new Array(arguments.length - 1), r3 = 0; r3 < e5.length; r3++)
                          e5[r3] = arguments[r3 + 1];
                        var s3 = { callback: t5, args: e5 };
                        return h[o] = s3, i3(o), o++;
                      }, c.clearImmediate = f;
                    }
                    function f(t5) {
                      delete h[t5];
                    }
                    function d(t5) {
                      if (u)
                        setTimeout(d, 0, t5);
                      else {
                        var e5 = h[t5];
                        if (e5) {
                          u = true;
                          try {
                            !function(t6) {
                              var e6 = t6.callback, i4 = t6.args;
                              switch (i4.length) {
                                case 0:
                                  e6();
                                  break;
                                case 1:
                                  e6(i4[0]);
                                  break;
                                case 2:
                                  e6(i4[0], i4[1]);
                                  break;
                                case 3:
                                  e6(i4[0], i4[1], i4[2]);
                                  break;
                                default:
                                  e6.apply(void 0, i4);
                              }
                            }(e5);
                          } finally {
                            f(t5), u = false;
                          }
                        }
                      }
                    }
                    function p(e5) {
                      e5.source === t4 && "string" == typeof e5.data && 0 === e5.data.indexOf(a) && d(+e5.data.slice(a.length));
                    }
                  }("undefined" == typeof self ? void 0 === t3 ? this : t3 : self);
                }).call(this, void 0 !== s ? s : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
              },
              {}
            ]
          },
          {},
          [10]
        )(10);
      }).call(this, i(2).Buffer, i(12).setImmediate, i(0), i(3));
    },
    function(t, e, i) {
      e.byteLength = function(t2) {
        var e2 = u(t2), i2 = e2[0], r2 = e2[1];
        return 3 * (i2 + r2) / 4 - r2;
      }, e.toByteArray = function(t2) {
        var e2, i2, r2 = u(t2), a2 = r2[0], o2 = r2[1], h2 = new n(
          function(t3, e3, i3) {
            return 3 * (e3 + i3) / 4 - i3;
          }(0, a2, o2)
        ), l2 = 0, c = o2 > 0 ? a2 - 4 : a2;
        for (i2 = 0; i2 < c; i2 += 4)
          e2 = s[t2.charCodeAt(i2)] << 18 | s[t2.charCodeAt(i2 + 1)] << 12 | s[t2.charCodeAt(i2 + 2)] << 6 | s[t2.charCodeAt(i2 + 3)], h2[l2++] = e2 >> 16 & 255, h2[l2++] = e2 >> 8 & 255, h2[l2++] = 255 & e2;
        2 === o2 && (e2 = s[t2.charCodeAt(i2)] << 2 | s[t2.charCodeAt(i2 + 1)] >> 4, h2[l2++] = 255 & e2);
        1 === o2 && (e2 = s[t2.charCodeAt(i2)] << 10 | s[t2.charCodeAt(i2 + 1)] << 4 | s[t2.charCodeAt(i2 + 2)] >> 2, h2[l2++] = e2 >> 8 & 255, h2[l2++] = 255 & e2);
        return h2;
      }, e.fromByteArray = function(t2) {
        for (var e2, i2 = t2.length, s2 = i2 % 3, n2 = [], a2 = 0, o2 = i2 - s2; a2 < o2; a2 += 16383)
          n2.push(l(t2, a2, a2 + 16383 > o2 ? o2 : a2 + 16383));
        1 === s2 ? (e2 = t2[i2 - 1], n2.push(r[e2 >> 2] + r[e2 << 4 & 63] + "==")) : 2 === s2 && (e2 = (t2[i2 - 2] << 8) + t2[i2 - 1], n2.push(r[e2 >> 10] + r[e2 >> 4 & 63] + r[e2 << 2 & 63] + "="));
        return n2.join("");
      };
      for (var r = [], s = [], n = "undefined" != typeof Uint8Array ? Uint8Array : Array, a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", o = 0, h = a.length; o < h; ++o)
        r[o] = a[o], s[a.charCodeAt(o)] = o;
      function u(t2) {
        var e2 = t2.length;
        if (e2 % 4 > 0)
          throw new Error("Invalid string. Length must be a multiple of 4");
        var i2 = t2.indexOf("=");
        return -1 === i2 && (i2 = e2), [i2, i2 === e2 ? 0 : 4 - i2 % 4];
      }
      function l(t2, e2, i2) {
        for (var s2, n2, a2 = [], o2 = e2; o2 < i2; o2 += 3)
          s2 = (t2[o2] << 16 & 16711680) + (t2[o2 + 1] << 8 & 65280) + (255 & t2[o2 + 2]), a2.push(r[(n2 = s2) >> 18 & 63] + r[n2 >> 12 & 63] + r[n2 >> 6 & 63] + r[63 & n2]);
        return a2.join("");
      }
      s["-".charCodeAt(0)] = 62, s["_".charCodeAt(0)] = 63;
    },
    function(t, e) {
      /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
      e.read = function(t2, e2, i, r, s) {
        var n, a, o = 8 * s - r - 1, h = (1 << o) - 1, u = h >> 1, l = -7, c = i ? s - 1 : 0, f = i ? -1 : 1, d = t2[e2 + c];
        for (c += f, n = d & (1 << -l) - 1, d >>= -l, l += o; l > 0; n = 256 * n + t2[e2 + c], c += f, l -= 8)
          ;
        for (a = n & (1 << -l) - 1, n >>= -l, l += r; l > 0; a = 256 * a + t2[e2 + c], c += f, l -= 8)
          ;
        if (0 === n)
          n = 1 - u;
        else {
          if (n === h)
            return a ? NaN : 1 / 0 * (d ? -1 : 1);
          a += Math.pow(2, r), n -= u;
        }
        return (d ? -1 : 1) * a * Math.pow(2, n - r);
      }, e.write = function(t2, e2, i, r, s, n) {
        var a, o, h, u = 8 * n - s - 1, l = (1 << u) - 1, c = l >> 1, f = 23 === s ? Math.pow(2, -24) - Math.pow(2, -77) : 0, d = r ? 0 : n - 1, p = r ? 1 : -1, m = e2 < 0 || 0 === e2 && 1 / e2 < 0 ? 1 : 0;
        for (e2 = Math.abs(e2), isNaN(e2) || e2 === 1 / 0 ? (o = isNaN(e2) ? 1 : 0, a = l) : (a = Math.floor(Math.log(e2) / Math.LN2), e2 * (h = Math.pow(2, -a)) < 1 && (a--, h *= 2), (e2 += a + c >= 1 ? f / h : f * Math.pow(2, 1 - c)) * h >= 2 && (a++, h /= 2), a + c >= l ? (o = 0, a = l) : a + c >= 1 ? (o = (e2 * h - 1) * Math.pow(2, s), a += c) : (o = e2 * Math.pow(2, c - 1) * Math.pow(2, s), a = 0)); s >= 8; t2[i + d] = 255 & o, d += p, o /= 256, s -= 8)
          ;
        for (a = a << s | o, u += s; u > 0; t2[i + d] = 255 & a, d += p, a /= 256, u -= 8)
          ;
        t2[i + d - p] |= 128 * m;
      };
    },
    function(t, e) {
      var i = {}.toString;
      t.exports = Array.isArray || function(t2) {
        return "[object Array]" == i.call(t2);
      };
    },
    function(t, e, i) {
      (function(t2) {
        var r = void 0 !== t2 && t2 || "undefined" != typeof self && self || window, s = Function.prototype.apply;
        function n(t3, e2) {
          this._id = t3, this._clearFn = e2;
        }
        e.setTimeout = function() {
          return new n(s.call(setTimeout, r, arguments), clearTimeout);
        }, e.setInterval = function() {
          return new n(s.call(setInterval, r, arguments), clearInterval);
        }, e.clearTimeout = e.clearInterval = function(t3) {
          t3 && t3.close();
        }, n.prototype.unref = n.prototype.ref = function() {
        }, n.prototype.close = function() {
          this._clearFn.call(r, this._id);
        }, e.enroll = function(t3, e2) {
          clearTimeout(t3._idleTimeoutId), t3._idleTimeout = e2;
        }, e.unenroll = function(t3) {
          clearTimeout(t3._idleTimeoutId), t3._idleTimeout = -1;
        }, e._unrefActive = e.active = function(t3) {
          clearTimeout(t3._idleTimeoutId);
          var e2 = t3._idleTimeout;
          e2 >= 0 && (t3._idleTimeoutId = setTimeout(function() {
            t3._onTimeout && t3._onTimeout();
          }, e2));
        }, i(13), e.setImmediate = "undefined" != typeof self && self.setImmediate || void 0 !== t2 && t2.setImmediate || this && this.setImmediate, e.clearImmediate = "undefined" != typeof self && self.clearImmediate || void 0 !== t2 && t2.clearImmediate || this && this.clearImmediate;
      }).call(this, i(0));
    },
    function(t, e, i) {
      (function(t2, e2) {
        !function(t3, i2) {
          if (!t3.setImmediate) {
            var r, s, n, a, o, h = 1, u = {}, l = false, c = t3.document, f = Object.getPrototypeOf && Object.getPrototypeOf(t3);
            f = f && f.setTimeout ? f : t3, "[object process]" === {}.toString.call(t3.process) ? r = function(t4) {
              e2.nextTick(function() {
                p(t4);
              });
            } : !function() {
              if (t3.postMessage && !t3.importScripts) {
                var e3 = true, i3 = t3.onmessage;
                return t3.onmessage = function() {
                  e3 = false;
                }, t3.postMessage("", "*"), t3.onmessage = i3, e3;
              }
            }() ? t3.MessageChannel ? ((n = new MessageChannel()).port1.onmessage = function(t4) {
              p(t4.data);
            }, r = function(t4) {
              n.port2.postMessage(t4);
            }) : c && "onreadystatechange" in c.createElement("script") ? (s = c.documentElement, r = function(t4) {
              var e3 = c.createElement("script");
              e3.onreadystatechange = function() {
                p(t4), e3.onreadystatechange = null, s.removeChild(e3), e3 = null;
              }, s.appendChild(e3);
            }) : r = function(t4) {
              setTimeout(p, 0, t4);
            } : (a = "setImmediate$" + Math.random() + "$", o = function(e3) {
              e3.source === t3 && "string" == typeof e3.data && 0 === e3.data.indexOf(a) && p(+e3.data.slice(a.length));
            }, t3.addEventListener ? t3.addEventListener("message", o, false) : t3.attachEvent("onmessage", o), r = function(e3) {
              t3.postMessage(a + e3, "*");
            }), f.setImmediate = function(t4) {
              "function" != typeof t4 && (t4 = new Function("" + t4));
              for (var e3 = new Array(arguments.length - 1), i3 = 0; i3 < e3.length; i3++)
                e3[i3] = arguments[i3 + 1];
              var s2 = { callback: t4, args: e3 };
              return u[h] = s2, r(h), h++;
            }, f.clearImmediate = d;
          }
          function d(t4) {
            delete u[t4];
          }
          function p(t4) {
            if (l)
              setTimeout(p, 0, t4);
            else {
              var e3 = u[t4];
              if (e3) {
                l = true;
                try {
                  !function(t5) {
                    var e4 = t5.callback, i3 = t5.args;
                    switch (i3.length) {
                      case 0:
                        e4();
                        break;
                      case 1:
                        e4(i3[0]);
                        break;
                      case 2:
                        e4(i3[0], i3[1]);
                        break;
                      case 3:
                        e4(i3[0], i3[1], i3[2]);
                        break;
                      default:
                        e4.apply(void 0, i3);
                    }
                  }(e3);
                } finally {
                  d(t4), l = false;
                }
              }
            }
          }
        }("undefined" == typeof self ? void 0 === t2 ? this : t2 : self);
      }).call(this, i(0), i(3));
    },
    function(t, e) {
      function i(t2) {
        var e2 = new Error("Cannot find module '" + t2 + "'");
        throw e2.code = "MODULE_NOT_FOUND", e2;
      }
      i.keys = function() {
        return [];
      }, i.resolve = i, t.exports = i, i.id = 14;
    },
    function(t, e, i) {
      (function(e2) {
        const r = i(16), s = i(5), n = i(2).Buffer;
        t.exports = async function(t2, i2) {
          if (!e2.fetch)
            return r(t2, i2);
          const a = s(t2, i2), o = "prj" === i2 || "cpg" === i2;
          try {
            const t3 = await fetch(a);
            if (t3.status > 399)
              throw new Error(t3.statusText);
            if (o)
              return t3.text();
            const e3 = await t3.arrayBuffer();
            return n.from(e3);
          } catch (t3) {
            if (console.log("ERROR", t3, i2), o || "dbf" === i2)
              return false;
            throw t3;
          }
        };
      }).call(this, i(0));
    },
    function(t, e, i) {
      const r = i(4), s = i(5), n = i(2).Buffer;
      t.exports = function(t2, e2) {
        return new r(function(i2, r2) {
          const a = s(t2, e2), o = new XMLHttpRequest();
          o.open("GET", a, true), "prj" !== e2 && "cpg" !== e2 && (o.responseType = "arraybuffer"), o.addEventListener(
            "load",
            function() {
              return o.status > 399 ? "prj" === e2 || "cpg" === e2 ? i2(false) : r2(new Error(o.status)) : i2("prj" !== e2 && "cpg" !== e2 ? n.from(o.response) : o.response);
            },
            false
          ), o.send();
        });
      };
    },
    function(t, e, i) {
      (function(e2) {
        var i2, r, s = e2.MutationObserver || e2.WebKitMutationObserver;
        if (s) {
          var n = 0, a = new s(l), o = e2.document.createTextNode("");
          a.observe(o, { characterData: true }), i2 = function() {
            o.data = n = ++n % 2;
          };
        } else if (e2.setImmediate || void 0 === e2.MessageChannel)
          i2 = "document" in e2 && "onreadystatechange" in e2.document.createElement("script") ? function() {
            var t2 = e2.document.createElement("script");
            t2.onreadystatechange = function() {
              l(), t2.onreadystatechange = null, t2.parentNode.removeChild(t2), t2 = null;
            }, e2.document.documentElement.appendChild(t2);
          } : function() {
            setTimeout(l, 0);
          };
        else {
          var h = new e2.MessageChannel();
          h.port1.onmessage = l, i2 = function() {
            h.port2.postMessage(0);
          };
        }
        var u = [];
        function l() {
          var t2, e3;
          r = true;
          for (var i3 = u.length; i3; ) {
            for (e3 = u, u = [], t2 = -1; ++t2 < i3; )
              e3[t2]();
            i3 = u.length;
          }
          r = false;
        }
        t.exports = function(t2) {
          1 !== u.push(t2) || r || i2();
        };
      }).call(this, i(0));
    },
    function(t, e, i) {
      function r(t2, e2) {
        return !function(t3) {
          let e3 = 0, i2 = 1;
          const r2 = t3.length;
          let s2, n2;
          for (; i2 < r2; )
            s2 = n2 || t3[0], n2 = t3[i2], e3 += (n2[0] - s2[0]) * (n2[1] + s2[1]), i2++;
          return e3 > 0;
        }(e2) && t2.length ? t2[t2.length - 1].push(e2) : t2.push([e2]), t2;
      }
      n.prototype.parsePoint = function(t2) {
        return { type: "Point", coordinates: this.parseCoord(t2, 0) };
      }, n.prototype.parseZPoint = function(t2) {
        const e2 = this.parsePoint(t2);
        return e2.coordinates.push(t2.readDoubleLE(16)), e2;
      }, n.prototype.parsePointArray = function(t2, e2, i2) {
        const r2 = [];
        let s2 = 0;
        for (; s2 < i2; )
          r2.push(this.parseCoord(t2, e2)), e2 += 16, s2++;
        return r2;
      }, n.prototype.parseZPointArray = function(t2, e2, i2, r2) {
        let s2 = 0;
        for (; s2 < i2; )
          r2[s2].push(t2.readDoubleLE(e2)), s2++, e2 += 8;
        return r2;
      }, n.prototype.parseArrayGroup = function(t2, e2, i2, r2, s2) {
        const n2 = [];
        let a, o, h = 0, u = 0;
        for (; h < r2; )
          h++, i2 += 4, a = u, u = h === r2 ? s2 : t2.readInt32LE(i2), o = u - a, o && (n2.push(this.parsePointArray(t2, e2, o)), e2 += o << 4);
        return n2;
      }, n.prototype.parseZArrayGroup = function(t2, e2, i2, r2) {
        let s2 = 0;
        for (; s2 < i2; )
          r2[s2] = this.parseZPointArray(t2, e2, r2[s2].length, r2[s2]), e2 += r2[s2].length << 3, s2++;
        return r2;
      }, n.prototype.parseMultiPoint = function(t2) {
        const e2 = {}, i2 = t2.readInt32LE(32, true);
        if (!i2)
          return null;
        const r2 = this.parseCoord(t2, 0), s2 = this.parseCoord(t2, 16);
        e2.bbox = [r2[0], r2[1], s2[0], s2[1]];
        return 1 === i2 ? (e2.type = "Point", e2.coordinates = this.parseCoord(t2, 36)) : (e2.type = "MultiPoint", e2.coordinates = this.parsePointArray(t2, 36, i2)), e2;
      }, n.prototype.parseZMultiPoint = function(t2) {
        const e2 = this.parseMultiPoint(t2);
        if (!e2)
          return null;
        let i2;
        if ("Point" === e2.type)
          return e2.coordinates.push(t2.readDoubleLE(72)), e2;
        i2 = e2.coordinates.length;
        const r2 = 52 + (i2 << 4);
        return e2.coordinates = this.parseZPointArray(t2, r2, i2, e2.coordinates), e2;
      }, n.prototype.parsePolyline = function(t2) {
        const e2 = {}, i2 = t2.readInt32LE(32);
        if (!i2)
          return null;
        const r2 = this.parseCoord(t2, 0), s2 = this.parseCoord(t2, 16);
        e2.bbox = [r2[0], r2[1], s2[0], s2[1]];
        const n2 = t2.readInt32LE(36);
        let a;
        return 1 === i2 ? (e2.type = "LineString", a = 44, e2.coordinates = this.parsePointArray(t2, a, n2)) : (e2.type = "MultiLineString", a = 40 + (i2 << 2), e2.coordinates = this.parseArrayGroup(t2, a, 40, i2, n2)), e2;
      }, n.prototype.parseZPolyline = function(t2) {
        const e2 = this.parsePolyline(t2);
        if (!e2)
          return null;
        const i2 = e2.coordinates.length;
        let r2;
        if ("LineString" === e2.type)
          return r2 = 60 + (i2 << 4), e2.coordinates = this.parseZPointArray(t2, r2, i2, e2.coordinates), e2;
        return r2 = 56 + (e2.coordinates.reduce(function(t3, e3) {
          return t3 + e3.length;
        }, 0) << 4) + (i2 << 2), e2.coordinates = this.parseZArrayGroup(t2, r2, i2, e2.coordinates), e2;
      }, n.prototype.polyFuncs = function(t2) {
        return t2 ? "LineString" === t2.type ? (t2.type = "Polygon", t2.coordinates = [t2.coordinates], t2) : (t2.coordinates = t2.coordinates.reduce(r, []), 1 === t2.coordinates.length ? (t2.type = "Polygon", t2.coordinates = t2.coordinates[0], t2) : (t2.type = "MultiPolygon", t2)) : t2;
      }, n.prototype.parsePolygon = function(t2) {
        return this.polyFuncs(this.parsePolyline(t2));
      }, n.prototype.parseZPolygon = function(t2) {
        return this.polyFuncs(this.parseZPolyline(t2));
      };
      const s = { 1: "parsePoint", 3: "parsePolyline", 5: "parsePolygon", 8: "parseMultiPoint", 11: "parseZPoint", 13: "parseZPolyline", 15: "parseZPolygon", 18: "parseZMultiPoint" };
      function n(t2, e2) {
        if (!(this instanceof n))
          return new n(t2, e2);
        this.buffer = t2, this.headers = this.parseHeader(), this.headers.length < this.buffer.byteLength && (this.buffer = this.buffer.slice(0, this.headers.length)), this.shpFuncs(e2), this.rows = this.getRows();
      }
      n.prototype.shpFuncs = function(t2) {
        let e2 = this.headers.shpCode;
        if (e2 > 20 && (e2 -= 20), !(e2 in s))
          throw new Error("I don't know that shp type");
        var i2;
        this.parseFunc = this[s[e2]], this.parseCoord = (i2 = t2) ? function(t3, e3) {
          const r2 = [t3.readDoubleLE(e3), t3.readDoubleLE(e3 + 8)];
          return i2.inverse(r2);
        } : function(t3, e3) {
          return [t3.readDoubleLE(e3), t3.readDoubleLE(e3 + 8)];
        };
      }, n.prototype.getShpCode = function() {
        return this.parseHeader().shpCode;
      }, n.prototype.parseHeader = function() {
        const t2 = this.buffer.slice(0, 100);
        return { length: t2.readInt32BE(24) << 1, version: t2.readInt32LE(28), shpCode: t2.readInt32LE(32), bbox: [t2.readDoubleLE(36), t2.readDoubleLE(44), t2.readDoubleLE(52), t2.readDoubleLE(52)] };
      }, n.prototype.getRows = function() {
        let t2 = 100;
        const e2 = this.buffer.byteLength, i2 = [];
        let r2;
        for (; t2 < e2 && (r2 = this.getRow(t2), r2); )
          t2 += 8, t2 += r2.len, r2.type ? i2.push(this.parseFunc(r2.data)) : i2.push(null);
        return i2;
      }, n.prototype.getRow = function(t2) {
        const e2 = this.buffer.slice(t2, t2 + 12), i2 = e2.readInt32BE(4) << 1, r2 = e2.readInt32BE(0);
        return 0 === i2 ? { id: r2, len: i2, type: 0 } : { id: r2, len: i2, data: this.buffer.slice(t2 + 12, t2 + i2 + 8), type: e2.readInt32LE(8) };
      }, t.exports = function(t2, e2) {
        return new n(t2, e2).rows;
      };
    },
    function(t, e, i) {
      var r = i(20);
      function s(t2, e2, i2, r2, s2) {
        var n2 = s2(t2.slice(e2, e2 + i2));
        switch (r2) {
          case "N":
          case "F":
          case "O":
            return parseFloat(n2, 10);
          case "D":
            return new Date(n2.slice(0, 4), parseInt(n2.slice(4, 6), 10) - 1, n2.slice(6, 8));
          case "L":
            return "y" === n2.toLowerCase() || "t" === n2.toLowerCase();
          default:
            return n2;
        }
      }
      function n(t2, e2, i2, r2) {
        for (var n2, a, o = {}, h = 0, u = i2.length; h < u; )
          n2 = s(t2, e2, (a = i2[h]).len, a.dataType, r2), e2 += a.len, void 0 !== n2 && (o[a.name] = n2), h++;
        return o;
      }
      t.exports = function(t2, e2) {
        for (var i2 = r(e2), s2 = function(t3) {
          var e3 = {};
          return e3.lastUpdated = new Date(t3.readUInt8(1) + 1900, t3.readUInt8(2), t3.readUInt8(3)), e3.records = t3.readUInt32LE(4), e3.headerLen = t3.readUInt16LE(8), e3.recLen = t3.readUInt16LE(10), e3;
        }(t2), a = function(t3, e3, i3) {
          for (var r2 = [], s3 = 32; s3 < e3 && (r2.push({ name: i3(t3.slice(s3, s3 + 11)), dataType: String.fromCharCode(t3.readUInt8(s3 + 11)), len: t3.readUInt8(s3 + 16), decimal: t3.readUInt8(s3 + 17) }), 13 !== t3.readUInt8(s3 + 32)); )
            s3 += 32;
          return r2;
        }(t2, s2.headerLen - 1, i2), o = 2 + (a.length + 1 << 5), h = s2.recLen, u = s2.records, l = []; u; )
          l.push(n(t2, o, a, i2)), o += h, u--;
        return l;
      };
    },
    function(t, e, i) {
      i(21);
      var r = i(24).StringDecoder;
      function s(t2) {
        var e2 = new r();
        return (e2.write(t2) + e2.end()).replace(/\0/g, "").trim();
      }
      t.exports = function t2(e2, i2) {
        if (!e2)
          return s;
        try {
          new TextDecoder(e2.trim());
        } catch (a) {
          var r2 = n.exec(e2);
          return r2 && !i2 ? t2("windows-" + r2[1], true) : s;
        }
        return function(t3) {
          var i3 = new TextDecoder(e2);
          return (i3.decode(t3, { stream: true }) + i3.decode()).replace(/\0/g, "").trim();
        };
      };
      var n = /^(?:ANSI\s)?(\d+)$/m;
    },
    function(t, e, i) {
      t.exports = i(22);
    },
    function(t, e, i) {
      !function(e2) {
        function r(t2, e3, i2) {
          return e3 <= t2 && t2 <= i2;
        }
        t.exports && !e2["encoding-indexes"] && i(23);
        var s = Math.floor;
        function n(t2) {
          if (void 0 === t2)
            return {};
          if (t2 === Object(t2))
            return t2;
          throw TypeError("Could not convert argument to dictionary");
        }
        function a(t2) {
          return 0 <= t2 && t2 <= 127;
        }
        var o = a;
        function h(t2) {
          this.tokens = [].slice.call(t2), this.tokens.reverse();
        }
        h.prototype = {
          endOfStream: function() {
            return !this.tokens.length;
          },
          read: function() {
            return this.tokens.length ? this.tokens.pop() : -1;
          },
          prepend: function(t2) {
            if (Array.isArray(t2))
              for (var e3 = t2; e3.length; )
                this.tokens.push(e3.pop());
            else
              this.tokens.push(t2);
          },
          push: function(t2) {
            if (Array.isArray(t2))
              for (var e3 = t2; e3.length; )
                this.tokens.unshift(e3.shift());
            else
              this.tokens.unshift(t2);
          }
        };
        function u(t2, e3) {
          if (t2)
            throw TypeError("Decoder error");
          return e3 || 65533;
        }
        function l(t2) {
          throw TypeError("The code point " + t2 + " could not be encoded.");
        }
        function c(t2) {
          return t2 = String(t2).trim().toLowerCase(), Object.prototype.hasOwnProperty.call(d, t2) ? d[t2] : null;
        }
        var f = [
          { encodings: [{ labels: ["unicode-1-1-utf-8", "utf-8", "utf8"], name: "UTF-8" }], heading: "The Encoding" },
          {
            encodings: [
              { labels: ["866", "cp866", "csibm866", "ibm866"], name: "IBM866" },
              { labels: ["csisolatin2", "iso-8859-2", "iso-ir-101", "iso8859-2", "iso88592", "iso_8859-2", "iso_8859-2:1987", "l2", "latin2"], name: "ISO-8859-2" },
              { labels: ["csisolatin3", "iso-8859-3", "iso-ir-109", "iso8859-3", "iso88593", "iso_8859-3", "iso_8859-3:1988", "l3", "latin3"], name: "ISO-8859-3" },
              { labels: ["csisolatin4", "iso-8859-4", "iso-ir-110", "iso8859-4", "iso88594", "iso_8859-4", "iso_8859-4:1988", "l4", "latin4"], name: "ISO-8859-4" },
              { labels: ["csisolatincyrillic", "cyrillic", "iso-8859-5", "iso-ir-144", "iso8859-5", "iso88595", "iso_8859-5", "iso_8859-5:1988"], name: "ISO-8859-5" },
              { labels: ["arabic", "asmo-708", "csiso88596e", "csiso88596i", "csisolatinarabic", "ecma-114", "iso-8859-6", "iso-8859-6-e", "iso-8859-6-i", "iso-ir-127", "iso8859-6", "iso88596", "iso_8859-6", "iso_8859-6:1987"], name: "ISO-8859-6" },
              { labels: ["csisolatingreek", "ecma-118", "elot_928", "greek", "greek8", "iso-8859-7", "iso-ir-126", "iso8859-7", "iso88597", "iso_8859-7", "iso_8859-7:1987", "sun_eu_greek"], name: "ISO-8859-7" },
              { labels: ["csiso88598e", "csisolatinhebrew", "hebrew", "iso-8859-8", "iso-8859-8-e", "iso-ir-138", "iso8859-8", "iso88598", "iso_8859-8", "iso_8859-8:1988", "visual"], name: "ISO-8859-8" },
              { labels: ["csiso88598i", "iso-8859-8-i", "logical"], name: "ISO-8859-8-I" },
              { labels: ["csisolatin6", "iso-8859-10", "iso-ir-157", "iso8859-10", "iso885910", "l6", "latin6"], name: "ISO-8859-10" },
              { labels: ["iso-8859-13", "iso8859-13", "iso885913"], name: "ISO-8859-13" },
              { labels: ["iso-8859-14", "iso8859-14", "iso885914"], name: "ISO-8859-14" },
              { labels: ["csisolatin9", "iso-8859-15", "iso8859-15", "iso885915", "iso_8859-15", "l9"], name: "ISO-8859-15" },
              { labels: ["iso-8859-16"], name: "ISO-8859-16" },
              { labels: ["cskoi8r", "koi", "koi8", "koi8-r", "koi8_r"], name: "KOI8-R" },
              { labels: ["koi8-ru", "koi8-u"], name: "KOI8-U" },
              { labels: ["csmacintosh", "mac", "macintosh", "x-mac-roman"], name: "macintosh" },
              { labels: ["dos-874", "iso-8859-11", "iso8859-11", "iso885911", "tis-620", "windows-874"], name: "windows-874" },
              { labels: ["cp1250", "windows-1250", "x-cp1250"], name: "windows-1250" },
              { labels: ["cp1251", "windows-1251", "x-cp1251"], name: "windows-1251" },
              { labels: ["ansi_x3.4-1968", "ascii", "cp1252", "cp819", "csisolatin1", "ibm819", "iso-8859-1", "iso-ir-100", "iso8859-1", "iso88591", "iso_8859-1", "iso_8859-1:1987", "l1", "latin1", "us-ascii", "windows-1252", "x-cp1252"], name: "windows-1252" },
              { labels: ["cp1253", "windows-1253", "x-cp1253"], name: "windows-1253" },
              { labels: ["cp1254", "csisolatin5", "iso-8859-9", "iso-ir-148", "iso8859-9", "iso88599", "iso_8859-9", "iso_8859-9:1989", "l5", "latin5", "windows-1254", "x-cp1254"], name: "windows-1254" },
              { labels: ["cp1255", "windows-1255", "x-cp1255"], name: "windows-1255" },
              { labels: ["cp1256", "windows-1256", "x-cp1256"], name: "windows-1256" },
              { labels: ["cp1257", "windows-1257", "x-cp1257"], name: "windows-1257" },
              { labels: ["cp1258", "windows-1258", "x-cp1258"], name: "windows-1258" },
              { labels: ["x-mac-cyrillic", "x-mac-ukrainian"], name: "x-mac-cyrillic" }
            ],
            heading: "Legacy single-byte encodings"
          },
          {
            encodings: [
              { labels: ["chinese", "csgb2312", "csiso58gb231280", "gb2312", "gb_2312", "gb_2312-80", "gbk", "iso-ir-58", "x-gbk"], name: "GBK" },
              { labels: ["gb18030"], name: "gb18030" }
            ],
            heading: "Legacy multi-byte Chinese (simplified) encodings"
          },
          { encodings: [{ labels: ["big5", "big5-hkscs", "cn-big5", "csbig5", "x-x-big5"], name: "Big5" }], heading: "Legacy multi-byte Chinese (traditional) encodings" },
          {
            encodings: [
              { labels: ["cseucpkdfmtjapanese", "euc-jp", "x-euc-jp"], name: "EUC-JP" },
              { labels: ["csiso2022jp", "iso-2022-jp"], name: "ISO-2022-JP" },
              { labels: ["csshiftjis", "ms932", "ms_kanji", "shift-jis", "shift_jis", "sjis", "windows-31j", "x-sjis"], name: "Shift_JIS" }
            ],
            heading: "Legacy multi-byte Japanese encodings"
          },
          { encodings: [{ labels: ["cseuckr", "csksc56011987", "euc-kr", "iso-ir-149", "korean", "ks_c_5601-1987", "ks_c_5601-1989", "ksc5601", "ksc_5601", "windows-949"], name: "EUC-KR" }], heading: "Legacy multi-byte Korean encodings" },
          {
            encodings: [
              { labels: ["csiso2022kr", "hz-gb-2312", "iso-2022-cn", "iso-2022-cn-ext", "iso-2022-kr"], name: "replacement" },
              { labels: ["utf-16be"], name: "UTF-16BE" },
              { labels: ["utf-16", "utf-16le"], name: "UTF-16LE" },
              { labels: ["x-user-defined"], name: "x-user-defined" }
            ],
            heading: "Legacy miscellaneous encodings"
          }
        ], d = {};
        f.forEach(function(t2) {
          t2.encodings.forEach(function(t3) {
            t3.labels.forEach(function(e3) {
              d[e3] = t3;
            });
          });
        });
        var p, m, g = {}, _ = {};
        function y(t2, e3) {
          return e3 && e3[t2] || null;
        }
        function v(t2, e3) {
          var i2 = e3.indexOf(t2);
          return -1 === i2 ? null : i2;
        }
        function b(t2) {
          if (!("encoding-indexes" in e2))
            throw Error("Indexes missing. Did you forget to include encoding-indexes.js first?");
          return e2["encoding-indexes"][t2];
        }
        function w(t2, e3) {
          if (!(this instanceof w))
            throw TypeError("Called as a function. Did you forget 'new'?");
          t2 = void 0 !== t2 ? String(t2) : "utf-8", e3 = n(e3), this._encoding = null, this._decoder = null, this._ignoreBOM = false, this._BOMseen = false, this._error_mode = "replacement", this._do_not_flush = false;
          var i2 = c(t2);
          if (null === i2 || "replacement" === i2.name)
            throw RangeError("Unknown encoding: " + t2);
          if (!_[i2.name])
            throw Error("Decoder not present. Did you forget to include encoding-indexes.js first?");
          return this._encoding = i2, Boolean(e3.fatal) && (this._error_mode = "fatal"), Boolean(e3.ignoreBOM) && (this._ignoreBOM = true), Object.defineProperty || (this.encoding = this._encoding.name.toLowerCase(), this.fatal = "fatal" === this._error_mode, this.ignoreBOM = this._ignoreBOM), this;
        }
        function M(t2, i2) {
          if (!(this instanceof M))
            throw TypeError("Called as a function. Did you forget 'new'?");
          i2 = n(i2), this._encoding = null, this._encoder = null, this._do_not_flush = false, this._fatal = Boolean(i2.fatal) ? "fatal" : "replacement";
          if (Boolean(i2.NONSTANDARD_allowLegacyEncoding)) {
            var r2 = c(t2 = void 0 !== t2 ? String(t2) : "utf-8");
            if (null === r2 || "replacement" === r2.name)
              throw RangeError("Unknown encoding: " + t2);
            if (!g[r2.name])
              throw Error("Encoder not present. Did you forget to include encoding-indexes.js first?");
            this._encoding = r2;
          } else
            this._encoding = c("utf-8"), void 0 !== t2 && "console" in e2 && console.warn("TextEncoder constructor called with encoding label, which is ignored.");
          return Object.defineProperty || (this.encoding = this._encoding.name.toLowerCase()), this;
        }
        function x(t2) {
          var e3 = t2.fatal, i2 = 0, s2 = 0, n2 = 0, a2 = 128, o2 = 191;
          this.handler = function(t3, h2) {
            if (-1 === h2 && 0 !== n2)
              return n2 = 0, u(e3);
            if (-1 === h2)
              return -1;
            if (0 === n2) {
              if (r(h2, 0, 127))
                return h2;
              if (r(h2, 194, 223))
                n2 = 1, i2 = 31 & h2;
              else if (r(h2, 224, 239))
                224 === h2 && (a2 = 160), 237 === h2 && (o2 = 159), n2 = 2, i2 = 15 & h2;
              else {
                if (!r(h2, 240, 244))
                  return u(e3);
                240 === h2 && (a2 = 144), 244 === h2 && (o2 = 143), n2 = 3, i2 = 7 & h2;
              }
              return null;
            }
            if (!r(h2, a2, o2))
              return i2 = n2 = s2 = 0, a2 = 128, o2 = 191, t3.prepend(h2), u(e3);
            if (a2 = 128, o2 = 191, i2 = i2 << 6 | 63 & h2, (s2 += 1) !== n2)
              return null;
            var l2 = i2;
            return i2 = n2 = s2 = 0, l2;
          };
        }
        function k(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            if (-1 === e3)
              return -1;
            if (o(e3))
              return e3;
            var i2, s2;
            r(e3, 128, 2047) ? (i2 = 1, s2 = 192) : r(e3, 2048, 65535) ? (i2 = 2, s2 = 224) : r(e3, 65536, 1114111) && (i2 = 3, s2 = 240);
            for (var n2 = [(e3 >> 6 * i2) + s2]; i2 > 0; ) {
              var a2 = e3 >> 6 * (i2 - 1);
              n2.push(128 | 63 & a2), i2 -= 1;
            }
            return n2;
          };
        }
        function S(t2, e3) {
          var i2 = e3.fatal;
          this.handler = function(e4, r2) {
            if (-1 === r2)
              return -1;
            if (a(r2))
              return r2;
            var s2 = t2[r2 - 128];
            return null === s2 ? u(i2) : s2;
          };
        }
        function E(t2, e3) {
          e3.fatal;
          this.handler = function(e4, i2) {
            if (-1 === i2)
              return -1;
            if (o(i2))
              return i2;
            var r2 = v(i2, t2);
            return null === r2 && l(i2), r2 + 128;
          };
        }
        function C(t2) {
          var e3 = t2.fatal, i2 = 0, s2 = 0, n2 = 0;
          this.handler = function(t3, o2) {
            if (-1 === o2 && 0 === i2 && 0 === s2 && 0 === n2)
              return -1;
            var h2;
            if (-1 !== o2 || 0 === i2 && 0 === s2 && 0 === n2 || (i2 = 0, s2 = 0, n2 = 0, u(e3)), 0 !== n2) {
              h2 = null, r(o2, 48, 57) && (h2 = function(t4) {
                if (t4 > 39419 && t4 < 189e3 || t4 > 1237575)
                  return null;
                if (7457 === t4)
                  return 59335;
                var e4, i3 = 0, r2 = 0, s3 = b("gb18030-ranges");
                for (e4 = 0; e4 < s3.length; ++e4) {
                  var n3 = s3[e4];
                  if (!(n3[0] <= t4))
                    break;
                  i3 = n3[0], r2 = n3[1];
                }
                return r2 + t4 - i3;
              }(10 * (126 * (10 * (i2 - 129) + s2 - 48) + n2 - 129) + o2 - 48));
              var l2 = [s2, n2, o2];
              return i2 = 0, s2 = 0, n2 = 0, null === h2 ? (t3.prepend(l2), u(e3)) : h2;
            }
            if (0 !== s2)
              return r(o2, 129, 254) ? (n2 = o2, null) : (t3.prepend([s2, o2]), i2 = 0, s2 = 0, u(e3));
            if (0 !== i2) {
              if (r(o2, 48, 57))
                return s2 = o2, null;
              var c2 = i2, f2 = null;
              i2 = 0;
              var d2 = o2 < 127 ? 64 : 65;
              return (r(o2, 64, 126) || r(o2, 128, 254)) && (f2 = 190 * (c2 - 129) + (o2 - d2)), null === (h2 = null === f2 ? null : y(f2, b("gb18030"))) && a(o2) && t3.prepend(o2), null === h2 ? u(e3) : h2;
            }
            return a(o2) ? o2 : 128 === o2 ? 8364 : r(o2, 129, 254) ? (i2 = o2, null) : u(e3);
          };
        }
        function A(t2, e3) {
          t2.fatal;
          this.handler = function(t3, i2) {
            if (-1 === i2)
              return -1;
            if (o(i2))
              return i2;
            if (58853 === i2)
              return l(i2);
            if (e3 && 8364 === i2)
              return 128;
            var r2 = v(i2, b("gb18030"));
            if (null !== r2) {
              var n2 = r2 % 190;
              return [s(r2 / 190) + 129, n2 + (n2 < 63 ? 64 : 65)];
            }
            if (e3)
              return l(i2);
            r2 = function(t4) {
              if (59335 === t4)
                return 7457;
              var e4, i3 = 0, r3 = 0, s2 = b("gb18030-ranges");
              for (e4 = 0; e4 < s2.length; ++e4) {
                var n3 = s2[e4];
                if (!(n3[1] <= t4))
                  break;
                i3 = n3[1], r3 = n3[0];
              }
              return r3 + t4 - i3;
            }(i2);
            var a2 = s(r2 / 10 / 126 / 10), h2 = s((r2 -= 10 * a2 * 126 * 10) / 10 / 126), u2 = s((r2 -= 10 * h2 * 126) / 10);
            return [a2 + 129, h2 + 48, u2 + 129, r2 - 10 * u2 + 48];
          };
        }
        function I(t2) {
          var e3 = t2.fatal, i2 = 0;
          this.handler = function(t3, s2) {
            if (-1 === s2 && 0 !== i2)
              return i2 = 0, u(e3);
            if (-1 === s2 && 0 === i2)
              return -1;
            if (0 !== i2) {
              var n2 = i2, o2 = null;
              i2 = 0;
              var h2 = s2 < 127 ? 64 : 98;
              switch ((r(s2, 64, 126) || r(s2, 161, 254)) && (o2 = 157 * (n2 - 129) + (s2 - h2)), o2) {
                case 1133:
                  return [202, 772];
                case 1135:
                  return [202, 780];
                case 1164:
                  return [234, 772];
                case 1166:
                  return [234, 780];
              }
              var l2 = null === o2 ? null : y(o2, b("big5"));
              return null === l2 && a(s2) && t3.prepend(s2), null === l2 ? u(e3) : l2;
            }
            return a(s2) ? s2 : r(s2, 129, 254) ? (i2 = s2, null) : u(e3);
          };
        }
        function O(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            if (-1 === e3)
              return -1;
            if (o(e3))
              return e3;
            var i2 = function(t4) {
              var e4 = m = m || b("big5").map(function(t5, e5) {
                return e5 < 5024 ? null : t5;
              });
              return 9552 === t4 || 9566 === t4 || 9569 === t4 || 9578 === t4 || 21313 === t4 || 21317 === t4 ? e4.lastIndexOf(t4) : v(t4, e4);
            }(e3);
            if (null === i2)
              return l(e3);
            var r2 = s(i2 / 157) + 129;
            if (r2 < 161)
              return l(e3);
            var n2 = i2 % 157;
            return [r2, n2 + (n2 < 63 ? 64 : 98)];
          };
        }
        function T(t2) {
          var e3 = t2.fatal, i2 = false, s2 = 0;
          this.handler = function(t3, n2) {
            if (-1 === n2 && 0 !== s2)
              return s2 = 0, u(e3);
            if (-1 === n2 && 0 === s2)
              return -1;
            if (142 === s2 && r(n2, 161, 223))
              return s2 = 0, 65216 + n2;
            if (143 === s2 && r(n2, 161, 254))
              return i2 = true, s2 = n2, null;
            if (0 !== s2) {
              var o2 = s2;
              s2 = 0;
              var h2 = null;
              return r(o2, 161, 254) && r(n2, 161, 254) && (h2 = y(94 * (o2 - 161) + (n2 - 161), b(i2 ? "jis0212" : "jis0208"))), i2 = false, r(n2, 161, 254) || t3.prepend(n2), null === h2 ? u(e3) : h2;
            }
            return a(n2) ? n2 : 142 === n2 || 143 === n2 || r(n2, 161, 254) ? (s2 = n2, null) : u(e3);
          };
        }
        function z(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            if (-1 === e3)
              return -1;
            if (o(e3))
              return e3;
            if (165 === e3)
              return 92;
            if (8254 === e3)
              return 126;
            if (r(e3, 65377, 65439))
              return [142, e3 - 65377 + 161];
            8722 === e3 && (e3 = 65293);
            var i2 = v(e3, b("jis0208"));
            return null === i2 ? l(e3) : [s(i2 / 94) + 161, i2 % 94 + 161];
          };
        }
        function P(t2) {
          var e3 = t2.fatal, i2 = 0, s2 = 1, n2 = 2, a2 = 3, o2 = 4, h2 = 5, l2 = 6, c2 = i2, f2 = i2, d2 = 0, p2 = false;
          this.handler = function(t3, m2) {
            switch (c2) {
              default:
              case i2:
                return 27 === m2 ? (c2 = h2, null) : r(m2, 0, 127) && 14 !== m2 && 15 !== m2 && 27 !== m2 ? (p2 = false, m2) : -1 === m2 ? -1 : (p2 = false, u(e3));
              case s2:
                return 27 === m2 ? (c2 = h2, null) : 92 === m2 ? (p2 = false, 165) : 126 === m2 ? (p2 = false, 8254) : r(m2, 0, 127) && 14 !== m2 && 15 !== m2 && 27 !== m2 && 92 !== m2 && 126 !== m2 ? (p2 = false, m2) : -1 === m2 ? -1 : (p2 = false, u(e3));
              case n2:
                return 27 === m2 ? (c2 = h2, null) : r(m2, 33, 95) ? (p2 = false, 65344 + m2) : -1 === m2 ? -1 : (p2 = false, u(e3));
              case a2:
                return 27 === m2 ? (c2 = h2, null) : r(m2, 33, 126) ? (p2 = false, d2 = m2, c2 = o2, null) : -1 === m2 ? -1 : (p2 = false, u(e3));
              case o2:
                if (27 === m2)
                  return c2 = h2, u(e3);
                if (r(m2, 33, 126)) {
                  c2 = a2;
                  var g2 = y(94 * (d2 - 33) + m2 - 33, b("jis0208"));
                  return null === g2 ? u(e3) : g2;
                }
                return -1 === m2 ? (c2 = a2, t3.prepend(m2), u(e3)) : (c2 = a2, u(e3));
              case h2:
                return 36 === m2 || 40 === m2 ? (d2 = m2, c2 = l2, null) : (t3.prepend(m2), p2 = false, c2 = f2, u(e3));
              case l2:
                var _2 = d2;
                d2 = 0;
                var v2 = null;
                if (40 === _2 && 66 === m2 && (v2 = i2), 40 === _2 && 74 === m2 && (v2 = s2), 40 === _2 && 73 === m2 && (v2 = n2), 36 !== _2 || 64 !== m2 && 66 !== m2 || (v2 = a2), null !== v2) {
                  c2 = c2 = v2;
                  var w2 = p2;
                  return p2 = true, w2 ? u(e3) : null;
                }
                return t3.prepend([_2, m2]), p2 = false, c2 = f2, u(e3);
            }
          };
        }
        function N(t2) {
          t2.fatal;
          var e3 = 0, i2 = 1, r2 = 2, n2 = e3;
          this.handler = function(t3, a2) {
            if (-1 === a2 && n2 !== e3)
              return t3.prepend(a2), n2 = e3, [27, 40, 66];
            if (-1 === a2 && n2 === e3)
              return -1;
            if (!(n2 !== e3 && n2 !== i2 || 14 !== a2 && 15 !== a2 && 27 !== a2))
              return l(65533);
            if (n2 === e3 && o(a2))
              return a2;
            if (n2 === i2 && (o(a2) && 92 !== a2 && 126 !== a2 || 165 == a2 || 8254 == a2)) {
              if (o(a2))
                return a2;
              if (165 === a2)
                return 92;
              if (8254 === a2)
                return 126;
            }
            if (o(a2) && n2 !== e3)
              return t3.prepend(a2), n2 = e3, [27, 40, 66];
            if ((165 === a2 || 8254 === a2) && n2 !== i2)
              return t3.prepend(a2), n2 = i2, [27, 40, 74];
            8722 === a2 && (a2 = 65293);
            var h2 = v(a2, b("jis0208"));
            return null === h2 ? l(a2) : n2 !== r2 ? (t3.prepend(a2), n2 = r2, [27, 36, 66]) : [s(h2 / 94) + 33, h2 % 94 + 33];
          };
        }
        function L(t2) {
          var e3 = t2.fatal, i2 = 0;
          this.handler = function(t3, s2) {
            if (-1 === s2 && 0 !== i2)
              return i2 = 0, u(e3);
            if (-1 === s2 && 0 === i2)
              return -1;
            if (0 !== i2) {
              var n2 = i2, o2 = null;
              i2 = 0;
              var h2 = s2 < 127 ? 64 : 65, l2 = n2 < 160 ? 129 : 193;
              if ((r(s2, 64, 126) || r(s2, 128, 252)) && (o2 = 188 * (n2 - l2) + s2 - h2), r(o2, 8836, 10715))
                return 48508 + o2;
              var c2 = null === o2 ? null : y(o2, b("jis0208"));
              return null === c2 && a(s2) && t3.prepend(s2), null === c2 ? u(e3) : c2;
            }
            return a(s2) || 128 === s2 ? s2 : r(s2, 161, 223) ? 65216 + s2 : r(s2, 129, 159) || r(s2, 224, 252) ? (i2 = s2, null) : u(e3);
          };
        }
        function R(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            if (-1 === e3)
              return -1;
            if (o(e3) || 128 === e3)
              return e3;
            if (165 === e3)
              return 92;
            if (8254 === e3)
              return 126;
            if (r(e3, 65377, 65439))
              return e3 - 65377 + 161;
            8722 === e3 && (e3 = 65293);
            var i2 = function(t4) {
              return (p = p || b("jis0208").map(function(t5, e4) {
                return r(e4, 8272, 8835) ? null : t5;
              })).indexOf(t4);
            }(e3);
            if (null === i2)
              return l(e3);
            var n2 = s(i2 / 188), a2 = i2 % 188;
            return [n2 + (n2 < 31 ? 129 : 193), a2 + (a2 < 63 ? 64 : 65)];
          };
        }
        function B(t2) {
          var e3 = t2.fatal, i2 = 0;
          this.handler = function(t3, s2) {
            if (-1 === s2 && 0 !== i2)
              return i2 = 0, u(e3);
            if (-1 === s2 && 0 === i2)
              return -1;
            if (0 !== i2) {
              var n2 = i2, o2 = null;
              i2 = 0, r(s2, 65, 254) && (o2 = 190 * (n2 - 129) + (s2 - 65));
              var h2 = null === o2 ? null : y(o2, b("euc-kr"));
              return null === o2 && a(s2) && t3.prepend(s2), null === h2 ? u(e3) : h2;
            }
            return a(s2) ? s2 : r(s2, 129, 254) ? (i2 = s2, null) : u(e3);
          };
        }
        function D(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            if (-1 === e3)
              return -1;
            if (o(e3))
              return e3;
            var i2 = v(e3, b("euc-kr"));
            return null === i2 ? l(e3) : [s(i2 / 190) + 129, i2 % 190 + 65];
          };
        }
        function j(t2, e3) {
          var i2 = t2 >> 8, r2 = 255 & t2;
          return e3 ? [i2, r2] : [r2, i2];
        }
        function U(t2, e3) {
          var i2 = e3.fatal, s2 = null, n2 = null;
          this.handler = function(e4, a2) {
            if (-1 === a2 && (null !== s2 || null !== n2))
              return u(i2);
            if (-1 === a2 && null === s2 && null === n2)
              return -1;
            if (null === s2)
              return s2 = a2, null;
            var o2;
            if (o2 = t2 ? (s2 << 8) + a2 : (a2 << 8) + s2, s2 = null, null !== n2) {
              var h2 = n2;
              return n2 = null, r(o2, 56320, 57343) ? 65536 + 1024 * (h2 - 55296) + (o2 - 56320) : (e4.prepend(j(o2, t2)), u(i2));
            }
            return r(o2, 55296, 56319) ? (n2 = o2, null) : r(o2, 56320, 57343) ? u(i2) : o2;
          };
        }
        function F(t2, e3) {
          e3.fatal;
          this.handler = function(e4, i2) {
            if (-1 === i2)
              return -1;
            if (r(i2, 0, 65535))
              return j(i2, t2);
            var s2 = j(55296 + (i2 - 65536 >> 10), t2), n2 = j(56320 + (i2 - 65536 & 1023), t2);
            return s2.concat(n2);
          };
        }
        function q(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            return -1 === e3 ? -1 : a(e3) ? e3 : 63360 + e3 - 128;
          };
        }
        function G(t2) {
          t2.fatal;
          this.handler = function(t3, e3) {
            return -1 === e3 ? -1 : o(e3) ? e3 : r(e3, 63360, 63487) ? e3 - 63360 + 128 : l(e3);
          };
        }
        Object.defineProperty && (Object.defineProperty(w.prototype, "encoding", {
          get: function() {
            return this._encoding.name.toLowerCase();
          }
        }), Object.defineProperty(w.prototype, "fatal", {
          get: function() {
            return "fatal" === this._error_mode;
          }
        }), Object.defineProperty(w.prototype, "ignoreBOM", {
          get: function() {
            return this._ignoreBOM;
          }
        })), w.prototype.decode = function(t2, e3) {
          var i2;
          i2 = "object" == typeof t2 && t2 instanceof ArrayBuffer ? new Uint8Array(t2) : "object" == typeof t2 && "buffer" in t2 && t2.buffer instanceof ArrayBuffer ? new Uint8Array(t2.buffer, t2.byteOffset, t2.byteLength) : new Uint8Array(0), e3 = n(e3), this._do_not_flush || (this._decoder = _[this._encoding.name]({ fatal: "fatal" === this._error_mode }), this._BOMseen = false), this._do_not_flush = Boolean(e3.stream);
          for (var r2, s2 = new h(i2), a2 = []; ; ) {
            var o2 = s2.read();
            if (-1 === o2)
              break;
            if (-1 === (r2 = this._decoder.handler(s2, o2)))
              break;
            null !== r2 && (Array.isArray(r2) ? a2.push.apply(a2, r2) : a2.push(r2));
          }
          if (!this._do_not_flush) {
            do {
              if (-1 === (r2 = this._decoder.handler(s2, s2.read())))
                break;
              null !== r2 && (Array.isArray(r2) ? a2.push.apply(a2, r2) : a2.push(r2));
            } while (!s2.endOfStream());
            this._decoder = null;
          }
          return function(t3) {
            var e4, i3;
            return e4 = ["UTF-8", "UTF-16LE", "UTF-16BE"], i3 = this._encoding.name, -1 === e4.indexOf(i3) || this._ignoreBOM || this._BOMseen || (t3.length > 0 && 65279 === t3[0] ? (this._BOMseen = true, t3.shift()) : t3.length > 0 && (this._BOMseen = true)), function(t4) {
              for (var e5 = "", i4 = 0; i4 < t4.length; ++i4) {
                var r3 = t4[i4];
                r3 <= 65535 ? e5 += String.fromCharCode(r3) : (r3 -= 65536, e5 += String.fromCharCode(55296 + (r3 >> 10), 56320 + (1023 & r3)));
              }
              return e5;
            }(t3);
          }.call(this, a2);
        }, Object.defineProperty && Object.defineProperty(M.prototype, "encoding", {
          get: function() {
            return this._encoding.name.toLowerCase();
          }
        }), M.prototype.encode = function(t2, e3) {
          t2 = void 0 === t2 ? "" : String(t2), e3 = n(e3), this._do_not_flush || (this._encoder = g[this._encoding.name]({ fatal: "fatal" === this._fatal })), this._do_not_flush = Boolean(e3.stream);
          for (var i2, r2 = new h(
            function(t3) {
              for (var e4 = String(t3), i3 = e4.length, r3 = 0, s3 = []; r3 < i3; ) {
                var n2 = e4.charCodeAt(r3);
                if (n2 < 55296 || n2 > 57343)
                  s3.push(n2);
                else if (56320 <= n2 && n2 <= 57343)
                  s3.push(65533);
                else if (55296 <= n2 && n2 <= 56319)
                  if (r3 === i3 - 1)
                    s3.push(65533);
                  else {
                    var a3 = e4.charCodeAt(r3 + 1);
                    if (56320 <= a3 && a3 <= 57343) {
                      var o2 = 1023 & n2, h2 = 1023 & a3;
                      s3.push(65536 + (o2 << 10) + h2), r3 += 1;
                    } else
                      s3.push(65533);
                  }
                r3 += 1;
              }
              return s3;
            }(t2)
          ), s2 = []; ; ) {
            var a2 = r2.read();
            if (-1 === a2)
              break;
            if (-1 === (i2 = this._encoder.handler(r2, a2)))
              break;
            Array.isArray(i2) ? s2.push.apply(s2, i2) : s2.push(i2);
          }
          if (!this._do_not_flush) {
            for (; -1 !== (i2 = this._encoder.handler(r2, r2.read())); )
              Array.isArray(i2) ? s2.push.apply(s2, i2) : s2.push(i2);
            this._encoder = null;
          }
          return new Uint8Array(s2);
        }, g["UTF-8"] = function(t2) {
          return new k(t2);
        }, _["UTF-8"] = function(t2) {
          return new x(t2);
        }, "encoding-indexes" in e2 && f.forEach(function(t2) {
          "Legacy single-byte encodings" === t2.heading && t2.encodings.forEach(function(t3) {
            var e3 = t3.name, i2 = b(e3.toLowerCase());
            _[e3] = function(t4) {
              return new S(i2, t4);
            }, g[e3] = function(t4) {
              return new E(i2, t4);
            };
          });
        }), _.GBK = function(t2) {
          return new C(t2);
        }, g.GBK = function(t2) {
          return new A(t2, true);
        }, g.gb18030 = function(t2) {
          return new A(t2);
        }, _.gb18030 = function(t2) {
          return new C(t2);
        }, g.Big5 = function(t2) {
          return new O(t2);
        }, _.Big5 = function(t2) {
          return new I(t2);
        }, g["EUC-JP"] = function(t2) {
          return new z(t2);
        }, _["EUC-JP"] = function(t2) {
          return new T(t2);
        }, g["ISO-2022-JP"] = function(t2) {
          return new N(t2);
        }, _["ISO-2022-JP"] = function(t2) {
          return new P(t2);
        }, g.Shift_JIS = function(t2) {
          return new R(t2);
        }, _.Shift_JIS = function(t2) {
          return new L(t2);
        }, g["EUC-KR"] = function(t2) {
          return new D(t2);
        }, _["EUC-KR"] = function(t2) {
          return new B(t2);
        }, g["UTF-16BE"] = function(t2) {
          return new F(true, t2);
        }, _["UTF-16BE"] = function(t2) {
          return new U(true, t2);
        }, g["UTF-16LE"] = function(t2) {
          return new F(false, t2);
        }, _["UTF-16LE"] = function(t2) {
          return new U(false, t2);
        }, g["x-user-defined"] = function(t2) {
          return new G(t2);
        }, _["x-user-defined"] = function(t2) {
          return new q(t2);
        }, e2.TextEncoder || (e2.TextEncoder = M), e2.TextDecoder || (e2.TextDecoder = w), t.exports && (t.exports = { TextEncoder: e2.TextEncoder, TextDecoder: e2.TextDecoder, EncodingIndexes: e2["encoding-indexes"] });
      }(this || {});
    },
    function(t, e) {
    },
    function(t, e, i) {
      var r = i(25).Buffer, s = r.isEncoding || function(t2) {
        switch ((t2 = "" + t2) && t2.toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
          case "raw":
            return true;
          default:
            return false;
        }
      };
      function n(t2) {
        var e2;
        switch (this.encoding = function(t3) {
          var e3 = function(t4) {
            if (!t4)
              return "utf8";
            for (var e4; ; )
              switch (t4) {
                case "utf8":
                case "utf-8":
                  return "utf8";
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return "utf16le";
                case "latin1":
                case "binary":
                  return "latin1";
                case "base64":
                case "ascii":
                case "hex":
                  return t4;
                default:
                  if (e4)
                    return;
                  t4 = ("" + t4).toLowerCase(), e4 = true;
              }
          }(t3);
          if ("string" != typeof e3 && (r.isEncoding === s || !s(t3)))
            throw new Error("Unknown encoding: " + t3);
          return e3 || t3;
        }(t2), this.encoding) {
          case "utf16le":
            this.text = h, this.end = u, e2 = 4;
            break;
          case "utf8":
            this.fillLast = o, e2 = 4;
            break;
          case "base64":
            this.text = l, this.end = c, e2 = 3;
            break;
          default:
            return this.write = f, void (this.end = d);
        }
        this.lastNeed = 0, this.lastTotal = 0, this.lastChar = r.allocUnsafe(e2);
      }
      function a(t2) {
        return t2 <= 127 ? 0 : t2 >> 5 == 6 ? 2 : t2 >> 4 == 14 ? 3 : t2 >> 3 == 30 ? 4 : t2 >> 6 == 2 ? -1 : -2;
      }
      function o(t2) {
        var e2 = this.lastTotal - this.lastNeed, i2 = function(t3, e3, i3) {
          if (128 != (192 & e3[0]))
            return t3.lastNeed = 0, "\u951F\uFFFD";
          if (t3.lastNeed > 1 && e3.length > 1) {
            if (128 != (192 & e3[1]))
              return t3.lastNeed = 1, "\u951F\uFFFD";
            if (t3.lastNeed > 2 && e3.length > 2 && 128 != (192 & e3[2]))
              return t3.lastNeed = 2, "\u951F\uFFFD";
          }
        }(this, t2);
        return void 0 !== i2 ? i2 : this.lastNeed <= t2.length ? (t2.copy(this.lastChar, e2, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal)) : (t2.copy(this.lastChar, e2, 0, t2.length), void (this.lastNeed -= t2.length));
      }
      function h(t2, e2) {
        if ((t2.length - e2) % 2 == 0) {
          var i2 = t2.toString("utf16le", e2);
          if (i2) {
            var r2 = i2.charCodeAt(i2.length - 1);
            if (r2 >= 55296 && r2 <= 56319)
              return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = t2[t2.length - 2], this.lastChar[1] = t2[t2.length - 1], i2.slice(0, -1);
          }
          return i2;
        }
        return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = t2[t2.length - 1], t2.toString("utf16le", e2, t2.length - 1);
      }
      function u(t2) {
        var e2 = t2 && t2.length ? this.write(t2) : "";
        if (this.lastNeed) {
          var i2 = this.lastTotal - this.lastNeed;
          return e2 + this.lastChar.toString("utf16le", 0, i2);
        }
        return e2;
      }
      function l(t2, e2) {
        var i2 = (t2.length - e2) % 3;
        return 0 === i2 ? t2.toString("base64", e2) : (this.lastNeed = 3 - i2, this.lastTotal = 3, 1 === i2 ? this.lastChar[0] = t2[t2.length - 1] : (this.lastChar[0] = t2[t2.length - 2], this.lastChar[1] = t2[t2.length - 1]), t2.toString("base64", e2, t2.length - i2));
      }
      function c(t2) {
        var e2 = t2 && t2.length ? this.write(t2) : "";
        return this.lastNeed ? e2 + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : e2;
      }
      function f(t2) {
        return t2.toString(this.encoding);
      }
      function d(t2) {
        return t2 && t2.length ? this.write(t2) : "";
      }
      e.StringDecoder = n, n.prototype.write = function(t2) {
        if (0 === t2.length)
          return "";
        var e2, i2;
        if (this.lastNeed) {
          if (void 0 === (e2 = this.fillLast(t2)))
            return "";
          i2 = this.lastNeed, this.lastNeed = 0;
        } else
          i2 = 0;
        return i2 < t2.length ? e2 ? e2 + this.text(t2, i2) : this.text(t2, i2) : e2 || "";
      }, n.prototype.end = function(t2) {
        var e2 = t2 && t2.length ? this.write(t2) : "";
        return this.lastNeed ? e2 + "\u951F\uFFFD" : e2;
      }, n.prototype.text = function(t2, e2) {
        var i2 = function(t3, e3, i3) {
          var r3 = e3.length - 1;
          if (r3 < i3)
            return 0;
          var s2 = a(e3[r3]);
          if (s2 >= 0)
            return s2 > 0 && (t3.lastNeed = s2 - 1), s2;
          if (--r3 < i3 || -2 === s2)
            return 0;
          if ((s2 = a(e3[r3])) >= 0)
            return s2 > 0 && (t3.lastNeed = s2 - 2), s2;
          if (--r3 < i3 || -2 === s2)
            return 0;
          if ((s2 = a(e3[r3])) >= 0)
            return s2 > 0 && (2 === s2 ? s2 = 0 : t3.lastNeed = s2 - 3), s2;
          return 0;
        }(this, t2, e2);
        if (!this.lastNeed)
          return t2.toString("utf8", e2);
        this.lastTotal = i2;
        var r2 = t2.length - (i2 - this.lastNeed);
        return t2.copy(this.lastChar, 0, r2), t2.toString("utf8", e2, r2);
      }, n.prototype.fillLast = function(t2) {
        if (this.lastNeed <= t2.length)
          return t2.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
        t2.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, t2.length), this.lastNeed -= t2.length;
      };
    },
    function(t, e, i) {
      var r = i(2), s = r.Buffer;
      function n(t2, e2) {
        for (var i2 in t2)
          e2[i2] = t2[i2];
      }
      function a(t2, e2, i2) {
        return s(t2, e2, i2);
      }
      s.from && s.alloc && s.allocUnsafe && s.allocUnsafeSlow ? t.exports = r : (n(r, e), e.Buffer = a), n(s, a), a.from = function(t2, e2, i2) {
        if ("number" == typeof t2)
          throw new TypeError("Argument must not be a number");
        return s(t2, e2, i2);
      }, a.alloc = function(t2, e2, i2) {
        if ("number" != typeof t2)
          throw new TypeError("Argument must be a number");
        var r2 = s(t2);
        return void 0 !== e2 ? "string" == typeof i2 ? r2.fill(e2, i2) : r2.fill(e2) : r2.fill(0), r2;
      }, a.allocUnsafe = function(t2) {
        if ("number" != typeof t2)
          throw new TypeError("Argument must be a number");
        return s(t2);
      }, a.allocUnsafeSlow = function(t2) {
        if ("number" != typeof t2)
          throw new TypeError("Argument must be a number");
        return r.SlowBuffer(t2);
      };
    },
    function(t, e, i) {
      (function(e2) {
        const i2 = "object" == typeof performance && performance && "function" == typeof performance.now ? performance : Date, r = "function" == typeof AbortController ? AbortController : class {
          constructor() {
            this.signal = new a();
          }
          abort() {
            this.signal.dispatchEvent("abort");
          }
        }, s = "function" == typeof AbortSignal, n = "function" == typeof r.AbortSignal, a = s ? AbortSignal : n ? r.AbortController : class {
          constructor() {
            this.aborted = false, this._listeners = [];
          }
          dispatchEvent(t2) {
            if ("abort" === t2) {
              this.aborted = true;
              const e3 = { type: t2, target: this };
              this.onabort(e3), this._listeners.forEach((t3) => t3(e3), this);
            }
          }
          onabort() {
          }
          addEventListener(t2, e3) {
            "abort" === t2 && this._listeners.push(e3);
          }
          removeEventListener(t2, e3) {
            "abort" === t2 && (this._listeners = this._listeners.filter((t3) => t3 !== e3));
          }
        }, o = /* @__PURE__ */ new Set(), h = (t2, e3) => {
          const i3 = "LRU_CACHE_OPTION_" + t2;
          c(i3) && f(i3, t2 + " option", "options." + e3, _);
        }, u = (t2, e3) => {
          const i3 = "LRU_CACHE_METHOD_" + t2;
          if (c(i3)) {
            const { prototype: r2 } = _, { get: s2 } = Object.getOwnPropertyDescriptor(r2, t2);
            f(i3, t2 + " method", `cache.${e3}()`, s2);
          }
        }, l = (...t2) => {
          "object" == typeof e2 && e2 && "function" == typeof e2.emitWarning ? e2.emitWarning(...t2) : console.error(...t2);
        }, c = (t2) => !o.has(t2), f = (t2, e3, i3, r2) => {
          o.add(t2);
          l(`The ${e3} is deprecated. Please use ${i3} instead.`, "DeprecationWarning", t2, r2);
        }, d = (t2) => t2 && t2 === Math.floor(t2) && t2 > 0 && isFinite(t2), p = (t2) => d(t2) ? t2 <= Math.pow(2, 8) ? Uint8Array : t2 <= Math.pow(2, 16) ? Uint16Array : t2 <= Math.pow(2, 32) ? Uint32Array : t2 <= Number.MAX_SAFE_INTEGER ? m : null : null;
        class m extends Array {
          constructor(t2) {
            super(t2), this.fill(0);
          }
        }
        class g {
          constructor(t2) {
            if (0 === t2)
              return [];
            const e3 = p(t2);
            this.heap = new e3(t2), this.length = 0;
          }
          push(t2) {
            this.heap[this.length++] = t2;
          }
          pop() {
            return this.heap[--this.length];
          }
        }
        class _ {
          constructor(t2 = {}) {
            const {
              max: e3 = 0,
              ttl: i3,
              ttlResolution: r2 = 1,
              ttlAutopurge: s2,
              updateAgeOnGet: n2,
              updateAgeOnHas: a2,
              allowStale: u2,
              dispose: f2,
              disposeAfter: m2,
              noDisposeOnSet: y,
              noUpdateTTL: v,
              maxSize: b = 0,
              maxEntrySize: w = 0,
              sizeCalculation: M,
              fetchMethod: x,
              fetchContext: k,
              noDeleteOnFetchRejection: S,
              noDeleteOnStaleGet: E
            } = t2, { length: C, maxAge: A, stale: I } = t2 instanceof _ ? {} : t2;
            if (0 !== e3 && !d(e3))
              throw new TypeError("max option must be a nonnegative integer");
            const O = e3 ? p(e3) : Array;
            if (!O)
              throw new Error("invalid max value: " + e3);
            if (this.max = e3, this.maxSize = b, this.maxEntrySize = w || this.maxSize, this.sizeCalculation = M || C, this.sizeCalculation) {
              if (!this.maxSize && !this.maxEntrySize)
                throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
              if ("function" != typeof this.sizeCalculation)
                throw new TypeError("sizeCalculation set to non-function");
            }
            if (this.fetchMethod = x || null, this.fetchMethod && "function" != typeof this.fetchMethod)
              throw new TypeError("fetchMethod must be a function if specified");
            if (this.fetchContext = k, !this.fetchMethod && void 0 !== k)
              throw new TypeError("cannot set fetchContext without fetchMethod");
            if (this.keyMap = /* @__PURE__ */ new Map(), this.keyList = new Array(e3).fill(null), this.valList = new Array(e3).fill(null), this.next = new O(e3), this.prev = new O(e3), this.head = 0, this.tail = 0, this.free = new g(e3), this.initialFill = 1, this.size = 0, "function" == typeof f2 && (this.dispose = f2), "function" == typeof m2 ? (this.disposeAfter = m2, this.disposed = []) : (this.disposeAfter = null, this.disposed = null), this.noDisposeOnSet = !!y, this.noUpdateTTL = !!v, this.noDeleteOnFetchRejection = !!S, 0 !== this.maxEntrySize) {
              if (0 !== this.maxSize && !d(this.maxSize))
                throw new TypeError("maxSize must be a positive integer if specified");
              if (!d(this.maxEntrySize))
                throw new TypeError("maxEntrySize must be a positive integer if specified");
              this.initializeSizeTracking();
            }
            if (this.allowStale = !!u2 || !!I, this.noDeleteOnStaleGet = !!E, this.updateAgeOnGet = !!n2, this.updateAgeOnHas = !!a2, this.ttlResolution = d(r2) || 0 === r2 ? r2 : 1, this.ttlAutopurge = !!s2, this.ttl = i3 || A || 0, this.ttl) {
              if (!d(this.ttl))
                throw new TypeError("ttl must be a positive integer if specified");
              this.initializeTTLTracking();
            }
            if (0 === this.max && 0 === this.ttl && 0 === this.maxSize)
              throw new TypeError("At least one of max, maxSize, or ttl is required");
            if (!this.ttlAutopurge && !this.max && !this.maxSize) {
              const t3 = "LRU_CACHE_UNBOUNDED";
              if (c(t3)) {
                o.add(t3);
                l("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", t3, _);
              }
            }
            I && h("stale", "allowStale"), A && h("maxAge", "ttl"), C && h("length", "sizeCalculation");
          }
          getRemainingTTL(t2) {
            return this.has(t2, { updateAgeOnHas: false }) ? 1 / 0 : 0;
          }
          initializeTTLTracking() {
            this.ttls = new m(this.max), this.starts = new m(this.max), this.setItemTTL = (t3, e4, r2 = i2.now()) => {
              if (this.starts[t3] = 0 !== e4 ? r2 : 0, this.ttls[t3] = e4, 0 !== e4 && this.ttlAutopurge) {
                const i3 = setTimeout(() => {
                  this.isStale(t3) && this.delete(this.keyList[t3]);
                }, e4 + 1);
                i3.unref && i3.unref();
              }
            }, this.updateItemAge = (t3) => {
              this.starts[t3] = 0 !== this.ttls[t3] ? i2.now() : 0;
            };
            let t2 = 0;
            const e3 = () => {
              const e4 = i2.now();
              if (this.ttlResolution > 0) {
                t2 = e4;
                const i3 = setTimeout(() => t2 = 0, this.ttlResolution);
                i3.unref && i3.unref();
              }
              return e4;
            };
            this.getRemainingTTL = (i3) => {
              const r2 = this.keyMap.get(i3);
              return void 0 === r2 ? 0 : 0 === this.ttls[r2] || 0 === this.starts[r2] ? 1 / 0 : this.starts[r2] + this.ttls[r2] - (t2 || e3());
            }, this.isStale = (i3) => 0 !== this.ttls[i3] && 0 !== this.starts[i3] && (t2 || e3()) - this.starts[i3] > this.ttls[i3];
          }
          updateItemAge(t2) {
          }
          setItemTTL(t2, e3, i3) {
          }
          isStale(t2) {
            return false;
          }
          initializeSizeTracking() {
            this.calculatedSize = 0, this.sizes = new m(this.max), this.removeItemSize = (t2) => {
              this.calculatedSize -= this.sizes[t2], this.sizes[t2] = 0;
            }, this.requireSize = (t2, e3, i3, r2) => {
              if (this.isBackgroundFetch(e3))
                return 0;
              if (!d(i3)) {
                if (!r2)
                  throw new TypeError("invalid size value (must be positive integer)");
                if ("function" != typeof r2)
                  throw new TypeError("sizeCalculation must be a function");
                if (i3 = r2(e3, t2), !d(i3))
                  throw new TypeError("sizeCalculation return invalid (expect positive integer)");
              }
              return i3;
            }, this.addItemSize = (t2, e3) => {
              if (this.sizes[t2] = e3, this.maxSize) {
                const e4 = this.maxSize - this.sizes[t2];
                for (; this.calculatedSize > e4; )
                  this.evict(true);
              }
              this.calculatedSize += this.sizes[t2];
            };
          }
          removeItemSize(t2) {
          }
          addItemSize(t2, e3) {
          }
          requireSize(t2, e3, i3, r2) {
            if (i3 || r2)
              throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
          }
          *indexes({ allowStale: t2 = this.allowStale } = {}) {
            if (this.size)
              for (let e3 = this.tail; this.isValidIndex(e3) && (!t2 && this.isStale(e3) || (yield e3), e3 !== this.head); )
                e3 = this.prev[e3];
          }
          *rindexes({ allowStale: t2 = this.allowStale } = {}) {
            if (this.size)
              for (let e3 = this.head; this.isValidIndex(e3) && (!t2 && this.isStale(e3) || (yield e3), e3 !== this.tail); )
                e3 = this.next[e3];
          }
          isValidIndex(t2) {
            return this.keyMap.get(this.keyList[t2]) === t2;
          }
          *entries() {
            for (const t2 of this.indexes())
              yield [this.keyList[t2], this.valList[t2]];
          }
          *rentries() {
            for (const t2 of this.rindexes())
              yield [this.keyList[t2], this.valList[t2]];
          }
          *keys() {
            for (const t2 of this.indexes())
              yield this.keyList[t2];
          }
          *rkeys() {
            for (const t2 of this.rindexes())
              yield this.keyList[t2];
          }
          *values() {
            for (const t2 of this.indexes())
              yield this.valList[t2];
          }
          *rvalues() {
            for (const t2 of this.rindexes())
              yield this.valList[t2];
          }
          [Symbol.iterator]() {
            return this.entries();
          }
          find(t2, e3 = {}) {
            for (const i3 of this.indexes())
              if (t2(this.valList[i3], this.keyList[i3], this))
                return this.get(this.keyList[i3], e3);
          }
          forEach(t2, e3 = this) {
            for (const i3 of this.indexes())
              t2.call(e3, this.valList[i3], this.keyList[i3], this);
          }
          rforEach(t2, e3 = this) {
            for (const i3 of this.rindexes())
              t2.call(e3, this.valList[i3], this.keyList[i3], this);
          }
          get prune() {
            return u("prune", "purgeStale"), this.purgeStale;
          }
          purgeStale() {
            let t2 = false;
            for (const e3 of this.rindexes({ allowStale: true }))
              this.isStale(e3) && (this.delete(this.keyList[e3]), t2 = true);
            return t2;
          }
          dump() {
            const t2 = [];
            for (const e3 of this.indexes({ allowStale: true })) {
              const r2 = this.keyList[e3], s2 = this.valList[e3], n2 = { value: this.isBackgroundFetch(s2) ? s2.__staleWhileFetching : s2 };
              if (this.ttls) {
                n2.ttl = this.ttls[e3];
                const t3 = i2.now() - this.starts[e3];
                n2.start = Math.floor(Date.now() - t3);
              }
              this.sizes && (n2.size = this.sizes[e3]), t2.unshift([r2, n2]);
            }
            return t2;
          }
          load(t2) {
            this.clear();
            for (const [e3, r2] of t2) {
              if (r2.start) {
                const t3 = Date.now() - r2.start;
                r2.start = i2.now() - t3;
              }
              this.set(e3, r2.value, r2);
            }
          }
          dispose(t2, e3, i3) {
          }
          set(t2, e3, { ttl: i3 = this.ttl, start: r2, noDisposeOnSet: s2 = this.noDisposeOnSet, size: n2 = 0, sizeCalculation: a2 = this.sizeCalculation, noUpdateTTL: o2 = this.noUpdateTTL } = {}) {
            if (n2 = this.requireSize(t2, e3, n2, a2), this.maxEntrySize && n2 > this.maxEntrySize)
              return this.delete(t2), this;
            let h2 = 0 === this.size ? void 0 : this.keyMap.get(t2);
            if (void 0 === h2)
              h2 = this.newIndex(), this.keyList[h2] = t2, this.valList[h2] = e3, this.keyMap.set(t2, h2), this.next[this.tail] = h2, this.prev[h2] = this.tail, this.tail = h2, this.size++, this.addItemSize(h2, n2), o2 = false;
            else {
              const i4 = this.valList[h2];
              e3 !== i4 && (this.isBackgroundFetch(i4) ? i4.__abortController.abort() : s2 || (this.dispose(i4, t2, "set"), this.disposeAfter && this.disposed.push([i4, t2, "set"])), this.removeItemSize(h2), this.valList[h2] = e3, this.addItemSize(h2, n2)), this.moveToTail(h2);
            }
            if (0 === i3 || 0 !== this.ttl || this.ttls || this.initializeTTLTracking(), o2 || this.setItemTTL(h2, i3, r2), this.disposeAfter)
              for (; this.disposed.length; )
                this.disposeAfter(...this.disposed.shift());
            return this;
          }
          newIndex() {
            return 0 === this.size ? this.tail : this.size === this.max && 0 !== this.max ? this.evict(false) : 0 !== this.free.length ? this.free.pop() : this.initialFill++;
          }
          pop() {
            if (this.size) {
              const t2 = this.valList[this.head];
              return this.evict(true), t2;
            }
          }
          evict(t2) {
            const e3 = this.head, i3 = this.keyList[e3], r2 = this.valList[e3];
            return this.isBackgroundFetch(r2) ? r2.__abortController.abort() : (this.dispose(r2, i3, "evict"), this.disposeAfter && this.disposed.push([r2, i3, "evict"])), this.removeItemSize(e3), t2 && (this.keyList[e3] = null, this.valList[e3] = null, this.free.push(e3)), this.head = this.next[e3], this.keyMap.delete(i3), this.size--, e3;
          }
          has(t2, { updateAgeOnHas: e3 = this.updateAgeOnHas } = {}) {
            const i3 = this.keyMap.get(t2);
            return void 0 !== i3 && !this.isStale(i3) && (e3 && this.updateItemAge(i3), true);
          }
          peek(t2, { allowStale: e3 = this.allowStale } = {}) {
            const i3 = this.keyMap.get(t2);
            if (void 0 !== i3 && (e3 || !this.isStale(i3))) {
              const t3 = this.valList[i3];
              return this.isBackgroundFetch(t3) ? t3.__staleWhileFetching : t3;
            }
          }
          backgroundFetch(t2, e3, i3, s2) {
            const n2 = void 0 === e3 ? void 0 : this.valList[e3];
            if (this.isBackgroundFetch(n2))
              return n2;
            const a2 = new r(), o2 = { signal: a2.signal, options: i3, context: s2 }, h2 = new Promise((e4) => e4(this.fetchMethod(t2, n2, o2))).then(
              (e4) => (a2.signal.aborted || this.set(t2, e4, o2.options), e4),
              (r2) => {
                if (this.valList[e3] === h2) {
                  !i3.noDeleteOnFetchRejection || void 0 === h2.__staleWhileFetching ? this.delete(t2) : this.valList[e3] = h2.__staleWhileFetching;
                }
                if (h2.__returned === h2)
                  throw r2;
              }
            );
            return h2.__abortController = a2, h2.__staleWhileFetching = n2, h2.__returned = null, void 0 === e3 ? (this.set(t2, h2, o2.options), e3 = this.keyMap.get(t2)) : this.valList[e3] = h2, h2;
          }
          isBackgroundFetch(t2) {
            return t2 && "object" == typeof t2 && "function" == typeof t2.then && Object.prototype.hasOwnProperty.call(t2, "__staleWhileFetching") && Object.prototype.hasOwnProperty.call(t2, "__returned") && (t2.__returned === t2 || null === t2.__returned);
          }
          async fetch(t2, {
            allowStale: e3 = this.allowStale,
            updateAgeOnGet: i3 = this.updateAgeOnGet,
            noDeleteOnStaleGet: r2 = this.noDeleteOnStaleGet,
            ttl: s2 = this.ttl,
            noDisposeOnSet: n2 = this.noDisposeOnSet,
            size: a2 = 0,
            sizeCalculation: o2 = this.sizeCalculation,
            noUpdateTTL: h2 = this.noUpdateTTL,
            noDeleteOnFetchRejection: u2 = this.noDeleteOnFetchRejection,
            fetchContext: l2 = this.fetchContext,
            forceRefresh: c2 = false
          } = {}) {
            if (!this.fetchMethod)
              return this.get(t2, { allowStale: e3, updateAgeOnGet: i3, noDeleteOnStaleGet: r2 });
            const f2 = { allowStale: e3, updateAgeOnGet: i3, noDeleteOnStaleGet: r2, ttl: s2, noDisposeOnSet: n2, size: a2, sizeCalculation: o2, noUpdateTTL: h2, noDeleteOnFetchRejection: u2 };
            let d2 = this.keyMap.get(t2);
            if (void 0 === d2) {
              const e4 = this.backgroundFetch(t2, d2, f2, l2);
              return e4.__returned = e4;
            }
            {
              const r3 = this.valList[d2];
              if (this.isBackgroundFetch(r3))
                return e3 && void 0 !== r3.__staleWhileFetching ? r3.__staleWhileFetching : r3.__returned = r3;
              if (!c2 && !this.isStale(d2))
                return this.moveToTail(d2), i3 && this.updateItemAge(d2), r3;
              const s3 = this.backgroundFetch(t2, d2, f2, l2);
              return e3 && void 0 !== s3.__staleWhileFetching ? s3.__staleWhileFetching : s3.__returned = s3;
            }
          }
          get(t2, { allowStale: e3 = this.allowStale, updateAgeOnGet: i3 = this.updateAgeOnGet, noDeleteOnStaleGet: r2 = this.noDeleteOnStaleGet } = {}) {
            const s2 = this.keyMap.get(t2);
            if (void 0 !== s2) {
              const n2 = this.valList[s2], a2 = this.isBackgroundFetch(n2);
              if (this.isStale(s2))
                return a2 ? e3 ? n2.__staleWhileFetching : void 0 : (r2 || this.delete(t2), e3 ? n2 : void 0);
              if (a2)
                return;
              return this.moveToTail(s2), i3 && this.updateItemAge(s2), n2;
            }
          }
          connect(t2, e3) {
            this.prev[e3] = t2, this.next[t2] = e3;
          }
          moveToTail(t2) {
            t2 !== this.tail && (t2 === this.head ? this.head = this.next[t2] : this.connect(this.prev[t2], this.next[t2]), this.connect(this.tail, t2), this.tail = t2);
          }
          get del() {
            return u("del", "delete"), this.delete;
          }
          delete(t2) {
            let e3 = false;
            if (0 !== this.size) {
              const i3 = this.keyMap.get(t2);
              if (void 0 !== i3)
                if (e3 = true, 1 === this.size)
                  this.clear();
                else {
                  this.removeItemSize(i3);
                  const e4 = this.valList[i3];
                  this.isBackgroundFetch(e4) ? e4.__abortController.abort() : (this.dispose(e4, t2, "delete"), this.disposeAfter && this.disposed.push([e4, t2, "delete"])), this.keyMap.delete(t2), this.keyList[i3] = null, this.valList[i3] = null, i3 === this.tail ? this.tail = this.prev[i3] : i3 === this.head ? this.head = this.next[i3] : (this.next[this.prev[i3]] = this.next[i3], this.prev[this.next[i3]] = this.prev[i3]), this.size--, this.free.push(i3);
                }
            }
            if (this.disposed)
              for (; this.disposed.length; )
                this.disposeAfter(...this.disposed.shift());
            return e3;
          }
          clear() {
            for (const t2 of this.rindexes({ allowStale: true })) {
              const e3 = this.valList[t2];
              if (this.isBackgroundFetch(e3))
                e3.__abortController.abort();
              else {
                const i3 = this.keyList[t2];
                this.dispose(e3, i3, "delete"), this.disposeAfter && this.disposed.push([e3, i3, "delete"]);
              }
            }
            if (this.keyMap.clear(), this.valList.fill(null), this.keyList.fill(null), this.ttls && (this.ttls.fill(0), this.starts.fill(0)), this.sizes && this.sizes.fill(0), this.head = 0, this.tail = 0, this.initialFill = 1, this.free.length = 0, this.calculatedSize = 0, this.size = 0, this.disposed)
              for (; this.disposed.length; )
                this.disposeAfter(...this.disposed.shift());
          }
          get reset() {
            return u("reset", "clear"), this.clear;
          }
          get length() {
            return ((t2, e3) => {
              const i3 = "LRU_CACHE_PROPERTY_" + t2;
              if (c(i3)) {
                const { prototype: r2 } = _, { get: s2 } = Object.getOwnPropertyDescriptor(r2, t2);
                f(i3, t2 + " property", "cache." + e3, s2);
              }
            })("length", "size"), this.size;
          }
          static get AbortController() {
            return r;
          }
          static get AbortSignal() {
            return a;
          }
        }
        t.exports = _;
      }).call(this, i(3));
    },
    function(t, e, i) {
      i.r(e);
      var r = 484813681109536e-20, s = Math.PI / 2, n = 0.017453292519943295, a = 57.29577951308232, o = Math.PI / 4, h = 2 * Math.PI, u = 3.14159265359, l = {
        greenwich: 0,
        lisbon: -9.131906111111,
        paris: 2.337229166667,
        bogota: -74.080916666667,
        madrid: -3.687938888889,
        rome: 12.452333333333,
        bern: 7.439583333333,
        jakarta: 106.807719444444,
        ferro: -17.666666666667,
        brussels: 4.367975,
        stockholm: 18.058277777778,
        athens: 23.7163375,
        oslo: 10.722916666667
      }, c = { ft: { to_meter: 0.3048 }, "us-ft": { to_meter: 1200 / 3937 } }, f = /[\s_\-\/\(\)]/g;
      function d(t2, e2) {
        if (t2[e2])
          return t2[e2];
        for (var i2, r2 = Object.keys(t2), s2 = e2.toLowerCase().replace(f, ""), n2 = -1; ++n2 < r2.length; )
          if ((i2 = r2[n2]).toLowerCase().replace(f, "") === s2)
            return t2[i2];
      }
      var p = function(t2) {
        var e2, i2, r2, s2 = {}, a2 = t2.split("+").map(function(t3) {
          return t3.trim();
        }).filter(function(t3) {
          return t3;
        }).reduce(function(t3, e3) {
          var i3 = e3.split("=");
          return i3.push(true), t3[i3[0].toLowerCase()] = i3[1], t3;
        }, {}), o2 = {
          proj: "projName",
          datum: "datumCode",
          rf: function(t3) {
            s2.rf = parseFloat(t3);
          },
          lat_0: function(t3) {
            s2.lat0 = t3 * n;
          },
          lat_1: function(t3) {
            s2.lat1 = t3 * n;
          },
          lat_2: function(t3) {
            s2.lat2 = t3 * n;
          },
          lat_ts: function(t3) {
            s2.lat_ts = t3 * n;
          },
          lon_0: function(t3) {
            s2.long0 = t3 * n;
          },
          lon_1: function(t3) {
            s2.long1 = t3 * n;
          },
          lon_2: function(t3) {
            s2.long2 = t3 * n;
          },
          alpha: function(t3) {
            s2.alpha = parseFloat(t3) * n;
          },
          gamma: function(t3) {
            s2.rectified_grid_angle = parseFloat(t3);
          },
          lonc: function(t3) {
            s2.longc = t3 * n;
          },
          x_0: function(t3) {
            s2.x0 = parseFloat(t3);
          },
          y_0: function(t3) {
            s2.y0 = parseFloat(t3);
          },
          k_0: function(t3) {
            s2.k0 = parseFloat(t3);
          },
          k: function(t3) {
            s2.k0 = parseFloat(t3);
          },
          a: function(t3) {
            s2.a = parseFloat(t3);
          },
          b: function(t3) {
            s2.b = parseFloat(t3);
          },
          r_a: function() {
            s2.R_A = true;
          },
          zone: function(t3) {
            s2.zone = parseInt(t3, 10);
          },
          south: function() {
            s2.utmSouth = true;
          },
          towgs84: function(t3) {
            s2.datum_params = t3.split(",").map(function(t4) {
              return parseFloat(t4);
            });
          },
          to_meter: function(t3) {
            s2.to_meter = parseFloat(t3);
          },
          units: function(t3) {
            s2.units = t3;
            var e3 = d(c, t3);
            e3 && (s2.to_meter = e3.to_meter);
          },
          from_greenwich: function(t3) {
            s2.from_greenwich = t3 * n;
          },
          pm: function(t3) {
            var e3 = d(l, t3);
            s2.from_greenwich = (e3 || parseFloat(t3)) * n;
          },
          nadgrids: function(t3) {
            "@null" === t3 ? s2.datumCode = "none" : s2.nadgrids = t3;
          },
          axis: function(t3) {
            3 === t3.length && -1 !== "ewnsud".indexOf(t3.substr(0, 1)) && -1 !== "ewnsud".indexOf(t3.substr(1, 1)) && -1 !== "ewnsud".indexOf(t3.substr(2, 1)) && (s2.axis = t3);
          },
          approx: function() {
            s2.approx = true;
          }
        };
        for (e2 in a2)
          i2 = a2[e2], e2 in o2 ? "function" == typeof (r2 = o2[e2]) ? r2(i2) : s2[r2] = i2 : s2[e2] = i2;
        return "string" == typeof s2.datumCode && "WGS84" !== s2.datumCode && (s2.datumCode = s2.datumCode.toLowerCase()), s2;
      }, m = function(t2) {
        return new w(t2).output();
      }, g = /\s/, _ = /[A-Za-z]/, y = /[A-Za-z84_]/, v = /[,\]]/, b = /[\d\.E\-\+]/;
      function w(t2) {
        if ("string" != typeof t2)
          throw new Error("not a string");
        this.text = t2.trim(), this.level = 0, this.place = 0, this.root = null, this.stack = [], this.currentObject = null, this.state = 1;
      }
      function M(t2, e2, i2) {
        Array.isArray(e2) && (i2.unshift(e2), e2 = null);
        var r2 = e2 ? {} : t2, s2 = i2.reduce(function(t3, e3) {
          return x(e3, t3), t3;
        }, r2);
        e2 && (t2[e2] = s2);
      }
      function x(t2, e2) {
        if (Array.isArray(t2)) {
          var i2 = t2.shift();
          if ("PARAMETER" === i2 && (i2 = t2.shift()), 1 === t2.length)
            return Array.isArray(t2[0]) ? (e2[i2] = {}, void x(t2[0], e2[i2])) : void (e2[i2] = t2[0]);
          if (t2.length)
            if ("TOWGS84" !== i2) {
              if ("AXIS" === i2)
                return i2 in e2 || (e2[i2] = []), void e2[i2].push(t2);
              var r2;
              switch (Array.isArray(i2) || (e2[i2] = {}), i2) {
                case "UNIT":
                case "PRIMEM":
                case "VERT_DATUM":
                  return e2[i2] = { name: t2[0].toLowerCase(), convert: t2[1] }, void (3 === t2.length && x(t2[2], e2[i2]));
                case "SPHEROID":
                case "ELLIPSOID":
                  return e2[i2] = { name: t2[0], a: t2[1], rf: t2[2] }, void (4 === t2.length && x(t2[3], e2[i2]));
                case "PROJECTEDCRS":
                case "PROJCRS":
                case "GEOGCS":
                case "GEOCCS":
                case "PROJCS":
                case "LOCAL_CS":
                case "GEODCRS":
                case "GEODETICCRS":
                case "GEODETICDATUM":
                case "EDATUM":
                case "ENGINEERINGDATUM":
                case "VERT_CS":
                case "VERTCRS":
                case "VERTICALCRS":
                case "COMPD_CS":
                case "COMPOUNDCRS":
                case "ENGINEERINGCRS":
                case "ENGCRS":
                case "FITTED_CS":
                case "LOCAL_DATUM":
                case "DATUM":
                  return t2[0] = ["name", t2[0]], void M(e2, i2, t2);
                default:
                  for (r2 = -1; ++r2 < t2.length; )
                    if (!Array.isArray(t2[r2]))
                      return x(t2, e2[i2]);
                  return M(e2, i2, t2);
              }
            } else
              e2[i2] = t2;
          else
            e2[i2] = true;
        } else
          e2[t2] = true;
      }
      w.prototype.readCharicter = function() {
        var t2 = this.text[this.place++];
        if (4 !== this.state)
          for (; g.test(t2); ) {
            if (this.place >= this.text.length)
              return;
            t2 = this.text[this.place++];
          }
        switch (this.state) {
          case 1:
            return this.neutral(t2);
          case 2:
            return this.keyword(t2);
          case 4:
            return this.quoted(t2);
          case 5:
            return this.afterquote(t2);
          case 3:
            return this.number(t2);
          case -1:
            return;
        }
      }, w.prototype.afterquote = function(t2) {
        if ('"' === t2)
          return this.word += '"', void (this.state = 4);
        if (v.test(t2))
          return this.word = this.word.trim(), void this.afterItem(t2);
        throw new Error(`havn't handled "` + t2 + '" in afterquote yet, index ' + this.place);
      }, w.prototype.afterItem = function(t2) {
        return "," === t2 ? (null !== this.word && this.currentObject.push(this.word), this.word = null, void (this.state = 1)) : "]" === t2 ? (this.level--, null !== this.word && (this.currentObject.push(this.word), this.word = null), this.state = 1, this.currentObject = this.stack.pop(), void (this.currentObject || (this.state = -1))) : void 0;
      }, w.prototype.number = function(t2) {
        if (!b.test(t2)) {
          if (v.test(t2))
            return this.word = parseFloat(this.word), void this.afterItem(t2);
          throw new Error(`havn't handled "` + t2 + '" in number yet, index ' + this.place);
        }
        this.word += t2;
      }, w.prototype.quoted = function(t2) {
        '"' !== t2 ? this.word += t2 : this.state = 5;
      }, w.prototype.keyword = function(t2) {
        if (y.test(t2))
          this.word += t2;
        else {
          if ("[" === t2) {
            var e2 = [];
            return e2.push(this.word), this.level++, null === this.root ? this.root = e2 : this.currentObject.push(e2), this.stack.push(this.currentObject), this.currentObject = e2, void (this.state = 1);
          }
          if (!v.test(t2))
            throw new Error(`havn't handled "` + t2 + '" in keyword yet, index ' + this.place);
          this.afterItem(t2);
        }
      }, w.prototype.neutral = function(t2) {
        if (_.test(t2))
          return this.word = t2, void (this.state = 2);
        if ('"' === t2)
          return this.word = "", void (this.state = 4);
        if (b.test(t2))
          return this.word = t2, void (this.state = 3);
        if (!v.test(t2))
          throw new Error(`havn't handled "` + t2 + '" in neutral yet, index ' + this.place);
        this.afterItem(t2);
      }, w.prototype.output = function() {
        for (; this.place < this.text.length; )
          this.readCharicter();
        if (-1 === this.state)
          return this.root;
        throw new Error('unable to parse string "' + this.text + '". State is ' + this.state);
      };
      function k(t2) {
        return 0.017453292519943295 * t2;
      }
      var S = function(t2) {
        var e2 = m(t2), i2 = e2.shift(), r2 = e2.shift();
        e2.unshift(["name", r2]), e2.unshift(["type", i2]);
        var s2 = {};
        return x(e2, s2), function(t3) {
          if ("GEOGCS" === t3.type ? t3.projName = "longlat" : "LOCAL_CS" === t3.type ? (t3.projName = "identity", t3.local = true) : "object" == typeof t3.PROJECTION ? t3.projName = Object.keys(t3.PROJECTION)[0] : t3.projName = t3.PROJECTION, t3.AXIS) {
            for (var e3 = "", i3 = 0, r3 = t3.AXIS.length; i3 < r3; ++i3) {
              var s3 = [t3.AXIS[i3][0].toLowerCase(), t3.AXIS[i3][1].toLowerCase()];
              -1 !== s3[0].indexOf("north") || ("y" === s3[0] || "lat" === s3[0]) && "north" === s3[1] ? e3 += "n" : -1 !== s3[0].indexOf("south") || ("y" === s3[0] || "lat" === s3[0]) && "south" === s3[1] ? e3 += "s" : -1 !== s3[0].indexOf("east") || ("x" === s3[0] || "lon" === s3[0]) && "east" === s3[1] ? e3 += "e" : -1 === s3[0].indexOf("west") && ("x" !== s3[0] && "lon" !== s3[0] || "west" !== s3[1]) || (e3 += "w");
            }
            2 === e3.length && (e3 += "u"), 3 === e3.length && (t3.axis = e3);
          }
          t3.UNIT && (t3.units = t3.UNIT.name.toLowerCase(), "metre" === t3.units && (t3.units = "meter"), t3.UNIT.convert && ("GEOGCS" === t3.type ? t3.DATUM && t3.DATUM.SPHEROID && (t3.to_meter = t3.UNIT.convert * t3.DATUM.SPHEROID.a) : t3.to_meter = t3.UNIT.convert));
          var n2 = t3.GEOGCS;
          function a2(e4) {
            return e4 * (t3.to_meter || 1);
          }
          "GEOGCS" === t3.type && (n2 = t3), n2 && (n2.DATUM ? t3.datumCode = n2.DATUM.name.toLowerCase() : t3.datumCode = n2.name.toLowerCase(), "d_" === t3.datumCode.slice(0, 2) && (t3.datumCode = t3.datumCode.slice(2)), "new_zealand_geodetic_datum_1949" !== t3.datumCode && "new_zealand_1949" !== t3.datumCode || (t3.datumCode = "nzgd49"), "wgs_1984" !== t3.datumCode && "world_geodetic_system_1984" !== t3.datumCode || ("Mercator_Auxiliary_Sphere" === t3.PROJECTION && (t3.sphere = true), t3.datumCode = "wgs84"), "_ferro" === t3.datumCode.slice(-6) && (t3.datumCode = t3.datumCode.slice(0, -6)), "_jakarta" === t3.datumCode.slice(-8) && (t3.datumCode = t3.datumCode.slice(0, -8)), ~t3.datumCode.indexOf("belge") && (t3.datumCode = "rnb72"), n2.DATUM && n2.DATUM.SPHEROID && (t3.ellps = n2.DATUM.SPHEROID.name.replace("_19", "").replace(/[Cc]larke\_18/, "clrk"), "international" === t3.ellps.toLowerCase().slice(0, 13) && (t3.ellps = "intl"), t3.a = n2.DATUM.SPHEROID.a, t3.rf = parseFloat(n2.DATUM.SPHEROID.rf, 10)), n2.DATUM && n2.DATUM.TOWGS84 && (t3.datum_params = n2.DATUM.TOWGS84), ~t3.datumCode.indexOf("osgb_1936") && (t3.datumCode = "osgb36"), ~t3.datumCode.indexOf("osni_1952") && (t3.datumCode = "osni52"), (~t3.datumCode.indexOf("tm65") || ~t3.datumCode.indexOf("geodetic_datum_of_1965")) && (t3.datumCode = "ire65"), "ch1903+" === t3.datumCode && (t3.datumCode = "ch1903"), ~t3.datumCode.indexOf("israel") && (t3.datumCode = "isr93")), t3.b && !isFinite(t3.b) && (t3.b = t3.a), [
            ["standard_parallel_1", "Standard_Parallel_1"],
            ["standard_parallel_1", "Latitude of 1st standard parallel"],
            ["standard_parallel_2", "Standard_Parallel_2"],
            ["standard_parallel_2", "Latitude of 2nd standard parallel"],
            ["false_easting", "False_Easting"],
            ["false_easting", "False easting"],
            ["false-easting", "Easting at false origin"],
            ["false_northing", "False_Northing"],
            ["false_northing", "False northing"],
            ["false_northing", "Northing at false origin"],
            ["central_meridian", "Central_Meridian"],
            ["central_meridian", "Longitude of natural origin"],
            ["central_meridian", "Longitude of false origin"],
            ["latitude_of_origin", "Latitude_Of_Origin"],
            ["latitude_of_origin", "Central_Parallel"],
            ["latitude_of_origin", "Latitude of natural origin"],
            ["latitude_of_origin", "Latitude of false origin"],
            ["scale_factor", "Scale_Factor"],
            ["k0", "scale_factor"],
            ["latitude_of_center", "Latitude_Of_Center"],
            ["latitude_of_center", "Latitude_of_center"],
            ["lat0", "latitude_of_center", k],
            ["longitude_of_center", "Longitude_Of_Center"],
            ["longitude_of_center", "Longitude_of_center"],
            ["longc", "longitude_of_center", k],
            ["x0", "false_easting", a2],
            ["y0", "false_northing", a2],
            ["long0", "central_meridian", k],
            ["lat0", "latitude_of_origin", k],
            ["lat0", "standard_parallel_1", k],
            ["lat1", "standard_parallel_1", k],
            ["lat2", "standard_parallel_2", k],
            ["azimuth", "Azimuth"],
            ["alpha", "azimuth", k],
            ["srsCode", "name"]
          ].forEach(function(e4) {
            return i4 = t3, s4 = (r4 = e4)[0], n3 = r4[1], void (!(s4 in i4) && n3 in i4 && (i4[s4] = i4[n3], 3 === r4.length && (i4[s4] = r4[2](i4[s4]))));
            var i4, r4, s4, n3;
          }), t3.long0 || !t3.longc || "Albers_Conic_Equal_Area" !== t3.projName && "Lambert_Azimuthal_Equal_Area" !== t3.projName || (t3.long0 = t3.longc), t3.lat_ts || !t3.lat1 || "Stereographic_South_Pole" !== t3.projName && "Polar Stereographic (variant B)" !== t3.projName || (t3.lat0 = k(t3.lat1 > 0 ? 90 : -90), t3.lat_ts = t3.lat1);
        }(s2), s2;
      };
      function E(t2) {
        var e2 = this;
        if (2 === arguments.length) {
          var i2 = arguments[1];
          "string" == typeof i2 ? "+" === i2.charAt(0) ? E[t2] = p(arguments[1]) : E[t2] = S(arguments[1]) : E[t2] = i2;
        } else if (1 === arguments.length) {
          if (Array.isArray(t2))
            return t2.map(function(t3) {
              Array.isArray(t3) ? E.apply(e2, t3) : E(t3);
            });
          if ("string" == typeof t2) {
            if (t2 in E)
              return E[t2];
          } else
            "EPSG" in t2 ? E["EPSG:" + t2.EPSG] = t2 : "ESRI" in t2 ? E["ESRI:" + t2.ESRI] = t2 : "IAU2000" in t2 ? E["IAU2000:" + t2.IAU2000] = t2 : console.log(t2);
          return;
        }
      }
      !function(t2) {
        t2("EPSG:4326", "+title=WGS 84 (long/lat) +proj=longlat +ellps=WGS84 +datum=WGS84 +units=degrees"), t2("EPSG:4269", "+title=NAD83 (long/lat) +proj=longlat +a=6378137.0 +b=6356752.31414036 +ellps=GRS80 +datum=NAD83 +units=degrees"), t2("EPSG:3857", "+title=WGS 84 / Pseudo-Mercator +proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +no_defs"), t2.WGS84 = t2["EPSG:4326"], t2["EPSG:3785"] = t2["EPSG:3857"], t2.GOOGLE = t2["EPSG:3857"], t2["EPSG:900913"] = t2["EPSG:3857"], t2["EPSG:102113"] = t2["EPSG:3857"];
      }(E);
      var C = E;
      var A = ["PROJECTEDCRS", "PROJCRS", "GEOGCS", "GEOCCS", "PROJCS", "LOCAL_CS", "GEODCRS", "GEODETICCRS", "GEODETICDATUM", "ENGCRS", "ENGINEERINGCRS"];
      var I = ["3857", "900913", "3785", "102113"];
      var O = function(t2) {
        if (!function(t3) {
          return "string" == typeof t3;
        }(t2))
          return t2;
        if (function(t3) {
          return t3 in C;
        }(t2))
          return C[t2];
        if (function(t3) {
          return A.some(function(e3) {
            return t3.indexOf(e3) > -1;
          });
        }(t2)) {
          var e2 = S(t2);
          if (function(t3) {
            var e3 = d(t3, "authority");
            if (e3) {
              var i3 = d(e3, "epsg");
              return i3 && I.indexOf(i3) > -1;
            }
          }(e2))
            return C["EPSG:3857"];
          var i2 = function(t3) {
            var e3 = d(t3, "extension");
            if (e3)
              return d(e3, "proj4");
          }(e2);
          return i2 ? p(i2) : e2;
        }
        return function(t3) {
          return "+" === t3[0];
        }(t2) ? p(t2) : void 0;
      }, T = function(t2, e2) {
        var i2, r2;
        if (t2 = t2 || {}, !e2)
          return t2;
        for (r2 in e2)
          void 0 !== (i2 = e2[r2]) && (t2[r2] = i2);
        return t2;
      }, z = function(t2, e2, i2) {
        var r2 = t2 * e2;
        return i2 / Math.sqrt(1 - r2 * r2);
      }, P = function(t2) {
        return t2 < 0 ? -1 : 1;
      }, N = function(t2) {
        return Math.abs(t2) <= u ? t2 : t2 - P(t2) * h;
      }, L = function(t2, e2, i2) {
        var r2 = t2 * i2, n2 = 0.5 * t2;
        return r2 = Math.pow((1 - r2) / (1 + r2), n2), Math.tan(0.5 * (s - e2)) / r2;
      }, R = function(t2, e2) {
        for (var i2, r2, n2 = 0.5 * t2, a2 = s - 2 * Math.atan(e2), o2 = 0; o2 <= 15; o2++)
          if (i2 = t2 * Math.sin(a2), a2 += r2 = s - 2 * Math.atan(e2 * Math.pow((1 - i2) / (1 + i2), n2)) - a2, Math.abs(r2) <= 1e-10)
            return a2;
        return -9999;
      };
      function B(t2) {
        return t2;
      }
      var D = [
        {
          init: function() {
            var t2 = this.b / this.a;
            this.es = 1 - t2 * t2, "x0" in this || (this.x0 = 0), "y0" in this || (this.y0 = 0), this.e = Math.sqrt(this.es), this.lat_ts ? this.sphere ? this.k0 = Math.cos(this.lat_ts) : this.k0 = z(this.e, Math.sin(this.lat_ts), Math.cos(this.lat_ts)) : this.k0 || (this.k ? this.k0 = this.k : this.k0 = 1);
          },
          forward: function(t2) {
            var e2, i2, r2 = t2.x, n2 = t2.y;
            if (n2 * a > 90 && n2 * a < -90 && r2 * a > 180 && r2 * a < -180)
              return null;
            if (Math.abs(Math.abs(n2) - s) <= 1e-10)
              return null;
            if (this.sphere)
              e2 = this.x0 + this.a * this.k0 * N(r2 - this.long0), i2 = this.y0 + this.a * this.k0 * Math.log(Math.tan(o + 0.5 * n2));
            else {
              var h2 = Math.sin(n2), u2 = L(this.e, n2, h2);
              e2 = this.x0 + this.a * this.k0 * N(r2 - this.long0), i2 = this.y0 - this.a * this.k0 * Math.log(u2);
            }
            return t2.x = e2, t2.y = i2, t2;
          },
          inverse: function(t2) {
            var e2, i2, r2 = t2.x - this.x0, n2 = t2.y - this.y0;
            if (this.sphere)
              i2 = s - 2 * Math.atan(Math.exp(-n2 / (this.a * this.k0)));
            else {
              var a2 = Math.exp(-n2 / (this.a * this.k0));
              if (-9999 === (i2 = R(this.e, a2)))
                return null;
            }
            return e2 = N(this.long0 + r2 / (this.a * this.k0)), t2.x = e2, t2.y = i2, t2;
          },
          names: ["Mercator", "Popular Visualisation Pseudo Mercator", "Mercator_1SP", "Mercator_Auxiliary_Sphere", "merc"]
        },
        { init: function() {
        }, forward: B, inverse: B, names: ["longlat", "identity"] }
      ], j = {}, U = [];
      function F(t2, e2) {
        var i2 = U.length;
        return t2.names ? (U[i2] = t2, t2.names.forEach(function(t3) {
          j[t3.toLowerCase()] = i2;
        }), this) : (console.log(e2), true);
      }
      var q = {
        start: function() {
          D.forEach(F);
        },
        add: F,
        get: function(t2) {
          if (!t2)
            return false;
          var e2 = t2.toLowerCase();
          return void 0 !== j[e2] && U[j[e2]] ? U[j[e2]] : void 0;
        }
      }, G = {
        MERIT: { a: 6378137, rf: 298.257, ellipseName: "MERIT 1983" },
        SGS85: { a: 6378136, rf: 298.257, ellipseName: "Soviet Geodetic System 85" },
        GRS80: { a: 6378137, rf: 298.257222101, ellipseName: "GRS 1980(IUGG, 1980)" },
        IAU76: { a: 6378140, rf: 298.257, ellipseName: "IAU 1976" },
        airy: { a: 6377563396e-3, b: 635625691e-2, ellipseName: "Airy 1830" },
        APL4: { a: 6378137, rf: 298.25, ellipseName: "Appl. Physics. 1965" },
        NWL9D: { a: 6378145, rf: 298.25, ellipseName: "Naval Weapons Lab., 1965" },
        mod_airy: { a: 6377340189e-3, b: 6356034446e-3, ellipseName: "Modified Airy" },
        andrae: { a: 637710443e-2, rf: 300, ellipseName: "Andrae 1876 (Den., Iclnd.)" },
        aust_SA: { a: 6378160, rf: 298.25, ellipseName: "Australian Natl & S. Amer. 1969" },
        GRS67: { a: 6378160, rf: 298.247167427, ellipseName: "GRS 67(IUGG 1967)" },
        bessel: { a: 6377397155e-3, rf: 299.1528128, ellipseName: "Bessel 1841" },
        bess_nam: { a: 6377483865e-3, rf: 299.1528128, ellipseName: "Bessel 1841 (Namibia)" },
        clrk66: { a: 63782064e-1, b: 63565838e-1, ellipseName: "Clarke 1866" },
        clrk80: { a: 6378249145e-3, rf: 293.4663, ellipseName: "Clarke 1880 mod." },
        clrk58: { a: 6378293645208759e-9, rf: 294.2606763692654, ellipseName: "Clarke 1858" },
        CPM: { a: 63757387e-1, rf: 334.29, ellipseName: "Comm. des Poids et Mesures 1799" },
        delmbr: { a: 6376428, rf: 311.5, ellipseName: "Delambre 1810 (Belgium)" },
        engelis: { a: 637813605e-2, rf: 298.2566, ellipseName: "Engelis 1985" },
        evrst30: { a: 6377276345e-3, rf: 300.8017, ellipseName: "Everest 1830" },
        evrst48: { a: 6377304063e-3, rf: 300.8017, ellipseName: "Everest 1948" },
        evrst56: { a: 6377301243e-3, rf: 300.8017, ellipseName: "Everest 1956" },
        evrst69: { a: 6377295664e-3, rf: 300.8017, ellipseName: "Everest 1969" },
        evrstSS: { a: 6377298556e-3, rf: 300.8017, ellipseName: "Everest (Sabah & Sarawak)" },
        fschr60: { a: 6378166, rf: 298.3, ellipseName: "Fischer (Mercury Datum) 1960" },
        fschr60m: { a: 6378155, rf: 298.3, ellipseName: "Fischer 1960" },
        fschr68: { a: 6378150, rf: 298.3, ellipseName: "Fischer 1968" },
        helmert: { a: 6378200, rf: 298.3, ellipseName: "Helmert 1906" },
        hough: { a: 6378270, rf: 297, ellipseName: "Hough" },
        intl: { a: 6378388, rf: 297, ellipseName: "International 1909 (Hayford)" },
        kaula: { a: 6378163, rf: 298.24, ellipseName: "Kaula 1961" },
        lerch: { a: 6378139, rf: 298.257, ellipseName: "Lerch 1979" },
        mprts: { a: 6397300, rf: 191, ellipseName: "Maupertius 1738" },
        new_intl: { a: 63781575e-1, b: 63567722e-1, ellipseName: "New International 1967" },
        plessis: { a: 6376523, rf: 6355863, ellipseName: "Plessis 1817 (France)" },
        krass: { a: 6378245, rf: 298.3, ellipseName: "Krassovsky, 1942" },
        SEasia: { a: 6378155, b: 63567733205e-4, ellipseName: "Southeast Asia" },
        walbeck: { a: 6376896, b: 63558348467e-4, ellipseName: "Walbeck" },
        WGS60: { a: 6378165, rf: 298.3, ellipseName: "WGS 60" },
        WGS66: { a: 6378145, rf: 298.25, ellipseName: "WGS 66" },
        WGS7: { a: 6378135, rf: 298.26, ellipseName: "WGS 72" }
      }, W = G.WGS84 = { a: 6378137, rf: 298.257223563, ellipseName: "WGS 84" };
      G.sphere = { a: 6370997, b: 6370997, ellipseName: "Normal Sphere (r=6370997)" };
      var Z = {};
      Z.wgs84 = { towgs84: "0,0,0", ellipse: "WGS84", datumName: "WGS84" }, Z.ch1903 = { towgs84: "674.374,15.056,405.346", ellipse: "bessel", datumName: "swiss" }, Z.ggrs87 = { towgs84: "-199.87,74.79,246.62", ellipse: "GRS80", datumName: "Greek_Geodetic_Reference_System_1987" }, Z.nad83 = { towgs84: "0,0,0", ellipse: "GRS80", datumName: "North_American_Datum_1983" }, Z.nad27 = { nadgrids: "@conus,@alaska,@ntv2_0.gsb,@ntv1_can.dat", ellipse: "clrk66", datumName: "North_American_Datum_1927" }, Z.potsdam = { towgs84: "598.1,73.7,418.2,0.202,0.045,-2.455,6.7", ellipse: "bessel", datumName: "Potsdam Rauenberg 1950 DHDN" }, Z.carthage = { towgs84: "-263.0,6.0,431.0", ellipse: "clark80", datumName: "Carthage 1934 Tunisia" }, Z.hermannskogel = { towgs84: "577.326,90.129,463.919,5.137,1.474,5.297,2.4232", ellipse: "bessel", datumName: "Hermannskogel" }, Z.osni52 = { towgs84: "482.530,-130.596,564.557,-1.042,-0.214,-0.631,8.15", ellipse: "airy", datumName: "Irish National" }, Z.ire65 = { towgs84: "482.530,-130.596,564.557,-1.042,-0.214,-0.631,8.15", ellipse: "mod_airy", datumName: "Ireland 1965" }, Z.rassadiran = { towgs84: "-133.63,-157.5,-158.62", ellipse: "intl", datumName: "Rassadiran" }, Z.nzgd49 = { towgs84: "59.47,-5.04,187.44,0.47,-0.1,1.024,-4.5993", ellipse: "intl", datumName: "New Zealand Geodetic Datum 1949" }, Z.osgb36 = { towgs84: "446.448,-125.157,542.060,0.1502,0.2470,0.8421,-20.4894", ellipse: "airy", datumName: "Airy 1830" }, Z.s_jtsk = { towgs84: "589,76,480", ellipse: "bessel", datumName: "S-JTSK (Ferro)" }, Z.beduaram = { towgs84: "-106,-87,188", ellipse: "clrk80", datumName: "Beduaram" }, Z.gunung_segara = { towgs84: "-403,684,41", ellipse: "bessel", datumName: "Gunung Segara Jakarta" }, Z.rnb72 = { towgs84: "106.869,-52.2978,103.724,-0.33657,0.456955,-1.84218,1", ellipse: "intl", datumName: "Reseau National Belge 1972" };
      var H = function(t2, e2, i2, s2, n2, a2, o2) {
        var h2 = {};
        return h2.datum_type = void 0 === t2 || "none" === t2 ? 5 : 4, e2 && (h2.datum_params = e2.map(parseFloat), 0 === h2.datum_params[0] && 0 === h2.datum_params[1] && 0 === h2.datum_params[2] || (h2.datum_type = 1), h2.datum_params.length > 3 && (0 === h2.datum_params[3] && 0 === h2.datum_params[4] && 0 === h2.datum_params[5] && 0 === h2.datum_params[6] || (h2.datum_type = 2, h2.datum_params[3] *= r, h2.datum_params[4] *= r, h2.datum_params[5] *= r, h2.datum_params[6] = h2.datum_params[6] / 1e6 + 1))), o2 && (h2.datum_type = 3, h2.grids = o2), h2.a = i2, h2.b = s2, h2.es = n2, h2.ep2 = a2, h2;
      }, Y = {};
      function X(t2) {
        if (0 === t2.length)
          return null;
        var e2 = "@" === t2[0];
        return e2 && (t2 = t2.slice(1)), "null" === t2 ? { name: "null", mandatory: !e2, grid: null, isNull: true } : { name: t2, mandatory: !e2, grid: Y[t2] || null, isNull: false };
      }
      function J(t2) {
        return t2 / 3600 * Math.PI / 180;
      }
      function K(t2, e2, i2) {
        return String.fromCharCode.apply(null, new Uint8Array(t2.buffer.slice(e2, i2)));
      }
      function Q(t2) {
        return t2.map(function(t3) {
          return [J(t3.longitudeShift), J(t3.latitudeShift)];
        });
      }
      function V(t2, e2, i2) {
        return {
          name: K(t2, e2 + 8, e2 + 16).trim(),
          parent: K(t2, e2 + 24, e2 + 24 + 8).trim(),
          lowerLatitude: t2.getFloat64(e2 + 72, i2),
          upperLatitude: t2.getFloat64(e2 + 88, i2),
          lowerLongitude: t2.getFloat64(e2 + 104, i2),
          upperLongitude: t2.getFloat64(e2 + 120, i2),
          latitudeInterval: t2.getFloat64(e2 + 136, i2),
          longitudeInterval: t2.getFloat64(e2 + 152, i2),
          gridNodeCount: t2.getInt32(e2 + 168, i2)
        };
      }
      function $(t2, e2, i2, r2) {
        for (var s2 = e2 + 176, n2 = [], a2 = 0; a2 < i2.gridNodeCount; a2++) {
          var o2 = { latitudeShift: t2.getFloat32(s2 + 16 * a2, r2), longitudeShift: t2.getFloat32(s2 + 16 * a2 + 4, r2), latitudeAccuracy: t2.getFloat32(s2 + 16 * a2 + 8, r2), longitudeAccuracy: t2.getFloat32(s2 + 16 * a2 + 12, r2) };
          n2.push(o2);
        }
        return n2;
      }
      function tt(t2, e2) {
        if (!(this instanceof tt))
          return new tt(t2);
        e2 = e2 || function(t3) {
          if (t3)
            throw t3;
        };
        var i2 = O(t2);
        if ("object" == typeof i2) {
          var r2 = tt.projections.get(i2.projName);
          if (r2) {
            if (i2.datumCode && "none" !== i2.datumCode) {
              var s2 = d(Z, i2.datumCode);
              s2 && (i2.datum_params = i2.datum_params || (s2.towgs84 ? s2.towgs84.split(",") : null), i2.ellps = s2.ellipse, i2.datumName = s2.datumName ? s2.datumName : i2.datumCode);
            }
            i2.k0 = i2.k0 || 1, i2.axis = i2.axis || "enu", i2.ellps = i2.ellps || "wgs84", i2.lat1 = i2.lat1 || i2.lat0;
            var n2, a2, o2, h2, u2, l2, c2, f2 = function(t3, e3, i3, r3, s3) {
              if (!t3) {
                var n3 = d(G, r3);
                n3 || (n3 = W), t3 = n3.a, e3 = n3.b, i3 = n3.rf;
              }
              return i3 && !e3 && (e3 = (1 - 1 / i3) * t3), (0 === i3 || Math.abs(t3 - e3) < 1e-10) && (s3 = true, e3 = t3), { a: t3, b: e3, rf: i3, sphere: s3 };
            }(i2.a, i2.b, i2.rf, i2.ellps, i2.sphere), p2 = (n2 = f2.a, a2 = f2.b, f2.rf, o2 = i2.R_A, l2 = ((h2 = n2 * n2) - (u2 = a2 * a2)) / h2, c2 = 0, o2 ? (h2 = (n2 *= 1 - l2 * (0.16666666666666666 + l2 * (0.04722222222222222 + 0.022156084656084655 * l2))) * n2, l2 = 0) : c2 = Math.sqrt(l2), { es: l2, e: c2, ep2: (h2 - u2) / u2 }), m2 = function(t3) {
              return void 0 === t3 ? null : t3.split(",").map(X);
            }(i2.nadgrids), g2 = i2.datum || H(i2.datumCode, i2.datum_params, f2.a, f2.b, p2.es, p2.ep2, m2);
            T(this, i2), T(this, r2), this.a = f2.a, this.b = f2.b, this.rf = f2.rf, this.sphere = f2.sphere, this.es = p2.es, this.e = p2.e, this.ep2 = p2.ep2, this.datum = g2, this.init(), e2(null, this);
          } else
            e2(t2);
        } else
          e2(t2);
      }
      tt.projections = q, tt.projections.start();
      var et = tt;
      function it(t2, e2, i2) {
        var r2, n2, a2, o2, h2 = t2.x, u2 = t2.y, l2 = t2.z ? t2.z : 0;
        if (u2 < -s && u2 > -1.001 * s)
          u2 = -s;
        else if (u2 > s && u2 < 1.001 * s)
          u2 = s;
        else {
          if (u2 < -s)
            return { x: -1 / 0, y: -1 / 0, z: t2.z };
          if (u2 > s)
            return { x: 1 / 0, y: 1 / 0, z: t2.z };
        }
        return h2 > Math.PI && (h2 -= 2 * Math.PI), n2 = Math.sin(u2), o2 = Math.cos(u2), a2 = n2 * n2, { x: ((r2 = i2 / Math.sqrt(1 - e2 * a2)) + l2) * o2 * Math.cos(h2), y: (r2 + l2) * o2 * Math.sin(h2), z: (r2 * (1 - e2) + l2) * n2 };
      }
      function rt(t2, e2, i2, r2) {
        var n2, a2, o2, h2, u2, l2, c2, f2, d2, p2, m2, g2, _2, y2, v2, b2 = t2.x, w2 = t2.y, M2 = t2.z ? t2.z : 0;
        if (n2 = Math.sqrt(b2 * b2 + w2 * w2), a2 = Math.sqrt(b2 * b2 + w2 * w2 + M2 * M2), n2 / i2 < 1e-12) {
          if (y2 = 0, a2 / i2 < 1e-12)
            return v2 = -r2, { x: t2.x, y: t2.y, z: t2.z };
        } else
          y2 = Math.atan2(w2, b2);
        o2 = M2 / a2, f2 = (h2 = n2 / a2) * (1 - e2) * (u2 = 1 / Math.sqrt(1 - e2 * (2 - e2) * h2 * h2)), d2 = o2 * u2, _2 = 0;
        do {
          _2++, l2 = e2 * (c2 = i2 / Math.sqrt(1 - e2 * d2 * d2)) / (c2 + (v2 = n2 * f2 + M2 * d2 - c2 * (1 - e2 * d2 * d2))), g2 = (m2 = o2 * (u2 = 1 / Math.sqrt(1 - l2 * (2 - l2) * h2 * h2))) * f2 - (p2 = h2 * (1 - l2) * u2) * d2, f2 = p2, d2 = m2;
        } while (g2 * g2 > 1e-24 && _2 < 30);
        return { x: y2, y: Math.atan(m2 / Math.abs(p2)), z: v2 };
      }
      function st(t2) {
        return 1 === t2 || 2 === t2;
      }
      var nt = function(t2, e2, i2) {
        if (function(t3, e3) {
          return t3.datum_type === e3.datum_type && !(t3.a !== e3.a || Math.abs(t3.es - e3.es) > 5e-11) && (1 === t3.datum_type ? t3.datum_params[0] === e3.datum_params[0] && t3.datum_params[1] === e3.datum_params[1] && t3.datum_params[2] === e3.datum_params[2] : 2 !== t3.datum_type || t3.datum_params[0] === e3.datum_params[0] && t3.datum_params[1] === e3.datum_params[1] && t3.datum_params[2] === e3.datum_params[2] && t3.datum_params[3] === e3.datum_params[3] && t3.datum_params[4] === e3.datum_params[4] && t3.datum_params[5] === e3.datum_params[5] && t3.datum_params[6] === e3.datum_params[6]);
        }(t2, e2))
          return i2;
        if (5 === t2.datum_type || 5 === e2.datum_type)
          return i2;
        var r2 = t2.a, s2 = t2.es;
        if (3 === t2.datum_type) {
          if (0 !== at(t2, false, i2))
            return;
          r2 = 6378137, s2 = 0.0066943799901413165;
        }
        var n2 = e2.a, a2 = e2.b, o2 = e2.es;
        if (3 === e2.datum_type && (n2 = 6378137, a2 = 6356752314e-3, o2 = 0.0066943799901413165), s2 === o2 && r2 === n2 && !st(t2.datum_type) && !st(e2.datum_type))
          return i2;
        if ((i2 = it(i2, s2, r2), st(t2.datum_type) && (i2 = function(t3, e3, i3) {
          if (1 === e3)
            return { x: t3.x + i3[0], y: t3.y + i3[1], z: t3.z + i3[2] };
          if (2 === e3) {
            var r3 = i3[0], s3 = i3[1], n3 = i3[2], a3 = i3[3], o3 = i3[4], h2 = i3[5], u2 = i3[6];
            return { x: u2 * (t3.x - h2 * t3.y + o3 * t3.z) + r3, y: u2 * (h2 * t3.x + t3.y - a3 * t3.z) + s3, z: u2 * (-o3 * t3.x + a3 * t3.y + t3.z) + n3 };
          }
        }(i2, t2.datum_type, t2.datum_params)), st(e2.datum_type) && (i2 = function(t3, e3, i3) {
          if (1 === e3)
            return { x: t3.x - i3[0], y: t3.y - i3[1], z: t3.z - i3[2] };
          if (2 === e3) {
            var r3 = i3[0], s3 = i3[1], n3 = i3[2], a3 = i3[3], o3 = i3[4], h2 = i3[5], u2 = i3[6], l2 = (t3.x - r3) / u2, c2 = (t3.y - s3) / u2, f2 = (t3.z - n3) / u2;
            return { x: l2 + h2 * c2 - o3 * f2, y: -h2 * l2 + c2 + a3 * f2, z: o3 * l2 - a3 * c2 + f2 };
          }
        }(i2, e2.datum_type, e2.datum_params)), i2 = rt(i2, o2, n2, a2), 3 === e2.datum_type) && 0 !== at(e2, true, i2))
          return;
        return i2;
      };
      function at(t2, e2, i2) {
        if (null === t2.grids || 0 === t2.grids.length)
          return console.log("Grid shift grids not found"), -1;
        for (var r2 = { x: -i2.x, y: i2.y }, s2 = { x: Number.NaN, y: Number.NaN }, n2 = [], o2 = 0; o2 < t2.grids.length; o2++) {
          var h2 = t2.grids[o2];
          if (n2.push(h2.name), h2.isNull) {
            s2 = r2;
            break;
          }
          if (h2.mandatory, null !== h2.grid) {
            var u2 = h2.grid.subgrids[0], l2 = (Math.abs(u2.del[1]) + Math.abs(u2.del[0])) / 1e4, c2 = u2.ll[0] - l2, f2 = u2.ll[1] - l2, d2 = u2.ll[0] + (u2.lim[0] - 1) * u2.del[0] + l2, p2 = u2.ll[1] + (u2.lim[1] - 1) * u2.del[1] + l2;
            if (!(f2 > r2.y || c2 > r2.x || p2 < r2.y || d2 < r2.x || (s2 = ot(r2, e2, u2), isNaN(s2.x))))
              break;
          } else if (h2.mandatory)
            return console.log("Unable to find mandatory grid '" + h2.name + "'"), -1;
        }
        return isNaN(s2.x) ? (console.log("Failed to find a grid shift table for location '" + -r2.x * a + " " + r2.y * a + " tried: '" + n2 + "'"), -1) : (i2.x = -s2.x, i2.y = s2.y, 0);
      }
      function ot(t2, e2, i2) {
        var r2 = { x: Number.NaN, y: Number.NaN };
        if (isNaN(t2.x))
          return r2;
        var s2 = { x: t2.x, y: t2.y };
        s2.x -= i2.ll[0], s2.y -= i2.ll[1], s2.x = N(s2.x - Math.PI) + Math.PI;
        var n2 = ht(s2, i2);
        if (e2) {
          if (isNaN(n2.x))
            return r2;
          n2.x = s2.x - n2.x, n2.y = s2.y - n2.y;
          var a2, o2, h2 = 9;
          do {
            if (o2 = ht(n2, i2), isNaN(o2.x)) {
              console.log("Inverse grid shift iteration failed, presumably at grid edge.  Using first approximation.");
              break;
            }
            a2 = { x: s2.x - (o2.x + n2.x), y: s2.y - (o2.y + n2.y) }, n2.x += a2.x, n2.y += a2.y;
          } while (h2-- && Math.abs(a2.x) > 1e-12 && Math.abs(a2.y) > 1e-12);
          if (h2 < 0)
            return console.log("Inverse grid shift iterator failed to converge."), r2;
          r2.x = N(n2.x + i2.ll[0]), r2.y = n2.y + i2.ll[1];
        } else
          isNaN(n2.x) || (r2.x = t2.x + n2.x, r2.y = t2.y + n2.y);
        return r2;
      }
      function ht(t2, e2) {
        var i2, r2 = { x: t2.x / e2.del[0], y: t2.y / e2.del[1] }, s2 = Math.floor(r2.x), n2 = Math.floor(r2.y), a2 = r2.x - 1 * s2, o2 = r2.y - 1 * n2, h2 = { x: Number.NaN, y: Number.NaN };
        if (s2 < 0 || s2 >= e2.lim[0])
          return h2;
        if (n2 < 0 || n2 >= e2.lim[1])
          return h2;
        i2 = n2 * e2.lim[0] + s2;
        var u2 = e2.cvs[i2][0], l2 = e2.cvs[i2][1];
        i2++;
        var c2 = e2.cvs[i2][0], f2 = e2.cvs[i2][1];
        i2 += e2.lim[0];
        var d2 = e2.cvs[i2][0], p2 = e2.cvs[i2][1];
        i2--;
        var m2 = e2.cvs[i2][0], g2 = e2.cvs[i2][1], _2 = a2 * o2, y2 = a2 * (1 - o2), v2 = (1 - a2) * (1 - o2), b2 = (1 - a2) * o2;
        return h2.x = v2 * u2 + y2 * c2 + b2 * m2 + _2 * d2, h2.y = v2 * l2 + y2 * f2 + b2 * g2 + _2 * p2, h2;
      }
      var ut = function(t2, e2, i2) {
        var r2, s2, n2, a2 = i2.x, o2 = i2.y, h2 = i2.z || 0, u2 = {};
        for (n2 = 0; n2 < 3; n2++)
          if (!e2 || 2 !== n2 || void 0 !== i2.z)
            switch (0 === n2 ? (r2 = a2, s2 = -1 !== "ew".indexOf(t2.axis[n2]) ? "x" : "y") : 1 === n2 ? (r2 = o2, s2 = -1 !== "ns".indexOf(t2.axis[n2]) ? "y" : "x") : (r2 = h2, s2 = "z"), t2.axis[n2]) {
              case "e":
                u2[s2] = r2;
                break;
              case "w":
                u2[s2] = -r2;
                break;
              case "n":
                u2[s2] = r2;
                break;
              case "s":
                u2[s2] = -r2;
                break;
              case "u":
                void 0 !== i2[s2] && (u2.z = r2);
                break;
              case "d":
                void 0 !== i2[s2] && (u2.z = -r2);
                break;
              default:
                return null;
            }
        return u2;
      }, lt = function(t2) {
        var e2 = { x: t2[0], y: t2[1] };
        return t2.length > 2 && (e2.z = t2[2]), t2.length > 3 && (e2.m = t2[3]), e2;
      };
      function ct(t2) {
        if ("function" == typeof Number.isFinite) {
          if (Number.isFinite(t2))
            return;
          throw new TypeError("coordinates must be finite numbers");
        }
        if ("number" != typeof t2 || t2 != t2 || !isFinite(t2))
          throw new TypeError("coordinates must be finite numbers");
      }
      function ft(t2, e2, i2, r2) {
        var s2;
        if (Array.isArray(i2) && (i2 = lt(i2)), function(t3) {
          ct(t3.x), ct(t3.y);
        }(i2), t2.datum && e2.datum && function(t3, e3) {
          return (1 === t3.datum.datum_type || 2 === t3.datum.datum_type) && "WGS84" !== e3.datumCode || (1 === e3.datum.datum_type || 2 === e3.datum.datum_type) && "WGS84" !== t3.datumCode;
        }(t2, e2) && (i2 = ft(t2, s2 = new et("WGS84"), i2, r2), t2 = s2), r2 && "enu" !== t2.axis && (i2 = ut(t2, false, i2)), "longlat" === t2.projName)
          i2 = { x: i2.x * n, y: i2.y * n, z: i2.z || 0 };
        else if (t2.to_meter && (i2 = { x: i2.x * t2.to_meter, y: i2.y * t2.to_meter, z: i2.z || 0 }), !(i2 = t2.inverse(i2)))
          return;
        if (t2.from_greenwich && (i2.x += t2.from_greenwich), i2 = nt(t2.datum, e2.datum, i2))
          return e2.from_greenwich && (i2 = { x: i2.x - e2.from_greenwich, y: i2.y, z: i2.z || 0 }), "longlat" === e2.projName ? i2 = { x: i2.x * a, y: i2.y * a, z: i2.z || 0 } : (i2 = e2.forward(i2), e2.to_meter && (i2 = { x: i2.x / e2.to_meter, y: i2.y / e2.to_meter, z: i2.z || 0 })), r2 && "enu" !== e2.axis ? ut(e2, true, i2) : i2;
      }
      var dt = et("WGS84");
      function pt(t2, e2, i2, r2) {
        var s2, n2, a2;
        return Array.isArray(i2) ? (s2 = ft(t2, e2, i2, r2) || { x: NaN, y: NaN }, i2.length > 2 ? void 0 !== t2.name && "geocent" === t2.name || void 0 !== e2.name && "geocent" === e2.name ? "number" == typeof s2.z ? [s2.x, s2.y, s2.z].concat(i2.splice(3)) : [s2.x, s2.y, i2[2]].concat(i2.splice(3)) : [s2.x, s2.y].concat(i2.splice(2)) : [s2.x, s2.y]) : (n2 = ft(t2, e2, i2, r2), 2 === (a2 = Object.keys(i2)).length || a2.forEach(function(r3) {
          if (void 0 !== t2.name && "geocent" === t2.name || void 0 !== e2.name && "geocent" === e2.name) {
            if ("x" === r3 || "y" === r3 || "z" === r3)
              return;
          } else if ("x" === r3 || "y" === r3)
            return;
          n2[r3] = i2[r3];
        }), n2);
      }
      function mt(t2) {
        return t2 instanceof et ? t2 : t2.oProj ? t2.oProj : et(t2);
      }
      var gt = function(t2, e2, i2) {
        t2 = mt(t2);
        var r2, s2 = false;
        return void 0 === e2 ? (e2 = t2, t2 = dt, s2 = true) : (void 0 !== e2.x || Array.isArray(e2)) && (i2 = e2, e2 = t2, t2 = dt, s2 = true), e2 = mt(e2), i2 ? pt(t2, e2, i2) : (r2 = {
          forward: function(i3, r3) {
            return pt(t2, e2, i3, r3);
          },
          inverse: function(i3, r3) {
            return pt(e2, t2, i3, r3);
          }
        }, s2 && (r2.oProj = e2), r2);
      }, _t = 73, yt = 79, vt = {
        forward: bt,
        inverse: function(t2) {
          var e2 = kt(Ct(t2.toUpperCase()));
          if (e2.lat && e2.lon)
            return [e2.lon, e2.lat, e2.lon, e2.lat];
          return [e2.left, e2.bottom, e2.right, e2.top];
        },
        toPoint: wt
      };
      function bt(t2, e2) {
        return e2 = e2 || 5, function(t3, e3) {
          var i2 = "00000" + t3.easting, r2 = "00000" + t3.northing;
          return t3.zoneNumber + t3.zoneLetter + (d2 = t3.easting, p2 = t3.northing, m2 = t3.zoneNumber, g2 = Et(m2), _2 = Math.floor(d2 / 1e5), y2 = Math.floor(p2 / 1e5) % 20, s2 = _2, n2 = y2, a2 = g2, o2 = a2 - 1, h2 = "AJSAJS".charCodeAt(o2), u2 = "AFAFAF".charCodeAt(o2), l2 = h2 + s2 - 1, c2 = u2 + n2, f2 = false, l2 > 90 && (l2 = l2 - 90 + 65 - 1, f2 = true), (l2 === _t || h2 < _t && l2 > _t || (l2 > _t || h2 < _t) && f2) && l2++, (l2 === yt || h2 < yt && l2 > yt || (l2 > yt || h2 < yt) && f2) && ++l2 === _t && l2++, l2 > 90 && (l2 = l2 - 90 + 65 - 1), c2 > 86 ? (c2 = c2 - 86 + 65 - 1, f2 = true) : f2 = false, (c2 === _t || u2 < _t && c2 > _t || (c2 > _t || u2 < _t) && f2) && c2++, (c2 === yt || u2 < yt && c2 > yt || (c2 > yt || u2 < yt) && f2) && ++c2 === _t && c2++, c2 > 86 && (c2 = c2 - 86 + 65 - 1), String.fromCharCode(l2) + String.fromCharCode(c2)) + i2.substr(i2.length - 5, e3) + r2.substr(r2.length - 5, e3);
          var s2, n2, a2, o2, h2, u2, l2, c2, f2;
          var d2, p2, m2, g2, _2, y2;
        }(
          function(t3) {
            var e3, i2, r2, s2, n2, a2, o2, h2 = t3.lat, u2 = t3.lon, l2 = 6378137, c2 = Mt(h2), f2 = Mt(u2);
            o2 = Math.floor((u2 + 180) / 6) + 1, 180 === u2 && (o2 = 60);
            h2 >= 56 && h2 < 64 && u2 >= 3 && u2 < 12 && (o2 = 32);
            h2 >= 72 && h2 < 84 && (u2 >= 0 && u2 < 9 ? o2 = 31 : u2 >= 9 && u2 < 21 ? o2 = 33 : u2 >= 21 && u2 < 33 ? o2 = 35 : u2 >= 33 && u2 < 42 && (o2 = 37));
            a2 = Mt(6 * (o2 - 1) - 180 + 3), e3 = l2 / Math.sqrt(1 - 669438e-8 * Math.sin(c2) * Math.sin(c2)), i2 = Math.tan(c2) * Math.tan(c2), r2 = 0.006739496752268451 * Math.cos(c2) * Math.cos(c2), s2 = Math.cos(c2) * (f2 - a2), n2 = l2 * (0.9983242984503243 * c2 - 0.002514607064228144 * Math.sin(2 * c2) + 2639046602129982e-21 * Math.sin(4 * c2) - 3418046101696858e-24 * Math.sin(6 * c2));
            var d2 = 0.9996 * e3 * (s2 + (1 - i2 + r2) * s2 * s2 * s2 / 6 + (5 - 18 * i2 + i2 * i2 + 72 * r2 - 0.39089081163157013) * s2 * s2 * s2 * s2 * s2 / 120) + 5e5, p2 = 0.9996 * (n2 + e3 * Math.tan(c2) * (s2 * s2 / 2 + (5 - i2 + 9 * r2 + 4 * r2 * r2) * s2 * s2 * s2 * s2 / 24 + (61 - 58 * i2 + i2 * i2 + 600 * r2 - 2.2240339282485886) * s2 * s2 * s2 * s2 * s2 * s2 / 720));
            h2 < 0 && (p2 += 1e7);
            return { northing: Math.round(p2), easting: Math.round(d2), zoneNumber: o2, zoneLetter: St(h2) };
          }({ lat: t2[1], lon: t2[0] }),
          e2
        );
      }
      function wt(t2) {
        var e2 = kt(Ct(t2.toUpperCase()));
        return e2.lat && e2.lon ? [e2.lon, e2.lat] : [(e2.left + e2.right) / 2, (e2.top + e2.bottom) / 2];
      }
      function Mt(t2) {
        return t2 * (Math.PI / 180);
      }
      function xt(t2) {
        return t2 / Math.PI * 180;
      }
      function kt(t2) {
        var e2 = t2.northing, i2 = t2.easting, r2 = t2.zoneLetter, s2 = t2.zoneNumber;
        if (s2 < 0 || s2 > 60)
          return null;
        var n2, a2, o2, h2, u2, l2, c2, f2, d2 = 6378137, p2 = (1 - Math.sqrt(0.99330562)) / (1 + Math.sqrt(0.99330562)), m2 = i2 - 5e5, g2 = e2;
        r2 < "N" && (g2 -= 1e7), l2 = 6 * (s2 - 1) - 180 + 3, f2 = (c2 = g2 / 0.9996 / 6367449145945056e-9) + (3 * p2 / 2 - 27 * p2 * p2 * p2 / 32) * Math.sin(2 * c2) + (21 * p2 * p2 / 16 - 55 * p2 * p2 * p2 * p2 / 32) * Math.sin(4 * c2) + 151 * p2 * p2 * p2 / 96 * Math.sin(6 * c2), n2 = d2 / Math.sqrt(1 - 669438e-8 * Math.sin(f2) * Math.sin(f2)), a2 = Math.tan(f2) * Math.tan(f2), o2 = 0.006739496752268451 * Math.cos(f2) * Math.cos(f2), h2 = 0.99330562 * d2 / Math.pow(1 - 669438e-8 * Math.sin(f2) * Math.sin(f2), 1.5), u2 = m2 / (0.9996 * n2);
        var _2 = f2 - n2 * Math.tan(f2) / h2 * (u2 * u2 / 2 - (5 + 3 * a2 + 10 * o2 - 4 * o2 * o2 - 0.06065547077041606) * u2 * u2 * u2 * u2 / 24 + (61 + 90 * a2 + 298 * o2 + 45 * a2 * a2 - 1.6983531815716497 - 3 * o2 * o2) * u2 * u2 * u2 * u2 * u2 * u2 / 720);
        _2 = xt(_2);
        var y2, v2 = (u2 - (1 + 2 * a2 + o2) * u2 * u2 * u2 / 6 + (5 - 2 * o2 + 28 * a2 - 3 * o2 * o2 + 0.05391597401814761 + 24 * a2 * a2) * u2 * u2 * u2 * u2 * u2 / 120) / Math.cos(f2);
        if (v2 = l2 + xt(v2), t2.accuracy) {
          var b2 = kt({ northing: t2.northing + t2.accuracy, easting: t2.easting + t2.accuracy, zoneLetter: t2.zoneLetter, zoneNumber: t2.zoneNumber });
          y2 = { top: b2.lat, right: b2.lon, bottom: _2, left: v2 };
        } else
          y2 = { lat: _2, lon: v2 };
        return y2;
      }
      function St(t2) {
        var e2 = "Z";
        return 84 >= t2 && t2 >= 72 ? e2 = "X" : 72 > t2 && t2 >= 64 ? e2 = "W" : 64 > t2 && t2 >= 56 ? e2 = "V" : 56 > t2 && t2 >= 48 ? e2 = "U" : 48 > t2 && t2 >= 40 ? e2 = "T" : 40 > t2 && t2 >= 32 ? e2 = "S" : 32 > t2 && t2 >= 24 ? e2 = "R" : 24 > t2 && t2 >= 16 ? e2 = "Q" : 16 > t2 && t2 >= 8 ? e2 = "P" : 8 > t2 && t2 >= 0 ? e2 = "N" : 0 > t2 && t2 >= -8 ? e2 = "M" : -8 > t2 && t2 >= -16 ? e2 = "L" : -16 > t2 && t2 >= -24 ? e2 = "K" : -24 > t2 && t2 >= -32 ? e2 = "J" : -32 > t2 && t2 >= -40 ? e2 = "H" : -40 > t2 && t2 >= -48 ? e2 = "G" : -48 > t2 && t2 >= -56 ? e2 = "F" : -56 > t2 && t2 >= -64 ? e2 = "E" : -64 > t2 && t2 >= -72 ? e2 = "D" : -72 > t2 && t2 >= -80 && (e2 = "C"), e2;
      }
      function Et(t2) {
        var e2 = t2 % 6;
        return 0 === e2 && (e2 = 6), e2;
      }
      function Ct(t2) {
        if (t2 && 0 === t2.length)
          throw "MGRSPoint coverting from nothing";
        for (var e2, i2 = t2.length, r2 = null, s2 = "", n2 = 0; !/[A-Z]/.test(e2 = t2.charAt(n2)); ) {
          if (n2 >= 2)
            throw "MGRSPoint bad conversion from: " + t2;
          s2 += e2, n2++;
        }
        var a2 = parseInt(s2, 10);
        if (0 === n2 || n2 + 3 > i2)
          throw "MGRSPoint bad conversion from: " + t2;
        var o2 = t2.charAt(n2++);
        if (o2 <= "A" || "B" === o2 || "Y" === o2 || o2 >= "Z" || "I" === o2 || "O" === o2)
          throw "MGRSPoint zone letter " + o2 + " not handled: " + t2;
        r2 = t2.substring(n2, n2 += 2);
        for (var h2 = Et(a2), u2 = function(t3, e3) {
          var i3 = "AJSAJS".charCodeAt(e3 - 1), r3 = 1e5, s3 = false;
          for (; i3 !== t3.charCodeAt(0); ) {
            if (++i3 === _t && i3++, i3 === yt && i3++, i3 > 90) {
              if (s3)
                throw "Bad character: " + t3;
              i3 = 65, s3 = true;
            }
            r3 += 1e5;
          }
          return r3;
        }(r2.charAt(0), h2), l2 = function(t3, e3) {
          if (t3 > "V")
            throw "MGRSPoint given invalid Northing " + t3;
          var i3 = "AFAFAF".charCodeAt(e3 - 1), r3 = 0, s3 = false;
          for (; i3 !== t3.charCodeAt(0); ) {
            if (++i3 === _t && i3++, i3 === yt && i3++, i3 > 86) {
              if (s3)
                throw "Bad character: " + t3;
              i3 = 65, s3 = true;
            }
            r3 += 1e5;
          }
          return r3;
        }(r2.charAt(1), h2); l2 < At(o2); )
          l2 += 2e6;
        var c2 = i2 - n2;
        if (c2 % 2 != 0)
          throw "MGRSPoint has to have an even number \nof digits after the zone letter and two 100km letters - front \nhalf for easting meters, second half for \nnorthing meters" + t2;
        var f2, d2, p2, m2 = c2 / 2, g2 = 0, _2 = 0;
        return m2 > 0 && (f2 = 1e5 / Math.pow(10, m2), d2 = t2.substring(n2, n2 + m2), g2 = parseFloat(d2) * f2, p2 = t2.substring(n2 + m2), _2 = parseFloat(p2) * f2), { easting: g2 + u2, northing: _2 + l2, zoneLetter: o2, zoneNumber: a2, accuracy: f2 };
      }
      function At(t2) {
        var e2;
        switch (t2) {
          case "C":
            e2 = 11e5;
            break;
          case "D":
            e2 = 2e6;
            break;
          case "E":
            e2 = 28e5;
            break;
          case "F":
            e2 = 37e5;
            break;
          case "G":
            e2 = 46e5;
            break;
          case "H":
            e2 = 55e5;
            break;
          case "J":
            e2 = 64e5;
            break;
          case "K":
            e2 = 73e5;
            break;
          case "L":
            e2 = 82e5;
            break;
          case "M":
            e2 = 91e5;
            break;
          case "N":
            e2 = 0;
            break;
          case "P":
            e2 = 8e5;
            break;
          case "Q":
            e2 = 17e5;
            break;
          case "R":
            e2 = 26e5;
            break;
          case "S":
            e2 = 35e5;
            break;
          case "T":
            e2 = 44e5;
            break;
          case "U":
            e2 = 53e5;
            break;
          case "V":
            e2 = 62e5;
            break;
          case "W":
            e2 = 7e6;
            break;
          case "X":
            e2 = 79e5;
            break;
          default:
            e2 = -1;
        }
        if (e2 >= 0)
          return e2;
        throw "Invalid zone letter: " + t2;
      }
      function It(t2, e2, i2) {
        if (!(this instanceof It))
          return new It(t2, e2, i2);
        if (Array.isArray(t2))
          this.x = t2[0], this.y = t2[1], this.z = t2[2] || 0;
        else if ("object" == typeof t2)
          this.x = t2.x, this.y = t2.y, this.z = t2.z || 0;
        else if ("string" == typeof t2 && void 0 === e2) {
          var r2 = t2.split(",");
          this.x = parseFloat(r2[0], 10), this.y = parseFloat(r2[1], 10), this.z = parseFloat(r2[2], 10) || 0;
        } else
          this.x = t2, this.y = e2, this.z = i2 || 0;
        console.warn("proj4.Point will be removed in version 3, use proj4.toPoint");
      }
      It.fromMGRS = function(t2) {
        return new It(wt(t2));
      }, It.prototype.toMGRS = function(t2) {
        return bt([this.x, this.y], t2);
      };
      var Ot = It, Tt = 0.01068115234375, zt = function(t2) {
        var e2 = [];
        e2[0] = 1 - t2 * (0.25 + t2 * (0.046875 + t2 * (0.01953125 + t2 * Tt))), e2[1] = t2 * (0.75 - t2 * (0.046875 + t2 * (0.01953125 + t2 * Tt)));
        var i2 = t2 * t2;
        return e2[2] = i2 * (0.46875 - t2 * (0.013020833333333334 + 0.007120768229166667 * t2)), i2 *= t2, e2[3] = i2 * (0.3645833333333333 - 0.005696614583333333 * t2), e2[4] = i2 * t2 * 0.3076171875, e2;
      }, Pt = function(t2, e2, i2, r2) {
        return i2 *= e2, e2 *= e2, r2[0] * t2 - i2 * (r2[1] + e2 * (r2[2] + e2 * (r2[3] + e2 * r2[4])));
      }, Nt = function(t2, e2, i2) {
        for (var r2 = 1 / (1 - e2), s2 = t2, n2 = 20; n2; --n2) {
          var a2 = Math.sin(s2), o2 = 1 - e2 * a2 * a2;
          if (s2 -= o2 = (Pt(s2, a2, Math.cos(s2), i2) - t2) * (o2 * Math.sqrt(o2)) * r2, Math.abs(o2) < 1e-10)
            return s2;
        }
        return s2;
      };
      var Lt = {
        init: function() {
          this.x0 = void 0 !== this.x0 ? this.x0 : 0, this.y0 = void 0 !== this.y0 ? this.y0 : 0, this.long0 = void 0 !== this.long0 ? this.long0 : 0, this.lat0 = void 0 !== this.lat0 ? this.lat0 : 0, this.es && (this.en = zt(this.es), this.ml0 = Pt(this.lat0, Math.sin(this.lat0), Math.cos(this.lat0), this.en));
        },
        forward: function(t2) {
          var e2, i2, r2, s2 = t2.x, n2 = t2.y, a2 = N(s2 - this.long0), o2 = Math.sin(n2), h2 = Math.cos(n2);
          if (this.es) {
            var u2 = h2 * a2, l2 = Math.pow(u2, 2), c2 = this.ep2 * Math.pow(h2, 2), f2 = Math.pow(c2, 2), d2 = Math.abs(h2) > 1e-10 ? Math.tan(n2) : 0, p2 = Math.pow(d2, 2), m2 = Math.pow(p2, 2);
            e2 = 1 - this.es * Math.pow(o2, 2), u2 /= Math.sqrt(e2);
            var g2 = Pt(n2, o2, h2, this.en);
            i2 = this.a * (this.k0 * u2 * (1 + l2 / 6 * (1 - p2 + c2 + l2 / 20 * (5 - 18 * p2 + m2 + 14 * c2 - 58 * p2 * c2 + l2 / 42 * (61 + 179 * m2 - m2 * p2 - 479 * p2))))) + this.x0, r2 = this.a * (this.k0 * (g2 - this.ml0 + o2 * a2 * u2 / 2 * (1 + l2 / 12 * (5 - p2 + 9 * c2 + 4 * f2 + l2 / 30 * (61 + m2 - 58 * p2 + 270 * c2 - 330 * p2 * c2 + l2 / 56 * (1385 + 543 * m2 - m2 * p2 - 3111 * p2)))))) + this.y0;
          } else {
            var _2 = h2 * Math.sin(a2);
            if (Math.abs(Math.abs(_2) - 1) < 1e-10)
              return 93;
            if (i2 = 0.5 * this.a * this.k0 * Math.log((1 + _2) / (1 - _2)) + this.x0, r2 = h2 * Math.cos(a2) / Math.sqrt(1 - Math.pow(_2, 2)), (_2 = Math.abs(r2)) >= 1) {
              if (_2 - 1 > 1e-10)
                return 93;
              r2 = 0;
            } else
              r2 = Math.acos(r2);
            n2 < 0 && (r2 = -r2), r2 = this.a * this.k0 * (r2 - this.lat0) + this.y0;
          }
          return t2.x = i2, t2.y = r2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2 = (t2.x - this.x0) * (1 / this.a), o2 = (t2.y - this.y0) * (1 / this.a);
          if (this.es)
            if (e2 = this.ml0 + o2 / this.k0, i2 = Nt(e2, this.es, this.en), Math.abs(i2) < s) {
              var h2 = Math.sin(i2), u2 = Math.cos(i2), l2 = Math.abs(u2) > 1e-10 ? Math.tan(i2) : 0, c2 = this.ep2 * Math.pow(u2, 2), f2 = Math.pow(c2, 2), d2 = Math.pow(l2, 2), p2 = Math.pow(d2, 2);
              e2 = 1 - this.es * Math.pow(h2, 2);
              var m2 = a2 * Math.sqrt(e2) / this.k0, g2 = Math.pow(m2, 2);
              r2 = i2 - (e2 *= l2) * g2 / (1 - this.es) * 0.5 * (1 - g2 / 12 * (5 + 3 * d2 - 9 * c2 * d2 + c2 - 4 * f2 - g2 / 30 * (61 + 90 * d2 - 252 * c2 * d2 + 45 * p2 + 46 * c2 - g2 / 56 * (1385 + 3633 * d2 + 4095 * p2 + 1574 * p2 * d2)))), n2 = N(this.long0 + m2 * (1 - g2 / 6 * (1 + 2 * d2 + c2 - g2 / 20 * (5 + 28 * d2 + 24 * p2 + 8 * c2 * d2 + 6 * c2 - g2 / 42 * (61 + 662 * d2 + 1320 * p2 + 720 * p2 * d2)))) / u2);
            } else
              r2 = s * P(o2), n2 = 0;
          else {
            var _2 = Math.exp(a2 / this.k0), y2 = 0.5 * (_2 - 1 / _2), v2 = this.lat0 + o2 / this.k0, b2 = Math.cos(v2);
            e2 = Math.sqrt((1 - Math.pow(b2, 2)) / (1 + Math.pow(y2, 2))), r2 = Math.asin(e2), o2 < 0 && (r2 = -r2), n2 = 0 === y2 && 0 === b2 ? 0 : N(Math.atan2(y2, b2) + this.long0);
          }
          return t2.x = n2, t2.y = r2, t2;
        },
        names: ["Fast_Transverse_Mercator", "Fast Transverse Mercator"]
      }, Rt = function(t2) {
        var e2 = Math.exp(t2);
        return e2 = (e2 - 1 / e2) / 2;
      }, Bt = function(t2, e2) {
        t2 = Math.abs(t2), e2 = Math.abs(e2);
        var i2 = Math.max(t2, e2), r2 = Math.min(t2, e2) / (i2 || 1);
        return i2 * Math.sqrt(1 + Math.pow(r2, 2));
      }, Dt = function(t2) {
        var e2 = Math.abs(t2);
        return e2 = function(t3) {
          var e3 = 1 + t3, i2 = e3 - 1;
          return 0 === i2 ? t3 : t3 * Math.log(e3) / i2;
        }(e2 * (1 + e2 / (Bt(1, e2) + 1))), t2 < 0 ? -e2 : e2;
      }, jt = function(t2, e2) {
        for (var i2, r2 = 2 * Math.cos(2 * e2), s2 = t2.length - 1, n2 = t2[s2], a2 = 0; --s2 >= 0; )
          i2 = r2 * n2 - a2 + t2[s2], a2 = n2, n2 = i2;
        return e2 + i2 * Math.sin(2 * e2);
      }, Ut = function(t2, e2, i2) {
        for (var r2, s2, n2 = Math.sin(e2), a2 = Math.cos(e2), o2 = Rt(i2), h2 = function(t3) {
          var e3 = Math.exp(t3);
          return e3 = (e3 + 1 / e3) / 2;
        }(i2), u2 = 2 * a2 * h2, l2 = -2 * n2 * o2, c2 = t2.length - 1, f2 = t2[c2], d2 = 0, p2 = 0, m2 = 0; --c2 >= 0; )
          r2 = p2, s2 = d2, f2 = u2 * (p2 = f2) - r2 - l2 * (d2 = m2) + t2[c2], m2 = l2 * p2 - s2 + u2 * d2;
        return [(u2 = n2 * h2) * f2 - (l2 = a2 * o2) * m2, u2 * m2 + l2 * f2];
      };
      var Ft = {
        init: function() {
          if (!this.approx && (isNaN(this.es) || this.es <= 0))
            throw new Error('Incorrect elliptical usage. Try using the +approx option in the proj string, or PROJECTION["Fast_Transverse_Mercator"] in the WKT.');
          this.approx && (Lt.init.apply(this), this.forward = Lt.forward, this.inverse = Lt.inverse), this.x0 = void 0 !== this.x0 ? this.x0 : 0, this.y0 = void 0 !== this.y0 ? this.y0 : 0, this.long0 = void 0 !== this.long0 ? this.long0 : 0, this.lat0 = void 0 !== this.lat0 ? this.lat0 : 0, this.cgb = [], this.cbg = [], this.utg = [], this.gtu = [];
          var t2 = this.es / (1 + Math.sqrt(1 - this.es)), e2 = t2 / (2 - t2), i2 = e2;
          this.cgb[0] = e2 * (2 + e2 * (-2 / 3 + e2 * (e2 * (116 / 45 + e2 * (26 / 45 + e2 * (-2854 / 675))) - 2))), this.cbg[0] = e2 * (e2 * (2 / 3 + e2 * (4 / 3 + e2 * (-82 / 45 + e2 * (32 / 45 + e2 * (4642 / 4725))))) - 2), i2 *= e2, this.cgb[1] = i2 * (7 / 3 + e2 * (e2 * (-227 / 45 + e2 * (2704 / 315 + e2 * (2323 / 945))) - 1.6)), this.cbg[1] = i2 * (5 / 3 + e2 * (-16 / 15 + e2 * (-13 / 9 + e2 * (904 / 315 + e2 * (-1522 / 945))))), i2 *= e2, this.cgb[2] = i2 * (56 / 15 + e2 * (-136 / 35 + e2 * (-1262 / 105 + e2 * (73814 / 2835)))), this.cbg[2] = i2 * (-26 / 15 + e2 * (34 / 21 + e2 * (1.6 + e2 * (-12686 / 2835)))), i2 *= e2, this.cgb[3] = i2 * (4279 / 630 + e2 * (-332 / 35 + e2 * (-399572 / 14175))), this.cbg[3] = i2 * (1237 / 630 + e2 * (e2 * (-24832 / 14175) - 2.4)), i2 *= e2, this.cgb[4] = i2 * (4174 / 315 + e2 * (-144838 / 6237)), this.cbg[4] = i2 * (-734 / 315 + e2 * (109598 / 31185)), i2 *= e2, this.cgb[5] = i2 * (601676 / 22275), this.cbg[5] = i2 * (444337 / 155925), i2 = Math.pow(e2, 2), this.Qn = this.k0 / (1 + e2) * (1 + i2 * (1 / 4 + i2 * (1 / 64 + i2 / 256))), this.utg[0] = e2 * (e2 * (2 / 3 + e2 * (-37 / 96 + e2 * (1 / 360 + e2 * (81 / 512 + e2 * (-96199 / 604800))))) - 0.5), this.gtu[0] = e2 * (0.5 + e2 * (-2 / 3 + e2 * (5 / 16 + e2 * (41 / 180 + e2 * (-127 / 288 + e2 * (7891 / 37800)))))), this.utg[1] = i2 * (-1 / 48 + e2 * (-1 / 15 + e2 * (437 / 1440 + e2 * (-46 / 105 + e2 * (1118711 / 3870720))))), this.gtu[1] = i2 * (13 / 48 + e2 * (e2 * (557 / 1440 + e2 * (281 / 630 + e2 * (-1983433 / 1935360))) - 0.6)), i2 *= e2, this.utg[2] = i2 * (-17 / 480 + e2 * (37 / 840 + e2 * (209 / 4480 + e2 * (-5569 / 90720)))), this.gtu[2] = i2 * (61 / 240 + e2 * (-103 / 140 + e2 * (15061 / 26880 + e2 * (167603 / 181440)))), i2 *= e2, this.utg[3] = i2 * (-4397 / 161280 + e2 * (11 / 504 + e2 * (830251 / 7257600))), this.gtu[3] = i2 * (49561 / 161280 + e2 * (-179 / 168 + e2 * (6601661 / 7257600))), i2 *= e2, this.utg[4] = i2 * (-4583 / 161280 + e2 * (108847 / 3991680)), this.gtu[4] = i2 * (34729 / 80640 + e2 * (-3418889 / 1995840)), i2 *= e2, this.utg[5] = i2 * (-20648693 / 638668800), this.gtu[5] = 0.6650675310896665 * i2;
          var r2 = jt(this.cbg, this.lat0);
          this.Zb = -this.Qn * (r2 + function(t3, e3) {
            for (var i3, r3 = 2 * Math.cos(e3), s2 = t3.length - 1, n2 = t3[s2], a2 = 0; --s2 >= 0; )
              i3 = r3 * n2 - a2 + t3[s2], a2 = n2, n2 = i3;
            return Math.sin(e3) * i3;
          }(this.gtu, 2 * r2));
        },
        forward: function(t2) {
          var e2 = N(t2.x - this.long0), i2 = t2.y;
          i2 = jt(this.cbg, i2);
          var r2 = Math.sin(i2), s2 = Math.cos(i2), n2 = Math.sin(e2), a2 = Math.cos(e2);
          i2 = Math.atan2(r2, a2 * s2), e2 = Math.atan2(n2 * s2, Bt(r2, s2 * a2)), e2 = Dt(Math.tan(e2));
          var o2, h2, u2 = Ut(this.gtu, 2 * i2, 2 * e2);
          return i2 += u2[0], e2 += u2[1], Math.abs(e2) <= 2.623395162778 ? (o2 = this.a * (this.Qn * e2) + this.x0, h2 = this.a * (this.Qn * i2 + this.Zb) + this.y0) : (o2 = 1 / 0, h2 = 1 / 0), t2.x = o2, t2.y = h2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2 = (t2.x - this.x0) * (1 / this.a), s2 = (t2.y - this.y0) * (1 / this.a);
          if (s2 = (s2 - this.Zb) / this.Qn, r2 /= this.Qn, Math.abs(r2) <= 2.623395162778) {
            var n2 = Ut(this.utg, 2 * s2, 2 * r2);
            s2 += n2[0], r2 += n2[1], r2 = Math.atan(Rt(r2));
            var a2 = Math.sin(s2), o2 = Math.cos(s2), h2 = Math.sin(r2), u2 = Math.cos(r2);
            s2 = Math.atan2(a2 * u2, Bt(h2, u2 * o2)), r2 = Math.atan2(h2, u2 * o2), e2 = N(r2 + this.long0), i2 = jt(this.cgb, s2);
          } else
            e2 = 1 / 0, i2 = 1 / 0;
          return t2.x = e2, t2.y = i2, t2;
        },
        names: ["Extended_Transverse_Mercator", "Extended Transverse Mercator", "etmerc", "Transverse_Mercator", "Transverse Mercator", "tmerc"]
      };
      var qt = {
        init: function() {
          var t2 = function(t3, e2) {
            if (void 0 === t3) {
              if ((t3 = Math.floor(30 * (N(e2) + Math.PI) / Math.PI) + 1) < 0)
                return 0;
              if (t3 > 60)
                return 60;
            }
            return t3;
          }(this.zone, this.long0);
          if (void 0 === t2)
            throw new Error("unknown utm zone");
          this.lat0 = 0, this.long0 = (6 * Math.abs(t2) - 183) * n, this.x0 = 5e5, this.y0 = this.utmSouth ? 1e7 : 0, this.k0 = 0.9996, Ft.init.apply(this), this.forward = Ft.forward, this.inverse = Ft.inverse;
        },
        names: ["Universal Transverse Mercator System", "utm"],
        dependsOn: "etmerc"
      }, Gt = function(t2, e2) {
        return Math.pow((1 - t2) / (1 + t2), e2);
      };
      var Wt = {
        init: function() {
          var t2 = Math.sin(this.lat0), e2 = Math.cos(this.lat0);
          e2 *= e2, this.rc = Math.sqrt(1 - this.es) / (1 - this.es * t2 * t2), this.C = Math.sqrt(1 + this.es * e2 * e2 / (1 - this.es)), this.phic0 = Math.asin(t2 / this.C), this.ratexp = 0.5 * this.C * this.e, this.K = Math.tan(0.5 * this.phic0 + o) / (Math.pow(Math.tan(0.5 * this.lat0 + o), this.C) * Gt(this.e * t2, this.ratexp));
        },
        forward: function(t2) {
          var e2 = t2.x, i2 = t2.y;
          return t2.y = 2 * Math.atan(this.K * Math.pow(Math.tan(0.5 * i2 + o), this.C) * Gt(this.e * Math.sin(i2), this.ratexp)) - s, t2.x = this.C * e2, t2;
        },
        inverse: function(t2) {
          for (var e2 = t2.x / this.C, i2 = t2.y, r2 = Math.pow(Math.tan(0.5 * i2 + o) / this.K, 1 / this.C), n2 = 20; n2 > 0 && (i2 = 2 * Math.atan(r2 * Gt(this.e * Math.sin(t2.y), -0.5 * this.e)) - s, !(Math.abs(i2 - t2.y) < 1e-14)); --n2)
            t2.y = i2;
          return n2 ? (t2.x = e2, t2.y = i2, t2) : null;
        },
        names: ["gauss"]
      };
      var Zt = {
        init: function() {
          Wt.init.apply(this), this.rc && (this.sinc0 = Math.sin(this.phic0), this.cosc0 = Math.cos(this.phic0), this.R2 = 2 * this.rc, this.title || (this.title = "Oblique Stereographic Alternative"));
        },
        forward: function(t2) {
          var e2, i2, r2, s2;
          return t2.x = N(t2.x - this.long0), Wt.forward.apply(this, [t2]), e2 = Math.sin(t2.y), i2 = Math.cos(t2.y), r2 = Math.cos(t2.x), s2 = this.k0 * this.R2 / (1 + this.sinc0 * e2 + this.cosc0 * i2 * r2), t2.x = s2 * i2 * Math.sin(t2.x), t2.y = s2 * (this.cosc0 * e2 - this.sinc0 * i2 * r2), t2.x = this.a * t2.x + this.x0, t2.y = this.a * t2.y + this.y0, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2;
          if (t2.x = (t2.x - this.x0) / this.a, t2.y = (t2.y - this.y0) / this.a, t2.x /= this.k0, t2.y /= this.k0, n2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y)) {
            var a2 = 2 * Math.atan2(n2, this.R2);
            e2 = Math.sin(a2), i2 = Math.cos(a2), s2 = Math.asin(i2 * this.sinc0 + t2.y * e2 * this.cosc0 / n2), r2 = Math.atan2(t2.x * e2, n2 * this.cosc0 * i2 - t2.y * this.sinc0 * e2);
          } else
            s2 = this.phic0, r2 = 0;
          return t2.x = r2, t2.y = s2, Wt.inverse.apply(this, [t2]), t2.x = N(t2.x + this.long0), t2;
        },
        names: ["Stereographic_North_Pole", "Oblique_Stereographic", "Polar_Stereographic", "sterea", "Oblique Stereographic Alternative", "Double_Stereographic"]
      };
      var Ht = {
        init: function() {
          this.coslat0 = Math.cos(this.lat0), this.sinlat0 = Math.sin(this.lat0), this.sphere ? 1 === this.k0 && !isNaN(this.lat_ts) && Math.abs(this.coslat0) <= 1e-10 && (this.k0 = 0.5 * (1 + P(this.lat0) * Math.sin(this.lat_ts))) : (Math.abs(this.coslat0) <= 1e-10 && (this.lat0 > 0 ? this.con = 1 : this.con = -1), this.cons = Math.sqrt(Math.pow(1 + this.e, 1 + this.e) * Math.pow(1 - this.e, 1 - this.e)), 1 === this.k0 && !isNaN(this.lat_ts) && Math.abs(this.coslat0) <= 1e-10 && (this.k0 = 0.5 * this.cons * z(this.e, Math.sin(this.lat_ts), Math.cos(this.lat_ts)) / L(this.e, this.con * this.lat_ts, this.con * Math.sin(this.lat_ts))), this.ms1 = z(this.e, this.sinlat0, this.coslat0), this.X0 = 2 * Math.atan(this.ssfn_(this.lat0, this.sinlat0, this.e)) - s, this.cosX0 = Math.cos(this.X0), this.sinX0 = Math.sin(this.X0));
        },
        forward: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2 = t2.x, u2 = t2.y, l2 = Math.sin(u2), c2 = Math.cos(u2), f2 = N(h2 - this.long0);
          return Math.abs(Math.abs(h2 - this.long0) - Math.PI) <= 1e-10 && Math.abs(u2 + this.lat0) <= 1e-10 ? (t2.x = NaN, t2.y = NaN, t2) : this.sphere ? (e2 = 2 * this.k0 / (1 + this.sinlat0 * l2 + this.coslat0 * c2 * Math.cos(f2)), t2.x = this.a * e2 * c2 * Math.sin(f2) + this.x0, t2.y = this.a * e2 * (this.coslat0 * l2 - this.sinlat0 * c2 * Math.cos(f2)) + this.y0, t2) : (i2 = 2 * Math.atan(this.ssfn_(u2, l2, this.e)) - s, n2 = Math.cos(i2), r2 = Math.sin(i2), Math.abs(this.coslat0) <= 1e-10 ? (a2 = L(this.e, u2 * this.con, this.con * l2), o2 = 2 * this.a * this.k0 * a2 / this.cons, t2.x = this.x0 + o2 * Math.sin(h2 - this.long0), t2.y = this.y0 - this.con * o2 * Math.cos(h2 - this.long0), t2) : (Math.abs(this.sinlat0) < 1e-10 ? (e2 = 2 * this.a * this.k0 / (1 + n2 * Math.cos(f2)), t2.y = e2 * r2) : (e2 = 2 * this.a * this.k0 * this.ms1 / (this.cosX0 * (1 + this.sinX0 * r2 + this.cosX0 * n2 * Math.cos(f2))), t2.y = e2 * (this.cosX0 * r2 - this.sinX0 * n2 * Math.cos(f2)) + this.y0), t2.x = e2 * n2 * Math.sin(f2) + this.x0, t2));
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2;
          t2.x -= this.x0, t2.y -= this.y0;
          var o2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y);
          if (this.sphere) {
            var h2 = 2 * Math.atan(o2 / (2 * this.a * this.k0));
            return e2 = this.long0, i2 = this.lat0, o2 <= 1e-10 ? (t2.x = e2, t2.y = i2, t2) : (i2 = Math.asin(Math.cos(h2) * this.sinlat0 + t2.y * Math.sin(h2) * this.coslat0 / o2), e2 = Math.abs(this.coslat0) < 1e-10 ? this.lat0 > 0 ? N(this.long0 + Math.atan2(t2.x, -1 * t2.y)) : N(this.long0 + Math.atan2(t2.x, t2.y)) : N(this.long0 + Math.atan2(t2.x * Math.sin(h2), o2 * this.coslat0 * Math.cos(h2) - t2.y * this.sinlat0 * Math.sin(h2))), t2.x = e2, t2.y = i2, t2);
          }
          if (Math.abs(this.coslat0) <= 1e-10) {
            if (o2 <= 1e-10)
              return i2 = this.lat0, e2 = this.long0, t2.x = e2, t2.y = i2, t2;
            t2.x *= this.con, t2.y *= this.con, r2 = o2 * this.cons / (2 * this.a * this.k0), i2 = this.con * R(this.e, r2), e2 = this.con * N(this.con * this.long0 + Math.atan2(t2.x, -1 * t2.y));
          } else
            n2 = 2 * Math.atan(o2 * this.cosX0 / (2 * this.a * this.k0 * this.ms1)), e2 = this.long0, o2 <= 1e-10 ? a2 = this.X0 : (a2 = Math.asin(Math.cos(n2) * this.sinX0 + t2.y * Math.sin(n2) * this.cosX0 / o2), e2 = N(this.long0 + Math.atan2(t2.x * Math.sin(n2), o2 * this.cosX0 * Math.cos(n2) - t2.y * this.sinX0 * Math.sin(n2)))), i2 = -1 * R(this.e, Math.tan(0.5 * (s + a2)));
          return t2.x = e2, t2.y = i2, t2;
        },
        names: ["stere", "Stereographic_South_Pole", "Polar Stereographic (variant B)"],
        ssfn_: function(t2, e2, i2) {
          return e2 *= i2, Math.tan(0.5 * (s + t2)) * Math.pow((1 - e2) / (1 + e2), 0.5 * i2);
        }
      };
      var Yt = {
        init: function() {
          var t2 = this.lat0;
          this.lambda0 = this.long0;
          var e2 = Math.sin(t2), i2 = this.a, r2 = 1 / this.rf, s2 = 2 * r2 - Math.pow(r2, 2), n2 = this.e = Math.sqrt(s2);
          this.R = this.k0 * i2 * Math.sqrt(1 - s2) / (1 - s2 * Math.pow(e2, 2)), this.alpha = Math.sqrt(1 + s2 / (1 - s2) * Math.pow(Math.cos(t2), 4)), this.b0 = Math.asin(e2 / this.alpha);
          var a2 = Math.log(Math.tan(Math.PI / 4 + this.b0 / 2)), o2 = Math.log(Math.tan(Math.PI / 4 + t2 / 2)), h2 = Math.log((1 + n2 * e2) / (1 - n2 * e2));
          this.K = a2 - this.alpha * o2 + this.alpha * n2 / 2 * h2;
        },
        forward: function(t2) {
          var e2 = Math.log(Math.tan(Math.PI / 4 - t2.y / 2)), i2 = this.e / 2 * Math.log((1 + this.e * Math.sin(t2.y)) / (1 - this.e * Math.sin(t2.y))), r2 = -this.alpha * (e2 + i2) + this.K, s2 = 2 * (Math.atan(Math.exp(r2)) - Math.PI / 4), n2 = this.alpha * (t2.x - this.lambda0), a2 = Math.atan(Math.sin(n2) / (Math.sin(this.b0) * Math.tan(s2) + Math.cos(this.b0) * Math.cos(n2))), o2 = Math.asin(Math.cos(this.b0) * Math.sin(s2) - Math.sin(this.b0) * Math.cos(s2) * Math.cos(n2));
          return t2.y = this.R / 2 * Math.log((1 + Math.sin(o2)) / (1 - Math.sin(o2))) + this.y0, t2.x = this.R * a2 + this.x0, t2;
        },
        inverse: function(t2) {
          for (var e2 = t2.x - this.x0, i2 = t2.y - this.y0, r2 = e2 / this.R, s2 = 2 * (Math.atan(Math.exp(i2 / this.R)) - Math.PI / 4), n2 = Math.asin(Math.cos(this.b0) * Math.sin(s2) + Math.sin(this.b0) * Math.cos(s2) * Math.cos(r2)), a2 = Math.atan(Math.sin(r2) / (Math.cos(this.b0) * Math.cos(r2) - Math.sin(this.b0) * Math.tan(s2))), o2 = this.lambda0 + a2 / this.alpha, h2 = 0, u2 = n2, l2 = -1e3, c2 = 0; Math.abs(u2 - l2) > 1e-7; ) {
            if (++c2 > 20)
              return;
            h2 = 1 / this.alpha * (Math.log(Math.tan(Math.PI / 4 + n2 / 2)) - this.K) + this.e * Math.log(Math.tan(Math.PI / 4 + Math.asin(this.e * Math.sin(u2)) / 2)), l2 = u2, u2 = 2 * Math.atan(Math.exp(h2)) - Math.PI / 2;
          }
          return t2.x = o2, t2.y = u2, t2;
        },
        names: ["somerc"]
      };
      var Xt = {
        init: function() {
          var t2, e2, i2, r2, a2, u2, l2, c2, f2, d2, p2, m2, g2, _2 = 0, y2 = 0, v2 = 0, b2 = 0, w2 = 0, M2 = 0, x2 = 0;
          this.no_off = (g2 = "object" == typeof (m2 = this).PROJECTION ? Object.keys(m2.PROJECTION)[0] : m2.PROJECTION, "no_uoff" in m2 || "no_off" in m2 || -1 !== ["Hotine_Oblique_Mercator", "Hotine_Oblique_Mercator_Azimuth_Natural_Origin"].indexOf(g2)), this.no_rot = "no_rot" in this;
          var k2 = false;
          "alpha" in this && (k2 = true);
          var S2 = false;
          if ("rectified_grid_angle" in this && (S2 = true), k2 && (x2 = this.alpha), S2 && (_2 = this.rectified_grid_angle * n), k2 || S2)
            y2 = this.longc;
          else if (v2 = this.long1, w2 = this.lat1, b2 = this.long2, M2 = this.lat2, Math.abs(w2 - M2) <= 1e-7 || (t2 = Math.abs(w2)) <= 1e-7 || Math.abs(t2 - s) <= 1e-7 || Math.abs(Math.abs(this.lat0) - s) <= 1e-7 || Math.abs(Math.abs(M2) - s) <= 1e-7)
            throw new Error();
          var E2 = 1 - this.es;
          e2 = Math.sqrt(E2), Math.abs(this.lat0) > 1e-10 ? (c2 = Math.sin(this.lat0), i2 = Math.cos(this.lat0), t2 = 1 - this.es * c2 * c2, this.B = i2 * i2, this.B = Math.sqrt(1 + this.es * this.B * this.B / E2), this.A = this.B * this.k0 * e2 / t2, (a2 = (r2 = this.B * e2 / (i2 * Math.sqrt(t2))) * r2 - 1) <= 0 ? a2 = 0 : (a2 = Math.sqrt(a2), this.lat0 < 0 && (a2 = -a2)), this.E = a2 += r2, this.E *= Math.pow(L(this.e, this.lat0, c2), this.B)) : (this.B = 1 / e2, this.A = this.k0, this.E = r2 = a2 = 1), k2 || S2 ? (k2 ? (p2 = Math.asin(Math.sin(x2) / r2), S2 || (_2 = x2)) : (p2 = _2, x2 = Math.asin(r2 * Math.sin(p2))), this.lam0 = y2 - Math.asin(0.5 * (a2 - 1 / a2) * Math.tan(p2)) / this.B) : (u2 = Math.pow(L(this.e, w2, Math.sin(w2)), this.B), l2 = Math.pow(L(this.e, M2, Math.sin(M2)), this.B), a2 = this.E / u2, f2 = (l2 - u2) / (l2 + u2), d2 = ((d2 = this.E * this.E) - l2 * u2) / (d2 + l2 * u2), (t2 = v2 - b2) < -Math.pi ? b2 -= h : t2 > Math.pi && (b2 += h), this.lam0 = N(0.5 * (v2 + b2) - Math.atan(d2 * Math.tan(0.5 * this.B * (v2 - b2)) / f2) / this.B), p2 = Math.atan(2 * Math.sin(this.B * N(v2 - this.lam0)) / (a2 - 1 / a2)), _2 = x2 = Math.asin(r2 * Math.sin(p2))), this.singam = Math.sin(p2), this.cosgam = Math.cos(p2), this.sinrot = Math.sin(_2), this.cosrot = Math.cos(_2), this.rB = 1 / this.B, this.ArB = this.A * this.rB, this.BrA = 1 / this.ArB, this.A, this.B, this.no_off ? this.u_0 = 0 : (this.u_0 = Math.abs(this.ArB * Math.atan(Math.sqrt(r2 * r2 - 1) / Math.cos(x2))), this.lat0 < 0 && (this.u_0 = -this.u_0)), a2 = 0.5 * p2, this.v_pole_n = this.ArB * Math.log(Math.tan(o - a2)), this.v_pole_s = this.ArB * Math.log(Math.tan(o + a2));
        },
        forward: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2, u2, l2 = {};
          if (t2.x = t2.x - this.lam0, Math.abs(Math.abs(t2.y) - s) > 1e-10) {
            if (e2 = 0.5 * ((a2 = this.E / Math.pow(L(this.e, t2.y, Math.sin(t2.y)), this.B)) - (o2 = 1 / a2)), i2 = 0.5 * (a2 + o2), n2 = Math.sin(this.B * t2.x), r2 = (e2 * this.singam - n2 * this.cosgam) / i2, Math.abs(Math.abs(r2) - 1) < 1e-10)
              throw new Error();
            u2 = 0.5 * this.ArB * Math.log((1 - r2) / (1 + r2)), o2 = Math.cos(this.B * t2.x), h2 = Math.abs(o2) < 1e-7 ? this.A * t2.x : this.ArB * Math.atan2(e2 * this.cosgam + n2 * this.singam, o2);
          } else
            u2 = t2.y > 0 ? this.v_pole_n : this.v_pole_s, h2 = this.ArB * t2.y;
          return this.no_rot ? (l2.x = h2, l2.y = u2) : (h2 -= this.u_0, l2.x = u2 * this.cosrot + h2 * this.sinrot, l2.y = h2 * this.cosrot - u2 * this.sinrot), l2.x = this.a * l2.x + this.x0, l2.y = this.a * l2.y + this.y0, l2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2, u2 = {};
          if (t2.x = (t2.x - this.x0) * (1 / this.a), t2.y = (t2.y - this.y0) * (1 / this.a), this.no_rot ? (i2 = t2.y, e2 = t2.x) : (i2 = t2.x * this.cosrot - t2.y * this.sinrot, e2 = t2.y * this.cosrot + t2.x * this.sinrot + this.u_0), n2 = 0.5 * ((r2 = Math.exp(-this.BrA * i2)) - 1 / r2), a2 = 0.5 * (r2 + 1 / r2), h2 = ((o2 = Math.sin(this.BrA * e2)) * this.cosgam + n2 * this.singam) / a2, Math.abs(Math.abs(h2) - 1) < 1e-10)
            u2.x = 0, u2.y = h2 < 0 ? -s : s;
          else {
            if (u2.y = this.E / Math.sqrt((1 + h2) / (1 - h2)), u2.y = R(this.e, Math.pow(u2.y, 1 / this.B)), u2.y === 1 / 0)
              throw new Error();
            u2.x = -this.rB * Math.atan2(n2 * this.cosgam - o2 * this.singam, Math.cos(this.BrA * e2));
          }
          return u2.x += this.lam0, u2;
        },
        names: ["Hotine_Oblique_Mercator", "Hotine Oblique Mercator", "Hotine_Oblique_Mercator_Azimuth_Natural_Origin", "Hotine_Oblique_Mercator_Two_Point_Natural_Origin", "Hotine_Oblique_Mercator_Azimuth_Center", "Oblique_Mercator", "omerc"]
      };
      var Jt = {
        init: function() {
          if (this.lat2 || (this.lat2 = this.lat1), this.k0 || (this.k0 = 1), this.x0 = this.x0 || 0, this.y0 = this.y0 || 0, !(Math.abs(this.lat1 + this.lat2) < 1e-10)) {
            var t2 = this.b / this.a;
            this.e = Math.sqrt(1 - t2 * t2);
            var e2 = Math.sin(this.lat1), i2 = Math.cos(this.lat1), r2 = z(this.e, e2, i2), s2 = L(this.e, this.lat1, e2), n2 = Math.sin(this.lat2), a2 = Math.cos(this.lat2), o2 = z(this.e, n2, a2), h2 = L(this.e, this.lat2, n2), u2 = L(this.e, this.lat0, Math.sin(this.lat0));
            Math.abs(this.lat1 - this.lat2) > 1e-10 ? this.ns = Math.log(r2 / o2) / Math.log(s2 / h2) : this.ns = e2, isNaN(this.ns) && (this.ns = e2), this.f0 = r2 / (this.ns * Math.pow(s2, this.ns)), this.rh = this.a * this.f0 * Math.pow(u2, this.ns), this.title || (this.title = "Lambert Conformal Conic");
          }
        },
        forward: function(t2) {
          var e2 = t2.x, i2 = t2.y;
          Math.abs(2 * Math.abs(i2) - Math.PI) <= 1e-10 && (i2 = P(i2) * (s - 2e-10));
          var r2, n2, a2 = Math.abs(Math.abs(i2) - s);
          if (a2 > 1e-10)
            r2 = L(this.e, i2, Math.sin(i2)), n2 = this.a * this.f0 * Math.pow(r2, this.ns);
          else {
            if ((a2 = i2 * this.ns) <= 0)
              return null;
            n2 = 0;
          }
          var o2 = this.ns * N(e2 - this.long0);
          return t2.x = this.k0 * (n2 * Math.sin(o2)) + this.x0, t2.y = this.k0 * (this.rh - n2 * Math.cos(o2)) + this.y0, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2, o2 = (t2.x - this.x0) / this.k0, h2 = this.rh - (t2.y - this.y0) / this.k0;
          this.ns > 0 ? (e2 = Math.sqrt(o2 * o2 + h2 * h2), i2 = 1) : (e2 = -Math.sqrt(o2 * o2 + h2 * h2), i2 = -1);
          var u2 = 0;
          if (0 !== e2 && (u2 = Math.atan2(i2 * o2, i2 * h2)), 0 !== e2 || this.ns > 0) {
            if (i2 = 1 / this.ns, r2 = Math.pow(e2 / (this.a * this.f0), i2), -9999 === (n2 = R(this.e, r2)))
              return null;
          } else
            n2 = -s;
          return a2 = N(u2 / this.ns + this.long0), t2.x = a2, t2.y = n2, t2;
        },
        names: ["Lambert Tangential Conformal Conic Projection", "Lambert_Conformal_Conic", "Lambert_Conformal_Conic_1SP", "Lambert_Conformal_Conic_2SP", "lcc", "Lambert Conic Conformal (1SP)", "Lambert Conic Conformal (2SP)"]
      };
      var Kt = {
        init: function() {
          this.a = 6377397155e-3, this.es = 0.006674372230614, this.e = Math.sqrt(this.es), this.lat0 || (this.lat0 = 0.863937979737193), this.long0 || (this.long0 = 0.4334234309119251), this.k0 || (this.k0 = 0.9999), this.s45 = 0.785398163397448, this.s90 = 2 * this.s45, this.fi0 = this.lat0, this.e2 = this.es, this.e = Math.sqrt(this.e2), this.alfa = Math.sqrt(1 + this.e2 * Math.pow(Math.cos(this.fi0), 4) / (1 - this.e2)), this.uq = 1.04216856380474, this.u0 = Math.asin(Math.sin(this.fi0) / this.alfa), this.g = Math.pow((1 + this.e * Math.sin(this.fi0)) / (1 - this.e * Math.sin(this.fi0)), this.alfa * this.e / 2), this.k = Math.tan(this.u0 / 2 + this.s45) / Math.pow(Math.tan(this.fi0 / 2 + this.s45), this.alfa) * this.g, this.k1 = this.k0, this.n0 = this.a * Math.sqrt(1 - this.e2) / (1 - this.e2 * Math.pow(Math.sin(this.fi0), 2)), this.s0 = 1.37008346281555, this.n = Math.sin(this.s0), this.ro0 = this.k1 * this.n0 / Math.tan(this.s0), this.ad = this.s90 - this.uq;
        },
        forward: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2 = t2.x, u2 = t2.y, l2 = N(h2 - this.long0);
          return e2 = Math.pow((1 + this.e * Math.sin(u2)) / (1 - this.e * Math.sin(u2)), this.alfa * this.e / 2), i2 = 2 * (Math.atan(this.k * Math.pow(Math.tan(u2 / 2 + this.s45), this.alfa) / e2) - this.s45), r2 = -l2 * this.alfa, s2 = Math.asin(Math.cos(this.ad) * Math.sin(i2) + Math.sin(this.ad) * Math.cos(i2) * Math.cos(r2)), n2 = Math.asin(Math.cos(i2) * Math.sin(r2) / Math.cos(s2)), a2 = this.n * n2, o2 = this.ro0 * Math.pow(Math.tan(this.s0 / 2 + this.s45), this.n) / Math.pow(Math.tan(s2 / 2 + this.s45), this.n), t2.y = o2 * Math.cos(a2) / 1, t2.x = o2 * Math.sin(a2) / 1, this.czech || (t2.y *= -1, t2.x *= -1), t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2 = t2.x;
          t2.x = t2.y, t2.y = h2, this.czech || (t2.y *= -1, t2.x *= -1), n2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), s2 = Math.atan2(t2.y, t2.x) / Math.sin(this.s0), r2 = 2 * (Math.atan(Math.pow(this.ro0 / n2, 1 / this.n) * Math.tan(this.s0 / 2 + this.s45)) - this.s45), e2 = Math.asin(Math.cos(this.ad) * Math.sin(r2) - Math.sin(this.ad) * Math.cos(r2) * Math.cos(s2)), i2 = Math.asin(Math.cos(r2) * Math.sin(s2) / Math.cos(e2)), t2.x = this.long0 - i2 / this.alfa, a2 = e2, o2 = 0;
          var u2 = 0;
          do {
            t2.y = 2 * (Math.atan(Math.pow(this.k, -1 / this.alfa) * Math.pow(Math.tan(e2 / 2 + this.s45), 1 / this.alfa) * Math.pow((1 + this.e * Math.sin(a2)) / (1 - this.e * Math.sin(a2)), this.e / 2)) - this.s45), Math.abs(a2 - t2.y) < 1e-10 && (o2 = 1), a2 = t2.y, u2 += 1;
          } while (0 === o2 && u2 < 15);
          return u2 >= 15 ? null : t2;
        },
        names: ["Krovak", "krovak"]
      }, Qt = function(t2, e2, i2, r2, s2) {
        return t2 * s2 - e2 * Math.sin(2 * s2) + i2 * Math.sin(4 * s2) - r2 * Math.sin(6 * s2);
      }, Vt = function(t2) {
        return 1 - 0.25 * t2 * (1 + t2 / 16 * (3 + 1.25 * t2));
      }, $t = function(t2) {
        return 0.375 * t2 * (1 + 0.25 * t2 * (1 + 0.46875 * t2));
      }, te = function(t2) {
        return 0.05859375 * t2 * t2 * (1 + 0.75 * t2);
      }, ee = function(t2) {
        return t2 * t2 * t2 * (35 / 3072);
      }, ie = function(t2, e2, i2) {
        var r2 = e2 * i2;
        return t2 / Math.sqrt(1 - r2 * r2);
      }, re = function(t2) {
        return Math.abs(t2) < s ? t2 : t2 - P(t2) * Math.PI;
      }, se = function(t2, e2, i2, r2, s2) {
        var n2, a2;
        n2 = t2 / e2;
        for (var o2 = 0; o2 < 15; o2++)
          if (n2 += a2 = (t2 - (e2 * n2 - i2 * Math.sin(2 * n2) + r2 * Math.sin(4 * n2) - s2 * Math.sin(6 * n2))) / (e2 - 2 * i2 * Math.cos(2 * n2) + 4 * r2 * Math.cos(4 * n2) - 6 * s2 * Math.cos(6 * n2)), Math.abs(a2) <= 1e-10)
            return n2;
        return NaN;
      };
      var ne = {
        init: function() {
          this.sphere || (this.e0 = Vt(this.es), this.e1 = $t(this.es), this.e2 = te(this.es), this.e3 = ee(this.es), this.ml0 = this.a * Qt(this.e0, this.e1, this.e2, this.e3, this.lat0));
        },
        forward: function(t2) {
          var e2, i2, r2 = t2.x, s2 = t2.y;
          if (r2 = N(r2 - this.long0), this.sphere)
            e2 = this.a * Math.asin(Math.cos(s2) * Math.sin(r2)), i2 = this.a * (Math.atan2(Math.tan(s2), Math.cos(r2)) - this.lat0);
          else {
            var n2 = Math.sin(s2), a2 = Math.cos(s2), o2 = ie(this.a, this.e, n2), h2 = Math.tan(s2) * Math.tan(s2), u2 = r2 * Math.cos(s2), l2 = u2 * u2, c2 = this.es * a2 * a2 / (1 - this.es);
            e2 = o2 * u2 * (1 - l2 * h2 * (1 / 6 - (8 - h2 + 8 * c2) * l2 / 120)), i2 = this.a * Qt(this.e0, this.e1, this.e2, this.e3, s2) - this.ml0 + o2 * n2 / a2 * l2 * (0.5 + (5 - h2 + 6 * c2) * l2 / 24);
          }
          return t2.x = e2 + this.x0, t2.y = i2 + this.y0, t2;
        },
        inverse: function(t2) {
          t2.x -= this.x0, t2.y -= this.y0;
          var e2, i2, r2 = t2.x / this.a, n2 = t2.y / this.a;
          if (this.sphere) {
            var a2 = n2 + this.lat0;
            e2 = Math.asin(Math.sin(a2) * Math.cos(r2)), i2 = Math.atan2(Math.tan(r2), Math.cos(a2));
          } else {
            var o2 = this.ml0 / this.a + n2, h2 = se(o2, this.e0, this.e1, this.e2, this.e3);
            if (Math.abs(Math.abs(h2) - s) <= 1e-10)
              return t2.x = this.long0, t2.y = s, n2 < 0 && (t2.y *= -1), t2;
            var u2 = ie(this.a, this.e, Math.sin(h2)), l2 = u2 * u2 * u2 / this.a / this.a * (1 - this.es), c2 = Math.pow(Math.tan(h2), 2), f2 = r2 * this.a / u2, d2 = f2 * f2;
            e2 = h2 - u2 * Math.tan(h2) / l2 * f2 * f2 * (0.5 - (1 + 3 * c2) * f2 * f2 / 24), i2 = f2 * (1 - d2 * (c2 / 3 + (1 + 3 * c2) * c2 * d2 / 15)) / Math.cos(h2);
          }
          return t2.x = N(i2 + this.long0), t2.y = re(e2), t2;
        },
        names: ["Cassini", "Cassini_Soldner", "cass"]
      }, ae = function(t2, e2) {
        var i2;
        return t2 > 1e-7 ? (1 - t2 * t2) * (e2 / (1 - (i2 = t2 * e2) * i2) - 0.5 / t2 * Math.log((1 - i2) / (1 + i2))) : 2 * e2;
      };
      var oe = {
        init: function() {
          var t2, e2 = Math.abs(this.lat0);
          if (Math.abs(e2 - s) < 1e-10 ? this.mode = this.lat0 < 0 ? this.S_POLE : this.N_POLE : Math.abs(e2) < 1e-10 ? this.mode = this.EQUIT : this.mode = this.OBLIQ, this.es > 0)
            switch (this.qp = ae(this.e, 1), this.mmf = 0.5 / (1 - this.es), this.apa = function(t3) {
              var e3, i2 = [];
              return i2[0] = 0.3333333333333333 * t3, e3 = t3 * t3, i2[0] += 0.17222222222222222 * e3, i2[1] = 0.06388888888888888 * e3, e3 *= t3, i2[0] += 0.10257936507936508 * e3, i2[1] += 0.0664021164021164 * e3, i2[2] = 0.016415012942191543 * e3, i2;
            }(this.es), this.mode) {
              case this.N_POLE:
              case this.S_POLE:
                this.dd = 1;
                break;
              case this.EQUIT:
                this.rq = Math.sqrt(0.5 * this.qp), this.dd = 1 / this.rq, this.xmf = 1, this.ymf = 0.5 * this.qp;
                break;
              case this.OBLIQ:
                this.rq = Math.sqrt(0.5 * this.qp), t2 = Math.sin(this.lat0), this.sinb1 = ae(this.e, t2) / this.qp, this.cosb1 = Math.sqrt(1 - this.sinb1 * this.sinb1), this.dd = Math.cos(this.lat0) / (Math.sqrt(1 - this.es * t2 * t2) * this.rq * this.cosb1), this.ymf = (this.xmf = this.rq) / this.dd, this.xmf *= this.dd;
            }
          else
            this.mode === this.OBLIQ && (this.sinph0 = Math.sin(this.lat0), this.cosph0 = Math.cos(this.lat0));
        },
        forward: function(t2) {
          var e2, i2, r2, n2, a2, h2, u2, l2, c2, f2, d2 = t2.x, p2 = t2.y;
          if (d2 = N(d2 - this.long0), this.sphere) {
            if (a2 = Math.sin(p2), f2 = Math.cos(p2), r2 = Math.cos(d2), this.mode === this.OBLIQ || this.mode === this.EQUIT) {
              if ((i2 = this.mode === this.EQUIT ? 1 + f2 * r2 : 1 + this.sinph0 * a2 + this.cosph0 * f2 * r2) <= 1e-10)
                return null;
              e2 = (i2 = Math.sqrt(2 / i2)) * f2 * Math.sin(d2), i2 *= this.mode === this.EQUIT ? a2 : this.cosph0 * a2 - this.sinph0 * f2 * r2;
            } else if (this.mode === this.N_POLE || this.mode === this.S_POLE) {
              if (this.mode === this.N_POLE && (r2 = -r2), Math.abs(p2 + this.lat0) < 1e-10)
                return null;
              i2 = o - 0.5 * p2, e2 = (i2 = 2 * (this.mode === this.S_POLE ? Math.cos(i2) : Math.sin(i2))) * Math.sin(d2), i2 *= r2;
            }
          } else {
            switch (u2 = 0, l2 = 0, c2 = 0, r2 = Math.cos(d2), n2 = Math.sin(d2), a2 = Math.sin(p2), h2 = ae(this.e, a2), this.mode !== this.OBLIQ && this.mode !== this.EQUIT || (u2 = h2 / this.qp, l2 = Math.sqrt(1 - u2 * u2)), this.mode) {
              case this.OBLIQ:
                c2 = 1 + this.sinb1 * u2 + this.cosb1 * l2 * r2;
                break;
              case this.EQUIT:
                c2 = 1 + l2 * r2;
                break;
              case this.N_POLE:
                c2 = s + p2, h2 = this.qp - h2;
                break;
              case this.S_POLE:
                c2 = p2 - s, h2 = this.qp + h2;
            }
            if (Math.abs(c2) < 1e-10)
              return null;
            switch (this.mode) {
              case this.OBLIQ:
              case this.EQUIT:
                c2 = Math.sqrt(2 / c2), i2 = this.mode === this.OBLIQ ? this.ymf * c2 * (this.cosb1 * u2 - this.sinb1 * l2 * r2) : (c2 = Math.sqrt(2 / (1 + l2 * r2))) * u2 * this.ymf, e2 = this.xmf * c2 * l2 * n2;
                break;
              case this.N_POLE:
              case this.S_POLE:
                h2 >= 0 ? (e2 = (c2 = Math.sqrt(h2)) * n2, i2 = r2 * (this.mode === this.S_POLE ? c2 : -c2)) : e2 = i2 = 0;
            }
          }
          return t2.x = this.a * e2 + this.x0, t2.y = this.a * i2 + this.y0, t2;
        },
        inverse: function(t2) {
          t2.x -= this.x0, t2.y -= this.y0;
          var e2, i2, r2, n2, a2, o2, h2, u2, l2, c2, f2 = t2.x / this.a, d2 = t2.y / this.a;
          if (this.sphere) {
            var p2, m2 = 0, g2 = 0;
            if ((i2 = 0.5 * (p2 = Math.sqrt(f2 * f2 + d2 * d2))) > 1)
              return null;
            switch (i2 = 2 * Math.asin(i2), this.mode !== this.OBLIQ && this.mode !== this.EQUIT || (g2 = Math.sin(i2), m2 = Math.cos(i2)), this.mode) {
              case this.EQUIT:
                i2 = Math.abs(p2) <= 1e-10 ? 0 : Math.asin(d2 * g2 / p2), f2 *= g2, d2 = m2 * p2;
                break;
              case this.OBLIQ:
                i2 = Math.abs(p2) <= 1e-10 ? this.lat0 : Math.asin(m2 * this.sinph0 + d2 * g2 * this.cosph0 / p2), f2 *= g2 * this.cosph0, d2 = (m2 - Math.sin(i2) * this.sinph0) * p2;
                break;
              case this.N_POLE:
                d2 = -d2, i2 = s - i2;
                break;
              case this.S_POLE:
                i2 -= s;
            }
            e2 = 0 !== d2 || this.mode !== this.EQUIT && this.mode !== this.OBLIQ ? Math.atan2(f2, d2) : 0;
          } else {
            if (h2 = 0, this.mode === this.OBLIQ || this.mode === this.EQUIT) {
              if (f2 /= this.dd, d2 *= this.dd, (o2 = Math.sqrt(f2 * f2 + d2 * d2)) < 1e-10)
                return t2.x = this.long0, t2.y = this.lat0, t2;
              n2 = 2 * Math.asin(0.5 * o2 / this.rq), r2 = Math.cos(n2), f2 *= n2 = Math.sin(n2), this.mode === this.OBLIQ ? (h2 = r2 * this.sinb1 + d2 * n2 * this.cosb1 / o2, a2 = this.qp * h2, d2 = o2 * this.cosb1 * r2 - d2 * this.sinb1 * n2) : (h2 = d2 * n2 / o2, a2 = this.qp * h2, d2 = o2 * r2);
            } else if (this.mode === this.N_POLE || this.mode === this.S_POLE) {
              if (this.mode === this.N_POLE && (d2 = -d2), !(a2 = f2 * f2 + d2 * d2))
                return t2.x = this.long0, t2.y = this.lat0, t2;
              h2 = 1 - a2 / this.qp, this.mode === this.S_POLE && (h2 = -h2);
            }
            e2 = Math.atan2(f2, d2), u2 = Math.asin(h2), l2 = this.apa, c2 = u2 + u2, i2 = u2 + l2[0] * Math.sin(c2) + l2[1] * Math.sin(c2 + c2) + l2[2] * Math.sin(c2 + c2 + c2);
          }
          return t2.x = N(this.long0 + e2), t2.y = i2, t2;
        },
        names: ["Lambert Azimuthal Equal Area", "Lambert_Azimuthal_Equal_Area", "laea"],
        S_POLE: 1,
        N_POLE: 2,
        EQUIT: 3,
        OBLIQ: 4
      }, he = function(t2) {
        return Math.abs(t2) > 1 && (t2 = t2 > 1 ? 1 : -1), Math.asin(t2);
      };
      var ue = {
        init: function() {
          Math.abs(this.lat1 + this.lat2) < 1e-10 || (this.temp = this.b / this.a, this.es = 1 - Math.pow(this.temp, 2), this.e3 = Math.sqrt(this.es), this.sin_po = Math.sin(this.lat1), this.cos_po = Math.cos(this.lat1), this.t1 = this.sin_po, this.con = this.sin_po, this.ms1 = z(this.e3, this.sin_po, this.cos_po), this.qs1 = ae(this.e3, this.sin_po, this.cos_po), this.sin_po = Math.sin(this.lat2), this.cos_po = Math.cos(this.lat2), this.t2 = this.sin_po, this.ms2 = z(this.e3, this.sin_po, this.cos_po), this.qs2 = ae(this.e3, this.sin_po, this.cos_po), this.sin_po = Math.sin(this.lat0), this.cos_po = Math.cos(this.lat0), this.t3 = this.sin_po, this.qs0 = ae(this.e3, this.sin_po, this.cos_po), Math.abs(this.lat1 - this.lat2) > 1e-10 ? this.ns0 = (this.ms1 * this.ms1 - this.ms2 * this.ms2) / (this.qs2 - this.qs1) : this.ns0 = this.con, this.c = this.ms1 * this.ms1 + this.ns0 * this.qs1, this.rh = this.a * Math.sqrt(this.c - this.ns0 * this.qs0) / this.ns0);
        },
        forward: function(t2) {
          var e2 = t2.x, i2 = t2.y;
          this.sin_phi = Math.sin(i2), this.cos_phi = Math.cos(i2);
          var r2 = ae(this.e3, this.sin_phi, this.cos_phi), s2 = this.a * Math.sqrt(this.c - this.ns0 * r2) / this.ns0, n2 = this.ns0 * N(e2 - this.long0), a2 = s2 * Math.sin(n2) + this.x0, o2 = this.rh - s2 * Math.cos(n2) + this.y0;
          return t2.x = a2, t2.y = o2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2, a2;
          return t2.x -= this.x0, t2.y = this.rh - t2.y + this.y0, this.ns0 >= 0 ? (e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), r2 = 1) : (e2 = -Math.sqrt(t2.x * t2.x + t2.y * t2.y), r2 = -1), s2 = 0, 0 !== e2 && (s2 = Math.atan2(r2 * t2.x, r2 * t2.y)), r2 = e2 * this.ns0 / this.a, this.sphere ? a2 = Math.asin((this.c - r2 * r2) / (2 * this.ns0)) : (i2 = (this.c - r2 * r2) / this.ns0, a2 = this.phi1z(this.e3, i2)), n2 = N(s2 / this.ns0 + this.long0), t2.x = n2, t2.y = a2, t2;
        },
        names: ["Albers_Conic_Equal_Area", "Albers", "aea"],
        phi1z: function(t2, e2) {
          var i2, r2, s2, n2, a2 = he(0.5 * e2);
          if (t2 < 1e-10)
            return a2;
          for (var o2 = t2 * t2, h2 = 1; h2 <= 25; h2++)
            if (a2 += n2 = 0.5 * (s2 = 1 - (r2 = t2 * (i2 = Math.sin(a2))) * r2) * s2 / Math.cos(a2) * (e2 / (1 - o2) - i2 / s2 + 0.5 / t2 * Math.log((1 - r2) / (1 + r2))), Math.abs(n2) <= 1e-7)
              return a2;
          return null;
        }
      };
      var le = {
        init: function() {
          this.sin_p14 = Math.sin(this.lat0), this.cos_p14 = Math.cos(this.lat0), this.infinity_dist = 1e3 * this.a, this.rc = 1;
        },
        forward: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2 = t2.x, u2 = t2.y;
          return r2 = N(h2 - this.long0), e2 = Math.sin(u2), i2 = Math.cos(u2), s2 = Math.cos(r2), (n2 = this.sin_p14 * e2 + this.cos_p14 * i2 * s2) > 0 || Math.abs(n2) <= 1e-10 ? (a2 = this.x0 + 1 * this.a * i2 * Math.sin(r2) / n2, o2 = this.y0 + 1 * this.a * (this.cos_p14 * e2 - this.sin_p14 * i2 * s2) / n2) : (a2 = this.x0 + this.infinity_dist * i2 * Math.sin(r2), o2 = this.y0 + this.infinity_dist * (this.cos_p14 * e2 - this.sin_p14 * i2 * s2)), t2.x = a2, t2.y = o2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2, a2;
          return t2.x = (t2.x - this.x0) / this.a, t2.y = (t2.y - this.y0) / this.a, t2.x /= this.k0, t2.y /= this.k0, (e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y)) ? (s2 = Math.atan2(e2, this.rc), i2 = Math.sin(s2), r2 = Math.cos(s2), a2 = he(r2 * this.sin_p14 + t2.y * i2 * this.cos_p14 / e2), n2 = Math.atan2(t2.x * i2, e2 * this.cos_p14 * r2 - t2.y * this.sin_p14 * i2), n2 = N(this.long0 + n2)) : (a2 = this.phic0, n2 = 0), t2.x = n2, t2.y = a2, t2;
        },
        names: ["gnom"]
      };
      var ce = {
        init: function() {
          this.sphere || (this.k0 = z(this.e, Math.sin(this.lat_ts), Math.cos(this.lat_ts)));
        },
        forward: function(t2) {
          var e2, i2, r2 = t2.x, s2 = t2.y, n2 = N(r2 - this.long0);
          if (this.sphere)
            e2 = this.x0 + this.a * n2 * Math.cos(this.lat_ts), i2 = this.y0 + this.a * Math.sin(s2) / Math.cos(this.lat_ts);
          else {
            var a2 = ae(this.e, Math.sin(s2));
            e2 = this.x0 + this.a * this.k0 * n2, i2 = this.y0 + this.a * a2 * 0.5 / this.k0;
          }
          return t2.x = e2, t2.y = i2, t2;
        },
        inverse: function(t2) {
          var e2, i2;
          return t2.x -= this.x0, t2.y -= this.y0, this.sphere ? (e2 = N(this.long0 + t2.x / this.a / Math.cos(this.lat_ts)), i2 = Math.asin(t2.y / this.a * Math.cos(this.lat_ts))) : (i2 = function(t3, e3) {
            var i3 = 1 - (1 - t3 * t3) / (2 * t3) * Math.log((1 - t3) / (1 + t3));
            if (Math.abs(Math.abs(e3) - i3) < 1e-6)
              return e3 < 0 ? -1 * s : s;
            for (var r2, n2, a2, o2, h2 = Math.asin(0.5 * e3), u2 = 0; u2 < 30; u2++)
              if (n2 = Math.sin(h2), a2 = Math.cos(h2), o2 = t3 * n2, h2 += r2 = Math.pow(1 - o2 * o2, 2) / (2 * a2) * (e3 / (1 - t3 * t3) - n2 / (1 - o2 * o2) + 0.5 / t3 * Math.log((1 - o2) / (1 + o2))), Math.abs(r2) <= 1e-10)
                return h2;
            return NaN;
          }(this.e, 2 * t2.y * this.k0 / this.a), e2 = N(this.long0 + t2.x / (this.a * this.k0))), t2.x = e2, t2.y = i2, t2;
        },
        names: ["cea"]
      };
      var fe = {
        init: function() {
          this.x0 = this.x0 || 0, this.y0 = this.y0 || 0, this.lat0 = this.lat0 || 0, this.long0 = this.long0 || 0, this.lat_ts = this.lat_ts || 0, this.title = this.title || "Equidistant Cylindrical (Plate Carre)", this.rc = Math.cos(this.lat_ts);
        },
        forward: function(t2) {
          var e2 = t2.x, i2 = t2.y, r2 = N(e2 - this.long0), s2 = re(i2 - this.lat0);
          return t2.x = this.x0 + this.a * r2 * this.rc, t2.y = this.y0 + this.a * s2, t2;
        },
        inverse: function(t2) {
          var e2 = t2.x, i2 = t2.y;
          return t2.x = N(this.long0 + (e2 - this.x0) / (this.a * this.rc)), t2.y = re(this.lat0 + (i2 - this.y0) / this.a), t2;
        },
        names: ["Equirectangular", "Equidistant_Cylindrical", "eqc"]
      };
      var de = {
        init: function() {
          this.temp = this.b / this.a, this.es = 1 - Math.pow(this.temp, 2), this.e = Math.sqrt(this.es), this.e0 = Vt(this.es), this.e1 = $t(this.es), this.e2 = te(this.es), this.e3 = ee(this.es), this.ml0 = this.a * Qt(this.e0, this.e1, this.e2, this.e3, this.lat0);
        },
        forward: function(t2) {
          var e2, i2, r2, s2 = t2.x, n2 = t2.y, a2 = N(s2 - this.long0);
          if (r2 = a2 * Math.sin(n2), this.sphere)
            Math.abs(n2) <= 1e-10 ? (e2 = this.a * a2, i2 = -1 * this.a * this.lat0) : (e2 = this.a * Math.sin(r2) / Math.tan(n2), i2 = this.a * (re(n2 - this.lat0) + (1 - Math.cos(r2)) / Math.tan(n2)));
          else if (Math.abs(n2) <= 1e-10)
            e2 = this.a * a2, i2 = -1 * this.ml0;
          else {
            var o2 = ie(this.a, this.e, Math.sin(n2)) / Math.tan(n2);
            e2 = o2 * Math.sin(r2), i2 = this.a * Qt(this.e0, this.e1, this.e2, this.e3, n2) - this.ml0 + o2 * (1 - Math.cos(r2));
          }
          return t2.x = e2 + this.x0, t2.y = i2 + this.y0, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2, u2;
          if (r2 = t2.x - this.x0, s2 = t2.y - this.y0, this.sphere)
            if (Math.abs(s2 + this.a * this.lat0) <= 1e-10)
              e2 = N(r2 / this.a + this.long0), i2 = 0;
            else {
              var l2;
              for (a2 = this.lat0 + s2 / this.a, o2 = r2 * r2 / this.a / this.a + a2 * a2, h2 = a2, n2 = 20; n2; --n2)
                if (h2 += u2 = -1 * (a2 * (h2 * (l2 = Math.tan(h2)) + 1) - h2 - 0.5 * (h2 * h2 + o2) * l2) / ((h2 - a2) / l2 - 1), Math.abs(u2) <= 1e-10) {
                  i2 = h2;
                  break;
                }
              e2 = N(this.long0 + Math.asin(r2 * Math.tan(h2) / this.a) / Math.sin(i2));
            }
          else if (Math.abs(s2 + this.ml0) <= 1e-10)
            i2 = 0, e2 = N(this.long0 + r2 / this.a);
          else {
            var c2, f2, d2, p2, m2;
            for (a2 = (this.ml0 + s2) / this.a, o2 = r2 * r2 / this.a / this.a + a2 * a2, h2 = a2, n2 = 20; n2; --n2)
              if (m2 = this.e * Math.sin(h2), c2 = Math.sqrt(1 - m2 * m2) * Math.tan(h2), f2 = this.a * Qt(this.e0, this.e1, this.e2, this.e3, h2), d2 = this.e0 - 2 * this.e1 * Math.cos(2 * h2) + 4 * this.e2 * Math.cos(4 * h2) - 6 * this.e3 * Math.cos(6 * h2), h2 -= u2 = (a2 * (c2 * (p2 = f2 / this.a) + 1) - p2 - 0.5 * c2 * (p2 * p2 + o2)) / (this.es * Math.sin(2 * h2) * (p2 * p2 + o2 - 2 * a2 * p2) / (4 * c2) + (a2 - p2) * (c2 * d2 - 2 / Math.sin(2 * h2)) - d2), Math.abs(u2) <= 1e-10) {
                i2 = h2;
                break;
              }
            c2 = Math.sqrt(1 - this.es * Math.pow(Math.sin(i2), 2)) * Math.tan(i2), e2 = N(this.long0 + Math.asin(r2 * c2 / this.a) / Math.sin(i2));
          }
          return t2.x = e2, t2.y = i2, t2;
        },
        names: ["Polyconic", "poly"]
      };
      var pe = {
        init: function() {
          this.A = [], this.A[1] = 0.6399175073, this.A[2] = -0.1358797613, this.A[3] = 0.063294409, this.A[4] = -0.02526853, this.A[5] = 0.0117879, this.A[6] = -55161e-7, this.A[7] = 26906e-7, this.A[8] = -1333e-6, this.A[9] = 67e-5, this.A[10] = -34e-5, this.B_re = [], this.B_im = [], this.B_re[1] = 0.7557853228, this.B_im[1] = 0, this.B_re[2] = 0.249204646, this.B_im[2] = 3371507e-9, this.B_re[3] = -1541739e-9, this.B_im[3] = 0.04105856, this.B_re[4] = -0.10162907, this.B_im[4] = 0.01727609, this.B_re[5] = -0.26623489, this.B_im[5] = -0.36249218, this.B_re[6] = -0.6870983, this.B_im[6] = -1.1651967, this.C_re = [], this.C_im = [], this.C_re[1] = 1.3231270439, this.C_im[1] = 0, this.C_re[2] = -0.577245789, this.C_im[2] = -7809598e-9, this.C_re[3] = 0.508307513, this.C_im[3] = -0.112208952, this.C_re[4] = -0.15094762, this.C_im[4] = 0.18200602, this.C_re[5] = 1.01418179, this.C_im[5] = 1.64497696, this.C_re[6] = 1.9660549, this.C_im[6] = 2.5127645, this.D = [], this.D[1] = 1.5627014243, this.D[2] = 0.5185406398, this.D[3] = -0.03333098, this.D[4] = -0.1052906, this.D[5] = -0.0368594, this.D[6] = 7317e-6, this.D[7] = 0.0122, this.D[8] = 394e-5, this.D[9] = -13e-4;
        },
        forward: function(t2) {
          var e2, i2 = t2.x, s2 = t2.y - this.lat0, n2 = i2 - this.long0, a2 = s2 / r * 1e-5, o2 = n2, h2 = 1, u2 = 0;
          for (e2 = 1; e2 <= 10; e2++)
            h2 *= a2, u2 += this.A[e2] * h2;
          var l2, c2 = u2, f2 = o2, d2 = 1, p2 = 0, m2 = 0, g2 = 0;
          for (e2 = 1; e2 <= 6; e2++)
            l2 = p2 * c2 + d2 * f2, d2 = d2 * c2 - p2 * f2, p2 = l2, m2 = m2 + this.B_re[e2] * d2 - this.B_im[e2] * p2, g2 = g2 + this.B_im[e2] * d2 + this.B_re[e2] * p2;
          return t2.x = g2 * this.a + this.x0, t2.y = m2 * this.a + this.y0, t2;
        },
        inverse: function(t2) {
          var e2, i2, s2 = t2.x, n2 = t2.y, a2 = s2 - this.x0, o2 = (n2 - this.y0) / this.a, h2 = a2 / this.a, u2 = 1, l2 = 0, c2 = 0, f2 = 0;
          for (e2 = 1; e2 <= 6; e2++)
            i2 = l2 * o2 + u2 * h2, u2 = u2 * o2 - l2 * h2, l2 = i2, c2 = c2 + this.C_re[e2] * u2 - this.C_im[e2] * l2, f2 = f2 + this.C_im[e2] * u2 + this.C_re[e2] * l2;
          for (var d2 = 0; d2 < this.iterations; d2++) {
            var p2, m2 = c2, g2 = f2, _2 = o2, y2 = h2;
            for (e2 = 2; e2 <= 6; e2++)
              p2 = g2 * c2 + m2 * f2, m2 = m2 * c2 - g2 * f2, g2 = p2, _2 += (e2 - 1) * (this.B_re[e2] * m2 - this.B_im[e2] * g2), y2 += (e2 - 1) * (this.B_im[e2] * m2 + this.B_re[e2] * g2);
            m2 = 1, g2 = 0;
            var v2 = this.B_re[1], b2 = this.B_im[1];
            for (e2 = 2; e2 <= 6; e2++)
              p2 = g2 * c2 + m2 * f2, m2 = m2 * c2 - g2 * f2, g2 = p2, v2 += e2 * (this.B_re[e2] * m2 - this.B_im[e2] * g2), b2 += e2 * (this.B_im[e2] * m2 + this.B_re[e2] * g2);
            var w2 = v2 * v2 + b2 * b2;
            c2 = (_2 * v2 + y2 * b2) / w2, f2 = (y2 * v2 - _2 * b2) / w2;
          }
          var M2 = c2, x2 = f2, k2 = 1, S2 = 0;
          for (e2 = 1; e2 <= 9; e2++)
            k2 *= M2, S2 += this.D[e2] * k2;
          var E2 = this.lat0 + S2 * r * 1e5, C2 = this.long0 + x2;
          return t2.x = C2, t2.y = E2, t2;
        },
        names: ["New_Zealand_Map_Grid", "nzmg"]
      };
      var me = {
        init: function() {
        },
        forward: function(t2) {
          var e2 = t2.x, i2 = t2.y, r2 = N(e2 - this.long0), s2 = this.x0 + this.a * r2, n2 = this.y0 + this.a * Math.log(Math.tan(Math.PI / 4 + i2 / 2.5)) * 1.25;
          return t2.x = s2, t2.y = n2, t2;
        },
        inverse: function(t2) {
          t2.x -= this.x0, t2.y -= this.y0;
          var e2 = N(this.long0 + t2.x / this.a), i2 = 2.5 * (Math.atan(Math.exp(0.8 * t2.y / this.a)) - Math.PI / 4);
          return t2.x = e2, t2.y = i2, t2;
        },
        names: ["Miller_Cylindrical", "mill"]
      };
      var ge = {
        init: function() {
          this.sphere ? (this.n = 1, this.m = 0, this.es = 0, this.C_y = Math.sqrt((this.m + 1) / this.n), this.C_x = this.C_y / (this.m + 1)) : this.en = zt(this.es);
        },
        forward: function(t2) {
          var e2, i2, r2 = t2.x, s2 = t2.y;
          if (r2 = N(r2 - this.long0), this.sphere) {
            if (this.m)
              for (var n2 = this.n * Math.sin(s2), a2 = 20; a2; --a2) {
                var o2 = (this.m * s2 + Math.sin(s2) - n2) / (this.m + Math.cos(s2));
                if (s2 -= o2, Math.abs(o2) < 1e-10)
                  break;
              }
            else
              s2 = 1 !== this.n ? Math.asin(this.n * Math.sin(s2)) : s2;
            e2 = this.a * this.C_x * r2 * (this.m + Math.cos(s2)), i2 = this.a * this.C_y * s2;
          } else {
            var h2 = Math.sin(s2), u2 = Math.cos(s2);
            i2 = this.a * Pt(s2, h2, u2, this.en), e2 = this.a * r2 * u2 / Math.sqrt(1 - this.es * h2 * h2);
          }
          return t2.x = e2, t2.y = i2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2;
          return t2.x -= this.x0, r2 = t2.x / this.a, t2.y -= this.y0, e2 = t2.y / this.a, this.sphere ? (e2 /= this.C_y, r2 /= this.C_x * (this.m + Math.cos(e2)), this.m ? e2 = he((this.m * e2 + Math.sin(e2)) / this.n) : 1 !== this.n && (e2 = he(Math.sin(e2) / this.n)), r2 = N(r2 + this.long0), e2 = re(e2)) : (e2 = Nt(t2.y / this.a, this.es, this.en), (n2 = Math.abs(e2)) < s ? (n2 = Math.sin(e2), i2 = this.long0 + t2.x * Math.sqrt(1 - this.es * n2 * n2) / (this.a * Math.cos(e2)), r2 = N(i2)) : n2 - 1e-10 < s && (r2 = this.long0)), t2.x = r2, t2.y = e2, t2;
        },
        names: ["Sinusoidal", "sinu"]
      };
      var _e = {
        init: function() {
        },
        forward: function(t2) {
          for (var e2 = t2.x, i2 = t2.y, r2 = N(e2 - this.long0), s2 = i2, n2 = Math.PI * Math.sin(i2); ; ) {
            var a2 = -(s2 + Math.sin(s2) - n2) / (1 + Math.cos(s2));
            if (s2 += a2, Math.abs(a2) < 1e-10)
              break;
          }
          s2 /= 2, Math.PI / 2 - Math.abs(i2) < 1e-10 && (r2 = 0);
          var o2 = 0.900316316158 * this.a * r2 * Math.cos(s2) + this.x0, h2 = 1.4142135623731 * this.a * Math.sin(s2) + this.y0;
          return t2.x = o2, t2.y = h2, t2;
        },
        inverse: function(t2) {
          var e2, i2;
          t2.x -= this.x0, t2.y -= this.y0, i2 = t2.y / (1.4142135623731 * this.a), Math.abs(i2) > 0.999999999999 && (i2 = 0.999999999999), e2 = Math.asin(i2);
          var r2 = N(this.long0 + t2.x / (0.900316316158 * this.a * Math.cos(e2)));
          r2 < -Math.PI && (r2 = -Math.PI), r2 > Math.PI && (r2 = Math.PI), i2 = (2 * e2 + Math.sin(2 * e2)) / Math.PI, Math.abs(i2) > 1 && (i2 = 1);
          var s2 = Math.asin(i2);
          return t2.x = r2, t2.y = s2, t2;
        },
        names: ["Mollweide", "moll"]
      };
      var ye = {
        init: function() {
          Math.abs(this.lat1 + this.lat2) < 1e-10 || (this.lat2 = this.lat2 || this.lat1, this.temp = this.b / this.a, this.es = 1 - Math.pow(this.temp, 2), this.e = Math.sqrt(this.es), this.e0 = Vt(this.es), this.e1 = $t(this.es), this.e2 = te(this.es), this.e3 = ee(this.es), this.sinphi = Math.sin(this.lat1), this.cosphi = Math.cos(this.lat1), this.ms1 = z(this.e, this.sinphi, this.cosphi), this.ml1 = Qt(this.e0, this.e1, this.e2, this.e3, this.lat1), Math.abs(this.lat1 - this.lat2) < 1e-10 ? this.ns = this.sinphi : (this.sinphi = Math.sin(this.lat2), this.cosphi = Math.cos(this.lat2), this.ms2 = z(this.e, this.sinphi, this.cosphi), this.ml2 = Qt(this.e0, this.e1, this.e2, this.e3, this.lat2), this.ns = (this.ms1 - this.ms2) / (this.ml2 - this.ml1)), this.g = this.ml1 + this.ms1 / this.ns, this.ml0 = Qt(this.e0, this.e1, this.e2, this.e3, this.lat0), this.rh = this.a * (this.g - this.ml0));
        },
        forward: function(t2) {
          var e2, i2 = t2.x, r2 = t2.y;
          if (this.sphere)
            e2 = this.a * (this.g - r2);
          else {
            var s2 = Qt(this.e0, this.e1, this.e2, this.e3, r2);
            e2 = this.a * (this.g - s2);
          }
          var n2 = this.ns * N(i2 - this.long0), a2 = this.x0 + e2 * Math.sin(n2), o2 = this.y0 + this.rh - e2 * Math.cos(n2);
          return t2.x = a2, t2.y = o2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2;
          t2.x -= this.x0, t2.y = this.rh - t2.y + this.y0, this.ns >= 0 ? (i2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), e2 = 1) : (i2 = -Math.sqrt(t2.x * t2.x + t2.y * t2.y), e2 = -1);
          var n2 = 0;
          if (0 !== i2 && (n2 = Math.atan2(e2 * t2.x, e2 * t2.y)), this.sphere)
            return s2 = N(this.long0 + n2 / this.ns), r2 = re(this.g - i2 / this.a), t2.x = s2, t2.y = r2, t2;
          var a2 = this.g - i2 / this.a;
          return r2 = se(a2, this.e0, this.e1, this.e2, this.e3), s2 = N(this.long0 + n2 / this.ns), t2.x = s2, t2.y = r2, t2;
        },
        names: ["Equidistant_Conic", "eqdc"]
      };
      var ve = {
        init: function() {
          this.R = this.a;
        },
        forward: function(t2) {
          var e2, i2, r2 = t2.x, n2 = t2.y, a2 = N(r2 - this.long0);
          Math.abs(n2) <= 1e-10 && (e2 = this.x0 + this.R * a2, i2 = this.y0);
          var o2 = he(2 * Math.abs(n2 / Math.PI));
          (Math.abs(a2) <= 1e-10 || Math.abs(Math.abs(n2) - s) <= 1e-10) && (e2 = this.x0, i2 = n2 >= 0 ? this.y0 + Math.PI * this.R * Math.tan(0.5 * o2) : this.y0 + Math.PI * this.R * -Math.tan(0.5 * o2));
          var h2 = 0.5 * Math.abs(Math.PI / a2 - a2 / Math.PI), u2 = h2 * h2, l2 = Math.sin(o2), c2 = Math.cos(o2), f2 = c2 / (l2 + c2 - 1), d2 = f2 * f2, p2 = f2 * (2 / l2 - 1), m2 = p2 * p2, g2 = Math.PI * this.R * (h2 * (f2 - m2) + Math.sqrt(u2 * (f2 - m2) * (f2 - m2) - (m2 + u2) * (d2 - m2))) / (m2 + u2);
          a2 < 0 && (g2 = -g2), e2 = this.x0 + g2;
          var _2 = u2 + f2;
          return g2 = Math.PI * this.R * (p2 * _2 - h2 * Math.sqrt((m2 + u2) * (u2 + 1) - _2 * _2)) / (m2 + u2), i2 = n2 >= 0 ? this.y0 + g2 : this.y0 - g2, t2.x = e2, t2.y = i2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2, u2, l2, c2, f2;
          return t2.x -= this.x0, t2.y -= this.y0, c2 = Math.PI * this.R, n2 = (r2 = t2.x / c2) * r2 + (s2 = t2.y / c2) * s2, c2 = 3 * (s2 * s2 / (h2 = -2 * (a2 = -Math.abs(s2) * (1 + n2)) + 1 + 2 * s2 * s2 + n2 * n2) + (2 * (o2 = a2 - 2 * s2 * s2 + r2 * r2) * o2 * o2 / h2 / h2 / h2 - 9 * a2 * o2 / h2 / h2) / 27) / (u2 = (a2 - o2 * o2 / 3 / h2) / h2) / (l2 = 2 * Math.sqrt(-u2 / 3)), Math.abs(c2) > 1 && (c2 = c2 >= 0 ? 1 : -1), f2 = Math.acos(c2) / 3, i2 = t2.y >= 0 ? (-l2 * Math.cos(f2 + Math.PI / 3) - o2 / 3 / h2) * Math.PI : -(-l2 * Math.cos(f2 + Math.PI / 3) - o2 / 3 / h2) * Math.PI, e2 = Math.abs(r2) < 1e-10 ? this.long0 : N(this.long0 + Math.PI * (n2 - 1 + Math.sqrt(1 + 2 * (r2 * r2 - s2 * s2) + n2 * n2)) / 2 / r2), t2.x = e2, t2.y = i2, t2;
        },
        names: ["Van_der_Grinten_I", "VanDerGrinten", "vandg"]
      };
      var be = {
        init: function() {
          this.sin_p12 = Math.sin(this.lat0), this.cos_p12 = Math.cos(this.lat0);
        },
        forward: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2, u2, l2, c2, f2, d2, p2, m2, g2, _2, y2, v2, b2, w2, M2, x2, k2 = t2.x, S2 = t2.y, E2 = Math.sin(t2.y), C2 = Math.cos(t2.y), A2 = N(k2 - this.long0);
          return this.sphere ? Math.abs(this.sin_p12 - 1) <= 1e-10 ? (t2.x = this.x0 + this.a * (s - S2) * Math.sin(A2), t2.y = this.y0 - this.a * (s - S2) * Math.cos(A2), t2) : Math.abs(this.sin_p12 + 1) <= 1e-10 ? (t2.x = this.x0 + this.a * (s + S2) * Math.sin(A2), t2.y = this.y0 + this.a * (s + S2) * Math.cos(A2), t2) : (v2 = this.sin_p12 * E2 + this.cos_p12 * C2 * Math.cos(A2), y2 = (_2 = Math.acos(v2)) ? _2 / Math.sin(_2) : 1, t2.x = this.x0 + this.a * y2 * C2 * Math.sin(A2), t2.y = this.y0 + this.a * y2 * (this.cos_p12 * E2 - this.sin_p12 * C2 * Math.cos(A2)), t2) : (e2 = Vt(this.es), i2 = $t(this.es), r2 = te(this.es), n2 = ee(this.es), Math.abs(this.sin_p12 - 1) <= 1e-10 ? (a2 = this.a * Qt(e2, i2, r2, n2, s), o2 = this.a * Qt(e2, i2, r2, n2, S2), t2.x = this.x0 + (a2 - o2) * Math.sin(A2), t2.y = this.y0 - (a2 - o2) * Math.cos(A2), t2) : Math.abs(this.sin_p12 + 1) <= 1e-10 ? (a2 = this.a * Qt(e2, i2, r2, n2, s), o2 = this.a * Qt(e2, i2, r2, n2, S2), t2.x = this.x0 + (a2 + o2) * Math.sin(A2), t2.y = this.y0 + (a2 + o2) * Math.cos(A2), t2) : (h2 = E2 / C2, u2 = ie(this.a, this.e, this.sin_p12), l2 = ie(this.a, this.e, E2), c2 = Math.atan((1 - this.es) * h2 + this.es * u2 * this.sin_p12 / (l2 * C2)), b2 = 0 === (f2 = Math.atan2(Math.sin(A2), this.cos_p12 * Math.tan(c2) - this.sin_p12 * Math.cos(A2))) ? Math.asin(this.cos_p12 * Math.sin(c2) - this.sin_p12 * Math.cos(c2)) : Math.abs(Math.abs(f2) - Math.PI) <= 1e-10 ? -Math.asin(this.cos_p12 * Math.sin(c2) - this.sin_p12 * Math.cos(c2)) : Math.asin(Math.sin(A2) * Math.cos(c2) / Math.sin(f2)), d2 = this.e * this.sin_p12 / Math.sqrt(1 - this.es), _2 = u2 * b2 * (1 - (w2 = b2 * b2) * (g2 = (p2 = this.e * this.cos_p12 * Math.cos(f2) / Math.sqrt(1 - this.es)) * p2) * (1 - g2) / 6 + (M2 = w2 * b2) / 8 * (m2 = d2 * p2) * (1 - 2 * g2) + (x2 = M2 * b2) / 120 * (g2 * (4 - 7 * g2) - 3 * d2 * d2 * (1 - 7 * g2)) - x2 * b2 / 48 * m2), t2.x = this.x0 + _2 * Math.sin(f2), t2.y = this.y0 + _2 * Math.cos(f2), t2));
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2, u2, l2, c2, f2, d2, p2, m2, g2, _2, y2, v2, b2, w2, M2, x2, k2;
          if (t2.x -= this.x0, t2.y -= this.y0, this.sphere) {
            if ((e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y)) > 2 * s * this.a)
              return;
            return i2 = e2 / this.a, r2 = Math.sin(i2), n2 = Math.cos(i2), a2 = this.long0, Math.abs(e2) <= 1e-10 ? o2 = this.lat0 : (o2 = he(n2 * this.sin_p12 + t2.y * r2 * this.cos_p12 / e2), h2 = Math.abs(this.lat0) - s, a2 = Math.abs(h2) <= 1e-10 ? this.lat0 >= 0 ? N(this.long0 + Math.atan2(t2.x, -t2.y)) : N(this.long0 - Math.atan2(-t2.x, t2.y)) : N(this.long0 + Math.atan2(t2.x * r2, e2 * this.cos_p12 * n2 - t2.y * this.sin_p12 * r2))), t2.x = a2, t2.y = o2, t2;
          }
          return u2 = Vt(this.es), l2 = $t(this.es), c2 = te(this.es), f2 = ee(this.es), Math.abs(this.sin_p12 - 1) <= 1e-10 ? (d2 = this.a * Qt(u2, l2, c2, f2, s), e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), o2 = se((d2 - e2) / this.a, u2, l2, c2, f2), a2 = N(this.long0 + Math.atan2(t2.x, -1 * t2.y)), t2.x = a2, t2.y = o2, t2) : Math.abs(this.sin_p12 + 1) <= 1e-10 ? (d2 = this.a * Qt(u2, l2, c2, f2, s), e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), o2 = se((e2 - d2) / this.a, u2, l2, c2, f2), a2 = N(this.long0 + Math.atan2(t2.x, t2.y)), t2.x = a2, t2.y = o2, t2) : (e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), g2 = Math.atan2(t2.x, t2.y), p2 = ie(this.a, this.e, this.sin_p12), _2 = Math.cos(g2), v2 = -(y2 = this.e * this.cos_p12 * _2) * y2 / (1 - this.es), b2 = 3 * this.es * (1 - v2) * this.sin_p12 * this.cos_p12 * _2 / (1 - this.es), x2 = 1 - v2 * (M2 = (w2 = e2 / p2) - v2 * (1 + v2) * Math.pow(w2, 3) / 6 - b2 * (1 + 3 * v2) * Math.pow(w2, 4) / 24) * M2 / 2 - w2 * M2 * M2 * M2 / 6, m2 = Math.asin(this.sin_p12 * Math.cos(M2) + this.cos_p12 * Math.sin(M2) * _2), a2 = N(this.long0 + Math.asin(Math.sin(g2) * Math.sin(M2) / Math.cos(m2))), k2 = Math.sin(m2), o2 = Math.atan2((k2 - this.es * x2 * this.sin_p12) * Math.tan(m2), k2 * (1 - this.es)), t2.x = a2, t2.y = o2, t2);
        },
        names: ["Azimuthal_Equidistant", "aeqd"]
      };
      var we = {
        init: function() {
          this.sin_p14 = Math.sin(this.lat0), this.cos_p14 = Math.cos(this.lat0);
        },
        forward: function(t2) {
          var e2, i2, r2, s2, n2, a2, o2, h2 = t2.x, u2 = t2.y;
          return r2 = N(h2 - this.long0), e2 = Math.sin(u2), i2 = Math.cos(u2), s2 = Math.cos(r2), ((n2 = this.sin_p14 * e2 + this.cos_p14 * i2 * s2) > 0 || Math.abs(n2) <= 1e-10) && (a2 = 1 * this.a * i2 * Math.sin(r2), o2 = this.y0 + 1 * this.a * (this.cos_p14 * e2 - this.sin_p14 * i2 * s2)), t2.x = a2, t2.y = o2, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2;
          return t2.x -= this.x0, t2.y -= this.y0, e2 = Math.sqrt(t2.x * t2.x + t2.y * t2.y), i2 = he(e2 / this.a), r2 = Math.sin(i2), n2 = Math.cos(i2), o2 = this.long0, Math.abs(e2) <= 1e-10 ? (h2 = this.lat0, t2.x = o2, t2.y = h2, t2) : (h2 = he(n2 * this.sin_p14 + t2.y * r2 * this.cos_p14 / e2), a2 = Math.abs(this.lat0) - s, Math.abs(a2) <= 1e-10 ? (o2 = this.lat0 >= 0 ? N(this.long0 + Math.atan2(t2.x, -t2.y)) : N(this.long0 - Math.atan2(-t2.x, t2.y)), t2.x = o2, t2.y = h2, t2) : (o2 = N(this.long0 + Math.atan2(t2.x * r2, e2 * this.cos_p14 * n2 - t2.y * this.sin_p14 * r2)), t2.x = o2, t2.y = h2, t2));
        },
        names: ["ortho"]
      }, Me = 1, xe = 2, ke = 3, Se = 4, Ee = 5, Ce = 6, Ae = 1, Ie = 2, Oe = 3, Te = 4;
      function ze(t2, e2, i2, r2) {
        var n2;
        return t2 < 1e-10 ? (r2.value = Ae, n2 = 0) : (n2 = Math.atan2(e2, i2), Math.abs(n2) <= o ? r2.value = Ae : n2 > o && n2 <= s + o ? (r2.value = Ie, n2 -= s) : n2 > s + o || n2 <= -(s + o) ? (r2.value = Oe, n2 = n2 >= 0 ? n2 - u : n2 + u) : (r2.value = Te, n2 += s)), n2;
      }
      function Pe(t2, e2) {
        var i2 = t2 + e2;
        return i2 < -u ? i2 += h : i2 > +u && (i2 -= h), i2;
      }
      var Ne = {
        init: function() {
          this.x0 = this.x0 || 0, this.y0 = this.y0 || 0, this.lat0 = this.lat0 || 0, this.long0 = this.long0 || 0, this.lat_ts = this.lat_ts || 0, this.title = this.title || "Quadrilateralized Spherical Cube", this.lat0 >= s - o / 2 ? this.face = Ee : this.lat0 <= -(s - o / 2) ? this.face = Ce : Math.abs(this.long0) <= o ? this.face = Me : Math.abs(this.long0) <= s + o ? this.face = this.long0 > 0 ? xe : Se : this.face = ke, 0 !== this.es && (this.one_minus_f = 1 - (this.a - this.b) / this.a, this.one_minus_f_squared = this.one_minus_f * this.one_minus_f);
        },
        forward: function(t2) {
          var e2, i2, r2, n2, a2, h2, l2 = { x: 0, y: 0 }, c2 = { value: 0 };
          if (t2.x -= this.long0, e2 = 0 !== this.es ? Math.atan(this.one_minus_f_squared * Math.tan(t2.y)) : t2.y, i2 = t2.x, this.face === Ee)
            n2 = s - e2, i2 >= o && i2 <= s + o ? (c2.value = Ae, r2 = i2 - s) : i2 > s + o || i2 <= -(s + o) ? (c2.value = Ie, r2 = i2 > 0 ? i2 - u : i2 + u) : i2 > -(s + o) && i2 <= -o ? (c2.value = Oe, r2 = i2 + s) : (c2.value = Te, r2 = i2);
          else if (this.face === Ce)
            n2 = s + e2, i2 >= o && i2 <= s + o ? (c2.value = Ae, r2 = -i2 + s) : i2 < o && i2 >= -o ? (c2.value = Ie, r2 = -i2) : i2 < -o && i2 >= -(s + o) ? (c2.value = Oe, r2 = -i2 - s) : (c2.value = Te, r2 = i2 > 0 ? -i2 + u : -i2 - u);
          else {
            var f2, d2, p2, m2, g2, _2;
            this.face === xe ? i2 = Pe(i2, +s) : this.face === ke ? i2 = Pe(i2, +u) : this.face === Se && (i2 = Pe(i2, -s)), m2 = Math.sin(e2), g2 = Math.cos(e2), _2 = Math.sin(i2), f2 = g2 * Math.cos(i2), d2 = g2 * _2, p2 = m2, this.face === Me ? r2 = ze(n2 = Math.acos(f2), p2, d2, c2) : this.face === xe ? r2 = ze(n2 = Math.acos(d2), p2, -f2, c2) : this.face === ke ? r2 = ze(n2 = Math.acos(-f2), p2, -d2, c2) : this.face === Se ? r2 = ze(n2 = Math.acos(-d2), p2, f2, c2) : (n2 = r2 = 0, c2.value = Ae);
          }
          return h2 = Math.atan(12 / u * (r2 + Math.acos(Math.sin(r2) * Math.cos(o)) - s)), a2 = Math.sqrt((1 - Math.cos(n2)) / (Math.cos(h2) * Math.cos(h2)) / (1 - Math.cos(Math.atan(1 / Math.cos(r2))))), c2.value === Ie ? h2 += s : c2.value === Oe ? h2 += u : c2.value === Te && (h2 += 1.5 * u), l2.x = a2 * Math.cos(h2), l2.y = a2 * Math.sin(h2), l2.x = l2.x * this.a + this.x0, l2.y = l2.y * this.a + this.y0, t2.x = l2.x, t2.y = l2.y, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, n2, a2, o2, h2, l2, c2, f2, d2, p2, m2 = { lam: 0, phi: 0 }, g2 = { value: 0 };
          if (t2.x = (t2.x - this.x0) / this.a, t2.y = (t2.y - this.y0) / this.a, i2 = Math.atan(Math.sqrt(t2.x * t2.x + t2.y * t2.y)), e2 = Math.atan2(t2.y, t2.x), t2.x >= 0 && t2.x >= Math.abs(t2.y) ? g2.value = Ae : t2.y >= 0 && t2.y >= Math.abs(t2.x) ? (g2.value = Ie, e2 -= s) : t2.x < 0 && -t2.x >= Math.abs(t2.y) ? (g2.value = Oe, e2 = e2 < 0 ? e2 + u : e2 - u) : (g2.value = Te, e2 += s), c2 = u / 12 * Math.tan(e2), a2 = Math.sin(c2) / (Math.cos(c2) - 1 / Math.sqrt(2)), o2 = Math.atan(a2), (h2 = 1 - (r2 = Math.cos(e2)) * r2 * (n2 = Math.tan(i2)) * n2 * (1 - Math.cos(Math.atan(1 / Math.cos(o2))))) < -1 ? h2 = -1 : h2 > 1 && (h2 = 1), this.face === Ee)
            l2 = Math.acos(h2), m2.phi = s - l2, g2.value === Ae ? m2.lam = o2 + s : g2.value === Ie ? m2.lam = o2 < 0 ? o2 + u : o2 - u : g2.value === Oe ? m2.lam = o2 - s : m2.lam = o2;
          else if (this.face === Ce)
            l2 = Math.acos(h2), m2.phi = l2 - s, g2.value === Ae ? m2.lam = -o2 + s : g2.value === Ie ? m2.lam = -o2 : g2.value === Oe ? m2.lam = -o2 - s : m2.lam = o2 < 0 ? -o2 - u : -o2 + u;
          else {
            var _2, y2, v2;
            c2 = (_2 = h2) * _2, y2 = (c2 += (v2 = c2 >= 1 ? 0 : Math.sqrt(1 - c2) * Math.sin(o2)) * v2) >= 1 ? 0 : Math.sqrt(1 - c2), g2.value === Ie ? (c2 = y2, y2 = -v2, v2 = c2) : g2.value === Oe ? (y2 = -y2, v2 = -v2) : g2.value === Te && (c2 = y2, y2 = v2, v2 = -c2), this.face === xe ? (c2 = _2, _2 = -y2, y2 = c2) : this.face === ke ? (_2 = -_2, y2 = -y2) : this.face === Se && (c2 = _2, _2 = y2, y2 = -c2), m2.phi = Math.acos(-v2) - s, m2.lam = Math.atan2(y2, _2), this.face === xe ? m2.lam = Pe(m2.lam, -s) : this.face === ke ? m2.lam = Pe(m2.lam, -u) : this.face === Se && (m2.lam = Pe(m2.lam, +s));
          }
          return 0 !== this.es && (f2 = m2.phi < 0 ? 1 : 0, d2 = Math.tan(m2.phi), p2 = this.b / Math.sqrt(d2 * d2 + this.one_minus_f_squared), m2.phi = Math.atan(Math.sqrt(this.a * this.a - p2 * p2) / (this.one_minus_f * p2)), f2 && (m2.phi = -m2.phi)), m2.lam += this.long0, t2.x = m2.lam, t2.y = m2.phi, t2;
        },
        names: ["Quadrilateralized Spherical Cube", "Quadrilateralized_Spherical_Cube", "qsc"]
      }, Le = [
        [1, 22199e-21, -715515e-10, 31103e-10],
        [0.9986, -482243e-9, -24897e-9, -13309e-10],
        [0.9954, -83103e-8, -448605e-10, -986701e-12],
        [0.99, -135364e-8, -59661e-9, 36777e-10],
        [0.9822, -167442e-8, -449547e-11, -572411e-11],
        [0.973, -214868e-8, -903571e-10, 18736e-12],
        [0.96, -305085e-8, -900761e-10, 164917e-11],
        [0.9427, -382792e-8, -653386e-10, -26154e-10],
        [0.9216, -467746e-8, -10457e-8, 481243e-11],
        [0.8962, -536223e-8, -323831e-10, -543432e-11],
        [0.8679, -609363e-8, -113898e-9, 332484e-11],
        [0.835, -698325e-8, -640253e-10, 934959e-12],
        [0.7986, -755338e-8, -500009e-10, 935324e-12],
        [0.7597, -798324e-8, -35971e-9, -227626e-11],
        [0.7186, -851367e-8, -701149e-10, -86303e-10],
        [0.6732, -986209e-8, -199569e-9, 191974e-10],
        [0.6213, -0.010418, 883923e-10, 624051e-11],
        [0.5722, -906601e-8, 182e-6, 624051e-11],
        [0.5322, -677797e-8, 275608e-9, 624051e-11]
      ], Re = [
        [-520417e-23, 0.0124, 121431e-23, -845284e-16],
        [0.062, 0.0124, -126793e-14, 422642e-15],
        [0.124, 0.0124, 507171e-14, -160604e-14],
        [0.186, 0.0123999, -190189e-13, 600152e-14],
        [0.248, 0.0124002, 710039e-13, -224e-10],
        [0.31, 0.0123992, -264997e-12, 835986e-13],
        [0.372, 0.0124029, 988983e-12, -311994e-12],
        [0.434, 0.0123893, -369093e-11, -435621e-12],
        [0.4958, 0.0123198, -102252e-10, -345523e-12],
        [0.5571, 0.0121916, -154081e-10, -582288e-12],
        [0.6176, 0.0119938, -241424e-10, -525327e-12],
        [0.6769, 0.011713, -320223e-10, -516405e-12],
        [0.7346, 0.0113541, -397684e-10, -609052e-12],
        [0.7903, 0.0109107, -489042e-10, -104739e-11],
        [0.8435, 0.0103431, -64615e-9, -140374e-14],
        [0.8936, 969686e-8, -64636e-9, -8547e-9],
        [0.9394, 840947e-8, -192841e-9, -42106e-10],
        [0.9761, 616527e-8, -256e-6, -42106e-10],
        [1, 328947e-8, -319159e-9, -42106e-10]
      ], Be = a / 5, De = function(t2, e2) {
        return t2[0] + e2 * (t2[1] + e2 * (t2[2] + e2 * t2[3]));
      };
      var je = {
        init: function() {
          this.x0 = this.x0 || 0, this.y0 = this.y0 || 0, this.long0 = this.long0 || 0, this.es = 0, this.title = this.title || "Robinson";
        },
        forward: function(t2) {
          var e2 = N(t2.x - this.long0), i2 = Math.abs(t2.y), r2 = Math.floor(i2 * Be);
          r2 < 0 ? r2 = 0 : r2 >= 18 && (r2 = 17);
          var s2 = { x: De(Le[r2], i2 = a * (i2 - 0.08726646259971647 * r2)) * e2, y: De(Re[r2], i2) };
          return t2.y < 0 && (s2.y = -s2.y), s2.x = s2.x * this.a * 0.8487 + this.x0, s2.y = s2.y * this.a * 1.3523 + this.y0, s2;
        },
        inverse: function(t2) {
          var e2 = { x: (t2.x - this.x0) / (0.8487 * this.a), y: Math.abs(t2.y - this.y0) / (1.3523 * this.a) };
          if (e2.y >= 1)
            e2.x /= Le[18][0], e2.y = t2.y < 0 ? -s : s;
          else {
            var i2 = Math.floor(18 * e2.y);
            for (i2 < 0 ? i2 = 0 : i2 >= 18 && (i2 = 17); ; )
              if (Re[i2][0] > e2.y)
                --i2;
              else {
                if (!(Re[i2 + 1][0] <= e2.y))
                  break;
                ++i2;
              }
            var r2 = Re[i2], a2 = 5 * (e2.y - r2[0]) / (Re[i2 + 1][0] - r2[0]);
            a2 = function(t3, e3, i3, r3) {
              for (var s2 = e3; r3; --r3) {
                var n2 = t3(s2);
                if (s2 -= n2, Math.abs(n2) < i3)
                  break;
              }
              return s2;
            }(
              function(t3) {
                return (De(r2, t3) - e2.y) / function(t4, e3) {
                  return t4[1] + e3 * (2 * t4[2] + 3 * e3 * t4[3]);
                }(r2, t3);
              },
              a2,
              1e-10,
              100
            ), e2.x /= De(Le[i2], a2), e2.y = (5 * i2 + a2) * n, t2.y < 0 && (e2.y = -e2.y);
          }
          return e2.x = N(e2.x + this.long0), e2;
        },
        names: ["Robinson", "robin"]
      };
      var Ue = {
        init: function() {
          this.name = "geocent";
        },
        forward: function(t2) {
          return it(t2, this.es, this.a);
        },
        inverse: function(t2) {
          return rt(t2, this.es, this.a, this.b);
        },
        names: ["Geocentric", "geocentric", "geocent", "Geocent"]
      }, Fe = 0, qe = 1, Ge = 2, We = 3, Ze = { h: { def: 1e5, num: true }, azi: { def: 0, num: true, degrees: true }, tilt: { def: 0, num: true, degrees: true }, long0: { def: 0, num: true }, lat0: { def: 0, num: true } };
      var He = {
        init: function() {
          if (Object.keys(Ze).forEach(
            function(t3) {
              if (void 0 === this[t3])
                this[t3] = Ze[t3].def;
              else {
                if (Ze[t3].num && isNaN(this[t3]))
                  throw new Error("Invalid parameter value, must be numeric " + t3 + " = " + this[t3]);
                Ze[t3].num && (this[t3] = parseFloat(this[t3]));
              }
              Ze[t3].degrees && (this[t3] = this[t3] * n);
            }.bind(this)
          ), Math.abs(Math.abs(this.lat0) - s) < 1e-10 ? this.mode = this.lat0 < 0 ? qe : Fe : Math.abs(this.lat0) < 1e-10 ? this.mode = Ge : (this.mode = We, this.sinph0 = Math.sin(this.lat0), this.cosph0 = Math.cos(this.lat0)), this.pn1 = this.h / this.a, this.pn1 <= 0 || this.pn1 > 1e10)
            throw new Error("Invalid height");
          this.p = 1 + this.pn1, this.rp = 1 / this.p, this.h1 = 1 / this.pn1, this.pfact = (this.p + 1) * this.h1, this.es = 0;
          var t2 = this.tilt, e2 = this.azi;
          this.cg = Math.cos(e2), this.sg = Math.sin(e2), this.cw = Math.cos(t2), this.sw = Math.sin(t2);
        },
        forward: function(t2) {
          t2.x -= this.long0;
          var e2, i2, r2, s2, n2 = Math.sin(t2.y), a2 = Math.cos(t2.y), o2 = Math.cos(t2.x);
          switch (this.mode) {
            case We:
              i2 = this.sinph0 * n2 + this.cosph0 * a2 * o2;
              break;
            case Ge:
              i2 = a2 * o2;
              break;
            case qe:
              i2 = -n2;
              break;
            case Fe:
              i2 = n2;
          }
          switch (e2 = (i2 = this.pn1 / (this.p - i2)) * a2 * Math.sin(t2.x), this.mode) {
            case We:
              i2 *= this.cosph0 * n2 - this.sinph0 * a2 * o2;
              break;
            case Ge:
              i2 *= n2;
              break;
            case Fe:
              i2 *= -a2 * o2;
              break;
            case qe:
              i2 *= a2 * o2;
          }
          return s2 = 1 / ((r2 = i2 * this.cg + e2 * this.sg) * this.sw * this.h1 + this.cw), e2 = (e2 * this.cg - i2 * this.sg) * this.cw * s2, i2 = r2 * s2, t2.x = e2 * this.a, t2.y = i2 * this.a, t2;
        },
        inverse: function(t2) {
          t2.x /= this.a, t2.y /= this.a;
          var e2, i2, r2, s2 = { x: t2.x, y: t2.y };
          r2 = 1 / (this.pn1 - t2.y * this.sw), e2 = this.pn1 * t2.x * r2, i2 = this.pn1 * t2.y * this.cw * r2, t2.x = e2 * this.cg + i2 * this.sg, t2.y = i2 * this.cg - e2 * this.sg;
          var n2 = Bt(t2.x, t2.y);
          if (Math.abs(n2) < 1e-10)
            s2.x = 0, s2.y = t2.y;
          else {
            var a2, o2;
            switch (o2 = 1 - n2 * n2 * this.pfact, o2 = (this.p - Math.sqrt(o2)) / (this.pn1 / n2 + n2 / this.pn1), a2 = Math.sqrt(1 - o2 * o2), this.mode) {
              case We:
                s2.y = Math.asin(a2 * this.sinph0 + t2.y * o2 * this.cosph0 / n2), t2.y = (a2 - this.sinph0 * Math.sin(s2.y)) * n2, t2.x *= o2 * this.cosph0;
                break;
              case Ge:
                s2.y = Math.asin(t2.y * o2 / n2), t2.y = a2 * n2, t2.x *= o2;
                break;
              case Fe:
                s2.y = Math.asin(a2), t2.y = -t2.y;
                break;
              case qe:
                s2.y = -Math.asin(a2);
            }
            s2.x = Math.atan2(t2.x, t2.y);
          }
          return t2.x = s2.x + this.long0, t2.y = s2.y, t2;
        },
        names: ["Tilted_Perspective", "tpers"]
      };
      var Ye, Xe = {
        init: function() {
          if (this.flip_axis = "x" === this.sweep ? 1 : 0, this.h = Number(this.h), this.radius_g_1 = this.h / this.a, this.radius_g_1 <= 0 || this.radius_g_1 > 1e10)
            throw new Error();
          if (this.radius_g = 1 + this.radius_g_1, this.C = this.radius_g * this.radius_g - 1, 0 !== this.es) {
            var t2 = 1 - this.es, e2 = 1 / t2;
            this.radius_p = Math.sqrt(t2), this.radius_p2 = t2, this.radius_p_inv2 = e2, this.shape = "ellipse";
          } else
            this.radius_p = 1, this.radius_p2 = 1, this.radius_p_inv2 = 1, this.shape = "sphere";
          this.title || (this.title = "Geostationary Satellite View");
        },
        forward: function(t2) {
          var e2, i2, r2, s2, n2 = t2.x, a2 = t2.y;
          if (n2 -= this.long0, "ellipse" === this.shape) {
            a2 = Math.atan(this.radius_p2 * Math.tan(a2));
            var o2 = this.radius_p / Bt(this.radius_p * Math.cos(a2), Math.sin(a2));
            if (i2 = o2 * Math.cos(n2) * Math.cos(a2), r2 = o2 * Math.sin(n2) * Math.cos(a2), s2 = o2 * Math.sin(a2), (this.radius_g - i2) * i2 - r2 * r2 - s2 * s2 * this.radius_p_inv2 < 0)
              return t2.x = Number.NaN, t2.y = Number.NaN, t2;
            e2 = this.radius_g - i2, this.flip_axis ? (t2.x = this.radius_g_1 * Math.atan(r2 / Bt(s2, e2)), t2.y = this.radius_g_1 * Math.atan(s2 / e2)) : (t2.x = this.radius_g_1 * Math.atan(r2 / e2), t2.y = this.radius_g_1 * Math.atan(s2 / Bt(r2, e2)));
          } else
            "sphere" === this.shape && (e2 = Math.cos(a2), i2 = Math.cos(n2) * e2, r2 = Math.sin(n2) * e2, s2 = Math.sin(a2), e2 = this.radius_g - i2, this.flip_axis ? (t2.x = this.radius_g_1 * Math.atan(r2 / Bt(s2, e2)), t2.y = this.radius_g_1 * Math.atan(s2 / e2)) : (t2.x = this.radius_g_1 * Math.atan(r2 / e2), t2.y = this.radius_g_1 * Math.atan(s2 / Bt(r2, e2))));
          return t2.x = t2.x * this.a, t2.y = t2.y * this.a, t2;
        },
        inverse: function(t2) {
          var e2, i2, r2, s2, n2 = -1, a2 = 0, o2 = 0;
          if (t2.x = t2.x / this.a, t2.y = t2.y / this.a, "ellipse" === this.shape) {
            this.flip_axis ? (o2 = Math.tan(t2.y / this.radius_g_1), a2 = Math.tan(t2.x / this.radius_g_1) * Bt(1, o2)) : (a2 = Math.tan(t2.x / this.radius_g_1), o2 = Math.tan(t2.y / this.radius_g_1) * Bt(1, a2));
            var h2 = o2 / this.radius_p;
            if (e2 = a2 * a2 + h2 * h2 + n2 * n2, (r2 = (i2 = 2 * this.radius_g * n2) * i2 - 4 * e2 * this.C) < 0)
              return t2.x = Number.NaN, t2.y = Number.NaN, t2;
            s2 = (-i2 - Math.sqrt(r2)) / (2 * e2), n2 = this.radius_g + s2 * n2, a2 *= s2, o2 *= s2, t2.x = Math.atan2(a2, n2), t2.y = Math.atan(o2 * Math.cos(t2.x) / n2), t2.y = Math.atan(this.radius_p_inv2 * Math.tan(t2.y));
          } else if ("sphere" === this.shape) {
            if (this.flip_axis ? (o2 = Math.tan(t2.y / this.radius_g_1), a2 = Math.tan(t2.x / this.radius_g_1) * Math.sqrt(1 + o2 * o2)) : (a2 = Math.tan(t2.x / this.radius_g_1), o2 = Math.tan(t2.y / this.radius_g_1) * Math.sqrt(1 + a2 * a2)), e2 = a2 * a2 + o2 * o2 + n2 * n2, (r2 = (i2 = 2 * this.radius_g * n2) * i2 - 4 * e2 * this.C) < 0)
              return t2.x = Number.NaN, t2.y = Number.NaN, t2;
            s2 = (-i2 - Math.sqrt(r2)) / (2 * e2), n2 = this.radius_g + s2 * n2, a2 *= s2, o2 *= s2, t2.x = Math.atan2(a2, n2), t2.y = Math.atan(o2 * Math.cos(t2.x) / n2);
          }
          return t2.x = t2.x + this.long0, t2;
        },
        names: ["Geostationary Satellite View", "Geostationary_Satellite", "geos"]
      };
      gt.defaultDatum = "WGS84", gt.Proj = et, gt.WGS84 = new gt.Proj("WGS84"), gt.Point = Ot, gt.toPoint = lt, gt.defs = C, gt.nadgrid = function(t2, e2) {
        var i2 = new DataView(e2), r2 = function(t3) {
          var e3 = t3.getInt32(8, false);
          if (11 === e3)
            return false;
          11 !== (e3 = t3.getInt32(8, true)) && console.warn("Failed to detect nadgrid endian-ness, defaulting to little-endian");
          return true;
        }(i2), s2 = function(t3, e3) {
          return {
            nFields: t3.getInt32(8, e3),
            nSubgridFields: t3.getInt32(24, e3),
            nSubgrids: t3.getInt32(40, e3),
            shiftType: K(t3, 56, 64).trim(),
            fromSemiMajorAxis: t3.getFloat64(120, e3),
            fromSemiMinorAxis: t3.getFloat64(136, e3),
            toSemiMajorAxis: t3.getFloat64(152, e3),
            toSemiMinorAxis: t3.getFloat64(168, e3)
          };
        }(i2, r2);
        s2.nSubgrids > 1 && console.log("Only single NTv2 subgrids are currently supported, subsequent sub grids are ignored");
        var n2 = {
          header: s2,
          subgrids: function(t3, e3, i3) {
            for (var r3 = [], s3 = 0; s3 < e3.nSubgrids; s3++) {
              var n3 = V(t3, 176, i3), a2 = $(t3, 176, n3, i3), o2 = Math.round(1 + (n3.upperLongitude - n3.lowerLongitude) / n3.longitudeInterval), h2 = Math.round(1 + (n3.upperLatitude - n3.lowerLatitude) / n3.latitudeInterval);
              r3.push({ ll: [J(n3.lowerLongitude), J(n3.lowerLatitude)], del: [J(n3.longitudeInterval), J(n3.latitudeInterval)], lim: [o2, h2], count: n3.gridNodeCount, cvs: Q(a2) });
            }
            return r3;
          }(i2, s2, r2)
        };
        return Y[t2] = n2, n2;
      }, gt.transform = ft, gt.mgrs = vt, gt.version = "__VERSION__", (Ye = gt).Proj.projections.add(Lt), Ye.Proj.projections.add(Ft), Ye.Proj.projections.add(qt), Ye.Proj.projections.add(Zt), Ye.Proj.projections.add(Ht), Ye.Proj.projections.add(Yt), Ye.Proj.projections.add(Xt), Ye.Proj.projections.add(Jt), Ye.Proj.projections.add(Kt), Ye.Proj.projections.add(ne), Ye.Proj.projections.add(oe), Ye.Proj.projections.add(ue), Ye.Proj.projections.add(le), Ye.Proj.projections.add(ce), Ye.Proj.projections.add(fe), Ye.Proj.projections.add(de), Ye.Proj.projections.add(pe), Ye.Proj.projections.add(me), Ye.Proj.projections.add(ge), Ye.Proj.projections.add(_e), Ye.Proj.projections.add(ye), Ye.Proj.projections.add(ve), Ye.Proj.projections.add(be), Ye.Proj.projections.add(we), Ye.Proj.projections.add(Ne), Ye.Proj.projections.add(je), Ye.Proj.projections.add(Ue), Ye.Proj.projections.add(He), Ye.Proj.projections.add(Xe);
      e.default = gt;
    }
  ]);
});
class Shp2JsonLayer extends mars3d.exports.layer.GeoJsonLayer {
  load(newOptions) {
    if (newOptions) {
      if (Cesium.defaultValue(newOptions.clear, true)) {
        delete this.options.url;
        delete this.options.data;
      }
      this.clear();
      this.options = {
        ...this.options,
        ...newOptions
      };
    }
    if (this.options.url) {
      shpUtil.toGeoJSON(this.options.url, void 0, "gbk").then((data) => {
        if (this._state === mars3d.exports.State.REMOVED) {
          return;
        }
        this._load_data(data);
      }).catch(function(error) {
        console.error("\u93C8\u5D85\u59DF\u9351\u6D2A\u654A", error);
      });
    } else {
      if (newOptions) {
        console.warn("Shp2JsonLayer\u951B\u6C2D\u75C5\u93C8\u5909\u7D36\u934F\uFFFD url \u9359\u509B\u669F,\u7487\u98CE\u2018\u7481\u3086\u69F8\u935A\uFE3D\u6E41\u7487\uE218\u20AC\uFFFD");
      }
    }
  }
}
mars3d.exports.layer.Shp2JsonLayer = Shp2JsonLayer;
mars3d.exports.LayerUtil.register("kml2json", Shp2JsonLayer);
const getLayerOptions = {
  basemaps: false,
  layers: false
};
function eachGather(gather, handler) {
  Reflect.ownKeys(gather).forEach((key) => handler(gather[key], key));
}
function handlerGather(layers, mapview, handler) {
  layers.forEach((layer) => {
    const find = () => mapview.getLayer(layer.name, "name");
    const show = () => find().show = true;
    const hide = () => find().show = false;
    const clear = () => {
      const l = find();
      l.clear ? l.clear(true) : l.remove(true);
    };
    handler(layer.name, {
      id: layer.id,
      find,
      show,
      hide,
      clear,
      switch: () => find().show = !find().show
    });
  });
}
function releaseGather(layer) {
  layer.clear();
}
function useLayer(mapview) {
  const layers = unref(mapview).getLayers(getLayerOptions);
  const gather = shallowRef({});
  const setupGather = (name, layer) => {
    gather.value[name] = layer;
  };
  const setupLayer = (conf) => {
    const id = uuid();
    const layer = handlerLayerConfig({ ...conf, id });
    addLayer(layer, unref(mapview));
    handlerGather([layer], unref(mapview), setupGather);
    return layer;
  };
  const destroyLayer = () => {
    eachGather(unref(gather), releaseGather);
  };
  handlerGather(layers, unref(mapview), setupGather);
  return {
    gather,
    setupLayer,
    destroyLayer
  };
}
const point = {
  radius: 1e4
};
const line = {
  scale: 2
};
const flyOptions = {
  polylineP: line,
  water: line,
  cylinder: point,
  point
};
function useLocation(layerEntity) {
  const { find } = layerEntity;
  const layer = find();
  const lockPosition = (key) => {
    var _a;
    const target = layer.getGraphicById(key);
    if (!target)
      return;
    const { type } = target;
    const options = (_a = flyOptions[type]) != null ? _a : point;
    target.flyTo(Object.assign({}, options, {
      pitchAdjustHeight: 12e3
    }));
    target.openHighlight();
  };
  return {
    ...layerEntity,
    layer,
    lockPosition
  };
}
function useMars3dEvent(events) {
  const gather = /* @__PURE__ */ new Map();
  const bindEventType = Reflect.ownKeys(events);
  bindEventType.forEach((type) => gather.set(type, events[type]));
  function tobind(target) {
    const { type } = target;
    if (!gather.has(type))
      return;
    gather.get(type)(target);
  }
  const setupBind = (layer) => {
    layer.on(bindEventType, tobind);
  };
  const revokeBind = (layer) => {
    layer.off(bindEventType, tobind);
  };
  return {
    setupBind,
    revokeBind
  };
}
function setupShapeLabel(options) {
  const {
    text,
    textColor,
    textBgColor,
    useBgColor,
    offsetx,
    offsety
  } = options;
  return {
    text,
    clampToGround: true,
    visibleDepth: false,
    scale: 1,
    font_size: 12,
    color: textColor != null ? textColor : "#FF0033",
    backgroundColor: textBgColor != null ? textBgColor : "#DCDFE6",
    background: useBgColor != null ? useBgColor : true,
    backgroundOpacity: textColor ? 1 : 0.8,
    backgroundPadding: 6,
    hasPixelOffset: true,
    pixelOffsetX: offsetx != null ? offsetx : 0,
    pixelOffsetY: offsety != null ? offsety : -18
  };
}
const { HorizontalOrigin, VerticalOrigin } = mars3d.exports.Cesium;
function setupBillboardShape(options) {
  const { longitude, latitude, text, image } = options;
  const position = new mars3d.exports.LngLatPoint(longitude, latitude);
  const highlight = {
    scale: 0.5
  };
  const style = {
    image,
    visibleDepth: false,
    clampToGround: true,
    scale: 0.4,
    horizontalOrigin: HorizontalOrigin.CENTER,
    verticalOrigin: VerticalOrigin.BOTTOM,
    highlight
  };
  if (text)
    style.label = setupShapeLabel(options);
  return {
    position,
    style
  };
}
const Address = "/SiteInfo/getSiteInfoList";
const Method = "POST";
const ChartAddress = "/realData/getAddvcditem";
const CGartMethod = "POST";
const DetailsAddress = "/SiteInfo/getSiteInfoListByID";
const DetailsMethod = "GET";
const service = useService();
function transResponse(response) {
  const data = get(response, "data.data", []);
  return { data };
}
const OverviewSite_Server = service.define({
  url: Address,
  method: Method
});
function OverviewSite_Obtain(props) {
  OverviewSite_Server.server.config.bind("data", transFormData(props));
  return OverviewSite_Server.obtain({ transResponse });
}
const JISHUIICON = "/assets/jishui-b3a13c62.png";
const SHIPINGICON = "/assets/shiping-49879fc8.png";
const YULIANGICON = "/assets/yuliang-e0206a3d.png";
const dataOverviewDefault_vue_vue_type_style_index_0_scoped_8a8c9ec6_lang = "";
const _sfc_main$1 = {
  __name: "data-overview-default",
  setup(__props) {
    const { BillboardEntity } = mars3d.exports.graphic;
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "70%",
      template: defineComponent(() => __vitePreload(() => import("./dialog-data-overview-2560cb26.js"), true ? ["assets/js/dialog-data-overview-2560cb26.js","assets/js/index-1ea80670.js","assets/js/element-ui-a9609798.js","assets/index-ed02b285.css","assets/js/useTabs-036f428d.js","assets/js/EmptyView-301669d6.js","assets/js/usePopup-500740ad.js","assets/dialog-data-overview-25c90f57.css"] : void 0))
    });
    const tableColumn = [
      {
        prop: "stnm",
        label: "\u540D\u79F0",
        align: "center",
        width: 220
      },
      {
        prop: "sttpname",
        label: "\u7AD9\u70B9\u7C7B\u578B",
        align: "center",
        width: 150
      }
    ];
    const setupFloat = (target) => {
      const { attr } = target.graphic;
      return tableColumn.map((item) => {
        var _a;
        const { label, prop } = item;
        return {
          label,
          field: prop,
          text: (_a = attr[prop]) != null ? _a : "--"
        };
      });
    };
    function setupRoundPoint(source) {
      const { lgtd: longitude, lttd: latitude, stnm: name, stcd: id, sttp } = source;
      const ICON = {
        WP: JISHUIICON,
        VD: SHIPINGICON,
        PP: YULIANGICON
      };
      const shape = setupBillboardShape({
        longitude,
        latitude,
        image: ICON[sttp]
      });
      return new BillboardEntity({
        name,
        id,
        attr: {
          ...source,
          dialogName: "dialog-real-time-reservoir-hydrological",
          setupFloat
        },
        ...shape
      });
    }
    const { loading } = OverviewSite_Server.server;
    const tableData = computed(() => transArray(unref(OverviewSite_Server.server.result.source).data, []));
    const legendStore = useLayerLegend();
    const { mapview } = useMars3d();
    const { gather, setupLayer } = useLayer(mapview);
    const videoLayer = setupLayer({
      type: "graphic",
      name: "VideoPointLayer",
      zIndex: 101
    });
    const pondLayer = setupLayer({
      type: "graphic",
      name: "PondPointLayer",
      zIndex: 101
    });
    const rainfallLayer = setupLayer({
      type: "graphic",
      name: "RainfallPointLayer",
      zIndex: 101
    });
    const { find: videoFind, clear: videoClear } = unref(gather).VideoPointLayer;
    const videoEntity = videoFind();
    const videoPoints = computed(() => {
      const data = unref(tableData).filter((item) => item.sttp === "VD");
      return data.map(setupRoundPoint);
    });
    const { find: pondFind, clear: pondClear } = unref(gather).PondPointLayer;
    const pondEntity = pondFind();
    const pondPoints = computed(() => {
      const data = unref(tableData).filter((item) => item.sttp === "WP");
      return data.map(setupRoundPoint);
    });
    const { find: rainfallFind, clear: rainfallClear } = unref(gather).RainfallPointLayer;
    const rainfallEntity = rainfallFind();
    const rainfallPoints = computed(() => {
      const data = unref(tableData).filter((item) => item.sttp === "PP");
      return data.map(setupRoundPoint);
    });
    const { setupFloatHide, setupFloatWindow } = inject("Mars3dFloat");
    const handlerClick = (target) => {
      const { graphic } = target;
      const { attr, name } = graphic;
      popupEntity.show(attr);
      popupEntity.setupTitle(name);
      setupFloatHide();
    };
    const handlerOver = (target) => {
      var _a;
      const { graphic, startPosition } = target;
      setupFloatWindow({
        content: (_a = graphic.attr) == null ? void 0 : _a.setupFloat(target),
        ...startPosition
      });
    };
    const { setupBind } = useMars3dEvent({
      [mars3d.exports.EventType.click]: handlerClick,
      [mars3d.exports.EventType.mouseOver]: handlerOver,
      [mars3d.exports.EventType.mouseOut]: setupFloatHide
    });
    function handleRow(row) {
      const { stcd, sttp } = row;
      const entity = {
        VD: unref(gather).VideoPointLayer,
        WP: unref(gather).PondPointLayer,
        PP: unref(gather).RainfallPointLayer
      };
      if (!entity[sttp]) {
        console.warn("\u672A\u627E\u5230\u8BE5\u7C7B\u578B\u56FE\u5C42");
        return false;
      }
      const { lockPosition, layer } = useLocation(entity[sttp]);
      lockPosition(stcd);
      layer.getGraphicById(stcd).startFlicker({
        time: 20,
        maxAlpha: 0.6,
        color: mars3d.exports.Cesium.Color.WHITE,
        onEnd: function() {
        }
      });
    }
    async function executeQuery() {
      videoClear();
      pondClear();
      rainfallClear();
      await SelectSite_Obtain();
      await OverviewSite_Obtain();
      videoEntity.addGraphic(unref(videoPoints));
      pondEntity.addGraphic(unref(pondPoints));
      rainfallEntity.addGraphic(unref(rainfallPoints));
      const SHPEntity = new mars3d.exports.layer.Shp2JsonLayer({
        url: "http://data.mars3d.cn/file/shp/yuexi_point.zip",
        symbol: {
          type: "pointP",
          merge: true,
          styleOptions: {
            color: "#ff0000",
            pixelSize: 6,
            addHeight: 500
          }
        }
      });
      unref(mapview).addLayer(SHPEntity);
      legendStore.setCheckList([
        {
          keyword: "video",
          label: "\u89C6\u9891\u7AD9",
          entity: videoEntity,
          size: videoEntity.length,
          show: true,
          icon: SHIPINGICON
        },
        {
          keyword: "pond",
          label: "\u79EF\u6C34\u68C0\u6D4B",
          entity: pondEntity,
          size: pondEntity.length,
          show: true,
          icon: JISHUIICON
        },
        {
          keyword: "rainfall",
          label: "\u96E8\u91CF\u7AD9",
          entity: rainfallEntity,
          size: rainfallEntity.length,
          show: true,
          icon: YULIANGICON
        },
        {
          keyword: "history",
          label: "\u5386\u53F2\u79EF\u6C34\u70B9",
          entity: SHPEntity,
          size: "-",
          show: true,
          icon: default_legend_icon
        }
      ]);
    }
    const selectValue = ref$1([]);
    const selcetOptions = computed(() => transArray(unref(SelectSite_Server.server.result.source).data, []));
    onMounted(() => {
      setupBind(videoLayer);
      setupBind(pondLayer);
      setupBind(rainfallLayer);
      executeQuery();
    });
    onBeforeUnmount(() => {
      videoLayer.remove();
      pondLayer.remove();
      rainfallLayer.remove();
      legendStore.clearCheckList();
      popup.release(popupEntity);
    });
    return { __sfc: true, BillboardEntity, popup, popupEntity, tableColumn, setupFloat, setupRoundPoint, loading, tableData, legendStore, mapview, gather, setupLayer, videoLayer, pondLayer, rainfallLayer, videoFind, videoClear, videoEntity, videoPoints, pondFind, pondClear, pondEntity, pondPoints, rainfallFind, rainfallClear, rainfallEntity, rainfallPoints, setupFloatHide, setupFloatWindow, handlerClick, handlerOver, setupBind, handleRow, executeQuery, selectValue, selcetOptions, EventType: mars3d.exports.EventType, graphic: mars3d.exports.graphic, Cesium: mars3d.exports.Cesium, mars3d: mars3d$1, useMars3d, useLayer, useLocation, useMars3dEvent, setupBillboardShape, useLayerLegend, OverviewSite_Obtain, OverviewSite_Server, SelectSite_Obtain, SelectSite_Server, loadStyle, transArray, usePopup, JISHUIICON, SHIPINGICON, YULIANGICON, LISHIJSICON: default_legend_icon };
  }
};
var _sfc_render$1 = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "data-overview-default" }, [_c("div", { staticClass: "data-overview-default-select" }, [_c("div", { staticClass: "data-overview-default-select-label" }, [_vm._v("\u7AD9\u70B9\u7C7B\u578B:")]), _c("div", { staticClass: "data-overview-default-select-form" }, [_c("el-select", { attrs: { "size": "mini", "multiple": "", "collapse-tags": "", "placeholder": "\u8BF7\u9009\u62E9" }, model: { value: _setup.selectValue, callback: function($$v) {
    _setup.selectValue = $$v;
  }, expression: "selectValue" } }, _vm._l(_setup.selcetOptions, function(item) {
    return _c("el-option", { key: item.stcd, attrs: { "label": item.stnm, "value": item.stcd } });
  }), 1)], 1)]), _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "data-overview-default-table", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "50", "align": "center" } }), _c("el-table-column", { attrs: { "label": "\u64CD\u4F5C", "width": "100", "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "success" }, on: { "click": function($event) {
      return _setup.handlerClick({ graphic: { attr: scope.row, name: scope.row.stnm } });
    } } }, [_vm._v("\u67E5\u770B")])];
  } }]) }), _vm._l(_setup.tableColumn, function(item) {
    return [item.prop === "stnm" ? _c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
      return [_c("el-link", { attrs: { "type": "primary" }, on: { "click": function($event) {
        return _setup.handleRow(scope.row);
      } } }, [_vm._v(_vm._s(scope.row.stnm))])];
    } }], null, true) }) : _c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2)], 1);
};
var _sfc_staticRenderFns$1 = [];
var __component__$1 = /* @__PURE__ */ normalizeComponent(
  _sfc_main$1,
  _sfc_render$1,
  _sfc_staticRenderFns$1,
  false,
  null,
  "8a8c9ec6",
  null,
  null
);
const DataOverviewDefault = __component__$1.exports;
const Menu = {
  defaultID: "e7c011a06efa4db7b8514198dcbafcee",
  menu: [
    {
      id: "e7c011a06efa4db7b8514198dcbafcee",
      label: "\u6570\u636E\u603B\u89C8",
      component: DataOverviewDefault,
      render: false,
      fragment: true
    }
  ]
};
const index_vue_vue_type_style_index_0_scoped_64e0dafb_lang = "";
const _sfc_main = {
  __name: "index",
  setup(__props) {
    const Name = "data-overview-menu";
    const { menu, defaultID } = Menu;
    const active = ref$1(defaultID);
    const componentName = ref$1("");
    const setupDefaultActive = () => active.value = defaultID;
    useWatchRevert(Name, {
      setupDriver: setupDefaultActive
    });
    const handlerComponent = (cell) => {
      const { component, revert } = cell;
      componentName.value = component;
      revert && context.emit("onResolve", {
        ...cell,
        type: Name
      });
    };
    const handlerDialog = (cell) => {
    };
    return { __sfc: true, Name, menu, defaultID, active, componentName, setupDefaultActive, handlerComponent, handlerDialog, Menu, useWatchRevert };
  }
};
var _sfc_render = function render2() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("screen-grid-container", { scopedSlots: _vm._u([{ key: "head", fn: function() {
    return [_c("screen-grid-select", { attrs: { "icon": "el-icon-s-help", "active": _setup.active, "menu": _setup.menu, "width": 80 }, on: { "update:active": function($event) {
      _setup.active = $event;
    }, "toComponent": _setup.handlerComponent, "toDialog": _setup.handlerDialog }, scopedSlots: _vm._u([{ key: "default", fn: function(node) {
      return [_c("screen-grid-node", { attrs: { "node": node } })];
    } }]) })];
  }, proxy: true }, { key: "body", fn: function() {
    return [_c(_setup.componentName, { tag: "component" })];
  }, proxy: true }]) });
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "64e0dafb",
  null,
  null
);
const index = __component__.exports;
const index$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index
}, Symbol.toStringTag, { value: "Module" }));
export {
  ChartAddress as C,
  DetailsAddress as D,
  CGartMethod as a,
  DetailsMethod as b,
  index$1 as i
};
