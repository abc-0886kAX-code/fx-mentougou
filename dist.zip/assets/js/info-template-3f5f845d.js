import { t as transFormData, g as get, n as normalizeComponent, _ as __vitePreload, e as transArray, A as loadStyle } from "./index-1ea80670.js";
import { v as defineComponent, j as computed, u as unref, x as onMounted, A as onBeforeUnmount } from "./element-ui-a9609798.js";
import { u as usePopup } from "./usePopup-500740ad.js";
import { u as useService } from "./Application-7fa37401.js";
const Address = "/realData/getAddvcditem";
const Method = "POST";
const ModifyAddress = "/login";
const ModifyMethod = "POST";
const msg = "success";
const total = 3;
const code = 200;
const data = [
  {
    id: "9c48a7426cea43fba4cef4e4356f0f7d",
    gate: "h<0.15",
    warnInfo: "\u524D\u65B9\u79EF\u6C34x.xx\u7C73,\u6CE8\u610F\u5B89\u5168",
    color: "\u7EFF"
  },
  {
    id: "0cfaaab161aa4946ab26360b6857c60d",
    gate: "0.15<=h<0.4",
    warnInfo: "\u524D\u65B9\u79EF\u6C34x.xx\u7C73,\u6CE8\u610F\u5B89\u5168",
    color: "\u9EC4"
  },
  {
    id: "a22ae63851cb42b694663742f9c9490c",
    gate: "0.18<=h<0.4",
    warnInfo: "\u524D\u65B9\u79EF\u6C34x.xx\u7C73,\u6CE8\u610F\u5B89\u5168",
    color: "\u6A59"
  },
  {
    id: "fbbb9a2a260947f29e32ba2e9027dc1b",
    gate: "h>=0.4",
    warnInfo: "\u524D\u65B9\u79EF\u6C34x.xx\u7C73,\u6CE8\u610F\u5B89\u5168",
    color: "\u7EA2"
  }
];
const InfoTemplate = {
  msg,
  total,
  code,
  data
};
const service = useService();
function transResponse(response) {
  const data2 = get(InfoTemplate, "data", []);
  return { data: data2 };
}
const InfoTemplate_Server = service.define({
  url: Address,
  method: Method
});
function InfoTemplate_Obtain(props) {
  InfoTemplate_Server.server.config.bind("data", transFormData(props));
  return InfoTemplate_Server.obtain({ transResponse });
}
const infoTemplate_vue_vue_type_style_index_0_scoped_67db8bd7_lang = "";
const _sfc_main = {
  __name: "info-template",
  setup(__props) {
    const popup = usePopup();
    const popupEntity = popup.define({
      width: "40%",
      height: "50vh",
      template: defineComponent(() => __vitePreload(() => import("./dialog-info-template-5f65a17a.js"), true ? ["assets/js/dialog-info-template-5f65a17a.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/Application-7fa37401.js","assets/js/usePopup-500740ad.js","assets/dialog-info-template-03f3f2c9.css"] : void 0)),
      title: "\u4FEE\u6539",
      afterClose: executeQuery
    });
    const { loading } = InfoTemplate_Server.server;
    const tableData = computed(() => transArray(unref(InfoTemplate_Server.server.result.source).data, []));
    const tableColumn = [
      {
        prop: "gate",
        label: "\u95F8\u503C",
        align: "center",
        width: 100
      },
      {
        prop: "color",
        label: "\u989C\u8272",
        align: "center"
      },
      {
        prop: "warnInfo",
        label: "\u8B66\u793A\u4FE1\u606F",
        align: "center",
        width: 110
      }
    ];
    function handleEdit(rows) {
      popupEntity.show(rows);
    }
    async function executeQuery() {
      await InfoTemplate_Obtain();
    }
    onMounted(() => {
      executeQuery();
    });
    onBeforeUnmount(() => {
      popup.release(popupEntity);
    });
    return { __sfc: true, popup, popupEntity, loading, tableData, tableColumn, handleEdit, executeQuery, loadStyle, transArray, usePopup, InfoTemplate_Obtain, InfoTemplate_Server };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "info-template", attrs: { "size": "mini", "data": _setup.tableData, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "type": "index", "width": "50", "align": "center" } }), _c("el-table-column", { attrs: { "label": "\u64CD\u4F5C", "width": "80", "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
    return [_c("el-link", { attrs: { "type": "warning" }, on: { "click": function($event) {
      return _setup.handleEdit(scope.row);
    } } }, [_vm._v("\u4FEE\u6539")])];
  } }]) }), _vm._l(_setup.tableColumn, function(item) {
    return [_c("el-table-column", { key: item.prop, attrs: { "prop": item.prop, "label": item.label, "width": item.width, "align": item.align } })];
  })], 2);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "67db8bd7",
  null,
  null
);
const infoTemplate = __component__.exports;
const infoTemplate$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: infoTemplate
}, Symbol.toStringTag, { value: "Module" }));
export {
  ModifyAddress as M,
  ModifyMethod as a,
  infoTemplate$1 as i
};
