import { n as normalizeComponent } from "./index-1ea80670.js";
import "./element-ui-a9609798.js";
const debug_vue_vue_type_style_index_0_scoped_6780dd44_lang = "";
const _sfc_main = {
  __name: "debug",
  setup(__props) {
    function upload() {
    }
    return { __sfc: true, upload };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "debug" }, [_c("el-buttton", { on: { "click": _setup.upload } }, [_vm._v("\u4E0A\u4F20")])], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "6780dd44",
  null,
  null
);
const debug = __component__.exports;
export {
  debug as default
};
