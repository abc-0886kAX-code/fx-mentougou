import { r as ref$1, z as elementUi_common, g as getCurrentInstance, u as unref } from "./element-ui-a9609798.js";
import { t as transFormData, g as get, n as normalizeComponent, u as useUserStore, a as uuid } from "./index-1ea80670.js";
import { u as useService } from "./Application-7fa37401.js";
import { _ as __$_require_f5a5ef2e__ } from "./login-video-69570771.js";
const Address = "/login";
const Method = "POST";
const service = useService();
function transResponse(response) {
  const data = get(response, "data", {});
  return data;
}
const LOGIN_Server = service.define({
  url: Address,
  method: Method
});
function LOGIN_Obtain(props) {
  LOGIN_Server.server.config.bind("data", transFormData(props));
  return LOGIN_Server.obtain({ transResponse });
}
const login_vue_vue_type_style_index_0_scoped_35c5eb1d_lang = "";
const _sfc_main = {
  __name: "login",
  setup(__props) {
    const user = useUserStore();
    const { proxy } = getCurrentInstance();
    const loginForm = ref$1(null);
    const { loading } = LOGIN_Server.server;
    const form = ref$1({
      username: "",
      userpwd: ""
    });
    const rules = {
      username: [
        {
          required: true,
          message: "\u8D26\u53F7\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ],
      password: [
        {
          required: true,
          message: "\u5BC6\u7801\u4E0D\u53EF\u4E3A\u7A7A",
          trigger: "blur"
        }
      ]
    };
    function onSubmit() {
      unref(loginForm).validate(async (valid) => {
        if (!valid)
          return;
        const data = await LOGIN_Obtain(unref(form));
        if (data.code === 200) {
          user.setupToken(data.data.token);
          user.setupTruename(data.data.truename);
          user.setupUserPower(data.data.layers);
          elementUi_common.exports.Notification.success({
            title: "\u6210\u529F!",
            message: "\u767B\u5F55\u6210\u529F!"
          });
          proxy.$router.push({ name: "home" });
        } else {
          elementUi_common.exports.Notification.error({
            title: "\u9519\u8BEF!",
            message: data.msg
          });
        }
      });
    }
    return { __sfc: true, user, proxy, loginForm, loading, form, rules, onSubmit, uuid, Notification: elementUi_common.exports.Notification, useUserStore, LOGIN_Server, LOGIN_Obtain };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "ytxd-login" }, [_c("video", { attrs: { "id": "v1", "autoplay": "", "loop": "", "muted": "" }, domProps: { "muted": true } }, [_c("source", { attrs: { "src": __$_require_f5a5ef2e__, "type": "video/mp4" } })]), _vm._m(0), _c("div", { staticClass: "login-body" }, [_c("h3", [_vm._v("\u5E94\u7528\u5E73\u53F0\u767B\u5F55")]), _c("el-form", { ref: "loginForm", staticClass: "login-box", attrs: { "model": _setup.form, "rules": _setup.rules }, nativeOn: { "submit": function($event) {
    $event.preventDefault();
  } } }, [_c("el-form-item", { attrs: { "prop": "username" } }, [_c("el-input", { staticClass: "login-input", attrs: { "type": "text", "prefix-icon": "el-icon-user", "placeholder": "\u8BF7\u8F93\u5165\u8D26\u53F7" }, nativeOn: { "keyup": function($event) {
    if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter"))
      return null;
    return _setup.onSubmit("loginForm");
  } }, model: { value: _setup.form.username, callback: function($$v) {
    _vm.$set(_setup.form, "username", $$v);
  }, expression: "form.username" } })], 1), _c("el-form-item", { attrs: { "prop": "userpwd" } }, [_c("el-input", { staticClass: "login-input", attrs: { "type": "password", "prefix-icon": "el-icon-lock", "placeholder": "\u8BF7\u8F93\u5165\u5BC6\u7801" }, nativeOn: { "keyup": function($event) {
    if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter"))
      return null;
    return _setup.onSubmit("loginForm");
  } }, model: { value: _setup.form.userpwd, callback: function($$v) {
    _vm.$set(_setup.form, "userpwd", $$v);
  }, expression: "form.userpwd" } })], 1), _c("el-button", { staticClass: "login-button", attrs: { "type": "primary", "loading": _setup.loading }, on: { "click": function($event) {
    return _setup.onSubmit("loginForm");
  } } }, [_vm._v("\u767B\u5F55 ")])], 1)], 1)]);
};
var _sfc_staticRenderFns = [function() {
  var _vm = this, _c = _vm._self._c;
  _vm._self._setupProxy;
  return _c("div", { staticClass: "login-head" }, [_c("h1", [_vm._v("\u95E8\u5934\u6C9F\u533A\u4E0B\u51F9\u5F0F\u7ACB\u4EA4\u6865\u79EF\u6C34\u70B9\u667A\u80FD\u8B66\u793A\u7CFB\u7EDF")])]);
}];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "35c5eb1d",
  null,
  null
);
const login = __component__.exports;
export {
  login as default
};
