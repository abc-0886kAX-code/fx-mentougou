import { w as defineStore } from "./index-1ea80670.js";
const Namespace = "useLayerLegend";
const useLayerLegend = defineStore(Namespace, {
  state: () => ({
    checkList: [],
    group: []
  }),
  getters: {
    isHasLayer() {
      return this.group.length > 0;
    }
  },
  actions: {
    setCheckList(layer) {
      this.group = layer;
    },
    clearCheckList() {
      this.group = [];
    }
  }
});
const default_legend_icon = "/assets/default_legend_icon-ae2b8ff3.png";
export {
  default_legend_icon as d,
  useLayerLegend as u
};
