import { j as computed, u as unref, x as onMounted } from "./element-ui-a9609798.js";
import { u as useDialog } from "./useDialog-4005c8b0.js";
import { n as normalizeComponent, D as transObject, A as loadStyle } from "./index-1ea80670.js";
import { C as ChartData_Server, a as ChartData_Obtain } from "./chart-a8297dd0.js";
import "./index-4cdc94bd.js";
import "./Application-7fa37401.js";
const dataTable_vue_vue_type_style_index_0_scoped_05ae5de3_lang = "";
const _sfc_main = {
  __name: "data-table",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { loading } = ChartData_Server.server;
    const source = computed(
      () => transObject(unref(ChartData_Server.server.result.source).data, {
        tableColumn: [],
        tableRows: []
      })
    );
    const dialog = useDialog(props.popupKeyword);
    const config = computed(() => unref(dialog.config));
    async function executeQuery() {
      await ChartData_Obtain(unref(config));
    }
    const max = [
      {
        stnm: "\u6D4B\u8BD5\u7AD9\u70B9",
        max: "20"
      },
      {
        stnm: "\u6D4B\u8BD5\u7AD9\u70B91",
        max: "20"
      },
      {
        stnm: "\u6D4B\u8BD5\u7AD9\u70B92",
        max: "20"
      }
    ];
    onMounted(() => {
      executeQuery();
    });
    return { __sfc: true, loading, source, props, dialog, config, executeQuery, max, useDialog, loadStyle, ChartData_Server, ChartData_Obtain, transObject };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "data-table" }, [_c("div", { staticClass: "data-table-console" }, [_c("div", { staticClass: "data-table-console-info" }, [_c("span", [_vm._v("\u6700\u5927\u503C\uFF1A")]), _vm._l(_setup.max, function(item, index) {
    return _c("div", { key: index, staticClass: "data-table-console-info-item" }, [_vm._v(_vm._s(item.stnm) + "\uFF1A" + _vm._s(item.max))]);
  })], 2), _c("el-button", { attrs: { "type": "primary", "size": "mini" } }, [_vm._v("\u5BFC\u51FA"), _c("i", { staticClass: "el-icon-upload el-icon--right" })])], 1), _c("el-table", _vm._b({ directives: [{ name: "loading", rawName: "v-loading", value: _setup.loading, expression: "loading" }], staticClass: "data-table-body", attrs: { "size": "mini", "data": _setup.source.tableRows, "width": "100%", "height": "100%" } }, "el-table", _setup.loadStyle, false), [_c("el-table-column", { attrs: { "width": "150", "prop": "tm", "align": "center" } }), _vm._l(_setup.source.tableColumn, function(item, index) {
    return [_c("el-table-column", { key: index, attrs: { "label": item.stnm, "align": "center" }, scopedSlots: _vm._u([{ key: "default", fn: function(scope) {
      return [_vm._v(_vm._s(scope.row[item.columnkey]))];
    } }], null, true) })];
  })], 2)], 1);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "05ae5de3",
  null,
  null
);
const dataTable = __component__.exports;
export {
  dataTable as default
};
