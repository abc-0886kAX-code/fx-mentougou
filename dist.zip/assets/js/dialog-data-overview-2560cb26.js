import { n as normalizeComponent, _ as __vitePreload } from "./index-1ea80670.js";
import { u as useTabs } from "./useTabs-036f428d.js";
import "./element-ui-a9609798.js";
import "./EmptyView-301669d6.js";
import "./usePopup-500740ad.js";
const dialogDataOverview_vue_vue_type_style_index_0_scoped_c82a650e_lang = "";
const _sfc_main = {
  __name: "dialog-data-overview",
  props: {
    popupKeyword: String
  },
  setup(__props) {
    const props = __props;
    const { active, component, dataset, update } = useTabs({
      data: [
        {
          keyword: "data-overview",
          label: "\u6570\u636E\u603B\u89C8",
          template: () => __vitePreload(() => import("./data-overview-b2447e05.js"), true ? ["assets/js/data-overview-b2447e05.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/login-video-69570771.js","assets/js/header-video-fd1f6550.js","assets/data-overview-3fc2224f.css"] : void 0)
        },
        {
          keyword: "data-chart",
          label: "\u6570\u636E\u56FE\u8868",
          template: () => __vitePreload(() => import("./data-chart-8ba32dad.js"), true ? ["assets/js/data-chart-8ba32dad.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/chart-b8a62d2a.js","assets/js/index-9706d3fe.js","assets/js/useMars3D-c560a623.js","assets/js/default_legend_icon-fcdb82ea.js","assets/js/Application-7fa37401.js","assets/js/index-4cdc94bd.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-e195207d.css","assets/js/useDate-287f32d4.js","assets/data-chart-52ead39a.css"] : void 0)
        },
        {
          keyword: "data-table",
          label: "\u6570\u636E\u8868\u683C",
          template: () => __vitePreload(() => import("./data-table-4bef4ff4.js"), true ? ["assets/js/data-table-4bef4ff4.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/useDate-287f32d4.js","assets/js/chart-b8a62d2a.js","assets/js/index-9706d3fe.js","assets/js/useMars3D-c560a623.js","assets/js/default_legend_icon-fcdb82ea.js","assets/js/Application-7fa37401.js","assets/js/index-4cdc94bd.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-e195207d.css","assets/data-table-c5c28131.css"] : void 0)
        },
        {
          keyword: "data-info",
          label: "\u7AD9\u70B9\u4FE1\u606F",
          template: () => __vitePreload(() => import("./data-info-e5ffb43d.js"), true ? ["assets/js/data-info-e5ffb43d.js","assets/js/element-ui-a9609798.js","assets/js/useDialog-4005c8b0.js","assets/js/index-1ea80670.js","assets/index-ed02b285.css","assets/js/index-9706d3fe.js","assets/js/useMars3D-c560a623.js","assets/js/default_legend_icon-fcdb82ea.js","assets/js/Application-7fa37401.js","assets/js/index-4cdc94bd.js","assets/js/usePopup-500740ad.js","assets/js/useWatchRevert-58689033.js","assets/index-e195207d.css","assets/data-info-dfcbdaeb.css"] : void 0)
        }
      ]
    });
    function tabClick(entity) {
      update({ keyword: entity.name });
    }
    return { __sfc: true, props, active, component, dataset, update, tabClick, useTabs };
  }
};
var _sfc_render = function render() {
  var _vm = this, _c = _vm._self._c, _setup = _vm._self._setupProxy;
  return _c("div", { staticClass: "dialog-data-overview" }, [_c("div", { staticClass: "dialog-data-overview-head" }, [_c("el-tabs", { attrs: { "value": _setup.active, "type": "card" }, on: { "tab-click": _setup.tabClick } }, [_vm._l(_setup.dataset, function(entity) {
    return [_c("el-tab-pane", { key: entity.keyword, attrs: { "label": entity.label, "name": entity.keyword } })];
  })], 2)], 1), _c("div", { staticClass: "dialog-data-overview-body" }, [_c(_setup.component, { key: _setup.active, tag: "components", attrs: { "popupKeyword": _setup.props.popupKeyword } })], 1)]);
};
var _sfc_staticRenderFns = [];
var __component__ = /* @__PURE__ */ normalizeComponent(
  _sfc_main,
  _sfc_render,
  _sfc_staticRenderFns,
  false,
  null,
  "c82a650e",
  null,
  null
);
const dialogDataOverview = __component__.exports;
export {
  dialogDataOverview as default
};
